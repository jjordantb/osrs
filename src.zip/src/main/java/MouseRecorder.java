public class MouseRecorder implements Runnable {
   static int[] field505;
   int[] ys = new int[500];
   int index = 0;
   boolean isRunning = true;
   long[] millis = new long[500];
   int[] xs = new int[500];
   Object lock = new Object();

   public void run() {
      for(; this.isRunning; class276.method5382(50L)) {
         Object var1 = this.lock;
         synchronized(this.lock) {
            if (this.index < 500) {
               this.xs[this.index] = MouseHandler.field154;
               this.ys[this.index] = MouseHandler.field145 * -976212263;
               this.millis[this.index] = MouseHandler.field153;
               ++this.index;
            }
         }
      }

   }

   static final void method1007(TaskDataNode var0) {
      var0.field1560 = false;
      if (var0.field1557 != null) {
         var0.field1557.integer = 0;
      }

      for(TaskDataNode var1 = var0.vmethod4628(); var1 != null; var1 = var0.vmethod4630()) {
         method1007(var1);
      }

   }

   public static void method1008(AbstractIndexCache var0, AbstractIndexCache var1, AbstractIndexCache var2) {
      SequenceDefinition.field3479 = var0;
      SequenceDefinition.field3464 = var1;
      SequenceDefinition.field3465 = var2;
   }

   static final void method1009(String var0, boolean var1) {
      if (Client.field2201) {
         byte var2 = 4;
         int var3 = var2 + 6;
         int var4 = var2 + 6;
         int var5 = TotalQuantityComparator.field982.lineWidth(var0, 250);
         int var6 = TotalQuantityComparator.field982.lineCount(var0, 250) * 13;
         Rasterizer2D.method6223(var3 - var2, var4 - var2, var2 + var5 + var2, var2 + var6 + var2, 0);
         Rasterizer2D.method6292(var3 - var2, var4 - var2, var5 + var2 + var2, var2 + var2 + var6, 16777215);
         TotalQuantityComparator.field982.drawLines(var0, var3, var4, var5, var6, 16777215, -1, 1, 1, 0);
         int var7 = var3 - var2;
         int var8 = var4 - var2;
         int var9 = var2 + var5 + var2;
         int var10 = var2 + var6 + var2;

         for(int var11 = 0; var11 < Client.field2296; ++var11) {
            if (Client.field2262[var11] + Client.field2206[var11] > var7 && Client.field2206[var11] < var9 + var7 && Client.field2297[var11] + Client.field2295[var11] > var8 && Client.field2295[var11] < var8 + var10) {
               Client.field2291[var11] = true;
            }
         }

         if (var1) {
            WorldMapManager.field45.drawFull(0, 0);
         } else {
            Varps.method4667(var3, var4, var5, var6);
         }

      }
   }
}
