public class class73 {
   static int field854;
   static Task field857;
   static Widget field855;
   int field859;
   TileLocation field860;

   class73(int var1, TileLocation var2) {
      this.field859 = var1;
      this.field860 = var2;
   }

   static final void method1483() {
      if (class31.field363 != Client.field2104) {
         Client.field2104 = class31.field363;
         int var0 = class31.field363;
         int[] var1 = TotalQuantityComparator.field986.pixels;
         int var2 = var1.length;

         int var3;
         for(var3 = 0; var3 < var2; ++var3) {
            var1[var3] = 0;
         }

         int var4;
         int var5;
         for(var3 = 1; var3 < 103; ++var3) {
            var4 = (103 - var3) * 2048 + 24628;

            for(var5 = 1; var5 < 103; ++var5) {
               if ((Tiles.field203[var0][var5][var3] & 24) == 0) {
                  class243.field2904.drawTileMinimap(var1, var4, 512, var0, var5, var3);
               }

               if (var0 < 3 && (Tiles.field203[var0 + 1][var5][var3] & 8) != 0) {
                  class243.field2904.drawTileMinimap(var1, var4, 512, var0 + 1, var5, var3);
               }

               var4 += 4;
            }
         }

         var3 = (238 + (int)(Math.random() * 20.0D) - 10 << 16) + (238 + (int)(Math.random() * 20.0D) - 10 << 8) + (238 + (int)(Math.random() * 20.0D) - 10);
         var4 = 238 + (int)(Math.random() * 20.0D) - 10 << 16;
         TotalQuantityComparator.field986.method6339();

         int var6;
         for(var5 = 1; var5 < 103; ++var5) {
            for(var6 = 1; var6 < 103; ++var6) {
               if ((Tiles.field203[var0][var6][var5] & 24) == 0) {
                  GameObject.method2902(var0, var6, var5, var3, var4);
               }

               if (var0 < 3 && (Tiles.field203[var0 + 1][var6][var5] & 8) != 0) {
                  GameObject.method2902(var0 + 1, var6, var5, var3, var4);
               }
            }
         }

         Client.field2263 = 0;

         for(var5 = 0; var5 < 104; ++var5) {
            for(var6 = 0; var6 < 104; ++var6) {
               long var7 = class243.field2904.getFloorDecorationTag(class31.field363, var5, var6);
               if (var7 != 0L) {
                  int var9 = WidgetGroupParent.method1000(var7);
                  int var10 = class252.method4958(var9).mapIconId;
                  if (var10 >= 0) {
                     Client.field2316[Client.field2263] = Clock.mark(var10).getSprite(false);
                     Client.field2314[Client.field2263] = var5;
                     Client.field2315[Client.field2263] = var6;
                     ++Client.field2263;
                  }
               }
            }
         }

         WorldMapManager.field45.apply();
      }

   }

   static final void method1484(int var0, int var1, int var2, int var3) {
      Client.field2123 = 0;
      int var4 = (ObjectSound.field589.x >> 7) + class21.field230;
      int var5 = (ObjectSound.field589.y >> 7) + class79.field902;
      if (var4 >= 3053 && var4 <= 3156 && var5 >= 3056 && var5 <= 3136) {
         Client.field2123 = 1;
      }

      if (var4 >= 3072 && var4 <= 3118 && var5 >= 9492 && var5 <= 9535) {
         Client.field2123 = 1;
      }

      if (Client.field2123 == 1 && var4 >= 3139 && var4 <= 3199 && var5 >= 3008 && var5 <= 3062) {
         Client.field2123 = 0;
      }

   }

   static final void method1482(Widget var0, ItemDefinition var1, int var2, int var3, boolean var4) {
      String[] var5 = var1.inventoryActions;
      byte var6 = -1;
      String var7 = null;
      if (var5 != null && var5[var3] != null) {
         if (var3 == 0) {
            var6 = 33;
         } else if (var3 == 1) {
            var6 = 34;
         } else if (var3 == 2) {
            var6 = 35;
         } else if (var3 == 3) {
            var6 = 36;
         } else {
            var6 = 37;
         }

         var7 = var5[var3];
      } else if (var3 == 4) {
         var6 = 37;
         var7 = "Drop";
      }

      if (var6 != -1 && var7 != null) {
         Bzip2State.method3887(var7, ModelData0.method2792(16748608) + var1.name, var6, var1.id, var2, var0.id, var4);
      }

   }
}
