import java.io.EOFException;
import java.io.IOException;

public class BufferedFile {
   static IndexedSprite[] field1424;
   static AbstractSocket field1423;
   static byte[][] field1421;
   int field1417 = 0;
   byte[] writeBuffer;
   long field1413 = -1L;
   AccessFile accessFile;
   long capacity;
   long field1419 = -1L;
   long field1422;
   long field1418;
   int field1414;
   byte[] readBuffer;
   long field1411;

   public BufferedFile(AccessFile var1, int var2, int var3) throws IOException {
      this.accessFile = var1;
      this.capacity = this.field1422 = var1.length();
      this.readBuffer = new byte[var2];
      this.writeBuffer = new byte[var3];
      this.field1411 = 0L;
   }

   public void read(byte[] var1, int var2, int var3) throws IOException {
      try {
         if (var3 + var2 > var1.length) {
            throw new ArrayIndexOutOfBoundsException(var3 + var2 - var1.length);
         }

         if (-1L != this.field1419 && this.field1411 >= this.field1419 && (long)var3 + this.field1411 <= this.field1419 + (long)this.field1417) {
            System.arraycopy(this.writeBuffer, (int)(this.field1411 - this.field1419), var1, var2, var3);
            this.field1411 += (long)var3;
            return;
         }

         long var4 = this.field1411;
         int var7 = var3;
         int var8;
         if (this.field1411 >= this.field1413 && this.field1411 < this.field1413 + (long)this.field1414) {
            var8 = (int)((long)this.field1414 - (this.field1411 - this.field1413));
            if (var8 > var3) {
               var8 = var3;
            }

            System.arraycopy(this.readBuffer, (int)(this.field1411 - this.field1413), var1, var2, var8);
            this.field1411 += (long)var8;
            var2 += var8;
            var3 -= var8;
         }

         if (var3 > this.readBuffer.length) {
            this.accessFile.seek(this.field1411);

            for(this.field1418 = this.field1411; var3 > 0; var3 -= var8) {
               var8 = this.accessFile.read(var1, var2, var3);
               if (var8 == -1) {
                  break;
               }

               this.field1418 += (long)var8;
               this.field1411 += (long)var8;
               var2 += var8;
            }
         } else if (var3 > 0) {
            this.load();
            var8 = var3;
            if (var3 > this.field1414) {
               var8 = this.field1414;
            }

            System.arraycopy(this.readBuffer, 0, var1, var2, var8);
            var2 += var8;
            var3 -= var8;
            this.field1411 += (long)var8;
         }

         if (this.field1419 != -1L) {
            if (this.field1419 > this.field1411 && var3 > 0) {
               var8 = var2 + (int)(this.field1419 - this.field1411);
               if (var8 > var3 + var2) {
                  var8 = var3 + var2;
               }

               while(var2 < var8) {
                  var1[var2++] = 0;
                  --var3;
                  ++this.field1411;
               }
            }

            long var13 = -1L;
            long var10 = -1L;
            if (this.field1419 >= var4 && this.field1419 < var4 + (long)var7) {
               var13 = this.field1419;
            } else if (var4 >= this.field1419 && var4 < this.field1419 + (long)this.field1417) {
               var13 = var4;
            }

            if ((long)this.field1417 + this.field1419 > var4 && (long)this.field1417 + this.field1419 <= (long)var7 + var4) {
               var10 = (long)this.field1417 + this.field1419;
            } else if ((long)var7 + var4 > this.field1419 && (long)var7 + var4 <= (long)this.field1417 + this.field1419) {
               var10 = (long)var7 + var4;
            }

            if (var13 > -1L && var10 > var13) {
               int var12 = (int)(var10 - var13);
               System.arraycopy(this.writeBuffer, (int)(var13 - this.field1419), var1, (int)(var13 - var4) + var2, var12);
               if (var10 > this.field1411) {
                  var3 = (int)((long)var3 - (var10 - this.field1411));
                  this.field1411 = var10;
               }
            }
         }
      } catch (IOException var16) {
         this.field1418 = -1L;
         throw var16;
      }

      if (var3 > 0) {
         throw new EOFException();
      }
   }

   public long length() {
      return this.capacity;
   }

   public void close() throws IOException {
      this.flush();
      this.accessFile.close();
   }

   void load() throws IOException {
      this.field1414 = 0;
      if (this.field1418 != this.field1411) {
         this.accessFile.seek(this.field1411);
         this.field1418 = this.field1411;
      }

      int var1;
      for(this.field1413 = this.field1411; this.field1414 < this.readBuffer.length; this.field1414 += var1) {
         var1 = this.accessFile.read(this.readBuffer, this.field1414, this.readBuffer.length - this.field1414);
         if (var1 == -1) {
            break;
         }

         this.field1418 += (long)var1;
      }

   }

   void flush() throws IOException {
      if (this.field1419 != -1L) {
         if (this.field1418 != this.field1419) {
            this.accessFile.seek(this.field1419);
            this.field1418 = this.field1419;
         }

         this.accessFile.write(this.writeBuffer, 0, this.field1417);
         this.field1418 += (long)(this.field1417 * 136693003) * -239280477L;
         if (this.field1418 > this.field1422) {
            this.field1422 = this.field1418;
         }

         long var1 = -1L;
         long var3 = -1L;
         if (this.field1419 >= this.field1413 && this.field1419 < this.field1413 + (long)this.field1414) {
            var1 = this.field1419;
         } else if (this.field1413 >= this.field1419 && this.field1413 < this.field1419 + (long)this.field1417) {
            var1 = this.field1413;
         }

         if ((long)this.field1417 + this.field1419 > this.field1413 && this.field1419 + (long)this.field1417 <= (long)this.field1414 + this.field1413) {
            var3 = (long)this.field1417 + this.field1419;
         } else if (this.field1413 + (long)this.field1414 > this.field1419 && this.field1413 + (long)this.field1414 <= (long)this.field1417 + this.field1419) {
            var3 = (long)this.field1414 + this.field1413;
         }

         if (var1 > -1L && var3 > var1) {
            int var5 = (int)(var3 - var1);
            System.arraycopy(this.writeBuffer, (int)(var1 - this.field1419), this.readBuffer, (int)(var1 - this.field1413), var5);
         }

         this.field1419 = -1L;
         this.field1417 = 0;
      }

   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      try {
         if ((long)var3 + this.field1411 > this.capacity) {
            this.capacity = this.field1411 + (long)var3;
         }

         if (-1L != this.field1419 && (this.field1411 < this.field1419 || this.field1411 > (long)this.field1417 + this.field1419)) {
            this.flush();
         }

         if (-1L != this.field1419 && (long)var3 + this.field1411 > this.field1419 + (long)this.writeBuffer.length) {
            int var4 = (int)((long)this.writeBuffer.length - (this.field1411 - this.field1419));
            System.arraycopy(var1, var2, this.writeBuffer, (int)(this.field1411 - this.field1419), var4);
            this.field1411 += (long)var4;
            var2 += var4;
            var3 -= var4;
            this.field1417 = this.writeBuffer.length;
            this.flush();
         }

         if (var3 <= this.writeBuffer.length) {
            if (var3 > 0) {
               if (-1L == this.field1419) {
                  this.field1419 = this.field1411;
               }

               System.arraycopy(var1, var2, this.writeBuffer, (int)(this.field1411 - this.field1419), var3);
               this.field1411 += (long)var3;
               if (this.field1411 - this.field1419 > (long)this.field1417) {
                  this.field1417 = (int)(this.field1411 - this.field1419);
               }

            }
         } else {
            if (this.field1411 != this.field1418) {
               this.accessFile.seek(this.field1411);
               this.field1418 = this.field1411;
            }

            this.accessFile.write(var1, var2, var3);
            this.field1418 += (long)var3;
            if (this.field1418 > this.field1422) {
               this.field1422 = this.field1418;
            }

            long var9 = -1L;
            long var6 = -1L;
            if (this.field1411 >= this.field1413 && this.field1411 < (long)this.field1414 + this.field1413) {
               var9 = this.field1411;
            } else if (this.field1413 >= this.field1411 && this.field1413 < this.field1411 + (long)var3) {
               var9 = this.field1413;
            }

            if ((long)var3 + this.field1411 > this.field1413 && this.field1411 + (long)var3 <= this.field1413 + (long)this.field1414) {
               var6 = (long)var3 + this.field1411;
            } else if (this.field1413 + (long)this.field1414 > this.field1411 && (long)this.field1414 + this.field1413 <= (long)var3 + this.field1411) {
               var6 = this.field1413 + (long)this.field1414;
            }

            if (var9 > -1L && var6 > var9) {
               int var8 = (int)(var6 - var9);
               System.arraycopy(var1, (int)(var9 + (long)var2 - this.field1411), this.readBuffer, (int)(var9 - this.field1413), var8);
            }

            this.field1411 += (long)var3;
         }
      } catch (IOException var12) {
         this.field1418 = -1L;
         throw var12;
      }
   }

   public void readFill(byte[] var1) throws IOException {
      this.read(var1, 0, var1.length);
   }

   public void seek(long var1) throws IOException {
      if (var1 < 0L) {
         throw new IOException("");
      } else {
         this.field1411 = var1;
      }
   }

   public static RunException seek(Throwable var0, String var1) {
      RunException var2;
      if (var0 instanceof RunException) {
         var2 = (RunException)var0;
         var2.string = var2.string + ' ' + var1;
      } else {
         var2 = new RunException(var0, var1);
      }

      return var2;
   }

   static void method2589(int var0) {
      if (var0 == -3) {
         ByteArrayPool.method4250("Connection timed out.", "Please try using a different world.", "");
      } else if (var0 == -2) {
         ByteArrayPool.method4250("", "Error connecting to server.", "");
      } else if (var0 == -1) {
         ByteArrayPool.method4250("No response from server.", "Please try using a different world.", "");
      } else if (var0 == 3) {
         Login.field669 = 3;
         Login.field667 = 1;
      } else if (var0 == 4) {
         Login.field669 = 12;
         Login.field648 = 0;
      } else if (var0 == 5) {
         Login.field667 = 2;
         ByteArrayPool.method4250("Your account has not logged out from its last", "session or the server is too busy right now.", "Please try again in a few minutes.");
      } else if (var0 == 6 || !Client.field2213 && var0 == 68) {
         ByteArrayPool.method4250("RuneScape has been updated!", "Please reload this page.", "");
      } else if (var0 == 7) {
         ByteArrayPool.method4250("This world is full.", "Please use a different world.", "");
      } else if (var0 == 8) {
         ByteArrayPool.method4250("Unable to connect.", "Login server offline.", "");
      } else if (var0 == 9) {
         ByteArrayPool.method4250("Login limit exceeded.", "Too many connections from your address.", "");
      } else if (var0 == 10) {
         ByteArrayPool.method4250("Unable to connect.", "Bad session id.", "");
      } else if (var0 == 11) {
         ByteArrayPool.method4250("We suspect someone knows your password.", "Press 'change your password' on front page.", "");
      } else if (var0 == 12) {
         ByteArrayPool.method4250("You need a members account to login to this world.", "Please subscribe, or use a different world.", "");
      } else if (var0 == 13) {
         ByteArrayPool.method4250("Could not complete login.", "Please try using a different world.", "");
      } else if (var0 == 14) {
         ByteArrayPool.method4250("The server is being updated.", "Please wait 1 minute and try again.", "");
      } else if (var0 == 16) {
         ByteArrayPool.method4250("Too many login attempts.", "Please wait a few minutes before trying again.", "");
      } else if (var0 == 17) {
         ByteArrayPool.method4250("You are standing in a members-only area.", "To play on this world move to a free area first", "");
      } else if (var0 == 18) {
         Login.field669 = 12;
         Login.field648 = 1;
      } else if (var0 == 19) {
         ByteArrayPool.method4250("This world is running a closed Beta.", "Sorry invited players only.", "Please use a different world.");
      } else if (var0 == 20) {
         ByteArrayPool.method4250("Invalid loginserver requested.", "Please try using a different world.", "");
      } else if (var0 == 22) {
         ByteArrayPool.method4250("Malformed login packet.", "Please try again.", "");
      } else if (var0 == 23) {
         ByteArrayPool.method4250("No reply from loginserver.", "Please wait 1 minute and try again.", "");
      } else if (var0 == 24) {
         ByteArrayPool.method4250("Error loading your profile.", "Please contact customer support.", "");
      } else if (var0 == 25) {
         ByteArrayPool.method4250("Unexpected loginserver response.", "Please try using a different world.", "");
      } else if (var0 == 26) {
         ByteArrayPool.method4250("This computers address has been blocked", "as it was used to break our rules.", "");
      } else if (var0 == 27) {
         ByteArrayPool.method4250("", "Service unavailable.", "");
      } else if (var0 == 31) {
         ByteArrayPool.method4250("Your account must have a displayname set", "in order to play the game.  Please set it", "via the website, or the main game.");
      } else if (var0 == 32) {
         ByteArrayPool.method4250("Your attempt to log into your account was", "unsuccessful.  Don't worry, you can sort", "this out by visiting the billing system.");
      } else if (var0 == 37) {
         ByteArrayPool.method4250("Your account is currently inaccessible.", "Please try again in a few minutes.", "");
      } else if (var0 == 38) {
         ByteArrayPool.method4250("You need to vote to play!", "Visit runescape.com and vote,", "and then come back here!");
      } else if (var0 == 55) {
         Login.field669 = 8;
      } else {
         if (var0 == 56) {
            ByteArrayPool.method4250("Enter the 6-digit code generated by your", "authenticator app.", "");
            class69.method1443(11);
            return;
         }

         if (var0 == 57) {
            ByteArrayPool.method4250("The code you entered was incorrect.", "Please try again.", "");
            class69.method1443(11);
            return;
         }

         if (var0 == 61) {
            Login.field669 = 7;
         } else {
            ByteArrayPool.method4250("Unexpected server response", "Please try using a different world.", "");
         }
      }

      class69.method1443(10);
   }
}
