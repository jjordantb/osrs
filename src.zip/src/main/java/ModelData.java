public class ModelData extends Entity {
   static int[] field1502;
   static int[] field1498 = new int[10000];
   static int[] field1499 = new int[10000];
   static int[] field1464;
   static int field1496 = 0;
   int field1494;
   int field1493;
   VertexNormal[] field1489;
   int field1497;
   int field1478;
   public short field1490;
   boolean isBoundsCalculated = false;
   public short field1491;
   int field1482;
   short[] field1481;
   int[] indices2;
   int faceCount = 0;
   short[] faceColors;
   int[] verticesY;
   short[] field1480;
   int verticesCount = 0;
   byte[] field1465;
   byte[] field1472;
   short[] faceTextures;
   int[] field1483;
   int[] indices1;
   byte[] field1500;
   byte[] field1471;
   VertexNormal[] field1501;
   byte[] faceAlphas;
   int[] verticesZ;
   int[] verticesX;
   int[][] vertexLabels;
   short[] field1463;
   FaceNormal[] faceNormals;
   int field1487;
   int[] indices3;
   byte field1477 = 0;
   int[][] faceLabelsAlpha;
   int[] field1484;

   static {
      field1464 = Rasterizer3D.field1446;
      field1502 = Rasterizer3D.field1453;
   }

   ModelData() {
   }

   public ModelData(ModelData[] var1, int var2) {
      boolean var3 = false;
      boolean var4 = false;
      boolean var5 = false;
      boolean var6 = false;
      boolean var7 = false;
      boolean var8 = false;
      this.verticesCount = 0;
      this.faceCount = 0;
      this.field1487 = 0;
      this.field1477 = -1;

      int var9;
      ModelData var10;
      for(var9 = 0; var9 < var2; ++var9) {
         var10 = var1[var9];
         if (var10 != null) {
            this.verticesCount += var10.verticesCount;
            this.faceCount += var10.faceCount;
            this.field1487 += var10.field1487;
            if (var10.field1472 != null) {
               var4 = true;
            } else {
               if (this.field1477 == -1) {
                  this.field1477 = var10.field1477;
               }

               if (this.field1477 != var10.field1477) {
                  var4 = true;
               }
            }

            var3 |= var10.field1471 != null;
            var5 |= var10.faceAlphas != null;
            var6 |= var10.field1484 != null;
            var7 |= var10.faceTextures != null;
            var8 |= var10.field1500 != null;
         }
      }

      this.verticesX = new int[this.verticesCount];
      this.verticesY = new int[this.verticesCount];
      this.verticesZ = new int[this.verticesCount];
      this.field1483 = new int[this.verticesCount];
      this.indices1 = new int[this.faceCount];
      this.indices2 = new int[this.faceCount];
      this.indices3 = new int[this.faceCount];
      if (var3) {
         this.field1471 = new byte[this.faceCount];
      }

      if (var4) {
         this.field1472 = new byte[this.faceCount];
      }

      if (var5) {
         this.faceAlphas = new byte[this.faceCount];
      }

      if (var6) {
         this.field1484 = new int[this.faceCount];
      }

      if (var7) {
         this.faceTextures = new short[this.faceCount];
      }

      if (var8) {
         this.field1500 = new byte[this.faceCount];
      }

      this.faceColors = new short[this.faceCount];
      if (this.field1487 > 0) {
         this.field1465 = new byte[this.field1487];
         this.field1480 = new short[this.field1487];
         this.field1481 = new short[this.field1487];
         this.field1463 = new short[this.field1487];
      }

      this.verticesCount = 0;
      this.faceCount = 0;
      this.field1487 = 0;

      for(var9 = 0; var9 < var2; ++var9) {
         var10 = var1[var9];
         if (var10 != null) {
            int var11;
            for(var11 = 0; var11 < var10.faceCount; ++var11) {
               if (var3 && var10.field1471 != null) {
                  this.field1471[this.faceCount] = var10.field1471[var11];
               }

               if (var4) {
                  if (var10.field1472 != null) {
                     this.field1472[this.faceCount] = var10.field1472[var11];
                  } else {
                     this.field1472[this.faceCount] = var10.field1477;
                  }
               }

               if (var5 && var10.faceAlphas != null) {
                  this.faceAlphas[this.faceCount] = var10.faceAlphas[var11];
               }

               if (var6 && var10.field1484 != null) {
                  this.field1484[this.faceCount] = var10.field1484[var11];
               }

               if (var7) {
                  if (var10.faceTextures != null) {
                     this.faceTextures[this.faceCount] = var10.faceTextures[var11];
                  } else {
                     this.faceTextures[this.faceCount] = -1;
                  }
               }

               if (var8) {
                  if (var10.field1500 != null && var10.field1500[var11] != -1) {
                     this.field1500[this.faceCount] = (byte)(this.field1487 + var10.field1500[var11]);
                  } else {
                     this.field1500[this.faceCount] = -1;
                  }
               }

               this.faceColors[this.faceCount] = var10.faceColors[var11];
               this.indices1[this.faceCount] = this.method2674(var10, var10.indices1[var11]);
               this.indices2[this.faceCount] = this.method2674(var10, var10.indices2[var11]);
               this.indices3[this.faceCount] = this.method2674(var10, var10.indices3[var11]);
               ++this.faceCount;
            }

            for(var11 = 0; var11 < var10.field1487; ++var11) {
               byte var12 = this.field1465[this.field1487] = var10.field1465[var11];
               if (var12 == 0) {
                  this.field1480[this.field1487] = (short)this.method2674(var10, var10.field1480[var11]);
                  this.field1481[this.field1487] = (short)this.method2674(var10, var10.field1481[var11]);
                  this.field1463[this.field1487] = (short)this.method2674(var10, var10.field1463[var11]);
               }

               ++this.field1487;
            }
         }
      }

   }

   ModelData(byte[] var1) {
      if (var1[var1.length - 1] == -1 && var1[var1.length - 2] == -1) {
         this.method2722(var1);
      } else {
         this.method2672(var1);
      }

   }

   public ModelData(ModelData var1, boolean var2, boolean var3, boolean var4, boolean var5) {
      this.verticesCount = var1.verticesCount;
      this.faceCount = var1.faceCount;
      this.field1487 = var1.field1487;
      int var6;
      if (var2) {
         this.verticesX = var1.verticesX;
         this.verticesY = var1.verticesY;
         this.verticesZ = var1.verticesZ;
      } else {
         this.verticesX = new int[this.verticesCount];
         this.verticesY = new int[this.verticesCount];
         this.verticesZ = new int[this.verticesCount];

         for(var6 = 0; var6 < this.verticesCount; ++var6) {
            this.verticesX[var6] = var1.verticesX[var6];
            this.verticesY[var6] = var1.verticesY[var6];
            this.verticesZ[var6] = var1.verticesZ[var6];
         }
      }

      if (var3) {
         this.faceColors = var1.faceColors;
      } else {
         this.faceColors = new short[this.faceCount];

         for(var6 = 0; var6 < this.faceCount; ++var6) {
            this.faceColors[var6] = var1.faceColors[var6];
         }
      }

      if (!var4 && var1.faceTextures != null) {
         this.faceTextures = new short[this.faceCount];

         for(var6 = 0; var6 < this.faceCount; ++var6) {
            this.faceTextures[var6] = var1.faceTextures[var6];
         }
      } else {
         this.faceTextures = var1.faceTextures;
      }

      this.faceAlphas = var1.faceAlphas;
      this.indices1 = var1.indices1;
      this.indices2 = var1.indices2;
      this.indices3 = var1.indices3;
      this.field1471 = var1.field1471;
      this.field1472 = var1.field1472;
      this.field1500 = var1.field1500;
      this.field1477 = var1.field1477;
      this.field1465 = var1.field1465;
      this.field1480 = var1.field1480;
      this.field1481 = var1.field1481;
      this.field1463 = var1.field1463;
      this.field1483 = var1.field1483;
      this.field1484 = var1.field1484;
      this.vertexLabels = var1.vertexLabels;
      this.faceLabelsAlpha = var1.faceLabelsAlpha;
      this.field1501 = var1.field1501;
      this.faceNormals = var1.faceNormals;
      this.field1489 = var1.field1489;
      this.field1490 = var1.field1490;
      this.field1491 = var1.field1491;
   }

   public final Model toModel(int var1, int var2, int var3, int var4, int var5) {
      this.method2700();
      int var6 = (int)Math.sqrt((double)(var5 * var5 + var3 * var3 + var4 * var4));
      int var7 = var6 * var2 >> 8;
      Model var8 = new Model();
      var8.faceColors1 = new int[this.faceCount];
      var8.faceColors2 = new int[this.faceCount];
      var8.faceColors3 = new int[this.faceCount];
      if (this.field1487 > 0 && this.field1500 != null) {
         int[] var9 = new int[this.field1487];

         int var10;
         for(var10 = 0; var10 < this.faceCount; ++var10) {
            if (this.field1500[var10] != -1) {
               ++var9[this.field1500[var10] & 255];
            }
         }

         var8.field1334 = 0;

         for(var10 = 0; var10 < this.field1487; ++var10) {
            if (var9[var10] > 0 && this.field1465[var10] == 0) {
               ++var8.field1334;
            }
         }

         var8.field1309 = new int[var8.field1334];
         var8.field1310 = new int[var8.field1334];
         var8.field1311 = new int[var8.field1334];
         var10 = 0;

         int var11;
         for(var11 = 0; var11 < this.field1487; ++var11) {
            if (var9[var11] > 0 && this.field1465[var11] == 0) {
               var8.field1309[var10] = this.field1480[var11] & '\uffff';
               var8.field1310[var10] = this.field1481[var11] & '\uffff';
               var8.field1311[var10] = this.field1463[var11] & '\uffff';
               var9[var11] = var10++;
            } else {
               var9[var11] = -1;
            }
         }

         var8.field1305 = new byte[this.faceCount];

         for(var11 = 0; var11 < this.faceCount; ++var11) {
            if (this.field1500[var11] != -1) {
               var8.field1305[var11] = (byte)var9[this.field1500[var11] & 255];
            } else {
               var8.field1305[var11] = -1;
            }
         }
      }

      for(int var16 = 0; var16 < this.faceCount; ++var16) {
         byte var17;
         if (this.field1471 == null) {
            var17 = 0;
         } else {
            var17 = this.field1471[var16];
         }

         byte var18;
         if (this.faceAlphas == null) {
            var18 = 0;
         } else {
            var18 = this.faceAlphas[var16];
         }

         short var12;
         if (this.faceTextures == null) {
            var12 = -1;
         } else {
            var12 = this.faceTextures[var16];
         }

         if (var18 == -2) {
            var17 = 3;
         }

         if (var18 == -1) {
            var17 = 2;
         }

         VertexNormal var13;
         int var14;
         FaceNormal var19;
         if (var12 == -1) {
            if (var17 != 0) {
               if (var17 == 1) {
                  var19 = this.faceNormals[var16];
                  var14 = (var4 * var19.field1619 + var5 * var19.field1620 + var3 * var19.field1618) / (var7 / 2 + var7) + var1;
                  var8.faceColors1[var16] = method2690(this.faceColors[var16] & '\uffff', var14);
                  var8.faceColors3[var16] = -1;
               } else if (var17 == 3) {
                  var8.faceColors1[var16] = 128;
                  var8.faceColors3[var16] = -1;
               } else {
                  var8.faceColors3[var16] = -2;
               }
            } else {
               int var15 = this.faceColors[var16] & '\uffff';
               if (this.field1489 != null && this.field1489[this.indices1[var16]] != null) {
                  var13 = this.field1489[this.indices1[var16]];
               } else {
                  var13 = this.field1501[this.indices1[var16]];
               }

               var14 = (var4 * var13.field1232 + var5 * var13.field1233 + var3 * var13.field1236) / (var7 * var13.field1235) + var1;
               var8.faceColors1[var16] = method2690(var15, var14);
               if (this.field1489 != null && this.field1489[this.indices2[var16]] != null) {
                  var13 = this.field1489[this.indices2[var16]];
               } else {
                  var13 = this.field1501[this.indices2[var16]];
               }

               var14 = (var4 * var13.field1232 + var5 * var13.field1233 + var3 * var13.field1236) / (var7 * var13.field1235) + var1;
               var8.faceColors2[var16] = method2690(var15, var14);
               if (this.field1489 != null && this.field1489[this.indices3[var16]] != null) {
                  var13 = this.field1489[this.indices3[var16]];
               } else {
                  var13 = this.field1501[this.indices3[var16]];
               }

               var14 = (var4 * var13.field1232 + var5 * var13.field1233 + var3 * var13.field1236) / (var7 * var13.field1235) + var1;
               var8.faceColors3[var16] = method2690(var15, var14);
            }
         } else if (var17 != 0) {
            if (var17 == 1) {
               var19 = this.faceNormals[var16];
               var14 = (var4 * var19.field1619 + var5 * var19.field1620 + var3 * var19.field1618) / (var7 / 2 + var7) + var1;
               var8.faceColors1[var16] = method2718(var14);
               var8.faceColors3[var16] = -1;
            } else {
               var8.faceColors3[var16] = -2;
            }
         } else {
            if (this.field1489 != null && this.field1489[this.indices1[var16]] != null) {
               var13 = this.field1489[this.indices1[var16]];
            } else {
               var13 = this.field1501[this.indices1[var16]];
            }

            var14 = (var4 * var13.field1232 + var5 * var13.field1233 + var3 * var13.field1236) / (var7 * var13.field1235) + var1;
            var8.faceColors1[var16] = method2718(var14);
            if (this.field1489 != null && this.field1489[this.indices2[var16]] != null) {
               var13 = this.field1489[this.indices2[var16]];
            } else {
               var13 = this.field1501[this.indices2[var16]];
            }

            var14 = (var4 * var13.field1232 + var5 * var13.field1233 + var3 * var13.field1236) / (var7 * var13.field1235) + var1;
            var8.faceColors2[var16] = method2718(var14);
            if (this.field1489 != null && this.field1489[this.indices3[var16]] != null) {
               var13 = this.field1489[this.indices3[var16]];
            } else {
               var13 = this.field1501[this.indices3[var16]];
            }

            var14 = (var4 * var13.field1232 + var5 * var13.field1233 + var3 * var13.field1236) / (var7 * var13.field1235) + var1;
            var8.faceColors3[var16] = method2718(var14);
         }
      }

      this.method2729();
      var8.verticesCount = this.verticesCount;
      var8.verticesX = this.verticesX;
      var8.verticesY = this.verticesY;
      var8.verticesZ = this.verticesZ;
      var8.indicesCount = this.faceCount;
      var8.indices1 = this.indices1;
      var8.indices2 = this.indices2;
      var8.indices3 = this.indices3;
      var8.field1303 = this.field1472;
      var8.faceAlphas = this.faceAlphas;
      var8.field1307 = this.field1477;
      var8.vertexLabels = this.vertexLabels;
      var8.faceLabelsAlpha = this.faceLabelsAlpha;
      var8.faceTextures = this.faceTextures;
      return var8;
   }

   public void retexture(short var1, short var2) {
      if (this.faceTextures != null) {
         for(int var3 = 0; var3 < this.faceCount; ++var3) {
            if (this.faceTextures[var3] == var1) {
               this.faceTextures[var3] = var2;
            }
         }

      }
   }

   public ModelData method2680() {
      ModelData var1 = new ModelData();
      if (this.field1471 != null) {
         var1.field1471 = new byte[this.faceCount];

         for(int var2 = 0; var2 < this.faceCount; ++var2) {
            var1.field1471[var2] = this.field1471[var2];
         }
      }

      var1.verticesCount = this.verticesCount;
      var1.faceCount = this.faceCount;
      var1.field1487 = this.field1487;
      var1.verticesX = this.verticesX;
      var1.verticesY = this.verticesY;
      var1.verticesZ = this.verticesZ;
      var1.indices1 = this.indices1;
      var1.indices2 = this.indices2;
      var1.indices3 = this.indices3;
      var1.field1472 = this.field1472;
      var1.faceAlphas = this.faceAlphas;
      var1.field1500 = this.field1500;
      var1.faceColors = this.faceColors;
      var1.faceTextures = this.faceTextures;
      var1.field1477 = this.field1477;
      var1.field1465 = this.field1465;
      var1.field1480 = this.field1480;
      var1.field1481 = this.field1481;
      var1.field1463 = this.field1463;
      var1.field1483 = this.field1483;
      var1.field1484 = this.field1484;
      var1.vertexLabels = this.vertexLabels;
      var1.faceLabelsAlpha = this.faceLabelsAlpha;
      var1.field1501 = this.field1501;
      var1.faceNormals = this.faceNormals;
      var1.field1490 = this.field1490;
      var1.field1491 = this.field1491;
      return var1;
   }

   void method2672(byte[] var1) {
      boolean var2 = false;
      boolean var3 = false;
      Buffer var4 = new Buffer(var1);
      Buffer var5 = new Buffer(var1);
      Buffer var6 = new Buffer(var1);
      Buffer var7 = new Buffer(var1);
      Buffer var8 = new Buffer(var1);
      var4.index = var1.length - 18;
      int var9 = var4.method3913();
      int var10 = var4.method3913();
      int var11 = var4.readUnsignedByte();
      int var12 = var4.readUnsignedByte();
      int var13 = var4.readUnsignedByte();
      int var14 = var4.readUnsignedByte();
      int var15 = var4.readUnsignedByte();
      int var16 = var4.readUnsignedByte();
      int var17 = var4.method3913();
      int var18 = var4.method3913();
      int var19 = var4.method3913();
      int var20 = var4.method3913();
      byte var21 = 0;
      int var45 = var21 + var9;
      int var23 = var45;
      var45 += var10;
      int var24 = var45;
      if (var13 == 255) {
         var45 += var10;
      }

      int var25 = var45;
      if (var15 == 1) {
         var45 += var10;
      }

      int var26 = var45;
      if (var12 == 1) {
         var45 += var10;
      }

      int var27 = var45;
      if (var16 == 1) {
         var45 += var9;
      }

      int var28 = var45;
      if (var14 == 1) {
         var45 += var10;
      }

      int var29 = var45;
      var45 += var20;
      int var30 = var45;
      var45 += var10 * 2;
      int var31 = var45;
      var45 += var11 * 6;
      int var32 = var45;
      var45 += var17;
      int var33 = var45;
      var45 += var18;
      int var10000 = var45 + var19;
      this.verticesCount = var9;
      this.faceCount = var10;
      this.field1487 = var11;
      this.verticesX = new int[var9];
      this.verticesY = new int[var9];
      this.verticesZ = new int[var9];
      this.indices1 = new int[var10];
      this.indices2 = new int[var10];
      this.indices3 = new int[var10];
      if (var11 > 0) {
         this.field1465 = new byte[var11];
         this.field1480 = new short[var11];
         this.field1481 = new short[var11];
         this.field1463 = new short[var11];
      }

      if (var16 == 1) {
         this.field1483 = new int[var9];
      }

      if (var12 == 1) {
         this.field1471 = new byte[var10];
         this.field1500 = new byte[var10];
         this.faceTextures = new short[var10];
      }

      if (var13 == 255) {
         this.field1472 = new byte[var10];
      } else {
         this.field1477 = (byte)var13;
      }

      if (var14 == 1) {
         this.faceAlphas = new byte[var10];
      }

      if (var15 == 1) {
         this.field1484 = new int[var10];
      }

      this.faceColors = new short[var10];
      var4.index = var21;
      var5.index = var32;
      var6.index = var33;
      var7.index = var45;
      var8.index = var27;
      int var35 = 0;
      int var36 = 0;
      int var37 = 0;

      int var38;
      int var39;
      int var40;
      int var41;
      int var42;
      for(var38 = 0; var38 < var9; ++var38) {
         var39 = var4.readUnsignedByte();
         var40 = 0;
         if ((var39 & 1) != 0) {
            var40 = var5.method3924();
         }

         var41 = 0;
         if ((var39 & 2) != 0) {
            var41 = var6.method3924();
         }

         var42 = 0;
         if ((var39 & 4) != 0) {
            var42 = var7.method3924();
         }

         this.verticesX[var38] = var35 + var40;
         this.verticesY[var38] = var36 + var41;
         this.verticesZ[var38] = var37 + var42;
         var35 = this.verticesX[var38];
         var36 = this.verticesY[var38];
         var37 = this.verticesZ[var38];
         if (var16 == 1) {
            this.field1483[var38] = var8.readUnsignedByte();
         }
      }

      var4.index = var30;
      var5.index = var26;
      var6.index = var24;
      var7.index = var28;
      var8.index = var25;

      for(var38 = 0; var38 < var10; ++var38) {
         this.faceColors[var38] = (short)var4.method3913();
         if (var12 == 1) {
            var39 = var5.readUnsignedByte();
            if ((var39 & 1) == 1) {
               this.field1471[var38] = 1;
               var2 = true;
            } else {
               this.field1471[var38] = 0;
            }

            if ((var39 & 2) == 2) {
               this.field1500[var38] = (byte)(var39 >> 2);
               this.faceTextures[var38] = this.faceColors[var38];
               this.faceColors[var38] = 127;
               if (this.faceTextures[var38] != -1) {
                  var3 = true;
               }
            } else {
               this.field1500[var38] = -1;
               this.faceTextures[var38] = -1;
            }
         }

         if (var13 == 255) {
            this.field1472[var38] = var6.readByte();
         }

         if (var14 == 1) {
            this.faceAlphas[var38] = var7.readByte();
         }

         if (var15 == 1) {
            this.field1484[var38] = var8.readUnsignedByte();
         }
      }

      var4.index = var29;
      var5.index = var23;
      var38 = 0;
      var39 = 0;
      var40 = 0;
      var41 = 0;

      int var43;
      int var44;
      for(var42 = 0; var42 < var10; ++var42) {
         var43 = var5.readUnsignedByte();
         if (var43 == 1) {
            var38 = var4.method3924() + var41;
            var39 = var4.method3924() + var38;
            var40 = var4.method3924() + var39;
            var41 = var40;
            this.indices1[var42] = var38;
            this.indices2[var42] = var39;
            this.indices3[var42] = var40;
         }

         if (var43 == 2) {
            var39 = var40;
            var40 = var4.method3924() + var41;
            var41 = var40;
            this.indices1[var42] = var38;
            this.indices2[var42] = var39;
            this.indices3[var42] = var40;
         }

         if (var43 == 3) {
            var38 = var40;
            var40 = var4.method3924() + var41;
            var41 = var40;
            this.indices1[var42] = var38;
            this.indices2[var42] = var39;
            this.indices3[var42] = var40;
         }

         if (var43 == 4) {
            var44 = var38;
            var38 = var39;
            var39 = var44;
            var40 = var4.method3924() + var41;
            var41 = var40;
            this.indices1[var42] = var38;
            this.indices2[var42] = var44;
            this.indices3[var42] = var40;
         }
      }

      var4.index = var31;

      for(var42 = 0; var42 < var11; ++var42) {
         this.field1465[var42] = 0;
         this.field1480[var42] = (short)var4.method3913();
         this.field1481[var42] = (short)var4.method3913();
         this.field1463[var42] = (short)var4.method3913();
      }

      if (this.field1500 != null) {
         boolean var46 = false;

         for(var43 = 0; var43 < var10; ++var43) {
            var44 = this.field1500[var43] & 255;
            if (var44 != 255) {
               if (this.indices1[var43] == (this.field1480[var44] & '\uffff') && this.indices2[var43] == (this.field1481[var44] & '\uffff') && this.indices3[var43] == (this.field1463[var44] & '\uffff')) {
                  this.field1500[var43] = -1;
               } else {
                  var46 = true;
               }
            }
         }

         if (!var46) {
            this.field1500 = null;
         }
      }

      if (!var3) {
         this.faceTextures = null;
      }

      if (!var2) {
         this.field1471 = null;
      }

   }

   public void recolor(short var1, short var2) {
      for(int var3 = 0; var3 < this.faceCount; ++var3) {
         if (this.faceColors[var3] == var1) {
            this.faceColors[var3] = var2;
         }
      }

   }

   public void method2725(int var1, int var2, int var3) {
      for(int var4 = 0; var4 < this.verticesCount; ++var4) {
         this.verticesX[var4] += var1;
         this.verticesY[var4] += var2;
         this.verticesZ[var4] += var3;
      }

      this.method2686();
   }

   public ModelData method2689(int[][] var1, int var2, int var3, int var4, boolean var5, int var6) {
      this.method2687();
      int var7 = var2 + this.field1494;
      int var8 = var2 + this.field1482;
      int var9 = var4 + this.field1497;
      int var10 = var4 + this.field1478;
      if (var7 >= 0 && var8 + 128 >> 7 < var1.length && var9 >= 0 && var10 + 128 >> 7 < var1[0].length) {
         var7 >>= 7;
         var8 = var8 + 127 >> 7;
         var9 >>= 7;
         var10 = var10 + 127 >> 7;
         if (var3 == var1[var7][var9] && var3 == var1[var8][var9] && var3 == var1[var7][var10] && var3 == var1[var8][var10]) {
            return this;
         } else {
            ModelData var11 = new ModelData();
            var11.verticesCount = this.verticesCount;
            var11.faceCount = this.faceCount;
            var11.field1487 = this.field1487;
            var11.verticesX = this.verticesX;
            var11.verticesZ = this.verticesZ;
            var11.indices1 = this.indices1;
            var11.indices2 = this.indices2;
            var11.indices3 = this.indices3;
            var11.field1471 = this.field1471;
            var11.field1472 = this.field1472;
            var11.faceAlphas = this.faceAlphas;
            var11.field1500 = this.field1500;
            var11.faceColors = this.faceColors;
            var11.faceTextures = this.faceTextures;
            var11.field1477 = this.field1477;
            var11.field1465 = this.field1465;
            var11.field1480 = this.field1480;
            var11.field1481 = this.field1481;
            var11.field1463 = this.field1463;
            var11.field1483 = this.field1483;
            var11.field1484 = this.field1484;
            var11.vertexLabels = this.vertexLabels;
            var11.faceLabelsAlpha = this.faceLabelsAlpha;
            var11.field1490 = this.field1490;
            var11.field1491 = this.field1491;
            var11.verticesY = new int[var11.verticesCount];
            int var12;
            int var13;
            int var14;
            int var15;
            int var16;
            int var17;
            int var18;
            int var19;
            int var20;
            int var21;
            if (var6 == 0) {
               for(var12 = 0; var12 < var11.verticesCount; ++var12) {
                  var13 = var2 + this.verticesX[var12];
                  var14 = var4 + this.verticesZ[var12];
                  var15 = var13 & 127;
                  var16 = var14 & 127;
                  var17 = var13 >> 7;
                  var18 = var14 >> 7;
                  var19 = var1[var17][var18] * (128 - var15) + var1[var17 + 1][var18] * var15 >> 7;
                  var20 = var1[var17][var18 + 1] * (128 - var15) + var15 * var1[var17 + 1][var18 + 1] >> 7;
                  var21 = var19 * (128 - var16) + var20 * var16 >> 7;
                  var11.verticesY[var12] = var21 + this.verticesY[var12] - var3;
               }
            } else {
               for(var12 = 0; var12 < var11.verticesCount; ++var12) {
                  var13 = (-this.verticesY[var12] << 16) / super.height;
                  if (var13 < var6) {
                     var14 = var2 + this.verticesX[var12];
                     var15 = var4 + this.verticesZ[var12];
                     var16 = var14 & 127;
                     var17 = var15 & 127;
                     var18 = var14 >> 7;
                     var19 = var15 >> 7;
                     var20 = var1[var18][var19] * (128 - var16) + var1[var18 + 1][var19] * var16 >> 7;
                     var21 = var1[var18][var19 + 1] * (128 - var16) + var16 * var1[var18 + 1][var19 + 1] >> 7;
                     int var22 = var20 * (128 - var17) + var21 * var17 >> 7;
                     var11.verticesY[var12] = (var6 - var13) * (var22 - var3) / var6 + this.verticesY[var12];
                  }
               }
            }

            var11.method2686();
            return var11;
         }
      } else {
         return this;
      }
   }

   public void method2677() {
      for(int var1 = 0; var1 < this.verticesCount; ++var1) {
         this.verticesX[var1] = -this.verticesX[var1];
         this.verticesZ[var1] = -this.verticesZ[var1];
      }

      this.method2686();
   }

   public void method2681(int var1, int var2, int var3) {
      for(int var4 = 0; var4 < this.verticesCount; ++var4) {
         this.verticesX[var4] = this.verticesX[var4] * var1 / 128;
         this.verticesY[var4] = var2 * this.verticesY[var4] / 128;
         this.verticesZ[var4] = var3 * this.verticesZ[var4] / 128;
      }

      this.method2686();
   }

   public void method2702() {
      for(int var1 = 0; var1 < this.verticesCount; ++var1) {
         int var2 = this.verticesX[var1];
         this.verticesX[var1] = this.verticesZ[var1];
         this.verticesZ[var1] = -var2;
      }

      this.method2686();
   }

   void method2729() {
      int[] var1;
      int var2;
      int var3;
      int var4;
      if (this.field1483 != null) {
         var1 = new int[256];
         var2 = 0;

         for(var3 = 0; var3 < this.verticesCount; ++var3) {
            var4 = this.field1483[var3];
            ++var1[var4];
            if (var4 > var2) {
               var2 = var4;
            }
         }

         this.vertexLabels = new int[var2 + 1][];

         for(var3 = 0; var3 <= var2; ++var3) {
            this.vertexLabels[var3] = new int[var1[var3]];
            var1[var3] = 0;
         }

         for(var3 = 0; var3 < this.verticesCount; this.vertexLabels[var4][var1[var4]++] = var3++) {
            var4 = this.field1483[var3];
         }

         this.field1483 = null;
      }

      if (this.field1484 != null) {
         var1 = new int[256];
         var2 = 0;

         for(var3 = 0; var3 < this.faceCount; ++var3) {
            var4 = this.field1484[var3];
            ++var1[var4];
            if (var4 > var2) {
               var2 = var4;
            }
         }

         this.faceLabelsAlpha = new int[var2 + 1][];

         for(var3 = 0; var3 <= var2; ++var3) {
            this.faceLabelsAlpha[var3] = new int[var1[var3]];
            var1[var3] = 0;
         }

         for(var3 = 0; var3 < this.faceCount; this.faceLabelsAlpha[var4][var1[var4]++] = var3++) {
            var4 = this.field1484[var3];
         }

         this.field1484 = null;
      }

   }

   final int method2674(ModelData var1, int var2) {
      int var3 = -1;
      int var4 = var1.verticesX[var2];
      int var5 = var1.verticesY[var2];
      int var6 = var1.verticesZ[var2];

      for(int var7 = 0; var7 < this.verticesCount; ++var7) {
         if (var4 == this.verticesX[var7] && var5 == this.verticesY[var7] && var6 == this.verticesZ[var7]) {
            var3 = var7;
            break;
         }
      }

      if (var3 == -1) {
         this.verticesX[this.verticesCount] = var4;
         this.verticesY[this.verticesCount] = var5;
         this.verticesZ[this.verticesCount] = var6;
         if (var1.field1483 != null) {
            this.field1483[this.verticesCount] = var1.field1483[var2];
         }

         var3 = this.verticesCount++;
      }

      return var3;
   }

   void method2722(byte[] var1) {
      Buffer var2 = new Buffer(var1);
      Buffer var3 = new Buffer(var1);
      Buffer var4 = new Buffer(var1);
      Buffer var5 = new Buffer(var1);
      Buffer var6 = new Buffer(var1);
      Buffer var7 = new Buffer(var1);
      Buffer var8 = new Buffer(var1);
      var2.index = var1.length - 23;
      int var9 = var2.method3913();
      int var10 = var2.method3913();
      int var11 = var2.readUnsignedByte();
      int var12 = var2.readUnsignedByte();
      int var13 = var2.readUnsignedByte();
      int var14 = var2.readUnsignedByte();
      int var15 = var2.readUnsignedByte();
      int var16 = var2.readUnsignedByte();
      int var17 = var2.readUnsignedByte();
      int var18 = var2.method3913();
      int var19 = var2.method3913();
      int var20 = var2.method3913();
      int var21 = var2.method3913();
      int var22 = var2.method3913();
      int var23 = 0;
      int var24 = 0;
      int var25 = 0;
      int var26;
      if (var11 > 0) {
         this.field1465 = new byte[var11];
         var2.index = 0;

         for(var26 = 0; var26 < var11; ++var26) {
            byte var27 = this.field1465[var26] = var2.readByte();
            if (var27 == 0) {
               ++var23;
            }

            if (var27 >= 1 && var27 <= 3) {
               ++var24;
            }

            if (var27 == 2) {
               ++var25;
            }
         }
      }

      var26 = var11 + var9;
      int var28 = var26;
      if (var12 == 1) {
         var26 += var10;
      }

      int var29 = var26;
      var26 += var10;
      int var30 = var26;
      if (var13 == 255) {
         var26 += var10;
      }

      int var31 = var26;
      if (var15 == 1) {
         var26 += var10;
      }

      int var32 = var26;
      if (var17 == 1) {
         var26 += var9;
      }

      int var33 = var26;
      if (var14 == 1) {
         var26 += var10;
      }

      int var34 = var26;
      var26 += var21;
      int var35 = var26;
      if (var16 == 1) {
         var26 += var10 * 2;
      }

      int var36 = var26;
      var26 += var22;
      int var37 = var26;
      var26 += var10 * 2;
      int var38 = var26;
      var26 += var18;
      int var39 = var26;
      var26 += var19;
      int var40 = var26;
      var26 += var20;
      int var41 = var26;
      var26 += var23 * 6;
      int var42 = var26;
      var26 += var24 * 6;
      int var43 = var26;
      var26 += var24 * 6;
      int var44 = var26;
      var26 += var24 * 2;
      int var45 = var26;
      var26 += var24;
      int var46 = var26;
      var26 += var24 * 2 + var25 * 2;
      this.verticesCount = var9;
      this.faceCount = var10;
      this.field1487 = var11;
      this.verticesX = new int[var9];
      this.verticesY = new int[var9];
      this.verticesZ = new int[var9];
      this.indices1 = new int[var10];
      this.indices2 = new int[var10];
      this.indices3 = new int[var10];
      if (var17 == 1) {
         this.field1483 = new int[var9];
      }

      if (var12 == 1) {
         this.field1471 = new byte[var10];
      }

      if (var13 == 255) {
         this.field1472 = new byte[var10];
      } else {
         this.field1477 = (byte)var13;
      }

      if (var14 == 1) {
         this.faceAlphas = new byte[var10];
      }

      if (var15 == 1) {
         this.field1484 = new int[var10];
      }

      if (var16 == 1) {
         this.faceTextures = new short[var10];
      }

      if (var16 == 1 && var11 > 0) {
         this.field1500 = new byte[var10];
      }

      this.faceColors = new short[var10];
      if (var11 > 0) {
         this.field1480 = new short[var11];
         this.field1481 = new short[var11];
         this.field1463 = new short[var11];
      }

      var2.index = var11;
      var3.index = var38;
      var4.index = var39;
      var5.index = var40;
      var6.index = var32;
      int var48 = 0;
      int var49 = 0;
      int var50 = 0;

      int var51;
      int var52;
      int var53;
      int var54;
      int var55;
      for(var51 = 0; var51 < var9; ++var51) {
         var52 = var2.readUnsignedByte();
         var53 = 0;
         if ((var52 & 1) != 0) {
            var53 = var3.method3924();
         }

         var54 = 0;
         if ((var52 & 2) != 0) {
            var54 = var4.method3924();
         }

         var55 = 0;
         if ((var52 & 4) != 0) {
            var55 = var5.method3924();
         }

         this.verticesX[var51] = var48 + var53;
         this.verticesY[var51] = var49 + var54;
         this.verticesZ[var51] = var50 + var55;
         var48 = this.verticesX[var51];
         var49 = this.verticesY[var51];
         var50 = this.verticesZ[var51];
         if (var17 == 1) {
            this.field1483[var51] = var6.readUnsignedByte();
         }
      }

      var2.index = var37;
      var3.index = var28;
      var4.index = var30;
      var5.index = var33;
      var6.index = var31;
      var7.index = var35;
      var8.index = var36;

      for(var51 = 0; var51 < var10; ++var51) {
         this.faceColors[var51] = (short)var2.method3913();
         if (var12 == 1) {
            this.field1471[var51] = var3.readByte();
         }

         if (var13 == 255) {
            this.field1472[var51] = var4.readByte();
         }

         if (var14 == 1) {
            this.faceAlphas[var51] = var5.readByte();
         }

         if (var15 == 1) {
            this.field1484[var51] = var6.readUnsignedByte();
         }

         if (var16 == 1) {
            this.faceTextures[var51] = (short)(var7.method3913() - 1);
         }

         if (this.field1500 != null && this.faceTextures[var51] != -1) {
            this.field1500[var51] = (byte)(var8.readUnsignedByte() - 1);
         }
      }

      var2.index = var34;
      var3.index = var29;
      var51 = 0;
      var52 = 0;
      var53 = 0;
      var54 = 0;

      int var56;
      for(var55 = 0; var55 < var10; ++var55) {
         var56 = var3.readUnsignedByte();
         if (var56 == 1) {
            var51 = var2.method3924() + var54;
            var52 = var2.method3924() + var51;
            var53 = var2.method3924() + var52;
            var54 = var53;
            this.indices1[var55] = var51;
            this.indices2[var55] = var52;
            this.indices3[var55] = var53;
         }

         if (var56 == 2) {
            var52 = var53;
            var53 = var2.method3924() + var54;
            var54 = var53;
            this.indices1[var55] = var51;
            this.indices2[var55] = var52;
            this.indices3[var55] = var53;
         }

         if (var56 == 3) {
            var51 = var53;
            var53 = var2.method3924() + var54;
            var54 = var53;
            this.indices1[var55] = var51;
            this.indices2[var55] = var52;
            this.indices3[var55] = var53;
         }

         if (var56 == 4) {
            int var57 = var51;
            var51 = var52;
            var52 = var57;
            var53 = var2.method3924() + var54;
            var54 = var53;
            this.indices1[var55] = var51;
            this.indices2[var55] = var57;
            this.indices3[var55] = var53;
         }
      }

      var2.index = var41;
      var3.index = var42;
      var4.index = var43;
      var5.index = var44;
      var6.index = var45;
      var7.index = var46;

      for(var55 = 0; var55 < var11; ++var55) {
         var56 = this.field1465[var55] & 255;
         if (var56 == 0) {
            this.field1480[var55] = (short)var2.method3913();
            this.field1481[var55] = (short)var2.method3913();
            this.field1463[var55] = (short)var2.method3913();
         }
      }

      var2.index = var26;
      var55 = var2.readUnsignedByte();
      if (var55 != 0) {
         new ModelData0();
         var2.method3913();
         var2.method3913();
         var2.method3913();
         var2.readInt();
      }

   }

   public void method2700() {
      if (this.field1501 == null) {
         this.field1501 = new VertexNormal[this.verticesCount];

         int var1;
         for(var1 = 0; var1 < this.verticesCount; ++var1) {
            this.field1501[var1] = new VertexNormal();
         }

         for(var1 = 0; var1 < this.faceCount; ++var1) {
            int var2 = this.indices1[var1];
            int var3 = this.indices2[var1];
            int var4 = this.indices3[var1];
            int var5 = this.verticesX[var3] - this.verticesX[var2];
            int var6 = this.verticesY[var3] - this.verticesY[var2];
            int var7 = this.verticesZ[var3] - this.verticesZ[var2];
            int var8 = this.verticesX[var4] - this.verticesX[var2];
            int var9 = this.verticesY[var4] - this.verticesY[var2];
            int var10 = this.verticesZ[var4] - this.verticesZ[var2];
            int var11 = var6 * var10 - var9 * var7;
            int var12 = var7 * var8 - var10 * var5;

            int var13;
            for(var13 = var5 * var9 - var8 * var6; var11 > 8192 || var12 > 8192 || var13 > 8192 || var11 < -8192 || var12 < -8192 || var13 < -8192; var13 >>= 1) {
               var11 >>= 1;
               var12 >>= 1;
            }

            int var14 = (int)Math.sqrt((double)(var11 * var11 + var12 * var12 + var13 * var13));
            if (var14 <= 0) {
               var14 = 1;
            }

            var11 = var11 * 256 / var14;
            var12 = var12 * 256 / var14;
            var13 = var13 * 256 / var14;
            byte var15;
            if (this.field1471 == null) {
               var15 = 0;
            } else {
               var15 = this.field1471[var1];
            }

            if (var15 == 0) {
               VertexNormal var16 = this.field1501[var2];
               var16.field1236 += var11;
               var16.field1232 += var12;
               var16.field1233 += var13;
               ++var16.field1235;
               var16 = this.field1501[var3];
               var16.field1236 += var11;
               var16.field1232 += var12;
               var16.field1233 += var13;
               ++var16.field1235;
               var16 = this.field1501[var4];
               var16.field1236 += var11;
               var16.field1232 += var12;
               var16.field1233 += var13;
               ++var16.field1235;
            } else if (var15 == 1) {
               if (this.faceNormals == null) {
                  this.faceNormals = new FaceNormal[this.faceCount];
               }

               FaceNormal var17 = this.faceNormals[var1] = new FaceNormal();
               var17.field1618 = var11;
               var17.field1619 = var12;
               var17.field1620 = var13;
            }
         }

      }
   }

   public void method2704() {
      int var1;
      for(var1 = 0; var1 < this.verticesCount; ++var1) {
         this.verticesZ[var1] = -this.verticesZ[var1];
      }

      for(var1 = 0; var1 < this.faceCount; ++var1) {
         int var2 = this.indices1[var1];
         this.indices1[var1] = this.indices3[var1];
         this.indices3[var1] = var2;
      }

      this.method2686();
   }

   void method2687() {
      if (!this.isBoundsCalculated) {
         super.height = 0;
         this.field1493 = 0;
         this.field1494 = 999999;
         this.field1482 = -999999;
         this.field1478 = -99999;
         this.field1497 = 99999;

         for(int var1 = 0; var1 < this.verticesCount; ++var1) {
            int var2 = this.verticesX[var1];
            int var3 = this.verticesY[var1];
            int var4 = this.verticesZ[var1];
            if (var2 < this.field1494) {
               this.field1494 = var2;
            }

            if (var2 > this.field1482) {
               this.field1482 = var2;
            }

            if (var4 < this.field1497) {
               this.field1497 = var4;
            }

            if (var4 > this.field1478) {
               this.field1478 = var4;
            }

            if (-var3 > super.height) {
               super.height = -var3;
            }

            if (var3 > this.field1493) {
               this.field1493 = var3;
            }
         }

         this.isBoundsCalculated = true;
      }
   }

   public void method2679(int var1) {
      int var2 = field1464[var1];
      int var3 = field1502[var1];

      for(int var4 = 0; var4 < this.verticesCount; ++var4) {
         int var5 = var2 * this.verticesZ[var4] + var3 * this.verticesX[var4] >> 16;
         this.verticesZ[var4] = var3 * this.verticesZ[var4] - var2 * this.verticesX[var4] >> 16;
         this.verticesX[var4] = var5;
      }

      this.method2686();
   }

   public void method2678() {
      for(int var1 = 0; var1 < this.verticesCount; ++var1) {
         int var2 = this.verticesZ[var1];
         this.verticesZ[var1] = this.verticesX[var1];
         this.verticesX[var1] = -var2;
      }

      this.method2686();
   }

   void method2686() {
      this.field1501 = null;
      this.field1489 = null;
      this.faceNormals = null;
      this.isBoundsCalculated = false;
   }

   static final int method2690(int var0, int var1) {
      var1 = (var0 & 127) * var1 >> 7;
      if (var1 < 2) {
         var1 = 2;
      } else if (var1 > 126) {
         var1 = 126;
      }

      return (var0 & 'ﾀ') + var1;
   }

   static final int method2718(int var0) {
      if (var0 < 2) {
         var0 = 2;
      } else if (var0 > 126) {
         var0 = 126;
      }

      return var0;
   }

   public static ModelData method2741(AbstractIndexCache var0, int var1, int var2) {
      byte[] var3 = var0.takeRecord(var1, var2);
      return var3 == null ? null : new ModelData(var3);
   }

   static void method2688(ModelData var0, ModelData var1, int var2, int var3, int var4, boolean var5) {
      var0.method2687();
      var0.method2700();
      var1.method2687();
      var1.method2700();
      ++field1496;
      int var6 = 0;
      int[] var7 = var1.verticesX;
      int var8 = var1.verticesCount;

      int var9;
      for(var9 = 0; var9 < var0.verticesCount; ++var9) {
         VertexNormal var10 = var0.field1501[var9];
         if (var10.field1235 != 0) {
            int var11 = var0.verticesY[var9] - var3;
            if (var11 <= var1.field1493) {
               int var12 = var0.verticesX[var9] - var2;
               if (var12 >= var1.field1494 && var12 <= var1.field1482) {
                  int var13 = var0.verticesZ[var9] - var4;
                  if (var13 >= var1.field1497 && var13 <= var1.field1478) {
                     for(int var14 = 0; var14 < var8; ++var14) {
                        VertexNormal var15 = var1.field1501[var14];
                        if (var12 == var7[var14] && var13 == var1.verticesZ[var14] && var11 == var1.verticesY[var14] && var15.field1235 != 0) {
                           if (var0.field1489 == null) {
                              var0.field1489 = new VertexNormal[var0.verticesCount];
                           }

                           if (var1.field1489 == null) {
                              var1.field1489 = new VertexNormal[var8];
                           }

                           VertexNormal var16 = var0.field1489[var9];
                           if (var16 == null) {
                              var16 = var0.field1489[var9] = new VertexNormal(var10);
                           }

                           VertexNormal var17 = var1.field1489[var14];
                           if (var17 == null) {
                              var17 = var1.field1489[var14] = new VertexNormal(var15);
                           }

                           var16.field1236 += var15.field1236;
                           var16.field1232 += var15.field1232;
                           var16.field1233 += var15.field1233;
                           var16.field1235 += var15.field1235;
                           var17.field1236 += var10.field1236;
                           var17.field1232 += var10.field1232;
                           var17.field1233 += var10.field1233;
                           var17.field1235 += var10.field1235;
                           ++var6;
                           field1498[var9] = field1496;
                           field1499[var14] = field1496;
                        }
                     }
                  }
               }
            }
         }
      }

      if (var6 >= 3 && var5) {
         for(var9 = 0; var9 < var0.faceCount; ++var9) {
            if (field1498[var0.indices1[var9]] == field1496 && field1498[var0.indices2[var9]] == field1496 && field1498[var0.indices3[var9]] == field1496) {
               if (var0.field1471 == null) {
                  var0.field1471 = new byte[var0.faceCount];
               }

               var0.field1471[var9] = 2;
            }
         }

         for(var9 = 0; var9 < var1.faceCount; ++var9) {
            if (field1496 == field1499[var1.indices1[var9]] && field1496 == field1499[var1.indices2[var9]] && field1496 == field1499[var1.indices3[var9]]) {
               if (var1.field1471 == null) {
                  var1.field1471 = new byte[var1.faceCount];
               }

               var1.field1471[var9] = 2;
            }
         }

      }
   }
}
