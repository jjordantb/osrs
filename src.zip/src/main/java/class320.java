public class class320 {
   static IndexCache field3912;
}
