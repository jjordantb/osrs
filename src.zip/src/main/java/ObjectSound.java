import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public final class ObjectSound extends Node {
   static int field576;
   static NodeDeque field577 = new NodeDeque();
   static int[] field573;
   static Player field589;
   int field578;
   int field585;
   int[] field584;
   int field574;
   class104 field590;
   int field581;
   int field588;
   int field583;
   int field580;
   int field582;
   int field575;
   ObjectDefinition obj;
   int field579;
   class104 field586;

   void method1084() {
      int var1 = this.field580;
      ObjectDefinition var2 = this.obj.transform();
      if (var2 != null) {
         this.field580 = var2.ambientSoundId;
         this.field579 = var2.int4 * 128;
         this.field582 = var2.int5;
         this.field583 = var2.int6;
         this.field584 = var2.field3436;
      } else {
         this.field580 = -1;
         this.field579 = 0;
         this.field582 = 0;
         this.field583 = 0;
         this.field584 = null;
      }

      if (var1 != this.field580 && this.field590 != null) {
         class10.field116.method1564(this.field590);
         this.field590 = null;
      }

   }

   public static final AbstractSoundSystem method1092(TaskHandler var0, int var1, int var2) {
      if (AbstractSoundSystem.field936 == 0) {
         throw new IllegalStateException();
      } else if (var1 >= 0 && var1 < 2) {
         if (var2 < 256) {
            var2 = 256;
         }

         try {
            AbstractSoundSystem var3 = ClientPreferences.field415.soundSystem();
            var3.ints = new int[(class5.field52 ? 2 : 1) * 256];
            var3.field926 = var2;
            var3.vmethod1645();
            var3.field924 = (var2 & -1024) + 1024;
            if (var3.field924 > 16384) {
               var3.field924 = 16384;
            }

            var3.open(var3.field924);
            if (class93.field1032 > 0 && Skills.field3314 == null) {
               Skills.field3314 = new SoundSystems();
               Login.field661 = Executors.newScheduledThreadPool(1);
               Login.field661.scheduleAtFixedRate(Skills.field3314, 0L, 10L, TimeUnit.MILLISECONDS);
            }

            if (Skills.field3314 != null) {
               if (Skills.field3314.soundSystems[var1] != null) {
                  throw new IllegalArgumentException();
               }

               Skills.field3314.soundSystems[var1] = var3;
            }

            return var3;
         } catch (Throwable var4) {
            return new AbstractSoundSystem();
         }
      } else {
         throw new IllegalArgumentException();
      }
   }

   static void method1093(int var0) {
      if (var0 == -1 && !Client.field2322) {
         WorldMapRegion.method1886();
      } else if (var0 != -1 && var0 != Client.field2321 && Client.field2320 != 0 && !Client.field2322) {
         class83.method1700(2, ServerPacket.field1995, var0, 0, Client.field2320, false);
      }

      Client.field2321 = var0;
   }

   static final void method1083(int var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      if (var2 >= 1 && var3 >= 1 && var2 <= 102 && var3 <= 102) {
         if (Client.field2091 && var0 != class31.field363) {
            return;
         }

         long var7 = 0L;
         boolean var9 = true;
         boolean var10 = false;
         boolean var11 = false;
         if (var1 == 0) {
            var7 = class243.field2904.method2251(var0, var2, var3);
         }

         if (var1 == 1) {
            var7 = class243.field2904.method2252(var0, var2, var3);
         }

         if (var1 == 2) {
            var7 = class243.field2904.method2253(var0, var2, var3);
         }

         if (var1 == 3) {
            var7 = class243.field2904.getFloorDecorationTag(var0, var2, var3);
         }

         int var12;
         if (0L != var7) {
            var12 = class243.field2904.getObjectFlags(var0, var2, var3, var7);
            int var14 = WidgetGroupParent.method1000(var7);
            int var15 = var12 & 31;
            int var16 = var12 >> 6 & 3;
            ObjectDefinition var13;
            if (var1 == 0) {
               class243.field2904.removeBoundaryObject(var0, var2, var3);
               var13 = class252.method4958(var14);
               if (var13.interactType != 0) {
                  Client.field2144[var0].method3187(var2, var3, var15, var16, var13.boolean1);
               }
            }

            if (var1 == 1) {
               class243.field2904.removeWallDecoration(var0, var2, var3);
            }

            if (var1 == 2) {
               class243.field2904.method2244(var0, var2, var3);
               var13 = class252.method4958(var14);
               if (var2 + var13.sizeX > 103 || var3 + var13.sizeX > 103 || var2 + var13.sizeY > 103 || var3 + var13.sizeY > 103) {
                  return;
               }

               if (var13.interactType != 0) {
                  Client.field2144[var0].method3188(var2, var3, var13.sizeX, var13.sizeY, var16, var13.boolean1);
               }
            }

            if (var1 == 3) {
               class243.field2904.removeFloorDecoration(var0, var2, var3);
               var13 = class252.method4958(var14);
               if (var13.interactType == 1) {
                  Client.field2144[var0].method3190(var2, var3);
               }
            }
         }

         if (var4 >= 0) {
            var12 = var0;
            if (var0 < 3 && (Tiles.field203[1][var2][var3] & 2) == 2) {
               var12 = var0 + 1;
            }

            GrandExchangeEvents.method1774(var0, var12, var2, var3, var4, var5, var6, class243.field2904, Client.field2144[var0]);
         }
      }

   }
}
