public class class303 {
   static Huffman field3768;

   static int method5813(int var0, Script var1, boolean var2) {
      if (var0 == 3300) {
         Interpreter.field467[++class31.field364 - 1] = Client.field2098;
         return 1;
      } else {
         int var3;
         int var4;
         if (var0 == 3301) {
            class31.field364 -= 2;
            var3 = Interpreter.field467[class31.field364];
            var4 = Interpreter.field467[class31.field364 + 1];
            Interpreter.field467[++class31.field364 - 1] = GrandExchangeOffer.method1272(var3, var4);
            return 1;
         } else if (var0 == 3302) {
            class31.field364 -= 2;
            var3 = Interpreter.field467[class31.field364];
            var4 = Interpreter.field467[class31.field364 + 1];
            Interpreter.field467[++class31.field364 - 1] = UrlRequest.getResponse(var3, var4);
            return 1;
         } else if (var0 == 3303) {
            class31.field364 -= 2;
            var3 = Interpreter.field467[class31.field364];
            var4 = Interpreter.field467[class31.field364 + 1];
            Interpreter.field467[++class31.field364 - 1] = Player.method857(var3, var4);
            return 1;
         } else if (var0 == 3304) {
            var3 = Interpreter.field467[--class31.field364];
            Interpreter.field467[++class31.field364 - 1] = class185.method3793(var3).size;
            return 1;
         } else if (var0 == 3305) {
            var3 = Interpreter.field467[--class31.field364];
            Interpreter.field467[++class31.field364 - 1] = Client.field2218[var3];
            return 1;
         } else if (var0 == 3306) {
            var3 = Interpreter.field467[--class31.field364];
            Interpreter.field467[++class31.field364 - 1] = Client.field2219[var3];
            return 1;
         } else if (var0 == 3307) {
            var3 = Interpreter.field467[--class31.field364];
            Interpreter.field467[++class31.field364 - 1] = Client.field2220[var3];
            return 1;
         } else {
            int var5;
            if (var0 == 3308) {
               var3 = class31.field363;
               var4 = (ObjectSound.field589.x >> 7) + class21.field230;
               var5 = (ObjectSound.field589.y >> 7) + class79.field902;
               Interpreter.field467[++class31.field364 - 1] = (var4 << 14) + var5 + (var3 << 28);
               return 1;
            } else if (var0 == 3309) {
               var3 = Interpreter.field467[--class31.field364];
               Interpreter.field467[++class31.field364 - 1] = var3 >> 14 & 16383;
               return 1;
            } else if (var0 == 3310) {
               var3 = Interpreter.field467[--class31.field364];
               Interpreter.field467[++class31.field364 - 1] = var3 >> 28;
               return 1;
            } else if (var0 == 3311) {
               var3 = Interpreter.field467[--class31.field364];
               Interpreter.field467[++class31.field364 - 1] = var3 & 16383;
               return 1;
            } else if (var0 == 3312) {
               Interpreter.field467[++class31.field364 - 1] = Client.field2090 ? 1 : 0;
               return 1;
            } else if (var0 == 3313) {
               class31.field364 -= 2;
               var3 = Interpreter.field467[class31.field364] + '耀';
               var4 = Interpreter.field467[class31.field364 + 1];
               Interpreter.field467[++class31.field364 - 1] = GrandExchangeOffer.method1272(var3, var4);
               return 1;
            } else if (var0 == 3314) {
               class31.field364 -= 2;
               var3 = Interpreter.field467[class31.field364] + '耀';
               var4 = Interpreter.field467[class31.field364 + 1];
               Interpreter.field467[++class31.field364 - 1] = UrlRequest.getResponse(var3, var4);
               return 1;
            } else if (var0 == 3315) {
               class31.field364 -= 2;
               var3 = Interpreter.field467[class31.field364] + '耀';
               var4 = Interpreter.field467[class31.field364 + 1];
               Interpreter.field467[++class31.field364 - 1] = Player.method857(var3, var4);
               return 1;
            } else if (var0 == 3316) {
               if (Client.field2255 >= 2) {
                  Interpreter.field467[++class31.field364 - 1] = Client.field2255;
               } else {
                  Interpreter.field467[++class31.field364 - 1] = 0;
               }

               return 1;
            } else if (var0 == 3317) {
               Interpreter.field467[++class31.field364 - 1] = Client.field2105;
               return 1;
            } else if (var0 == 3318) {
               Interpreter.field467[++class31.field364 - 1] = Client.field2134;
               return 1;
            } else if (var0 == 3321) {
               Interpreter.field467[++class31.field364 - 1] = Client.field2253;
               return 1;
            } else if (var0 == 3322) {
               Interpreter.field467[++class31.field364 - 1] = Client.field2294;
               return 1;
            } else if (var0 == 3323) {
               if (Client.field2306) {
                  Interpreter.field467[++class31.field364 - 1] = 1;
               } else {
                  Interpreter.field467[++class31.field364 - 1] = 0;
               }

               return 1;
            } else if (var0 == 3324) {
               Interpreter.field467[++class31.field364 - 1] = Client.field2103;
               return 1;
            } else if (var0 == 3325) {
               class31.field364 -= 4;
               var3 = Interpreter.field467[class31.field364];
               var4 = Interpreter.field467[class31.field364 + 1];
               var5 = Interpreter.field467[class31.field364 + 2];
               int var6 = Interpreter.field467[class31.field364 + 3];
               var3 += var4 << 14;
               var3 += var5 << 28;
               var3 += var6;
               Interpreter.field467[++class31.field364 - 1] = var3;
               return 1;
            } else {
               return 2;
            }
         }
      }
   }
}
