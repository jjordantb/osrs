import java.math.BigInteger;

public class class45 {
   static final BigInteger field524 = new BigInteger("10001", 16);
   static final BigInteger field520 = new BigInteger("83ff79a3e258b99ead1a70e1049883e78e513c4cdec538d8da9483879a9f81689c0c7d146d7b82b52d05cf26132b1cda5930eeef894e4ccf3d41eebc3aabe54598c4ca48eb5a31d736bfeea17875a35558b9e3fcd4aebe2a9cc970312a477771b36e173dc2ece6001ab895c553e2770de40073ea278026f36961c94428d8d7db", 16);

   static int method1022() {
      return 11;
   }

   public static VarbitDefinition method1021(int var0) {
      VarbitDefinition var1 = (VarbitDefinition)VarbitDefinition.field3500.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = VarbitDefinition.field3504.takeRecord(14, var0);
         var1 = new VarbitDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         VarbitDefinition.field3500.put(var1, (long)var0);
         return var1;
      }
   }
}
