public final class WallDecoration {
   int yOffset;
   int int7;
   int y;
   int tileHeight;
   public long tag = 0L;
   int xOffset;
   public Entity entity2;
   int flags = 0;
   int orientation;
   int x;
   public Entity entity1;

   static int method2958(World var0, World var1, int var2, boolean var3) {
      if (var2 == 1) {
         int var4 = var0.population;
         int var5 = var1.population;
         if (!var3) {
            if (var4 == -1) {
               var4 = 2001;
            }

            if (var5 == -1) {
               var5 = 2001;
            }
         }

         return var4 - var5;
      } else if (var2 == 2) {
         return var0.location - var1.location;
      } else if (var2 == 3) {
         if (var0.activity.equals("-")) {
            if (var1.activity.equals("-")) {
               return 0;
            } else {
               return var3 ? -1 : 1;
            }
         } else if (var1.activity.equals("-")) {
            return var3 ? 1 : -1;
         } else {
            return var0.activity.compareTo(var1.activity);
         }
      } else if (var2 == 4) {
         return var0.method696() ? (var1.method696() ? 0 : 1) : (var1.method696() ? -1 : 0);
      } else if (var2 == 5) {
         return var0.method699() ? (var1.method699() ? 0 : 1) : (var1.method699() ? -1 : 0);
      } else if (var2 == 6) {
         return var0.method652() ? (var1.method652() ? 0 : 1) : (var1.method652() ? -1 : 0);
      } else if (var2 == 7) {
         return var0.method649() ? (var1.method649() ? 0 : 1) : (var1.method649() ? -1 : 0);
      } else {
         return var0.id - var1.id;
      }
   }

   public static void method2959(int var0) {
      if (class219.field2568 != 0) {
         class321.field3913 = var0;
      } else {
         class205.field2492.method4393(var0);
      }

   }
}
