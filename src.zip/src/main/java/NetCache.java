import java.util.zip.CRC32;

public class NetCache {
   static CRC32 field2844 = new CRC32();
   static int field2834 = 0;
   static int field2832 = 0;
   static long field2830;
   public static AbstractSocket field2833;
   static int field2846 = 0;
   static int field2837 = 0;
   static IndexCache[] field2845 = new IndexCache[256];
   static NodeHashTable field2831 = new NodeHashTable(32);
   static int field2839 = 0;
   static NodeHashTable field2836 = new NodeHashTable(4096);
   static NodeHashTable field2838 = new NodeHashTable(4096);
   static NodeHashTable field2840 = new NodeHashTable(4096);
   static int field2842 = 0;
   public static int field2847 = 0;
   static Buffer field2841;
   static DualNodeDeque field2835 = new DualNodeDeque();
   static Buffer field2828 = new Buffer(8);
   public static int field2848 = 0;
   static byte field2849 = 0;

   static int method4809(int var0) {
      return (int)((Math.log((double)var0) / Interpreter.field478 - 7.0D) * 256.0D);
   }
}
