import java.io.IOException;

public final class Npc extends Actor {
   NpcDefinition definition;

   protected final Model getModel() {
      if (this.definition == null) {
         return null;
      } else {
         SequenceDefinition var1 = super.sequence != -1 && super.sequenceDelay == 0 ? WorldMapCacheName.method547(super.sequence) : null;
         SequenceDefinition var2 = super.movementSequence != -1 && (super.idleSequence != super.movementSequence || var1 == null) ? WorldMapCacheName.method547(super.movementSequence) : null;
         Model var3 = this.definition.getModel(var1, super.sequenceFrame, var2, super.movementFrame);
         if (var3 == null) {
            return null;
         } else {
            var3.calculateBoundsCylinder();
            super.defaultHeight = var3.height;
            if (super.spotAnimation != -1 && super.spotAnimationFrame != -1) {
               Model var4 = IndexStoreActionHandler.method4937(super.spotAnimation).getModel(super.spotAnimationFrame);
               if (var4 != null) {
                  var4.offsetBy(0, -super.heightOffset, 0);
                  Model[] var5 = new Model[]{var3, var4};
                  var3 = new Model(var5, 2);
               }
            }

            if (this.definition.size == 1) {
               var3.isSingleTile = true;
            }

            return var3;
         }
      }
   }

   final void method984(int var1, byte var2) {
      int var3 = super.pathX[0];
      int var4 = super.pathY[0];
      if (var1 == 0) {
         --var3;
         ++var4;
      }

      if (var1 == 1) {
         ++var4;
      }

      if (var1 == 2) {
         ++var3;
         ++var4;
      }

      if (var1 == 3) {
         --var3;
      }

      if (var1 == 4) {
         ++var3;
      }

      if (var1 == 5) {
         --var3;
         --var4;
      }

      if (var1 == 6) {
         --var4;
      }

      if (var1 == 7) {
         ++var3;
         --var4;
      }

      if (super.sequence != -1 && WorldMapCacheName.method547(super.sequence).field3480 == 1) {
         super.sequence = -1;
      }

      if (super.pathLength < 9) {
         ++super.pathLength;
      }

      for(int var5 = super.pathLength; var5 > 0; --var5) {
         super.pathX[var5] = super.pathX[var5 - 1];
         super.pathY[var5] = super.pathY[var5 - 1];
         super.pathTraversed[var5] = super.pathTraversed[var5 - 1];
      }

      super.pathX[0] = var3;
      super.pathY[0] = var4;
      super.pathTraversed[0] = var2;
   }

   final boolean isVisible() {
      return this.definition != null;
   }

   final void method996(int var1, int var2, boolean var3) {
      if (super.sequence != -1 && WorldMapCacheName.method547(super.sequence).field3480 == 1) {
         super.sequence = -1;
      }

      if (!var3) {
         int var4 = var1 - super.pathX[0];
         int var5 = var2 - super.pathY[0];
         if (var4 >= -8 && var4 <= 8 && var5 >= -8 && var5 <= 8) {
            if (super.pathLength < 9) {
               ++super.pathLength;
            }

            for(int var6 = super.pathLength; var6 > 0; --var6) {
               super.pathX[var6] = super.pathX[var6 - 1];
               super.pathY[var6] = super.pathY[var6 - 1];
               super.pathTraversed[var6] = super.pathTraversed[var6 - 1];
            }

            super.pathX[0] = var1;
            super.pathY[0] = var2;
            super.pathTraversed[0] = 1;
            return;
         }
      }

      super.pathLength = 0;
      super.field297 = 0;
      super.field293 = 0;
      super.pathX[0] = var1;
      super.pathY[0] = var2;
      super.x = super.size * 64 + super.pathX[0] * 128;
      super.y = super.size * 64 + super.pathY[0] * 128;
   }

   public static int method983(byte[] var0, int var1, int var2) {
      int var3 = -1;

      for(int var4 = var1; var4 < var2; ++var4) {
         var3 = var3 >>> 8 ^ Buffer.field2442[(var3 ^ var0[var4]) & 255];
      }

      var3 = ~var3;
      return var3;
   }

   static final void method997(boolean var0) {
      class162.method3077();
      ++Client.field2133.field709;
      if (Client.field2133.field709 >= 50 || var0) {
         Client.field2133.field709 = 0;
         if (!Client.field2135 && Client.field2133.getSocket() != null) {
            PacketBufferNode var1 = FaceNormal.method2884(ClientPacket.field1853, Client.field2133.isaacCipher);
            Client.field2133.method1281(var1);

            try {
               Client.field2133.method1275();
            } catch (IOException var3) {
               Client.field2135 = true;
            }
         }

      }
   }
}
