import java.util.Hashtable;

public class class162 {
   static Hashtable field1774 = new Hashtable(16);
   static boolean field1777 = false;

   static final void method3077() {
      if (class57.field642 != null) {
         class57.field642.method1638();
      }

      if (Client.field2325 != null) {
         Client.field2325.method1638();
      }

   }

   static final void method3075(class158 var0) {
      PacketBuffer var1 = Client.field2133.packetBuffer;
      int var2;
      int var3;
      int var4;
      int var5;
      int var6;
      int var7;
      if (class158.field1737 == var0) {
         var2 = var1.method3913();
         var3 = var1.method4025();
         var4 = var1.method3950();
         var5 = var1.readUnsignedByte();
         var6 = (var5 >> 4 & 7) + class185.field2382;
         var7 = (var5 & 7) + HealthBar.field343;
         if (var6 >= 0 && var7 >= 0 && var6 < 104 && var7 < 104) {
            var6 = var6 * 128 + 64;
            var7 = var7 * 128 + 64;
            GraphicsObject var39 = new GraphicsObject(var2, class31.field363, var6, var7, MilliClock.method2923(var6, var7, class31.field363) - var3, var4, Client.field2098);
            Client.field2154.addFirst(var39);
         }

      } else {
         int var31;
         if (class158.field1740 == var0) {
            var2 = var1.method4033();
            var3 = var2 >> 2;
            var4 = var2 & 3;
            var5 = Client.field2147[var3];
            var6 = var1.method4033();
            var7 = (var6 >> 4 & 7) + class185.field2382;
            var31 = (var6 & 7) + HealthBar.field343;
            if (var7 >= 0 && var31 >= 0 && var7 < 104 && var31 < 104) {
               class251.method4943(class31.field363, var7, var31, var5, -1, var3, var4, 0, -1);
            }

         } else if (class158.field1741 == var0) {
            var2 = var1.method3949();
            var3 = var1.method3934();
            var4 = var1.method3949();
            var5 = var1.method4025();
            var6 = (var5 >> 4 & 7) + class185.field2382;
            var7 = (var5 & 7) + HealthBar.field343;
            if (var6 >= 0 && var7 >= 0 && var6 < 104 && var7 < 104) {
               NodeDeque var8 = Client.field2272[class31.field363][var6][var7];
               if (var8 != null) {
                  for(GroundItem var9 = (GroundItem)var8.last(); var9 != null; var9 = (GroundItem)var8.previous()) {
                     if ((var2 & 32767) == var9.id && var4 == var9.quantity) {
                        var9.quantity = var3;
                        break;
                     }
                  }

                  class240.method4819(var6, var7);
               }
            }

         } else {
            int var32;
            if (class158.field1743 == var0) {
               var2 = var1.method4025();
               var3 = (var2 >> 4 & 7) + class185.field2382;
               var4 = (var2 & 7) + HealthBar.field343;
               var5 = var1.method4033();
               var6 = var5 >> 2;
               var7 = var5 & 3;
               var31 = Client.field2147[var6];
               var32 = var1.method3950();
               if (var3 >= 0 && var4 >= 0 && var3 < 104 && var4 < 104) {
                  class251.method4943(class31.field363, var3, var4, var31, var32, var6, var7, 0, -1);
               }

            } else {
               int var10;
               if (class158.field1739 == var0) {
                  var2 = var1.readUnsignedByte();
                  var3 = (var2 >> 4 & 7) + class185.field2382;
                  var4 = (var2 & 7) + HealthBar.field343;
                  var5 = var1.method4033();
                  var6 = var1.method4025();
                  var7 = var6 >> 4 & 15;
                  var31 = var6 & 7;
                  var32 = var1.method3934();
                  if (var3 >= 0 && var4 >= 0 && var3 < 104 && var4 < 104) {
                     var10 = var7 + 1;
                     if (ObjectSound.field589.pathX[0] >= var3 - var10 && ObjectSound.field589.pathX[0] <= var10 + var3 && ObjectSound.field589.pathY[0] >= var4 - var10 && ObjectSound.field589.pathY[0] <= var4 + var10 && Client.field2324 != 0 && var31 > 0 && Client.field2348 < 50) {
                        Client.field2327[Client.field2348] = var32;
                        Client.field2328[Client.field2348] = var31;
                        Client.field2236[Client.field2348] = var5;
                        Client.field2153[Client.field2348] = null;
                        Client.field2330[Client.field2348] = var7 + (var4 << 8) + (var3 << 16);
                        ++Client.field2348;
                     }
                  }
               }

               int var40;
               if (class158.field1738 == var0) {
                  var2 = var1.method4033();
                  var3 = var2 >> 2;
                  var4 = var2 & 3;
                  var5 = Client.field2147[var3];
                  var6 = var1.readUnsignedByteNegate();
                  var7 = (var6 >> 4 & 7) + class185.field2382;
                  var31 = (var6 & 7) + HealthBar.field343;
                  var32 = var1.method3913();
                  if (var7 >= 0 && var31 >= 0 && var7 < 103 && var31 < 103) {
                     if (var5 == 0) {
                        BoundaryObject var33 = class243.field2904.getBoundaryObject(class31.field363, var7, var31);
                        if (var33 != null) {
                           var40 = WidgetGroupParent.method1000(var33.tag);
                           if (var3 == 2) {
                              var33.entity1 = new DynamicObject(var40, 2, var4 + 4, class31.field363, var7, var31, var32, false, var33.entity1);
                              var33.entity2 = new DynamicObject(var40, 2, var4 + 1 & 3, class31.field363, var7, var31, var32, false, var33.entity2);
                           } else {
                              var33.entity1 = new DynamicObject(var40, var3, var4, class31.field363, var7, var31, var32, false, var33.entity1);
                           }
                        }
                     }

                     if (var5 == 1) {
                        WallDecoration var43 = class243.field2904.getWallDecoration(class31.field363, var7, var31);
                        if (var43 != null) {
                           var40 = WidgetGroupParent.method1000(var43.tag);
                           if (var3 != 4 && var3 != 5) {
                              if (var3 == 6) {
                                 var43.entity1 = new DynamicObject(var40, 4, var4 + 4, class31.field363, var7, var31, var32, false, var43.entity1);
                              } else if (var3 == 7) {
                                 var43.entity1 = new DynamicObject(var40, 4, (var4 + 2 & 3) + 4, class31.field363, var7, var31, var32, false, var43.entity1);
                              } else if (var3 == 8) {
                                 var43.entity1 = new DynamicObject(var40, 4, var4 + 4, class31.field363, var7, var31, var32, false, var43.entity1);
                                 var43.entity2 = new DynamicObject(var40, 4, (var4 + 2 & 3) + 4, class31.field363, var7, var31, var32, false, var43.entity2);
                              }
                           } else {
                              var43.entity1 = new DynamicObject(var40, 4, var4, class31.field363, var7, var31, var32, false, var43.entity1);
                           }
                        }
                     }

                     if (var5 == 2) {
                        GameObject var44 = class243.field2904.method2249(class31.field363, var7, var31);
                        if (var3 == 11) {
                           var3 = 10;
                        }

                        if (var44 != null) {
                           var44.entity = new DynamicObject(WidgetGroupParent.method1000(var44.tag), var3, var4, class31.field363, var7, var31, var32, false, var44.entity);
                        }
                     }

                     if (var5 == 3) {
                        FloorDecoration var45 = class243.field2904.getFloorDecoration(class31.field363, var7, var31);
                        if (var45 != null) {
                           var45.entity = new DynamicObject(WidgetGroupParent.method1000(var45.tag), 22, var4, class31.field363, var7, var31, var32, false, var45.entity);
                        }
                     }
                  }

               } else {
                  int var12;
                  byte var13;
                  int var14;
                  if (class158.field1734 == var0) {
                     var2 = var1.method4033() * 4;
                     var3 = var1.method3913();
                     var4 = var1.method3950();
                     var5 = var1.method4033() * 4;
                     var6 = var1.method3952();
                     var7 = var1.readUnsignedByte();
                     var31 = var1.method4033();
                     var32 = var1.method3949();
                     var10 = var1.method4025();
                     var40 = (var10 >> 4 & 7) + class185.field2382;
                     var12 = (var10 & 7) + HealthBar.field343;
                     var13 = var1.method4110();
                     byte var41 = var1.method3944();
                     var14 = var41 + var40;
                     int var42 = var13 + var12;
                     if (var40 >= 0 && var12 >= 0 && var40 < 104 && var12 < 104 && var14 >= 0 && var42 >= 0 && var14 < 104 && var42 < 104 && var4 != 65535) {
                        var40 = var40 * 128 + 64;
                        var12 = var12 * 128 + 64;
                        var14 = var14 * 128 + 64;
                        var42 = var42 * 128 + 64;
                        Projectile var15 = new Projectile(var4, class31.field363, var40, var12, MilliClock.method2923(var40, var12, class31.field363) - var5, var32 + Client.field2098, var3 + Client.field2098, var7, var31, var6, var2);
                        var15.setDestination(var14, var42, MilliClock.method2923(var14, var42, class31.field363) - var2, var32 + Client.field2098);
                        Client.field2216.addFirst(var15);
                     }

                  } else {
                     GroundItem var35;
                     if (class158.field1735 == var0) {
                        var2 = var1.method4025();
                        var3 = (var2 >> 4 & 7) + class185.field2382;
                        var4 = (var2 & 7) + HealthBar.field343;
                        var5 = var1.method3934();
                        if (var3 >= 0 && var4 >= 0 && var3 < 104 && var4 < 104) {
                           NodeDeque var34 = Client.field2272[class31.field363][var3][var4];
                           if (var34 != null) {
                              for(var35 = (GroundItem)var34.last(); var35 != null; var35 = (GroundItem)var34.previous()) {
                                 if ((var5 & 32767) == var35.id) {
                                    var35.remove();
                                    break;
                                 }
                              }

                              if (var34.last() == null) {
                                 Client.field2272[class31.field363][var3][var4] = null;
                              }

                              class240.method4819(var3, var4);
                           }
                        }

                     } else {
                        if (class158.field1736 == var0) {
                           byte var37 = var1.method3944();
                           var3 = var1.method3934();
                           byte var38 = var1.method3944();
                           var5 = var1.method3950();
                           var6 = var1.method3913();
                           var7 = var1.method4025();
                           var31 = var7 >> 2;
                           var32 = var7 & 3;
                           var10 = Client.field2147[var31];
                           byte var11 = var1.method4110();
                           var12 = var1.method3949();
                           var13 = var1.method3944();
                           var14 = var1.readUnsignedByteNegate();
                           int var36 = (var14 >> 4 & 7) + class185.field2382;
                           int var16 = (var14 & 7) + HealthBar.field343;
                           Object var17;
                           if (var12 == Client.field2190) {
                              var17 = ObjectSound.field589;
                           } else {
                              var17 = Client.field2141[var12];
                           }

                           if (var17 != null) {
                              ObjectDefinition var18 = class252.method4958(var5);
                              int var19;
                              int var20;
                              if (var32 != 1 && var32 != 3) {
                                 var19 = var18.sizeX;
                                 var20 = var18.sizeY;
                              } else {
                                 var19 = var18.sizeY;
                                 var20 = var18.sizeX;
                              }

                              int var21 = var36 + (var19 >> 1);
                              int var22 = var36 + (var19 + 1 >> 1);
                              int var23 = var16 + (var20 >> 1);
                              int var24 = var16 + (var20 + 1 >> 1);
                              int[][] var25 = Tiles.field217[class31.field363];
                              int var26 = var25[var22][var24] + var25[var22][var23] + var25[var21][var23] + var25[var21][var24] >> 2;
                              int var27 = (var36 << 7) + (var19 << 6);
                              int var28 = (var16 << 7) + (var20 << 6);
                              Model var29 = var18.getModel(var31, var32, var25, var27, var26, var28);
                              if (var29 != null) {
                                 class251.method4943(class31.field363, var36, var16, var10, -1, 0, 0, var6 + 1, var3 + 1);
                                 ((Player)var17).animationCycleStart = var6 + Client.field2098;
                                 ((Player)var17).animationCycleEnd = var3 + Client.field2098;
                                 ((Player)var17).model0 = var29;
                                 ((Player)var17).field426 = var36 * 128 + var19 * 64;
                                 ((Player)var17).field422 = var16 * 128 + var20 * 64;
                                 ((Player)var17).tileHeight2 = var26;
                                 byte var30;
                                 if (var37 > var13) {
                                    var30 = var37;
                                    var37 = var13;
                                    var13 = var30;
                                 }

                                 if (var11 > var38) {
                                    var30 = var11;
                                    var11 = var38;
                                    var38 = var30;
                                 }

                                 ((Player)var17).field418 = var36 + var37;
                                 ((Player)var17).field431 = var36 + var13;
                                 ((Player)var17).field416 = var11 + var16;
                                 ((Player)var17).field433 = var38 + var16;
                              }
                           }
                        }

                        if (class158.field1747 == var0) {
                           var2 = var1.method3950();
                           var3 = var1.method3934();
                           var4 = var1.method4025();
                           var5 = (var4 >> 4 & 7) + class185.field2382;
                           var6 = (var4 & 7) + HealthBar.field343;
                           if (var5 >= 0 && var6 >= 0 && var5 < 104 && var6 < 104) {
                              var35 = new GroundItem();
                              var35.id = var3;
                              var35.quantity = var2;
                              if (Client.field2272[class31.field363][var5][var6] == null) {
                                 Client.field2272[class31.field363][var5][var6] = new NodeDeque();
                              }

                              Client.field2272[class31.field363][var5][var6].addFirst(var35);
                              class240.method4819(var5, var6);
                           }

                        }
                     }
                  }
               }
            }
         }
      }
   }

   static final void method3079(int var0) {
      if (class196.method4189(var0)) {
         Widget[] var1 = UserComparator3.field1708[var0];

         for(int var2 = 0; var2 < var1.length; ++var2) {
            Widget var3 = var1[var2];
            if (var3 != null) {
               var3.modelFrame = 0;
               var3.modelFrameCycle = 0;
            }
         }

      }
   }
}
