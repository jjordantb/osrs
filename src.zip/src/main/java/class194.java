import java.util.Iterator;

public class class194 implements Iterator {
   Node field2447 = null;
   IterableNodeDeque field2449;
   Node field2448;

   class194(IterableNodeDeque var1) {
      this.field2449 = var1;
      this.field2448 = this.field2449.sentinel.previous;
      this.field2447 = null;
   }

   public void remove() {
      this.field2447.remove();
      this.field2447 = null;
   }

   public boolean hasNext() {
      return this.field2449.sentinel != this.field2448;
   }

   public Object next() {
      Node var1 = this.field2448;
      if (var1 == this.field2449.sentinel) {
         var1 = null;
         this.field2448 = null;
      } else {
         this.field2448 = var1.previous;
      }

      this.field2447 = var1;
      return var1;
   }
}
