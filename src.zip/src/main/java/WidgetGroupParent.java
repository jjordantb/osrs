public class WidgetGroupParent extends Node {
   boolean keep = false;
   int group;
   int type;

   public static void method1002() {
      PlayerAppearance.field2548.clear();
   }

   public static int method1000(long var0) {
      return (int)(var0 >>> 17 & 4294967295L);
   }

   static void method998(int var0, int var1) {
      int var2 = NetSocket.field1950.stringWidth("Choose Option");

      int var3;
      int var4;
      for(var3 = 0; var3 < Client.field2223; ++var3) {
         var4 = NetSocket.field1950.stringWidth(class6.method184(var3));
         if (var4 > var2) {
            var2 = var4;
         }
      }

      var2 += 8;
      var3 = Client.field2223 * 15 + 22;
      var4 = var0 - var2 / 2;
      if (var4 + var2 > FriendSystem.field379) {
         var4 = FriendSystem.field379 - var2;
      }

      if (var4 < 0) {
         var4 = 0;
      }

      int var5 = var1;
      if (var1 + var3 > UserComparator8.field1678) {
         var5 = UserComparator8.field1678 - var3;
      }

      if (var5 < 0) {
         var5 = 0;
      }

      NetSocket.field1951 = var4;
      Script.field1051 = var5;
      class39.field491 = var2;
      ModelData0.field1555 = Client.field2223 * 15 + 22;
   }

   static final void method1001(int var0, int var1, int var2, int var3, Sprite var4, SpriteMask var5) {
      if (var4 != null) {
         int var6 = Client.field2101 & 2047;
         int var7 = var3 * var3 + var2 * var2;
         if (var7 <= 6400) {
            int var8 = Rasterizer3D.field1446[var6];
            int var9 = Rasterizer3D.field1453[var6];
            int var10 = var9 * var2 + var3 * var8 >> 16;
            int var11 = var3 * var9 - var8 * var2 >> 16;
            if (var7 > 2500) {
               var4.method6363(var10 + var5.width / 2 - var4.width / 2, var5.height / 2 - var11 - var4.height / 2, var0, var1, var5.width, var5.height, var5.xStarts, var5.xWidths);
            } else {
               var4.method6348(var0 + var10 + var5.width / 2 - var4.width / 2, var5.height / 2 + var1 - var11 - var4.height / 2);
            }

         }
      }
   }

   static String method999(String var0, boolean var1) {
      String var2 = var1 ? "https://" : "http://";
      if (Client.field2088 == 1) {
         var0 = var0 + "-wtrc";
      } else if (Client.field2088 == 2) {
         var0 = var0 + "-wtqa";
      } else if (Client.field2088 == 3) {
         var0 = var0 + "-wtwip";
      } else if (Client.field2088 == 5) {
         var0 = var0 + "-wti";
      } else if (Client.field2088 == 4) {
         var0 = "local";
      }

      String var3 = "";
      if (class57.field644 != null) {
         var3 = "/p=" + class57.field644;
      }

      String var4 = "runescape.com";
      return var2 + var0 + "." + var4 + "/l=" + Client.field2228 + "/a=" + Client.field2093 + var3 + "/";
   }
}
