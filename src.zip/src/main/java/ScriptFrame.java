import java.io.File;

public class ScriptFrame {
   static File field171;
   static MenuAction field172;
   int[] intLocals;
   Script script;
   String[] stringLocals;
   int pc = -1;

   public static class291 method462(int var0) {
      class291[] var1 = new class291[]{class291.field3712, class291.field3714, class291.field3711};
      class291[] var2 = var1;

      for(int var3 = 0; var3 < var2.length; ++var3) {
         class291 var4 = var2[var3];
         if (var0 == var4.field3713) {
            return var4;
         }
      }

      return null;
   }

   public static void method464() {
      SequenceDefinition.field3466.clear();
      SequenceDefinition.field3467.clear();
   }

   static final boolean method463(Model var0, int var1, int var2, int var3) {
      boolean var4 = ViewportMouse.field1506;
      if (!var4) {
         return false;
      } else {
         int var5;
         int var6;
         int var7;
         int var8;
         int var11;
         int var12;
         int var13;
         int var16;
         int var17;
         if (!ViewportMouse.field1503) {
            var5 = Scene.field1164;
            var6 = Scene.field1191;
            var7 = Scene.field1192;
            var8 = Scene.field1193;
            byte var9 = 50;
            short var10 = 3500;
            var11 = (ViewportMouse.field1507 - Rasterizer3D.field1438) * var9 / Rasterizer3D.field1440;
            var12 = (ViewportMouse.field1510 - Rasterizer3D.field1429) * var9 / Rasterizer3D.field1440;
            var13 = (ViewportMouse.field1507 - Rasterizer3D.field1438) * var10 / Rasterizer3D.field1440;
            int var14 = (ViewportMouse.field1510 - Rasterizer3D.field1429) * var10 / Rasterizer3D.field1440;
            int var15 = Rasterizer3D.method2613(var12, var9, var6, var5);
            var16 = Rasterizer3D.method2627(var12, var9, var6, var5);
            var12 = var15;
            var15 = Rasterizer3D.method2613(var14, var10, var6, var5);
            var17 = Rasterizer3D.method2627(var14, var10, var6, var5);
            var14 = var15;
            var15 = Rasterizer3D.method2603(var11, var16, var8, var7);
            var16 = Rasterizer3D.method2612(var11, var16, var8, var7);
            var11 = var15;
            var15 = Rasterizer3D.method2603(var13, var17, var8, var7);
            var17 = Rasterizer3D.method2612(var13, var17, var8, var7);
            ViewportMouse.field1504 = (var11 + var15) / 2;
            class34.field403 = (var14 + var12) / 2;
            class31.field369 = (var17 + var16) / 2;
            NetFileRequest.field3267 = (var15 - var11) / 2;
            Varcs.field635 = (var14 - var12) / 2;
            GroundItemPile.field1455 = (var17 - var16) / 2;
            Friend.field3823 = Math.abs(NetFileRequest.field3267);
            SoundSystemProvider.field101 = Math.abs(Varcs.field635);
            FriendsList.field3734 = Math.abs(GroundItemPile.field1455);
         }

         var5 = var0.xMid + var1;
         var6 = var2 + var0.yMid;
         var7 = var3 + var0.zMid;
         var8 = var0.xMidOffset;
         var16 = var0.yMidOffset;
         var17 = var0.zMidOffset;
         var11 = ViewportMouse.field1504 - var5;
         var12 = class34.field403 - var6;
         var13 = class31.field369 - var7;
         if (Math.abs(var11) > var8 + Friend.field3823) {
            return false;
         } else if (Math.abs(var12) > var16 + SoundSystemProvider.field101) {
            return false;
         } else if (Math.abs(var13) > var17 + FriendsList.field3734) {
            return false;
         } else if (Math.abs(var13 * Varcs.field635 - var12 * GroundItemPile.field1455) > var17 * SoundSystemProvider.field101 + var16 * FriendsList.field3734) {
            return false;
         } else if (Math.abs(var11 * GroundItemPile.field1455 - var13 * NetFileRequest.field3267) > var17 * Friend.field3823 + var8 * FriendsList.field3734) {
            return false;
         } else {
            return Math.abs(var12 * NetFileRequest.field3267 - var11 * Varcs.field635) <= var16 * Friend.field3823 + var8 * SoundSystemProvider.field101;
         }
      }
   }
}
