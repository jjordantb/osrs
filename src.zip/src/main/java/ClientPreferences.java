import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class ClientPreferences {
   static int field406;
   public static AbstractSoundSystemProvider field415;
   static int field409 = 6;
   boolean hideUsername = false;
   int windowMode = 1;
   boolean roofsHidden;
   String rememberedUsername = null;
   boolean titleMusicDisabled;
   LinkedHashMap parameters = new LinkedHashMap();

   ClientPreferences() {
      this.method798(true);
   }

   ClientPreferences(Buffer var1) {
      if (var1 != null && var1.array != null) {
         int var2 = var1.readUnsignedByte();
         if (var2 >= 0 && var2 <= field409) {
            if (var1.readUnsignedByte() == 1) {
               this.roofsHidden = true;
            }

            if (var2 > 1) {
               this.titleMusicDisabled = var1.readUnsignedByte() == 1;
            }

            if (var2 > 3) {
               this.windowMode = var1.readUnsignedByte();
            }

            if (var2 > 2) {
               int var3 = var1.readUnsignedByte();

               for(int var4 = 0; var4 < var3; ++var4) {
                  int var5 = var1.readInt();
                  int var6 = var1.readInt();
                  this.parameters.put(var5, var6);
               }
            }

            if (var2 > 4) {
               this.rememberedUsername = var1.method3919();
            }

            if (var2 > 5) {
               this.hideUsername = var1.readBoolean();
            }
         } else {
            this.method798(true);
         }
      } else {
         this.method798(true);
      }

   }

   void method798(boolean var1) {
   }

   Buffer toBuffer() {
      Buffer var1 = new Buffer(100);
      var1.writeByte(field409);
      var1.writeByte(this.roofsHidden ? 1 : 0);
      var1.writeByte(this.titleMusicDisabled ? 1 : 0);
      var1.writeByte(this.windowMode);
      var1.writeByte(this.parameters.size());
      Iterator var2 = this.parameters.entrySet().iterator();

      while(var2.hasNext()) {
         Entry var3 = (Entry)var2.next();
         var1.writeInt(((Integer)var3.getKey()).intValue());
         var1.writeInt(((Integer)var3.getValue()).intValue());
      }

      var1.writeStringCp1252NullTerminated(this.rememberedUsername != null ? this.rememberedUsername : "");
      var1.writeBoolean(this.hideUsername);
      return var1;
   }

   static void method804(GameShell var0) {
      int var4;
      if (Login.field682) {
         if (MouseHandler.field158 == 1 || !WorldMapSection0.field1101 && MouseHandler.field158 == 4) {
            int var1 = Login.field649 + 280;
            if (MouseHandler.field159 >= var1 && MouseHandler.field159 <= var1 + 14 && MouseHandler.field148 >= 4 && MouseHandler.field148 <= 18) {
               class12.method366(0, 0);
            } else if (MouseHandler.field159 >= var1 + 15 && MouseHandler.field159 <= var1 + 80 && MouseHandler.field148 >= 4 && MouseHandler.field148 <= 18) {
               class12.method366(0, 1);
            } else {
               int var2 = Login.field649 + 390;
               if (MouseHandler.field159 >= var2 && MouseHandler.field159 <= var2 + 14 && MouseHandler.field148 >= 4 && MouseHandler.field148 <= 18) {
                  class12.method366(1, 0);
               } else if (MouseHandler.field159 >= var2 + 15 && MouseHandler.field159 <= var2 + 80 && MouseHandler.field148 >= 4 && MouseHandler.field148 <= 18) {
                  class12.method366(1, 1);
               } else {
                  int var17 = Login.field649 + 500;
                  if (MouseHandler.field159 >= var17 && MouseHandler.field159 <= var17 + 14 && MouseHandler.field148 >= 4 && MouseHandler.field148 <= 18) {
                     class12.method366(2, 0);
                  } else if (MouseHandler.field159 >= var17 + 15 && MouseHandler.field159 <= var17 + 80 && MouseHandler.field148 >= 4 && MouseHandler.field148 <= 18) {
                     class12.method366(2, 1);
                  } else {
                     var4 = Login.field649 + 610;
                     if (MouseHandler.field159 >= var4 && MouseHandler.field159 <= var4 + 14 && MouseHandler.field148 >= 4 && MouseHandler.field148 <= 18) {
                        class12.method366(3, 0);
                     } else if (MouseHandler.field159 >= var4 + 15 && MouseHandler.field159 <= var4 + 80 && MouseHandler.field148 >= 4 && MouseHandler.field148 <= 18) {
                        class12.method366(3, 1);
                     } else if (MouseHandler.field159 >= Login.field649 + 708 && MouseHandler.field148 >= 4 && MouseHandler.field159 <= Login.field649 + 708 + 50 && MouseHandler.field148 <= 20) {
                        Login.field682 = false;
                        Login.field651.method6368(Login.field649, 0);
                        Login.field652.method6368(Login.field649 + 382, 0);
                        VarbitDefinition.field3505.method6304(Login.field649 + 382 - VarbitDefinition.field3505.subWidth / 2, 18);
                     } else if (Login.field670 != -1) {
                        World var5 = World.field353[Login.field670];
                        UrlRequest.method2877(var5);
                        Login.field682 = false;
                        Login.field651.method6368(Login.field649, 0);
                        Login.field652.method6368(Login.field649 + 382, 0);
                        VarbitDefinition.field3505.method6304(Login.field649 + 382 - VarbitDefinition.field3505.subWidth / 2, 18);
                     }
                  }
               }
            }
         }

      } else {
         if ((MouseHandler.field158 == 1 || !WorldMapSection0.field1101 && MouseHandler.field158 == 4) && MouseHandler.field159 >= Login.field649 + 765 - 50 && MouseHandler.field148 >= 453) {
            GameShell.field72.titleMusicDisabled = !GameShell.field72.titleMusicDisabled;
            Player.method840();
            if (!GameShell.field72.titleMusicDisabled) {
               HealthBar.get(ServerPacket.field1995, "scape main", "", 255, false);
            } else {
               WorldMapRegion.method1886();
            }
         }

         if (Client.field2163 != 5) {
            if (-1L == Login.field684) {
               Login.field684 = Tile.method2779() + 1000L;
            }

            long var12 = Tile.method2779();
            boolean var3;
            if (Client.field2358 != null && Client.field2208 < Client.field2358.size()) {
               while(true) {
                  if (Client.field2208 >= Client.field2358.size()) {
                     var3 = true;
                     break;
                  }

                  IndexCacheLoader var15 = (IndexCacheLoader) Client.field2358.get(Client.field2208);
                  if (!var15.method1095()) {
                     var3 = false;
                     break;
                  }

                  ++Client.field2208;
               }
            } else {
               var3 = true;
            }

            if (var3 && Login.field685 == -1L) {
               Login.field685 = var12;
               if (Login.field685 > Login.field684) {
                  Login.field684 = Login.field685;
               }
            }

            ++Login.field662;
            if (Client.field2163 == 10 || Client.field2163 == 11) {
               if (Client.field2228 == 0) {
                  if (MouseHandler.field158 == 1 || !WorldMapSection0.field1101 && MouseHandler.field158 == 4) {
                     var4 = Login.field649 + 5;
                     short var14 = 463;
                     byte var6 = 100;
                     byte var7 = 35;
                     if (MouseHandler.field159 >= var4 && MouseHandler.field159 <= var6 + var4 && MouseHandler.field148 >= var14 && MouseHandler.field148 <= var14 + var7) {
                        class99.method1841();
                        return;
                     }
                  }

                  if (World.field346 != null) {
                     class99.method1841();
                  }
               }

               var4 = MouseHandler.field158;
               int var25 = MouseHandler.field159;
               int var18 = MouseHandler.field148;
               if (var4 == 0) {
                  var25 = MouseHandler.field154;
                  var18 = MouseHandler.field145 * -976212263;
               }

               if (!WorldMapSection0.field1101 && var4 == 4) {
                  var4 = 1;
               }

               int var8;
               short var9;
               if (Login.field669 == 0) {
                  boolean var19 = false;

                  while(ClanMate.method5342()) {
                     if (Message.field561 == 84) {
                        var19 = true;
                     }
                  }

                  var8 = class73.field854 - 80;
                  var9 = 291;
                  if (var4 == 1 && var25 >= var8 - 75 && var25 <= var8 + 75 && var18 >= var9 - 20 && var18 <= var9 + 20) {
                     UrlRequest.isDone(WidgetGroupParent.method999("secure", true) + "m=account-creation/g=oldscape/create_account_funnel.ws", true, false);
                  }

                  var8 = class73.field854 + 80;
                  if (var4 == 1 && var25 >= var8 - 75 && var25 <= var8 + 75 && var18 >= var9 - 20 && var18 <= var9 + 20 || var19) {
                     if ((Client.field2103 & 33554432) != 0) {
                        Login.field674 = "";
                        Login.field671 = "This is a <col=00ffff>Beta<col=ffffff> world.";
                        Login.field672 = "Your normal account will not be affected.";
                        Login.field673 = "";
                        Login.field669 = 1;
                        if (Client.field2189 && Login.field686 != null && Login.field686.length() > 0) {
                           Login.field656 = 1;
                        } else {
                           Login.field656 = 0;
                        }
                     } else if ((Client.field2103 & 4) != 0) {
                        if ((Client.field2103 & 1024) != 0) {
                           Login.field671 = "This is a <col=ffff00>High Risk <col=ff0000>PvP<col=ffffff> world.";
                           Login.field672 = "Players can attack each other almost everywhere";
                           Login.field673 = "and the Protect Item prayer won't work.";
                        } else {
                           Login.field671 = "This is a <col=ff0000>PvP<col=ffffff> world.";
                           Login.field672 = "Players can attack each other";
                           Login.field673 = "almost everywhere.";
                        }

                        Login.field674 = "Warning!";
                        Login.field669 = 1;
                        if (Client.field2189 && Login.field686 != null && Login.field686.length() > 0) {
                           Login.field656 = 1;
                        } else {
                           Login.field656 = 0;
                        }
                     } else if ((Client.field2103 & 1024) != 0) {
                        Login.field671 = "This is a <col=ffff00>High Risk<col=ffffff> world.";
                        Login.field672 = "The Protect Item prayer will";
                        Login.field673 = "not work on this world.";
                        Login.field674 = "Warning!";
                        Login.field669 = 1;
                        if (Client.field2189 && Login.field686 != null && Login.field686.length() > 0) {
                           Login.field656 = 1;
                        } else {
                           Login.field656 = 0;
                        }
                     } else {
                        class21.method544(false);
                     }
                  }
               } else {
                  int var20;
                  short var22;
                  if (Login.field669 != 1) {
                     short var21;
                     if (Login.field669 == 2) {
                        var21 = 201;
                        var20 = var21 + 52;
                        if (var4 == 1 && var18 >= var20 - 12 && var18 < var20 + 2) {
                           Login.field656 = 0;
                        }

                        var20 += 15;
                        if (var4 == 1 && var18 >= var20 - 12 && var18 < var20 + 2) {
                           Login.field656 = 1;
                        }

                        var20 += 15;
                        var21 = 361;
                        if (Login.field683 != null) {
                           var8 = Login.field683.field3828 / 2;
                           if (var4 == 1 && var25 >= Login.field683.field3827 - var8 && var25 <= var8 + Login.field683.field3827 && var18 >= var21 - 15 && var18 < var21) {
                              switch(Login.field667) {
                              case 1:
                                 ByteArrayPool.method4250("Please enter your username.", "If you created your account after November", "2010, this will be the creation email address.");
                                 Login.field669 = 5;
                                 return;
                              case 2:
                                 UrlRequest.isDone("https://support.runescape.com/hc/en-gb", true, false);
                              }
                           }
                        }

                        var8 = class73.field854 - 80;
                        var9 = 321;
                        if (var4 == 1 && var25 >= var8 - 75 && var25 <= var8 + 75 && var18 >= var9 - 20 && var18 <= var9 + 20) {
                           Login.field686 = Login.field686.trim();
                           if (Login.field686.length() == 0) {
                              ByteArrayPool.method4250("", "Please enter your username/email address.", "");
                              return;
                           }

                           if (Login.field675.length() == 0) {
                              ByteArrayPool.method4250("", "Please enter your password.", "");
                              return;
                           }

                           ByteArrayPool.method4250("", "Connecting to server...", "");
                           WorldMapManager.method143(false);
                           class69.method1443(20);
                           return;
                        }

                        var8 = Login.field650 + 180 + 80;
                        if (var4 == 1 && var25 >= var8 - 75 && var25 <= var8 + 75 && var18 >= var9 - 20 && var18 <= var9 + 20) {
                           Login.field669 = 0;
                           Login.field686 = "";
                           Login.field675 = "";
                           class31.field368 = 0;
                           class85.field968 = "";
                           Login.field678 = true;
                        }

                        var8 = class73.field854 + -117;
                        var9 = 277;
                        Login.field676 = var25 >= var8 && var25 < var8 + ObjectSound.field576 && var18 >= var9 && var18 < var9 + Canvas.field122;
                        if (var4 == 1 && Login.field676) {
                           Client.field2189 = !Client.field2189;
                           if (!Client.field2189 && GameShell.field72.rememberedUsername != null) {
                              GameShell.field72.rememberedUsername = null;
                              Player.method840();
                           }
                        }

                        var8 = class73.field854 + 24;
                        var9 = 277;
                        Login.field677 = var25 >= var8 && var25 < var8 + ObjectSound.field576 && var18 >= var9 && var18 < var9 + Canvas.field122;
                        if (var4 == 1 && Login.field677) {
                           GameShell.field72.hideUsername = !GameShell.field72.hideUsername;
                           if (!GameShell.field72.hideUsername) {
                              Login.field686 = "";
                              GameShell.field72.rememberedUsername = null;
                              if (Client.field2189 && Login.field686 != null && Login.field686.length() > 0) {
                                 Login.field656 = 1;
                              } else {
                                 Login.field656 = 0;
                              }
                           }

                           Player.method840();
                        }

                        while(true) {
                           while(ClanMate.method5342()) {
                              boolean var10 = false;

                              for(int var11 = 0; var11 < "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!\"£$%^&*()-_=+[{]};:'@#~,<.>/?\\| ".length(); ++var11) {
                                 if (FaceNormal.field1622 == "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!\"£$%^&*()-_=+[{]};:'@#~,<.>/?\\| ".charAt(var11)) {
                                    var10 = true;
                                    break;
                                 }
                              }

                              if (Message.field561 == 13) {
                                 Login.field669 = 0;
                                 Login.field686 = "";
                                 Login.field675 = "";
                                 class31.field368 = 0;
                                 class85.field968 = "";
                                 Login.field678 = true;
                              } else if (Login.field656 == 0) {
                                 if (Message.field561 == 85 && Login.field686.length() > 0) {
                                    Login.field686 = Login.field686.substring(0, Login.field686.length() - 1);
                                 }

                                 if (Message.field561 == 84 || Message.field561 == 80) {
                                    Login.field656 = 1;
                                 }

                                 if (var10 && Login.field686.length() < 320) {
                                    Login.field686 = Login.field686 + FaceNormal.field1622;
                                 }
                              } else if (Login.field656 == 1) {
                                 if (Message.field561 == 85 && Login.field675.length() > 0) {
                                    Login.field675 = Login.field675.substring(0, Login.field675.length() - 1);
                                 }

                                 if (Message.field561 == 84 || Message.field561 == 80) {
                                    Login.field656 = 0;
                                 }

                                 if (Message.field561 == 84) {
                                    Login.field686 = Login.field686.trim();
                                    if (Login.field686.length() == 0) {
                                       ByteArrayPool.method4250("", "Please enter your username/email address.", "");
                                       return;
                                    }

                                    if (Login.field675.length() == 0) {
                                       ByteArrayPool.method4250("", "Please enter your password.", "");
                                       return;
                                    }

                                    ByteArrayPool.method4250("", "Connecting to server...", "");
                                    WorldMapManager.method143(false);
                                    class69.method1443(20);
                                    return;
                                 }

                                 if (var10 && Login.field675.length() < 20) {
                                    Login.field675 = Login.field675 + FaceNormal.field1622;
                                 }
                              }
                           }

                           return;
                        }
                     } else if (Login.field669 == 3) {
                        var20 = Login.field650 + 180;
                        var22 = 276;
                        if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                           class21.method544(false);
                        }

                        var20 = Login.field650 + 180;
                        var22 = 326;
                        if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                           ByteArrayPool.method4250("Please enter your username.", "If you created your account after November", "2010, this will be the creation email address.");
                           Login.field669 = 5;
                           return;
                        }
                     } else {
                        boolean var23;
                        int var24;
                        if (Login.field669 == 4) {
                           var20 = Login.field650 + 180 - 80;
                           var22 = 321;
                           if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                              class85.field968.trim();
                              if (class85.field968.length() != 6) {
                                 ByteArrayPool.method4250("", "Please enter a 6-digit PIN.", "");
                                 return;
                              }

                              class31.field368 = Integer.parseInt(class85.field968);
                              class85.field968 = "";
                              WorldMapManager.method143(true);
                              ByteArrayPool.method4250("", "Connecting to server...", "");
                              class69.method1443(20);
                              return;
                           }

                           if (var4 == 1 && var25 >= Login.field650 + 180 - 9 && var25 <= Login.field650 + 180 + 130 && var18 >= 263 && var18 <= 296) {
                              Login.field678 = !Login.field678;
                           }

                           if (var4 == 1 && var25 >= Login.field650 + 180 - 34 && var25 <= Login.field650 + 34 + 180 && var18 >= 351 && var18 <= 363) {
                              UrlRequest.isDone(WidgetGroupParent.method999("secure", true) + "m=totp-authenticator/disableTOTPRequest", true, false);
                           }

                           var20 = Login.field650 + 180 + 80;
                           if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                              Login.field669 = 0;
                              Login.field686 = "";
                              Login.field675 = "";
                              class31.field368 = 0;
                              class85.field968 = "";
                           }

                           while(ClanMate.method5342()) {
                              var23 = false;

                              for(var24 = 0; var24 < "1234567890".length(); ++var24) {
                                 if (FaceNormal.field1622 == "1234567890".charAt(var24)) {
                                    var23 = true;
                                    break;
                                 }
                              }

                              if (Message.field561 == 13) {
                                 Login.field669 = 0;
                                 Login.field686 = "";
                                 Login.field675 = "";
                                 class31.field368 = 0;
                                 class85.field968 = "";
                              } else {
                                 if (Message.field561 == 85 && class85.field968.length() > 0) {
                                    class85.field968 = class85.field968.substring(0, class85.field968.length() - 1);
                                 }

                                 if (Message.field561 == 84) {
                                    class85.field968.trim();
                                    if (class85.field968.length() != 6) {
                                       ByteArrayPool.method4250("", "Please enter a 6-digit PIN.", "");
                                       return;
                                    }

                                    class31.field368 = Integer.parseInt(class85.field968);
                                    class85.field968 = "";
                                    WorldMapManager.method143(true);
                                    ByteArrayPool.method4250("", "Connecting to server...", "");
                                    class69.method1443(20);
                                    return;
                                 }

                                 if (var23 && class85.field968.length() < 6) {
                                    class85.field968 = class85.field968 + FaceNormal.field1622;
                                 }
                              }
                           }
                        } else if (Login.field669 == 5) {
                           var20 = Login.field650 + 180 - 80;
                           var22 = 321;
                           if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                              Clock.method3019();
                              return;
                           }

                           var20 = Login.field650 + 180 + 80;
                           if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                              class21.method544(true);
                           }

                           while(ClanMate.method5342()) {
                              var23 = false;

                              for(var24 = 0; var24 < "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!\"£$%^&*()-_=+[{]};:'@#~,<.>/?\\| ".length(); ++var24) {
                                 if (FaceNormal.field1622 == "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!\"£$%^&*()-_=+[{]};:'@#~,<.>/?\\| ".charAt(var24)) {
                                    var23 = true;
                                    break;
                                 }
                              }

                              if (Message.field561 == 13) {
                                 class21.method544(true);
                              } else {
                                 if (Message.field561 == 85 && Login.field686.length() > 0) {
                                    Login.field686 = Login.field686.substring(0, Login.field686.length() - 1);
                                 }

                                 if (Message.field561 == 84) {
                                    Clock.method3019();
                                    return;
                                 }

                                 if (var23 && Login.field686.length() < 320) {
                                    Login.field686 = Login.field686 + FaceNormal.field1622;
                                 }
                              }
                           }
                        } else if (Login.field669 == 6) {
                           while(true) {
                              do {
                                 if (!ClanMate.method5342()) {
                                    var21 = 321;
                                    if (var4 == 1 && var18 >= var21 - 20 && var18 <= var21 + 20) {
                                       class21.method544(true);
                                    }

                                    return;
                                 }
                              } while(Message.field561 != 84 && Message.field561 != 13);

                              class21.method544(true);
                           }
                        } else if (Login.field669 == 7) {
                           var20 = Login.field650 + 180 - 80;
                           var22 = 321;
                           if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                              UrlRequest.isDone(WidgetGroupParent.method999("secure", true) + "m=dob/set_dob.ws", true, false);
                              ByteArrayPool.method4250("", "Page has opened in a new window.", "(Please check your popup blocker.)");
                              Login.field669 = 6;
                              return;
                           }

                           var20 = Login.field650 + 180 + 80;
                           if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                              class21.method544(true);
                           }
                        } else if (Login.field669 == 8) {
                           var20 = Login.field650 + 180 - 80;
                           var22 = 321;
                           if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                              UrlRequest.isDone("https://www.jagex.com/terms/privacy/#eight", true, false);
                              ByteArrayPool.method4250("", "Page has opened in a new window.", "(Please check your popup blocker.)");
                              Login.field669 = 6;
                              return;
                           }

                           var20 = Login.field650 + 180 + 80;
                           if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                              class21.method544(true);
                           }
                        } else if (Login.field669 == 12) {
                           String var16 = "";
                           switch(Login.field648) {
                           case 0:
                              var16 = "https://support.runescape.com/hc/en-gb/articles/115002238729-Account-Bans";
                              break;
                           case 1:
                              var16 = "https://support.runescape.com/hc/en-gb/articles/206103939-My-account-is-locked";
                              break;
                           default:
                              class21.method544(false);
                           }

                           var8 = Login.field650 + 180;
                           var9 = 276;
                           if (var4 == 1 && var25 >= var8 - 75 && var25 <= var8 + 75 && var18 >= var9 - 20 && var18 <= var9 + 20) {
                              UrlRequest.isDone(var16, true, false);
                              ByteArrayPool.method4250("", "Page has opened in a new window.", "(Please check your popup blocker.)");
                              Login.field669 = 6;
                              return;
                           }

                           var8 = Login.field650 + 180;
                           var9 = 326;
                           if (var4 == 1 && var25 >= var8 - 75 && var25 <= var8 + 75 && var18 >= var9 - 20 && var18 <= var9 + 20) {
                              class21.method544(false);
                           }
                        }
                     }
                  } else {
                     while(ClanMate.method5342()) {
                        if (Message.field561 == 84) {
                           class21.method544(false);
                        } else if (Message.field561 == 13) {
                           Login.field669 = 0;
                        }
                     }

                     var20 = class73.field854 - 80;
                     var22 = 321;
                     if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                        class21.method544(false);
                     }

                     var20 = class73.field854 + 80;
                     if (var4 == 1 && var25 >= var20 - 75 && var25 <= var20 + 75 && var18 >= var22 - 20 && var18 <= var22 + 20) {
                        Login.field669 = 0;
                     }
                  }
               }

            }
         }
      }
   }

   public static boolean last() {
      ReflectionCheck var0 = (ReflectionCheck)class321.field3914.last();
      return var0 != null;
   }

   static final void toBuffer(PacketBuffer var0, int var1) {
      int var2 = var0.index;
      Players.field952 = 0;
      class85.method1733(var0);
      BufferedSource.method2941(var0);
      if (var0.index - var2 != var1) {
         throw new RuntimeException(var0.index - var2 + " " + var1);
      }
   }

   static final void method800(NpcDefinition var0, int var1, int var2, int var3) {
      if (Client.field2223 < 400) {
         if (var0.transforms != null) {
            var0 = var0.transform();
         }

         if (var0 != null) {
            if (var0.isInteractable) {
               if (!var0.field3590 || Client.field2256 == var1) {
                  String var4 = var0.name;
                  int var7;
                  int var8;
                  if (var0.combatLevel != 0) {
                     var7 = var0.combatLevel;
                     var8 = ObjectSound.field589.combatLevel;
                     int var9 = var8 - var7;
                     String var6;
                     if (var9 < -9) {
                        var6 = ModelData0.method2792(16711680);
                     } else if (var9 < -6) {
                        var6 = ModelData0.method2792(16723968);
                     } else if (var9 < -3) {
                        var6 = ModelData0.method2792(16740352);
                     } else if (var9 < 0) {
                        var6 = ModelData0.method2792(16756736);
                     } else if (var9 > 9) {
                        var6 = ModelData0.method2792(65280);
                     } else if (var9 > 6) {
                        var6 = ModelData0.method2792(4259584);
                     } else if (var9 > 3) {
                        var6 = ModelData0.method2792(8453888);
                     } else if (var9 > 0) {
                        var6 = ModelData0.method2792(12648192);
                     } else {
                        var6 = ModelData0.method2792(16776960);
                     }

                     var4 = var4 + var6 + " " + " (" + "level-" + var0.combatLevel + ")";
                  }

                  if (var0.field3590 && Client.field2231) {
                     Login.method1253("Examine", ModelData0.method2792(16776960) + var4, 1003, var1, var2, var3);
                  }

                  if (Client.field2239 == 1) {
                     Login.method1253("Use", Client.field2209 + " " + "->" + " " + ModelData0.method2792(16776960) + var4, 7, var1, var2, var3);
                  } else if (Client.field2241) {
                     if ((FontName.field3737 & 2) == 2) {
                        Login.method1253(Client.field2244, Client.field2159 + " " + "->" + " " + ModelData0.method2792(16776960) + var4, 8, var1, var2, var3);
                     }
                  } else {
                     int var10 = var0.field3590 && Client.field2231 ? 2000 : 0;
                     String[] var11 = var0.actions;
                     if (var11 != null) {
                        for(var7 = 4; var7 >= 0; --var7) {
                           if (var11[var7] != null && !var11[var7].equalsIgnoreCase("Attack")) {
                              var8 = 0;
                              if (var7 == 0) {
                                 var8 = var10 + 9;
                              }

                              if (var7 == 1) {
                                 var8 = var10 + 10;
                              }

                              if (var7 == 2) {
                                 var8 = var10 + 11;
                              }

                              if (var7 == 3) {
                                 var8 = var10 + 12;
                              }

                              if (var7 == 4) {
                                 var8 = var10 + 13;
                              }

                              Login.method1253(var11[var7], ModelData0.method2792(16776960) + var4, var8, var1, var2, var3);
                           }
                        }
                     }

                     if (var11 != null) {
                        for(var7 = 4; var7 >= 0; --var7) {
                           if (var11[var7] != null && var11[var7].equalsIgnoreCase("Attack")) {
                              short var12 = 0;
                              if (Client.field2115 != AttackOption.field600) {
                                 if (Client.field2115 == AttackOption.field605 || Client.field2115 == AttackOption.field607 && var0.combatLevel > ObjectSound.field589.combatLevel) {
                                    var12 = 2000;
                                 }

                                 var8 = 0;
                                 if (var7 == 0) {
                                    var8 = var12 + 9;
                                 }

                                 if (var7 == 1) {
                                    var8 = var12 + 10;
                                 }

                                 if (var7 == 2) {
                                    var8 = var12 + 11;
                                 }

                                 if (var7 == 3) {
                                    var8 = var12 + 12;
                                 }

                                 if (var7 == 4) {
                                    var8 = var12 + 13;
                                 }

                                 Login.method1253(var11[var7], ModelData0.method2792(16776960) + var4, var8, var1, var2, var3);
                              }
                           }
                        }
                     }

                     if (!var0.field3590 || !Client.field2231) {
                        Login.method1253("Examine", ModelData0.method2792(16776960) + var4, 1003, var1, var2, var3);
                     }
                  }

               }
            }
         }
      }
   }
}
