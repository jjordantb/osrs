import java.awt.Component;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

public final class WorldMapManager {
   static int field46;
   public static AbstractRasterProvider field45;
   HashMap field37 = new HashMap();
   HashMap icons;
   int field43;
   WorldMapData2 field34;
   boolean field33 = false;
   int field42;
   public int field44 = 0;
   WorldMapRegion[][] regions;
   int field31;
   final HashMap fonts;
   int field41;
   Sprite field40;
   boolean field32 = false;
   IndexedSprite[] mapSceneSprites;

   public WorldMapManager(IndexedSprite[] var1, HashMap var2) {
      this.mapSceneSprites = var1;
      this.fonts = var2;
   }

   void method100(int var1, int var2, WorldMapRegion[] var3) {
      boolean var4 = var1 <= 0;
      boolean var5 = var1 >= this.regions.length - 1;
      boolean var6 = var2 <= 0;
      boolean var7 = var2 >= this.regions[0].length - 1;
      if (var7) {
         var3[OctantDirection.field3332.ordinal()] = null;
      } else {
         var3[OctantDirection.field3332.ordinal()] = this.regions[var1][var2 + 1];
      }

      var3[OctantDirection.field3323.ordinal()] = !var7 && !var5 ? this.regions[var1 + 1][var2 + 1] : null;
      var3[OctantDirection.field3327.ordinal()] = !var7 && !var4 ? this.regions[var1 - 1][var2 + 1] : null;
      var3[OctantDirection.field3324.ordinal()] = var5 ? null : this.regions[var1 + 1][var2];
      var3[OctantDirection.field3328.ordinal()] = var4 ? null : this.regions[var1 - 1][var2];
      var3[OctantDirection.field3326.ordinal()] = var6 ? null : this.regions[var1][var2 - 1];
      var3[OctantDirection.field3322.ordinal()] = !var6 && !var5 ? this.regions[var1 + 1][var2 - 1] : null;
      var3[OctantDirection.field3329.ordinal()] = !var6 && !var4 ? this.regions[var1 - 1][var2 - 1] : null;
   }

   public boolean method109() {
      return this.field33;
   }

   public final void method103(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      int[] var9 = Rasterizer2D.field3900;
      int var10 = Rasterizer2D.field3898;
      int var11 = Rasterizer2D.field3899;
      int[] var12 = new int[4];
      Rasterizer2D.method6286(var12);
      class65 var13 = this.method108(var1, var2, var3, var4);
      float var14 = this.method128(var7 - var5, var3 - var1);
      int var15 = (int)Math.ceil((double)var14);
      this.field44 = var15;
      if (!this.field37.containsKey(var15)) {
         class1 var16 = new class1(var15);
         var16.method31();
         this.field37.put(var15, var16);
      }

      WorldMapRegion[] var22 = new WorldMapRegion[8];

      int var17;
      int var18;
      for(var17 = var13.field798; var17 < var13.field798 + var13.field802; ++var17) {
         for(var18 = var13.field799; var18 < var13.field796 + var13.field799; ++var18) {
            this.method100(var17, var18, var22);
            this.regions[var17][var18].method1885(var15, (class1)this.field37.get(var15), var22, this.mapSceneSprites);
         }
      }

      Rasterizer2D.method6214(var9, var10, var11);
      Rasterizer2D.method6226(var12);
      var17 = (int)(var14 * 64.0F);
      var18 = this.field42 + var1;
      int var19 = var2 + this.field41;

      for(int var20 = var13.field798; var20 < var13.field798 + var13.field802; ++var20) {
         for(int var21 = var13.field799; var21 < var13.field799 + var13.field796; ++var21) {
            this.regions[var20][var21].method1880(var5 + var17 * (this.regions[var20][var21].x * 64 - var18) / 64, var8 - var17 * (this.regions[var20][var21].y * 64 - var19 + 64) / 64, var17);
         }
      }

   }

   public void method101(AbstractIndexCache var1, String var2, boolean var3) {
      if (!this.field32) {
         this.field33 = false;
         this.field32 = true;
         System.nanoTime();
         int var4 = var1.getArchiveId(WorldMapCacheName.field235.name);
         int var5 = var1.getRecordId(var4, var2);
         Buffer var6 = new Buffer(var1.takeRecordByNames(WorldMapCacheName.field235.name, var2));
         Buffer var7 = new Buffer(var1.takeRecordByNames(WorldMapCacheName.field232.name, var2));
         Buffer var8 = new Buffer(var1.takeRecordByNames(var2, WorldMapCacheName.field234.name));
         System.nanoTime();
         System.nanoTime();
         this.field34 = new WorldMapData2();

         try {
            this.field34.method339(var6, var8, var7, var5, var3);
         } catch (IllegalStateException var20) {
            return;
         }

         this.field34.method1546();
         this.field34.method1499();
         this.field34.method1508();
         this.field42 = this.field34.method1523() * 64;
         this.field41 = this.field34.method1494() * 64;
         this.field31 = (this.field34.method1503() - this.field34.method1523() + 1) * 64;
         this.field43 = (this.field34.method1514() - this.field34.method1494() + 1) * 64;
         int var17 = this.field34.method1503() - this.field34.method1523() + 1;
         int var10 = this.field34.method1514() - this.field34.method1494() + 1;
         System.nanoTime();
         System.nanoTime();
         FriendSystem.method789();
         this.regions = new WorldMapRegion[var17][var10];
         Iterator var11 = this.field34.field108.iterator();

         while(var11.hasNext()) {
            class85 var12 = (class85)var11.next();
            int var13 = var12.field824;
            int var14 = var12.field829;
            int var15 = var13 - this.field34.method1523();
            int var16 = var14 - this.field34.method1494();
            this.regions[var15][var16] = new WorldMapRegion(var13, var14, this.field34.method1500(), this.fonts);
            this.regions[var15][var16].method1881(var12, this.field34.field107);
         }

         for(int var18 = 0; var18 < var17; ++var18) {
            for(int var19 = 0; var19 < var10; ++var19) {
               if (this.regions[var18][var19] == null) {
                  this.regions[var18][var19] = new WorldMapRegion(this.field34.method1523() + var18, this.field34.method1494() + var19, this.field34.method1500(), this.fonts);
                  this.regions[var18][var19].method1990(this.field34.field105, this.field34.field107);
               }
            }
         }

         System.nanoTime();
         System.nanoTime();
         if (var1.method4984(WorldMapCacheName.field233.name, var2)) {
            byte[] var21 = var1.takeRecordByNames(WorldMapCacheName.field233.name, var2);
            this.field40 = Interpreter.method966(var21);
         }

         System.nanoTime();
         var1.method4978();
         var1.method4980();
         this.field33 = true;
      }
   }

   public void method106(int var1, int var2, int var3, int var4, HashSet var5, int var6, int var7) {
      if (this.field40 != null) {
         this.field40.method6350(var1, var2, var3, var4);
         if (var6 > 0 && var6 % var7 < var7 / 2) {
            if (this.icons == null) {
               this.buildIcons0();
            }

            Iterator var8 = var5.iterator();

            while(true) {
               List var10;
               do {
                  if (!var8.hasNext()) {
                     return;
                  }

                  int var9 = ((Integer)var8.next()).intValue();
                  var10 = (List)this.icons.get(var9);
               } while(var10 == null);

               Iterator var11 = var10.iterator();

               while(var11.hasNext()) {
                  WorldMapIcon var12 = (WorldMapIcon)var11.next();
                  int var13 = var3 * (var12.field244.x - this.field42) / this.field31;
                  int var14 = var4 - (var12.field244.y - this.field41) * var4 / this.field43;
                  Rasterizer2D.method6271(var13 + var1, var14 + var2, 2, 16776960, 256);
               }
            }
         }
      }
   }

   public HashMap buildIcons() {
      this.buildIcons0();
      return this.icons;
   }

   class65 method108(int var1, int var2, int var3, int var4) {
      class65 var5 = new class65(this);
      int var6 = this.field42 + var1;
      int var7 = var2 + this.field41;
      int var8 = var3 + this.field42;
      int var9 = var4 + this.field41;
      int var10 = var6 / 64;
      int var11 = var7 / 64;
      int var12 = var8 / 64;
      int var13 = var9 / 64;
      var5.field802 = var12 - var10 + 1;
      var5.field796 = var13 - var11 + 1;
      var5.field798 = var10 - this.field34.method1523();
      var5.field799 = var11 - this.field34.method1494();
      if (var5.field798 < 0) {
         var5.field802 += var5.field798;
         var5.field798 = 0;
      }

      if (var5.field798 > this.regions.length - var5.field802) {
         var5.field802 = this.regions.length - var5.field798;
      }

      if (var5.field799 < 0) {
         var5.field796 += var5.field799;
         var5.field799 = 0;
      }

      if (var5.field799 > this.regions[0].length - var5.field796) {
         var5.field796 = this.regions[0].length - var5.field799;
      }

      var5.field802 = Math.min(var5.field802, this.regions.length);
      var5.field796 = Math.min(var5.field796, this.regions[0].length);
      return var5;
   }

   public List method107(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10) {
      LinkedList var11 = new LinkedList();
      if (!this.field33) {
         return var11;
      } else {
         class65 var12 = this.method108(var1, var2, var3, var4);
         float var13 = this.method128(var7, var3 - var1);
         int var14 = (int)(64.0F * var13);
         int var15 = this.field42 + var1;
         int var16 = var2 + this.field41;

         for(int var17 = var12.field798; var17 < var12.field798 + var12.field802; ++var17) {
            for(int var18 = var12.field799; var18 < var12.field796 + var12.field799; ++var18) {
               List var19 = this.regions[var17][var18].method1915(var5 + var14 * (this.regions[var17][var18].x * 64 - var15) / 64, var8 + var6 - var14 * (this.regions[var17][var18].y * 64 - var16 + 64) / 64, var14, var9, var10);
               if (!var19.isEmpty()) {
                  var11.addAll(var19);
               }
            }
         }

         return var11;
      }
   }

   public final void method115(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, HashSet var9, HashSet var10, int var11, int var12, boolean var13) {
      class65 var14 = this.method108(var1, var2, var3, var4);
      float var15 = this.method128(var7 - var5, var3 - var1);
      int var16 = (int)(64.0F * var15);
      int var17 = this.field42 + var1;
      int var18 = var2 + this.field41;

      int var19;
      int var20;
      for(var19 = var14.field798; var19 < var14.field798 + var14.field802; ++var19) {
         for(var20 = var14.field799; var20 < var14.field799 + var14.field796; ++var20) {
            if (var13) {
               this.regions[var19][var20].method1980();
            }

            this.regions[var19][var20].method1960(var5 + var16 * (this.regions[var19][var20].x * 64 - var17) / 64, var8 - var16 * (this.regions[var19][var20].y * 64 - var18 + 64) / 64, var16, var9);
         }
      }

      if (var10 != null && var11 > 0) {
         for(var19 = var14.field798; var19 < var14.field798 + var14.field802; ++var19) {
            for(var20 = var14.field799; var20 < var14.field799 + var14.field796; ++var20) {
               this.regions[var19][var20].method1887(var10, var11, var12);
            }
         }
      }

   }

   public final void method113() {
      this.icons = null;
   }

   float method128(int var1, int var2) {
      float var3 = (float)var1 / (float)var2;
      if (var3 > 8.0F) {
         return 8.0F;
      } else if (var3 < 1.0F) {
         return 1.0F;
      } else {
         int var4 = Math.round(var3);
         return Math.abs((float)var4 - var3) < 0.05F ? (float)var4 : var3;
      }
   }

   void buildIcons0() {
      if (this.icons == null) {
         this.icons = new HashMap();
      }

      this.icons.clear();

      for(int var1 = 0; var1 < this.regions.length; ++var1) {
         for(int var2 = 0; var2 < this.regions[var1].length; ++var2) {
            List var3 = this.regions[var1][var2].icons();
            Iterator var4 = var3.iterator();

            while(var4.hasNext()) {
               WorldMapIcon var5 = (WorldMapIcon)var4.next();
               if (!this.icons.containsKey(var5.field252)) {
                  LinkedList var6 = new LinkedList();
                  var6.add(var5);
                  this.icons.put(var5.field252, var6);
               } else {
                  List var7 = (List)this.icons.get(var5.field252);
                  var7.add(var5);
               }
            }
         }
      }

   }

   static void method145(Component var0) {
      var0.addMouseListener(MouseHandler.field151);
      var0.addMouseMotionListener(MouseHandler.field151);
      var0.addFocusListener(MouseHandler.field151);
   }

   static void method141(int var0) {
      ItemContainer var1 = (ItemContainer)ItemContainer.field267.get((long)var0);
      if (var1 != null) {
         var1.remove();
      }
   }

   static void method140(Component var0) {
      var0.setFocusTraversalKeysEnabled(false);
      var0.addKeyListener(KeyHandler.field17);
      var0.addFocusListener(KeyHandler.field17);
   }

   static Script method144(int var0, int var1, int var2) {
      int var3 = class219.method4567(var1, var0);
      Script var4 = Script.method1805(var3, var0);
      if (var4 != null) {
         return var4;
      } else {
         int var5 = var0 + (var2 + '鱀' << 8);
         var4 = Script.method1805(var5, var0);
         return var4 != null ? var4 : null;
      }
   }

   static final void method143(boolean var0) {
      if (var0) {
         Client.field2124 = Login.field678 ? class130.field1562 : class130.field1563;
      } else {
         LinkedHashMap var1 = GameShell.field72.parameters;
         String var3 = Login.field686;
         int var4 = var3.length();
         int var5 = 0;

         for(int var6 = 0; var6 < var4; ++var6) {
            var5 = (var5 << 5) - var5 + var3.charAt(var6);
         }

         Client.field2124 = var1.containsKey(var5) ? class130.field1564 : class130.field1561;
      }

   }

   static final void method102(int var0, int var1, int var2, boolean var3) {
      if (class196.method4189(var0)) {
         Clock.method3016(UserComparator3.field1708[var0], -1, var1, var2, var3);
      }
   }
}
