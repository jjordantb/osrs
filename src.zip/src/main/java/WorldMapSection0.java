public class WorldMapSection0 implements WorldMapSection {
   static boolean field1101;
   int field1091;
   int field1089;
   int field1100;
   int field1087;
   int field1094;
   int field1093;
   int field1102;
   int field1099;
   int field1090;
   int field1098;
   int field1095;
   int field1088;
   int field1086;
   int field1092;

   public TileLocation vmethod1861(int var1, int var2) {
      if (!this.vmethod1857(var1, var2)) {
         return null;
      } else {
         int var3 = this.field1087 * 64 - this.field1089 * 64 + (this.field1091 * 8 - this.field1095 * 8) + var1;
         int var4 = this.field1088 * 64 - this.field1099 * 64 + var2 + (this.field1092 * 8 - this.field1090 * 8);
         return new TileLocation(this.field1094, var3, var4);
      }
   }

   public boolean vmethod1857(int var1, int var2) {
      return var1 >= (this.field1089 << 6) + (this.field1095 << 3) && var1 <= (this.field1089 << 6) + (this.field1100 << 3) + 7 && var2 >= (this.field1099 << 6) + (this.field1090 << 3) && var2 <= (this.field1099 << 6) + (this.field1102 << 3) + 7;
   }

   public void vmethod1855(WorldMapData var1) {
      if (var1.field881 > this.field1089) {
         var1.field881 = this.field1089;
      }

      if (var1.field882 < this.field1089) {
         var1.field882 = this.field1089;
      }

      if (var1.field877 > this.field1099) {
         var1.field877 = this.field1099;
      }

      if (var1.field886 < this.field1099) {
         var1.field886 = this.field1099;
      }

   }

   public void read(Buffer var1) {
      this.field1094 = var1.readUnsignedByte();
      this.field1086 = var1.readUnsignedByte();
      this.field1087 = var1.method3913();
      this.field1091 = var1.readUnsignedByte();
      this.field1098 = var1.readUnsignedByte();
      this.field1088 = var1.method3913();
      this.field1092 = var1.readUnsignedByte();
      this.field1093 = var1.readUnsignedByte();
      this.field1089 = var1.method3913();
      this.field1095 = var1.readUnsignedByte();
      this.field1100 = var1.readUnsignedByte();
      this.field1099 = var1.method3913();
      this.field1090 = var1.readUnsignedByte();
      this.field1102 = var1.readUnsignedByte();
      this.method1877();
   }

   void method1877() {
   }

   public int[] vmethod1858(int var1, int var2, int var3) {
      if (!this.vmethod1856(var1, var2, var3)) {
         return null;
      } else {
         int[] var4 = new int[]{this.field1089 * 64 - this.field1087 * 64 + var2 + (this.field1095 * 8 - this.field1091 * 8), var3 + (this.field1099 * 64 - this.field1088 * 64) + (this.field1090 * 8 - this.field1092 * 8)};
         return var4;
      }
   }

   public boolean vmethod1856(int var1, int var2, int var3) {
      if (var1 >= this.field1094 && var1 < this.field1086 + this.field1094) {
         return var2 >= (this.field1087 << 6) + (this.field1091 << 3) && var2 <= (this.field1087 << 6) + (this.field1098 << 3) + 7 && var3 >= (this.field1088 << 6) + (this.field1092 << 3) && var3 <= (this.field1088 << 6) + (this.field1093 << 3) + 7;
      } else {
         return false;
      }
   }

   static void method1872() {
      Client.field2223 = 0;
      Client.field2276 = false;
      Client.field2359[0] = "Cancel";
      Client.field2229[0] = "";
      Client.field2226[0] = 1006;
      Client.field2215[0] = false;
      Client.field2223 = 1;
   }

   static final boolean method1854(Widget var0) {
      int var1 = var0.contentType;
      if (var1 == 205) {
         Client.field2168 = 250;
         return true;
      } else {
         int var2;
         int var3;
         if (var1 >= 300 && var1 <= 313) {
            var2 = (var1 - 300) / 2;
            var3 = var1 & 1;
            Client.field2351.method4501(var2, var3 == 1);
         }

         if (var1 >= 314 && var1 <= 323) {
            var2 = (var1 - 314) / 2;
            var3 = var1 & 1;
            Client.field2351.method4502(var2, var3 == 1);
         }

         if (var1 == 324) {
            Client.field2351.method4503(false);
         }

         if (var1 == 325) {
            Client.field2351.method4503(true);
         }

         if (var1 == 326) {
            PacketBufferNode var4 = FaceNormal.method2884(ClientPacket.field1848, Client.field2133.isaacCipher);
            Client.field2351.method4504(var4.packetBuffer);
            Client.field2133.method1281(var4);
            return true;
         } else {
            return false;
         }
      }
   }
}
