public class class167 {
   protected static int field1800;

   static boolean method3168() {
      return (Client.field2119 & 2) != 0;
   }
}
