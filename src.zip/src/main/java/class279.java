public class class279 {
   public static Sprite[] method5407(AbstractIndexCache var0, String var1, String var2) {
      int var3 = var0.getArchiveId(var1);
      int var4 = var0.getRecordId(var3, var2);
      byte[] var7 = var0.takeRecord(var3, var4);
      boolean var6;
      if (var7 == null) {
         var6 = false;
      } else {
         TilePaint.method2436(var7);
         var6 = true;
      }

      Sprite[] var5;
      if (!var6) {
         var5 = null;
      } else {
         Sprite[] var8 = new Sprite[class328.field3985];

         for(int var9 = 0; var9 < class328.field3985; ++var9) {
            Sprite var10 = var8[var9] = new Sprite();
            var10.width = class328.field3983;
            var10.height = class328.field3988;
            var10.yOffset = class328.field3982[var9];
            var10.xOffset = class328.field3984[var9];
            var10.subWidth = class328.field3987[var9];
            var10.subHeight = VarcInt.field2811[var9];
            int var11 = var10.subWidth * var10.subHeight;
            byte[] var12 = class328.field3989[var9];
            var10.pixels = new int[var11];

            for(int var13 = 0; var13 < var11; ++var13) {
               var10.pixels[var13] = class328.field3986[var12[var13] & 255];
            }
         }

         class328.field3982 = null;
         class328.field3984 = null;
         class328.field3987 = null;
         VarcInt.field2811 = null;
         class328.field3986 = null;
         class328.field3989 = null;
         var5 = var8;
      }

      return var5;
   }
}
