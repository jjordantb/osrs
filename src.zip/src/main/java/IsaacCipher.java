public final class IsaacCipher {
   static IndexCache field2480;
   static byte[][] field2482;
   int field2478;
   int[] field2481 = new int[256];
   int[] field2477 = new int[256];
   int field2473;
   int field2475;
   int field2479;

   public IsaacCipher(int[] var1) {
      for(int var2 = 0; var2 < var1.length; ++var2) {
         this.field2481[var2] = var1[var2];
      }

      this.method4255();
   }

   final void method4254() {
      this.field2479 += ++this.field2473;

      for(int var1 = 0; var1 < 256; ++var1) {
         int var2 = this.field2477[var1];
         if ((var1 & 2) == 0) {
            if ((var1 & 1) == 0) {
               this.field2478 ^= this.field2478 << 13;
            } else {
               this.field2478 ^= this.field2478 >>> 6;
            }
         } else if ((var1 & 1) == 0) {
            this.field2478 ^= this.field2478 << 2;
         } else {
            this.field2478 ^= this.field2478 >>> 16;
         }

         this.field2478 += this.field2477[var1 + 128 & 255];
         int var3;
         this.field2477[var1] = var3 = this.field2477[(var2 & 1020) >> 2] + this.field2478 + this.field2479;
         this.field2481[var1] = this.field2479 = this.field2477[(var3 >> 8 & 1020) >> 2] + var2;
      }

   }

   final int method4252() {
      if (0 == --this.field2475 + 1) {
         this.method4254();
         this.field2475 = 255;
      }

      return this.field2481[this.field2475];
   }

   final void method4255() {
      int var9 = -1640531527;
      int var8 = -1640531527;
      int var7 = -1640531527;
      int var6 = -1640531527;
      int var5 = -1640531527;
      int var4 = -1640531527;
      int var3 = -1640531527;
      int var2 = -1640531527;

      int var1;
      for(var1 = 0; var1 < 4; ++var1) {
         var2 ^= var3 << 11;
         var5 += var2;
         var3 += var4;
         var3 ^= var4 >>> 2;
         var6 += var3;
         var4 += var5;
         var4 ^= var5 << 8;
         var7 += var4;
         var5 += var6;
         var5 ^= var6 >>> 16;
         var8 += var5;
         var6 += var7;
         var6 ^= var7 << 10;
         var9 += var6;
         var7 += var8;
         var7 ^= var8 >>> 4;
         var2 += var7;
         var8 += var9;
         var8 ^= var9 << 8;
         var3 += var8;
         var9 += var2;
         var9 ^= var2 >>> 9;
         var4 += var9;
         var2 += var3;
      }

      for(var1 = 0; var1 < 256; var1 += 8) {
         var2 += this.field2481[var1];
         var3 += this.field2481[var1 + 1];
         var4 += this.field2481[var1 + 2];
         var5 += this.field2481[var1 + 3];
         var6 += this.field2481[var1 + 4];
         var7 += this.field2481[var1 + 5];
         var8 += this.field2481[var1 + 6];
         var9 += this.field2481[var1 + 7];
         var2 ^= var3 << 11;
         var5 += var2;
         var3 += var4;
         var3 ^= var4 >>> 2;
         var6 += var3;
         var4 += var5;
         var4 ^= var5 << 8;
         var7 += var4;
         var5 += var6;
         var5 ^= var6 >>> 16;
         var8 += var5;
         var6 += var7;
         var6 ^= var7 << 10;
         var9 += var6;
         var7 += var8;
         var7 ^= var8 >>> 4;
         var2 += var7;
         var8 += var9;
         var8 ^= var9 << 8;
         var3 += var8;
         var9 += var2;
         var9 ^= var2 >>> 9;
         var4 += var9;
         var2 += var3;
         this.field2477[var1] = var2;
         this.field2477[var1 + 1] = var3;
         this.field2477[var1 + 2] = var4;
         this.field2477[var1 + 3] = var5;
         this.field2477[var1 + 4] = var6;
         this.field2477[var1 + 5] = var7;
         this.field2477[var1 + 6] = var8;
         this.field2477[var1 + 7] = var9;
      }

      for(var1 = 0; var1 < 256; var1 += 8) {
         var2 += this.field2477[var1];
         var3 += this.field2477[var1 + 1];
         var4 += this.field2477[var1 + 2];
         var5 += this.field2477[var1 + 3];
         var6 += this.field2477[var1 + 4];
         var7 += this.field2477[var1 + 5];
         var8 += this.field2477[var1 + 6];
         var9 += this.field2477[var1 + 7];
         var2 ^= var3 << 11;
         var5 += var2;
         var3 += var4;
         var3 ^= var4 >>> 2;
         var6 += var3;
         var4 += var5;
         var4 ^= var5 << 8;
         var7 += var4;
         var5 += var6;
         var5 ^= var6 >>> 16;
         var8 += var5;
         var6 += var7;
         var6 ^= var7 << 10;
         var9 += var6;
         var7 += var8;
         var7 ^= var8 >>> 4;
         var2 += var7;
         var8 += var9;
         var8 ^= var9 << 8;
         var3 += var8;
         var9 += var2;
         var9 ^= var2 >>> 9;
         var4 += var9;
         var2 += var3;
         this.field2477[var1] = var2;
         this.field2477[var1 + 1] = var3;
         this.field2477[var1 + 2] = var4;
         this.field2477[var1 + 3] = var5;
         this.field2477[var1 + 4] = var6;
         this.field2477[var1 + 5] = var7;
         this.field2477[var1 + 6] = var8;
         this.field2477[var1 + 7] = var9;
      }

      this.method4254();
      this.field2475 = 256;
   }

   final int method4251() {
      if (this.field2475 == 0) {
         this.method4254();
         this.field2475 = 256;
      }

      return this.field2481[this.field2475 - 1];
   }

   public static String method4258(byte[] var0, int var1, int var2) {
      char[] var3 = new char[var2];
      int var4 = 0;

      for(int var5 = 0; var5 < var2; ++var5) {
         int var6 = var0[var5 + var1] & 255;
         if (var6 != 0) {
            if (var6 >= 128 && var6 < 160) {
               char var7 = class301.field3761[var6 - 128];
               if (var7 == 0) {
                  var7 = '?';
               }

               var6 = var7;
            }

            var3[var4++] = (char)var6;
         }
      }

      return new String(var3, 0, var4);
   }
}
