public class UserComparator9 extends AbstractUserComparator {
   public static class252 field1598;
   static byte[][][] field1597;
   static Font field1596;
   final boolean field1599;

   public UserComparator9(boolean var1) {
      this.field1599 = var1;
   }

   int method2848(Buddy var1, Buddy var2) {
      if (Client.field2134 == var1.world && var2.world == Client.field2134) {
         return this.field1599 ? var1.method5384().compareTo0(var2.method5384()) : var2.method5384().compareTo0(var1.method5384());
      } else {
         return this.method5349(var1, var2);
      }
   }

   public int compare(Object var1, Object var2) {
      return this.method2848((Buddy)var1, (Buddy)var2);
   }

   static int method2852(int var0, Script var1, boolean var2) {
      if (var0 < 1000) {
         return Tiles.method513(var0, var1, var2);
      } else if (var0 < 1100) {
         return CollisionMap.method3211(var0, var1, var2);
      } else if (var0 < 1200) {
         return class5.method154(var0, var1, var2);
      } else if (var0 < 1300) {
         return WorldMapCacheName.method545(var0, var1, var2);
      } else if (var0 < 1400) {
         return FriendsList.method5748(var0, var1, var2);
      } else if (var0 < 1500) {
         return WorldMapSection3.method1173(var0, var1, var2);
      } else if (var0 < 1600) {
         return DynamicObject.method1830(var0, var1, var2);
      } else if (var0 < 1700) {
         return class267.method5266(var0, var1, var2);
      } else if (var0 < 1800) {
         return Message.method1054(var0, var1, var2);
      } else if (var0 < 1900) {
         return class37.method861(var0, var1, var2);
      } else if (var0 < 2000) {
         return ItemContainer.method604(var0, var1, var2);
      } else if (var0 < 2100) {
         return CollisionMap.method3211(var0, var1, var2);
      } else if (var0 < 2200) {
         return class5.method154(var0, var1, var2);
      } else if (var0 < 2300) {
         return WorldMapCacheName.method545(var0, var1, var2);
      } else if (var0 < 2400) {
         return FriendsList.method5748(var0, var1, var2);
      } else if (var0 < 2500) {
         return WorldMapSection3.method1173(var0, var1, var2);
      } else if (var0 < 2600) {
         return GzipDecompressor.method3216(var0, var1, var2);
      } else if (var0 < 2700) {
         return class69.method1446(var0, var1, var2);
      } else if (var0 < 2800) {
         return PacketWriter.method1298(var0, var1, var2);
      } else if (var0 < 2900) {
         return Canvas.method363(var0, var1, var2);
      } else if (var0 < 3000) {
         return ItemContainer.method604(var0, var1, var2);
      } else if (var0 < 3200) {
         return class223.method4657(var0, var1, var2);
      } else if (var0 < 3300) {
         return SequenceDefinition.method5264(var0, var1, var2);
      } else if (var0 < 3400) {
         return class303.method5813(var0, var1, var2);
      } else if (var0 < 3500) {
         return WorldMapIndexCacheLoader.method6514(var0, var1, var2);
      } else if (var0 < 3700) {
         return VarpDefinition.method4926(var0, var1, var2);
      } else if (var0 < 4000) {
         return class137.method2881(var0, var1, var2);
      } else if (var0 < 4100) {
         return FontName.method5759(var0, var1, var2);
      } else if (var0 < 4200) {
         return BufferedNetSocket.method3133(var0, var1, var2);
      } else if (var0 < 4300) {
         return class31.method707(var0, var1, var2);
      } else if (var0 < 5100) {
         return VarcInt.method4773(var0, var1, var2);
      } else if (var0 < 5400) {
         return class103.method2016(var0, var1, var2);
      } else if (var0 < 5600) {
         return BufferedSource.method2925(var0, var1, var2);
      } else if (var0 < 5700) {
         return class39.method980(var0, var1, var2);
      } else if (var0 < 6300) {
         return SpotAnimationDefinition.method5542(var0, var1, var2);
      } else if (var0 < 6600) {
         return AbstractSocket.method3106(var0, var1, var2);
      } else {
         return var0 < 6700 ? class99.method1847(var0, var1, var2) : 2;
      }
   }
}
