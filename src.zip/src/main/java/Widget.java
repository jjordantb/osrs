public class Widget extends Node {
   public static EvictingDualNodeHashTable field2583 = new EvictingDualNodeHashTable(50);
   public static EvictingDualNodeHashTable field2584 = new EvictingDualNodeHashTable(20);
   public static EvictingDualNodeHashTable field2582 = new EvictingDualNodeHashTable(200);
   public static boolean field2586 = false;
   public static AbstractIndexCache field2678;
   public static EvictingDualNodeHashTable field2585 = new EvictingDualNodeHashTable(8);
   public int scrollY = 0;
   public int field2589 = 1;
   public int y = 0;
   public int scrollHeight = 0;
   public int x = 0;
   public int rawX = 0;
   public int field2605 = 1;
   public RectangleMode rectangleMode;
   public int scrollWidth = 0;
   public int height = 0;
   public int color2 = 0;
   public int color = 0;
   public int mouseOverColor2 = 0;
   public int rawY = 0;
   public int mouseOverColor = 0;
   public int transparency;
   public boolean field2622;
   public int parentId = -1;
   public int scrollX = 0;
   public boolean isHidden = false;
   public int lineWid;
   public int field2620;
   public int rawHeight = 0;
   public int rawWidth = 0;
   public boolean fill = false;
   public int width = 0;
   public int spriteAngle;
   int modelType2;
   public int sequenceId;
   public int field2643;
   public int modelOffsetX;
   public int modelType;
   public int sequenceId2;
   public int modelAngleX;
   public boolean spriteTiling;
   public int modelOffsetY;
   public int modelId;
   int modelId2;
   public int modelAngleZ;
   public boolean modelOrthog;
   public int field2644;
   public int outline;
   public boolean spriteFlipH;
   public int field2718;
   public int spriteId2;
   public int fontId;
   public boolean field2646;
   public int spriteShadow;
   public boolean spriteFlipV;
   public int modelZoom;
   public int modelAngleY;
   public int spriteId;
   public int[] inventorySprites;
   public String text;
   public int paddingY;
   public int childIndex = -1;
   public int paddingX;
   public String text2;
   public String[] itemActions;
   public int textLineHeight;
   public int id = -1;
   public int[] field2666;
   public boolean isIf3 = false;
   public int textYAlignment;
   public int textXAlignment;
   public int buttonType = 0;
   public int clickMask;
   public boolean field2645;
   public int[] field2686;
   public int heightAlignment = 0;
   public boolean textShadowed;
   public byte[][] field2664;
   public byte[][] field2631;
   public int xAlignment = 0;
   public int type;
   public int widthAlignment = 0;
   public int[] inventoryXOffsets;
   public int[] inventoryYOffsets;
   public String dataText;
   public int yAlignment = 0;
   public int contentType = 0;
   public Widget parent;
   public int[] invTransmitTriggers;
   public int dragZoneSize;
   public Object[] onTimer;
   public Object[] onStatTransmit;
   public Object[] onVarTransmit;
   public Object[] onClickRepeat;
   public String spellActionName;
   public Object[] onInvTransmit;
   public boolean hasListener;
   public boolean isScrollBar;
   public Object[] onTargetEnter;
   public String[] actions;
   public Object[] onClick;
   public Object[] onDrag;
   public Object[] onMouseOver;
   public Object[] onMouseRepeat;
   public Object[] onLoad;
   public int[] varTransmitTriggers;
   public Object[] onRelease;
   public Object[] onHold;
   public Object[] onTargetLeave;
   public Object[] onDragComplete;
   public Object[] onMouseLeave;
   public int[] statTransmitTriggers;
   public int dragThreshold;
   public int[] itemIds;
   public Object[] onOp;
   public Object[] field2710;
   public int[] cs1ComparisonValues;
   public Object[] field2704;
   public Widget[] children;
   public Object[] field2702;
   public int itemId;
   public Object[] onScroll;
   public String buttonText;
   public int itemQuantity;
   public Object[] field2696;
   public Object[] field2700;
   public int[][] cs1Instructions;
   public int modelFrame;
   public int modelFrameCycle;
   public int[] itemQuantities;
   public String spellName;
   public Object[] field2717;
   public boolean field2719;
   public Object[] field2668;
   public int[] cs1Comparisons;
   public int mouseOverRedirect;
   public Object[] field2587;
   public Object[] field2698;
   public Object[] field2703;
   public int cycle;
   public boolean field2667;
   public boolean field2590;
   public int field2656;
   public int field2723;
   public int rootIndex;
   public boolean noClickThrough;
   public int[] field2727;
   public int field2722;
   public int field2721;

   public Widget() {
      this.rectangleMode = RectangleMode.field4001;
      this.transparency = 0;
      this.field2620 = 0;
      this.lineWid = 1;
      this.field2622 = false;
      this.spriteId2 = -1;
      this.spriteId = -1;
      this.spriteAngle = 0;
      this.spriteTiling = false;
      this.outline = 0;
      this.spriteShadow = 0;
      this.modelType = 1;
      this.modelId = -1;
      this.modelType2 = 1;
      this.modelId2 = -1;
      this.sequenceId = -1;
      this.sequenceId2 = -1;
      this.modelOffsetX = 0;
      this.modelOffsetY = 0;
      this.modelAngleX = 0;
      this.modelAngleY = 0;
      this.modelAngleZ = 0;
      this.modelZoom = 100;
      this.field2643 = 0;
      this.field2644 = 0;
      this.modelOrthog = false;
      this.field2646 = false;
      this.field2718 = 2;
      this.fontId = -1;
      this.text = "";
      this.text2 = "";
      this.textLineHeight = 0;
      this.textXAlignment = 0;
      this.textYAlignment = 0;
      this.textShadowed = false;
      this.paddingX = 0;
      this.paddingY = 0;
      this.clickMask = 0;
      this.field2645 = false;
      this.dataText = "";
      this.parent = null;
      this.dragZoneSize = 0;
      this.dragThreshold = 0;
      this.isScrollBar = false;
      this.spellActionName = "";
      this.hasListener = false;
      this.mouseOverRedirect = -1;
      this.spellName = "";
      this.buttonText = "Ok";
      this.itemId = -1;
      this.itemQuantity = 0;
      this.modelFrame = 0;
      this.modelFrameCycle = 0;
      this.field2719 = false;
      this.field2590 = false;
      this.field2721 = -1;
      this.field2722 = 0;
      this.field2723 = 0;
      this.field2656 = 0;
      this.rootIndex = -1;
      this.cycle = -1;
      this.noClickThrough = false;
      this.field2667 = false;
   }

   public SpriteMask getSpriteMask(boolean var1) {
      if (this.spriteId == -1) {
         var1 = false;
      }

      int var2 = var1 ? this.spriteId : this.spriteId2;
      if (var2 == -1) {
         return null;
      } else {
         long var3 = ((long)this.spriteShadow << 40) + ((this.spriteFlipV ? 1L : 0L) << 39) + ((this.spriteFlipH ? 1L : 0L) << 38) + (long)var2 + ((long)this.outline << 36);
         SpriteMask var5 = (SpriteMask)field2585.get(var3);
         if (var5 != null) {
            return var5;
         } else {
            Sprite var6 = this.getSprite(var1);
            if (var6 == null) {
               return null;
            } else {
               Sprite var7 = var6.copyNormalized();
               int[] var8 = new int[var7.subHeight];
               int[] var9 = new int[var7.subHeight];

               for(int var10 = 0; var10 < var7.subHeight; ++var10) {
                  int var11 = 0;
                  int var12 = var7.subWidth;

                  int var13;
                  for(var13 = 0; var13 < var7.subWidth; ++var13) {
                     if (var7.pixels[var13 + var10 * var7.subWidth] == 0) {
                        var11 = var13;
                        break;
                     }
                  }

                  for(var13 = var7.subWidth - 1; var13 >= var11; --var13) {
                     if (var7.pixels[var13 + var10 * var7.subWidth] == 0) {
                        var12 = var13 + 1;
                        break;
                     }
                  }

                  var8[var10] = var11;
                  var9[var10] = var12 - var11;
               }

               var5 = new SpriteMask(var7.subWidth, var7.subHeight, var9, var8, var2);
               field2585.put(var5, var3);
               return var5;
            }
         }
      }
   }

   int[] readListenerTriggers(Buffer var1) {
      int var2 = var1.readUnsignedByte();
      if (var2 == 0) {
         return null;
      } else {
         int[] var3 = new int[var2];

         for(int var4 = 0; var4 < var2; ++var4) {
            var3[var4] = var1.readInt();
         }

         return var3;
      }
   }

   public Model getModel(SequenceDefinition var1, int var2, boolean var3, PlayerAppearance var4) {
      field2586 = false;
      int var5;
      int var6;
      if (var3) {
         var5 = this.modelType2;
         var6 = this.modelId2;
      } else {
         var5 = this.modelType;
         var6 = this.modelId;
      }

      if (var5 == 0) {
         return null;
      } else if (var5 == 1 && var6 == -1) {
         return null;
      } else {
         Model var7 = (Model)field2583.get((long)(var6 + (var5 << 16)));
         if (var7 == null) {
            ModelData var8;
            if (var5 == 1) {
               var8 = ModelData.method2741(Frames.field1632, var6, 0);
               if (var8 == null) {
                  field2586 = true;
                  return null;
               }

               var7 = var8.toModel(64, 768, -50, -10, -50);
            }

            if (var5 == 2) {
               var8 = NetFileRequest.method4959(var6).getModelData();
               if (var8 == null) {
                  field2586 = true;
                  return null;
               }

               var7 = var8.toModel(64, 768, -50, -10, -50);
            }

            if (var5 == 3) {
               if (var4 == null) {
                  return null;
               }

               var8 = var4.getModelData();
               if (var8 == null) {
                  field2586 = true;
                  return null;
               }

               var7 = var8.toModel(64, 768, -50, -10, -50);
            }

            if (var5 == 4) {
               ItemDefinition var9 = Varcs.getItemDefinition(var6);
               var8 = var9.method5525(10);
               if (var8 == null) {
                  field2586 = true;
                  return null;
               }

               var7 = var8.toModel(var9.ambient + 64, var9.contrast + 768, -50, -10, -50);
            }

            field2583.put(var7, (long)(var6 + (var5 << 16)));
         }

         if (var1 != null) {
            var7 = var1.animateWidget(var7, var2);
         }

         return var7;
      }
   }

   public Sprite getInventorySprite(int var1) {
      field2586 = false;
      if (var1 >= 0 && var1 < this.inventorySprites.length) {
         int var2 = this.inventorySprites[var1];
         if (var2 == -1) {
            return null;
         } else {
            Sprite var3 = (Sprite)field2582.get((long)var2);
            if (var3 != null) {
               return var3;
            } else {
               var3 = UserComparator3.method2971(Buddy.field3791, var2, 0);
               if (var3 != null) {
                  field2582.put(var3, (long)var2);
               } else {
                  field2586 = true;
               }

               return var3;
            }
         }
      } else {
         return null;
      }
   }

   void decodeLegacy(Buffer var1) {
      this.isIf3 = false;
      this.type = var1.readUnsignedByte();
      this.buttonType = var1.readUnsignedByte();
      this.contentType = var1.method3913();
      this.rawX = var1.method3956();
      this.rawY = var1.method3956();
      this.rawWidth = var1.method3913();
      this.rawHeight = var1.method3913();
      this.transparency = var1.readUnsignedByte();
      this.parentId = var1.method3913();
      if (this.parentId == 65535) {
         this.parentId = -1;
      } else {
         this.parentId += this.id & -65536;
      }

      this.mouseOverRedirect = var1.method3913();
      if (this.mouseOverRedirect == 65535) {
         this.mouseOverRedirect = -1;
      }

      int var2 = var1.readUnsignedByte();
      int var3;
      if (var2 > 0) {
         this.cs1Comparisons = new int[var2];
         this.cs1ComparisonValues = new int[var2];

         for(var3 = 0; var3 < var2; ++var3) {
            this.cs1Comparisons[var3] = var1.readUnsignedByte();
            this.cs1ComparisonValues[var3] = var1.method3913();
         }
      }

      var3 = var1.readUnsignedByte();
      int var4;
      int var5;
      int var6;
      if (var3 > 0) {
         this.cs1Instructions = new int[var3][];

         for(var4 = 0; var4 < var3; ++var4) {
            var5 = var1.method3913();
            this.cs1Instructions[var4] = new int[var5];

            for(var6 = 0; var6 < var5; ++var6) {
               this.cs1Instructions[var4][var6] = var1.method3913();
               if (this.cs1Instructions[var4][var6] == 65535) {
                  this.cs1Instructions[var4][var6] = -1;
               }
            }
         }
      }

      if (this.type == 0) {
         this.scrollHeight = var1.method3913();
         this.isHidden = var1.readUnsignedByte() == 1;
      }

      if (this.type == 1) {
         var1.method3913();
         var1.readUnsignedByte();
      }

      if (this.type == 2) {
         this.itemIds = new int[this.rawWidth * this.rawHeight];
         this.itemQuantities = new int[this.rawHeight * this.rawWidth];
         var4 = var1.readUnsignedByte();
         if (var4 == 1) {
            this.clickMask |= 268435456;
         }

         var5 = var1.readUnsignedByte();
         if (var5 == 1) {
            this.clickMask |= 1073741824;
         }

         var6 = var1.readUnsignedByte();
         if (var6 == 1) {
            this.clickMask |= Integer.MIN_VALUE;
         }

         int var7 = var1.readUnsignedByte();
         if (var7 == 1) {
            this.clickMask |= 536870912;
         }

         this.paddingX = var1.readUnsignedByte();
         this.paddingY = var1.readUnsignedByte();
         this.inventoryXOffsets = new int[20];
         this.inventoryYOffsets = new int[20];
         this.inventorySprites = new int[20];

         int var8;
         for(var8 = 0; var8 < 20; ++var8) {
            int var9 = var1.readUnsignedByte();
            if (var9 == 1) {
               this.inventoryXOffsets[var8] = var1.method3956();
               this.inventoryYOffsets[var8] = var1.method3956();
               this.inventorySprites[var8] = var1.readInt();
            } else {
               this.inventorySprites[var8] = -1;
            }
         }

         this.itemActions = new String[5];

         for(var8 = 0; var8 < 5; ++var8) {
            String var10 = var1.readStringCp1252NullTerminated();
            if (var10.length() > 0) {
               this.itemActions[var8] = var10;
               this.clickMask |= 1 << var8 + 23;
            }
         }
      }

      if (this.type == 3) {
         this.fill = var1.readUnsignedByte() == 1;
      }

      if (this.type == 4 || this.type == 1) {
         this.textXAlignment = var1.readUnsignedByte();
         this.textYAlignment = var1.readUnsignedByte();
         this.textLineHeight = var1.readUnsignedByte();
         this.fontId = var1.method3913();
         if (this.fontId == 65535) {
            this.fontId = -1;
         }

         this.textShadowed = var1.readUnsignedByte() == 1;
      }

      if (this.type == 4) {
         this.text = var1.readStringCp1252NullTerminated();
         this.text2 = var1.readStringCp1252NullTerminated();
      }

      if (this.type == 1 || this.type == 3 || this.type == 4) {
         this.color = var1.readInt();
      }

      if (this.type == 3 || this.type == 4) {
         this.color2 = var1.readInt();
         this.mouseOverColor = var1.readInt();
         this.mouseOverColor2 = var1.readInt();
      }

      if (this.type == 5) {
         this.spriteId2 = var1.readInt();
         this.spriteId = var1.readInt();
      }

      if (this.type == 6) {
         this.modelType = 1;
         this.modelId = var1.method3913();
         if (this.modelId == 65535) {
            this.modelId = -1;
         }

         this.modelType2 = 1;
         this.modelId2 = var1.method3913();
         if (this.modelId2 == 65535) {
            this.modelId2 = -1;
         }

         this.sequenceId = var1.method3913();
         if (this.sequenceId == 65535) {
            this.sequenceId = -1;
         }

         this.sequenceId2 = var1.method3913();
         if (this.sequenceId2 == 65535) {
            this.sequenceId2 = -1;
         }

         this.modelZoom = var1.method3913();
         this.modelAngleX = var1.method3913();
         this.modelAngleY = var1.method3913();
      }

      if (this.type == 7) {
         this.itemIds = new int[this.rawWidth * this.rawHeight];
         this.itemQuantities = new int[this.rawWidth * this.rawHeight];
         this.textXAlignment = var1.readUnsignedByte();
         this.fontId = var1.method3913();
         if (this.fontId == 65535) {
            this.fontId = -1;
         }

         this.textShadowed = var1.readUnsignedByte() == 1;
         this.color = var1.readInt();
         this.paddingX = var1.method3956();
         this.paddingY = var1.method3956();
         var4 = var1.readUnsignedByte();
         if (var4 == 1) {
            this.clickMask |= 1073741824;
         }

         this.itemActions = new String[5];

         for(var5 = 0; var5 < 5; ++var5) {
            String var11 = var1.readStringCp1252NullTerminated();
            if (var11.length() > 0) {
               this.itemActions[var5] = var11;
               this.clickMask |= 1 << var5 + 23;
            }
         }
      }

      if (this.type == 8) {
         this.text = var1.readStringCp1252NullTerminated();
      }

      if (this.buttonType == 2 || this.type == 2) {
         this.spellActionName = var1.readStringCp1252NullTerminated();
         this.spellName = var1.readStringCp1252NullTerminated();
         var4 = var1.method3913() & 63;
         this.clickMask |= var4 << 11;
      }

      if (this.buttonType == 1 || this.buttonType == 4 || this.buttonType == 5 || this.buttonType == 6) {
         this.buttonText = var1.readStringCp1252NullTerminated();
         if (this.buttonText.length() == 0) {
            if (this.buttonType == 1) {
               this.buttonText = "Ok";
            }

            if (this.buttonType == 4) {
               this.buttonText = "Select";
            }

            if (this.buttonType == 5) {
               this.buttonText = "Select";
            }

            if (this.buttonType == 6) {
               this.buttonText = "Continue";
            }
         }
      }

      if (this.buttonType == 1 || this.buttonType == 4 || this.buttonType == 5) {
         this.clickMask |= 4194304;
      }

      if (this.buttonType == 6) {
         this.clickMask |= 1;
      }

   }

   public void swapItems(int var1, int var2) {
      int var3 = this.itemIds[var2];
      this.itemIds[var2] = this.itemIds[var1];
      this.itemIds[var1] = var3;
      var3 = this.itemQuantities[var2];
      this.itemQuantities[var2] = this.itemQuantities[var1];
      this.itemQuantities[var1] = var3;
   }

   Object[] readListener(Buffer var1) {
      int var2 = var1.readUnsignedByte();
      if (var2 == 0) {
         return null;
      } else {
         Object[] var3 = new Object[var2];

         for(int var4 = 0; var4 < var2; ++var4) {
            int var5 = var1.readUnsignedByte();
            if (var5 == 0) {
               var3[var4] = new Integer(var1.readInt());
            } else if (var5 == 1) {
               var3[var4] = var1.readStringCp1252NullTerminated();
            }
         }

         this.hasListener = true;
         return var3;
      }
   }

   void decode(Buffer var1) {
      var1.readUnsignedByte();
      this.isIf3 = true;
      this.type = var1.readUnsignedByte();
      this.contentType = var1.method3913();
      this.rawX = var1.method3956();
      this.rawY = var1.method3956();
      this.rawWidth = var1.method3913();
      if (this.type == 9) {
         this.rawHeight = var1.method3956();
      } else {
         this.rawHeight = var1.method3913();
      }

      this.widthAlignment = var1.readByte();
      this.heightAlignment = var1.readByte();
      this.xAlignment = var1.readByte();
      this.yAlignment = var1.readByte();
      this.parentId = var1.method3913();
      if (this.parentId == 65535) {
         this.parentId = -1;
      } else {
         this.parentId += this.id & -65536;
      }

      this.isHidden = var1.readUnsignedByte() == 1;
      if (this.type == 0) {
         this.scrollWidth = var1.method3913();
         this.scrollHeight = var1.method3913();
         this.noClickThrough = var1.readUnsignedByte() == 1;
      }

      if (this.type == 5) {
         this.spriteId2 = var1.readInt();
         this.spriteAngle = var1.method3913();
         this.spriteTiling = var1.readUnsignedByte() == 1;
         this.transparency = var1.readUnsignedByte();
         this.outline = var1.readUnsignedByte();
         this.spriteShadow = var1.readInt();
         this.spriteFlipH = var1.readUnsignedByte() == 1;
         this.spriteFlipV = var1.readUnsignedByte() == 1;
      }

      if (this.type == 6) {
         this.modelType = 1;
         this.modelId = var1.method3913();
         if (this.modelId == 65535) {
            this.modelId = -1;
         }

         this.modelOffsetX = var1.method3956();
         this.modelOffsetY = var1.method3956();
         this.modelAngleX = var1.method3913();
         this.modelAngleY = var1.method3913();
         this.modelAngleZ = var1.method3913();
         this.modelZoom = var1.method3913();
         this.sequenceId = var1.method3913();
         if (this.sequenceId == 65535) {
            this.sequenceId = -1;
         }

         this.modelOrthog = var1.readUnsignedByte() == 1;
         var1.method3913();
         if (this.widthAlignment != 0) {
            this.field2643 = var1.method3913();
         }

         if (this.heightAlignment != 0) {
            var1.method3913();
         }
      }

      if (this.type == 4) {
         this.fontId = var1.method3913();
         if (this.fontId == 65535) {
            this.fontId = -1;
         }

         this.text = var1.readStringCp1252NullTerminated();
         this.textLineHeight = var1.readUnsignedByte();
         this.textXAlignment = var1.readUnsignedByte();
         this.textYAlignment = var1.readUnsignedByte();
         this.textShadowed = var1.readUnsignedByte() == 1;
         this.color = var1.readInt();
      }

      if (this.type == 3) {
         this.color = var1.readInt();
         this.fill = var1.readUnsignedByte() == 1;
         this.transparency = var1.readUnsignedByte();
      }

      if (this.type == 9) {
         this.lineWid = var1.readUnsignedByte();
         this.color = var1.readInt();
         this.field2622 = var1.readUnsignedByte() == 1;
      }

      this.clickMask = var1.readMedium();
      this.dataText = var1.readStringCp1252NullTerminated();
      int var2 = var1.readUnsignedByte();
      if (var2 > 0) {
         this.actions = new String[var2];

         for(int var3 = 0; var3 < var2; ++var3) {
            this.actions[var3] = var1.readStringCp1252NullTerminated();
         }
      }

      this.dragZoneSize = var1.readUnsignedByte();
      this.dragThreshold = var1.readUnsignedByte();
      this.isScrollBar = var1.readUnsignedByte() == 1;
      this.spellActionName = var1.readStringCp1252NullTerminated();
      this.onLoad = this.readListener(var1);
      this.onMouseOver = this.readListener(var1);
      this.onMouseLeave = this.readListener(var1);
      this.onTargetLeave = this.readListener(var1);
      this.onTargetEnter = this.readListener(var1);
      this.onVarTransmit = this.readListener(var1);
      this.onInvTransmit = this.readListener(var1);
      this.onStatTransmit = this.readListener(var1);
      this.onTimer = this.readListener(var1);
      this.onOp = this.readListener(var1);
      this.onMouseRepeat = this.readListener(var1);
      this.onClick = this.readListener(var1);
      this.onClickRepeat = this.readListener(var1);
      this.onRelease = this.readListener(var1);
      this.onHold = this.readListener(var1);
      this.onDrag = this.readListener(var1);
      this.onDragComplete = this.readListener(var1);
      this.onScroll = this.readListener(var1);
      this.varTransmitTriggers = this.readListenerTriggers(var1);
      this.invTransmitTriggers = this.readListenerTriggers(var1);
      this.statTransmitTriggers = this.readListenerTriggers(var1);
   }

   public void setAction(int var1, String var2) {
      if (this.actions == null || this.actions.length <= var1) {
         String[] var3 = new String[var1 + 1];
         if (this.actions != null) {
            for(int var4 = 0; var4 < this.actions.length; ++var4) {
               var3[var4] = this.actions[var4];
            }
         }

         this.actions = var3;
      }

      this.actions[var1] = var2;
   }

   public Font getFont() {
      field2586 = false;
      if (this.fontId == -1) {
         return null;
      } else {
         Font var1 = (Font)field2584.get((long)this.fontId);
         if (var1 != null) {
            return var1;
         } else {
            AbstractIndexCache var3 = Buddy.field3791;
            AbstractIndexCache var4 = WorldMapIcon.field249;
            int var5 = this.fontId;
            Font var2;
            if (!class65.method1382(var3, var5, 0)) {
               var2 = null;
            } else {
               byte[] var7 = var4.takeRecord(var5, 0);
               Font var6;
               if (var7 == null) {
                  var6 = null;
               } else {
                  Font var8 = new Font(var7, class328.field3982, class328.field3984, class328.field3987, VarcInt.field2811, class328.field3986, class328.field3989);
                  class328.field3982 = null;
                  class328.field3984 = null;
                  class328.field3987 = null;
                  VarcInt.field2811 = null;
                  class328.field3986 = null;
                  class328.field3989 = null;
                  var6 = var8;
               }

               var2 = var6;
            }

            if (var2 != null) {
               field2584.put(var2, (long)this.fontId);
            } else {
               field2586 = true;
            }

            return var2;
         }
      }
   }

   public Sprite getSprite(boolean var1) {
      field2586 = false;
      int var2;
      if (var1) {
         var2 = this.spriteId;
      } else {
         var2 = this.spriteId2;
      }

      if (var2 == -1) {
         return null;
      } else {
         long var3 = ((long)this.spriteShadow << 40) + ((this.spriteFlipV ? 1L : 0L) << 39) + ((this.spriteFlipH ? 1L : 0L) << 38) + ((long)this.outline << 36) + (long)var2;
         Sprite var5 = (Sprite)field2582.get(var3);
         if (var5 != null) {
            return var5;
         } else {
            var5 = UserComparator3.method2971(Buddy.field3791, var2, 0);
            if (var5 == null) {
               field2586 = true;
               return null;
            } else {
               if (this.spriteFlipH) {
                  var5.method6365();
               }

               if (this.spriteFlipV) {
                  var5.method6343();
               }

               if (this.outline > 0) {
                  var5.method6341(this.outline);
               }

               if (this.outline >= 1) {
                  var5.method6344(1);
               }

               if (this.outline >= 2) {
                  var5.method6344(16777215);
               }

               if (this.spriteShadow != 0) {
                  var5.method6345(this.spriteShadow);
               }

               field2582.put(var5, var3);
               return var5;
            }
         }
      }
   }

   public static String method4613(CharSequence var0, LoginType var1) {
      if (var0 == null) {
         return null;
      } else {
         int var2 = 0;

         int var3;
         for(var3 = var0.length(); var2 < var3 && ParamsDefinition.method5297(var0.charAt(var2)); ++var2) {
            ;
         }

         while(var3 > var2 && ParamsDefinition.method5297(var0.charAt(var3 - 1))) {
            --var3;
         }

         int var4 = var3 - var2;
         if (var4 >= 1 && var4 <= class81.method1635(var1)) {
            StringBuilder var5 = new StringBuilder(var4);

            for(int var6 = var2; var6 < var3; ++var6) {
               char var7 = var0.charAt(var6);
               boolean var8;
               if (Character.isISOControl(var7)) {
                  var8 = false;
               } else if (class257.method5070(var7)) {
                  var8 = true;
               } else {
                  char[] var9 = class306.field3786;
                  int var10 = 0;

                  label73:
                  while(true) {
                     char var11;
                     if (var10 >= var9.length) {
                        var9 = class306.field3787;

                        for(var10 = 0; var10 < var9.length; ++var10) {
                           var11 = var9[var10];
                           if (var11 == var7) {
                              var8 = true;
                              break label73;
                           }
                        }

                        var8 = false;
                        break;
                     }

                     var11 = var9[var10];
                     if (var7 == var11) {
                        var8 = true;
                        break;
                     }

                     ++var10;
                  }
               }

               if (var8) {
                  char var12 = SoundSystems.method1780(var7);
                  if (var12 != 0) {
                     var5.append(var12);
                  }
               }
            }

            if (var5.length() == 0) {
               return null;
            } else {
               return var5.toString();
            }
         } else {
            return null;
         }
      }
   }
}
