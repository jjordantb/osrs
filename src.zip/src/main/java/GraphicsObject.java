public final class GraphicsObject extends Entity {
   static IndexCache field569;
   SequenceDefinition sequenceDefinition;
   int y;
   int plane;
   int id;
   boolean isFinished = false;
   int height;
   int frameCycle = 0;
   int x;
   int cycleStart;
   int frame = 0;

   GraphicsObject(int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      this.id = var1;
      this.plane = var2;
      this.x = var3;
      this.y = var4;
      this.height = var5;
      this.cycleStart = var7 + var6;
      int var8 = IndexStoreActionHandler.method4937(this.id).sequence;
      if (var8 != -1) {
         this.isFinished = false;
         this.sequenceDefinition = WorldMapCacheName.method547(var8);
      } else {
         this.isFinished = true;
      }

   }

   protected final Model getModel() {
      SpotAnimationDefinition var1 = IndexStoreActionHandler.method4937(this.id);
      Model var2;
      if (!this.isFinished) {
         var2 = var1.getModel(this.frame);
      } else {
         var2 = var1.getModel(-1);
      }

      return var2 == null ? null : var2;
   }

   final void advance(int var1) {
      if (!this.isFinished) {
         this.frameCycle += var1;

         while(this.frameCycle > this.sequenceDefinition.frameLengths[this.frame]) {
            this.frameCycle -= this.sequenceDefinition.frameLengths[this.frame];
            ++this.frame;
            if (this.frame >= this.sequenceDefinition.frameIds.length) {
               this.isFinished = true;
               break;
            }
         }

      }
   }

   static void method1082(int var0) {
      ItemContainer var1 = (ItemContainer)ItemContainer.field267.get((long)var0);
      if (var1 != null) {
         for(int var2 = 0; var2 < var1.ids.length; ++var2) {
            var1.ids[var2] = -1;
            var1.quantities[var2] = 0;
         }

      }
   }

   static final void method1075(Widget var0, int var1, int var2) {
      if (var0.buttonType == 1) {
         Login.method1253(var0.buttonText, "", 24, 0, 0, var0.id);
      }

      String var3;
      if (var0.buttonType == 2 && !Client.field2241) {
         var3 = Script.method1819(var0);
         if (var3 != null) {
            Login.method1253(var3, ModelData0.method2792(65280) + var0.spellName, 25, 0, -1, var0.id);
         }
      }

      if (var0.buttonType == 3) {
         Login.method1253("Close", "", 26, 0, 0, var0.id);
      }

      if (var0.buttonType == 4) {
         Login.method1253(var0.buttonText, "", 28, 0, 0, var0.id);
      }

      if (var0.buttonType == 5) {
         Login.method1253(var0.buttonText, "", 29, 0, 0, var0.id);
      }

      if (var0.buttonType == 6 && Client.field2323 == null) {
         Login.method1253(var0.buttonText, "", 30, 0, -1, var0.id);
      }

      int var4;
      int var5;
      int var6;
      int var7;
      int var15;
      if (var0.type == 2) {
         var15 = 0;

         for(var4 = 0; var4 < var0.height; ++var4) {
            for(var5 = 0; var5 < var0.width; ++var5) {
               var6 = (var0.paddingX + 32) * var5;
               var7 = (var0.paddingY + 32) * var4;
               if (var15 < 20) {
                  var6 += var0.inventoryXOffsets[var15];
                  var7 += var0.inventoryYOffsets[var15];
               }

               if (var1 >= var6 && var2 >= var7 && var1 < var6 + 32 && var2 < var7 + 32) {
                  Client.field2240 = var15;
                  class73.field855 = var0;
                  if (var0.itemIds[var15] > 0) {
                     ItemDefinition var8 = Varcs.getItemDefinition(var0.itemIds[var15] - 1);
                     if (Client.field2239 == 1 && LoginPacket.method3275(class257.method5068(var0))) {
                        if (var0.id != ChatChannel.field598 || var15 != WorldMapLabel.field1014) {
                           Login.method1253("Use", Client.field2209 + " " + "->" + " " + ModelData0.method2792(16748608) + var8.name, 31, var8.id, var15, var0.id);
                        }
                     } else if (Client.field2241 && LoginPacket.method3275(class257.method5068(var0))) {
                        if ((FontName.field3737 & 16) == 16) {
                           Login.method1253(Client.field2244, Client.field2159 + " " + "->" + " " + ModelData0.method2792(16748608) + var8.name, 32, var8.id, var15, var0.id);
                        }
                     } else {
                        String[] var9 = var8.inventoryActions;
                        int var10 = -1;
                        boolean var11;
                        if (Client.field2232) {
                           var11 = Client.field2233 || KeyHandler.field11[81];
                           if (var11) {
                              var10 = var8.getShiftClickIndex();
                           }
                        }

                        if (LoginPacket.method3275(class257.method5068(var0))) {
                           for(int var22 = 4; var22 >= 3; --var22) {
                              if (var10 != var22) {
                                 class73.method1482(var0, var8, var15, var22, false);
                              }
                           }
                        }

                        int var12 = class257.method5068(var0);
                        var11 = (var12 >> 31 & 1) != 0;
                        if (var11) {
                           Login.method1253("Use", ModelData0.method2792(16748608) + var8.name, 38, var8.id, var15, var0.id);
                        }

                        Object var10000 = null;
                        int var13;
                        if (LoginPacket.method3275(class257.method5068(var0))) {
                           for(var13 = 2; var13 >= 0; --var13) {
                              if (var13 != var10) {
                                 class73.method1482(var0, var8, var15, var13, false);
                              }
                           }

                           if (var10 >= 0) {
                              class73.method1482(var0, var8, var15, var10, true);
                           }
                        }

                        var9 = var0.itemActions;
                        if (var9 != null) {
                           for(var13 = 4; var13 >= 0; --var13) {
                              if (var9[var13] != null) {
                                 byte var14 = 0;
                                 if (var13 == 0) {
                                    var14 = 39;
                                 }

                                 if (var13 == 1) {
                                    var14 = 40;
                                 }

                                 if (var13 == 2) {
                                    var14 = 41;
                                 }

                                 if (var13 == 3) {
                                    var14 = 42;
                                 }

                                 if (var13 == 4) {
                                    var14 = 43;
                                 }

                                 Login.method1253(var9[var13], ModelData0.method2792(16748608) + var8.name, var14, var8.id, var15, var0.id);
                              }
                           }
                        }

                        Login.method1253("Examine", ModelData0.method2792(16748608) + var8.name, 1005, var8.id, var15, var0.id);
                     }
                  }
               }

               ++var15;
            }
         }
      }

      if (var0.isIf3) {
         if (Client.field2241) {
            var4 = class257.method5068(var0);
            boolean var23 = (var4 >> 21 & 1) != 0;
            if (var23 && (FontName.field3737 & 32) == 32) {
               Login.method1253(Client.field2244, Client.field2159 + " " + "->" + " " + var0.dataText, 58, 0, var0.childIndex, var0.id);
            }
         } else {
            for(var15 = 9; var15 >= 5; --var15) {
               var6 = class257.method5068(var0);
               boolean var19 = (var6 >> var15 + 1 & 1) != 0;
               String var16;
               if (!var19 && var0.onOp == null) {
                  var16 = null;
               } else if (var0.actions != null && var0.actions.length > var15 && var0.actions[var15] != null && var0.actions[var15].trim().length() != 0) {
                  var16 = var0.actions[var15];
               } else {
                  var16 = null;
               }

               if (var16 != null) {
                  Login.method1253(var16, var0.dataText, 1007, var15 + 1, var0.childIndex, var0.id);
               }
            }

            var3 = Script.method1819(var0);
            if (var3 != null) {
               Login.method1253(var3, var0.dataText, 25, 0, var0.childIndex, var0.id);
            }

            for(var4 = 4; var4 >= 0; --var4) {
               var7 = class257.method5068(var0);
               boolean var21 = (var7 >> var4 + 1 & 1) != 0;
               String var17;
               if (!var21 && var0.onOp == null) {
                  var17 = null;
               } else if (var0.actions != null && var0.actions.length > var4 && var0.actions[var4] != null && var0.actions[var4].trim().length() != 0) {
                  var17 = var0.actions[var4];
               } else {
                  var17 = null;
               }

               if (var17 != null) {
                  Login.method1253(var17, var0.dataText, 57, var4 + 1, var0.childIndex, var0.id);
               }
            }

            var5 = class257.method5068(var0);
            boolean var20 = (var5 & 1) != 0;
            if (var20) {
               Login.method1253("Continue", "", 30, 0, var0.childIndex, var0.id);
            }
         }
      }

   }
}
