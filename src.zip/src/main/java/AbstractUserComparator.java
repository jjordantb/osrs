import java.util.Comparator;

public abstract class AbstractUserComparator implements Comparator {
   Comparator field3515;

   final void method5345(Comparator var1) {
      if (this.field3515 == null) {
         this.field3515 = var1;
      } else if (this.field3515 instanceof AbstractUserComparator) {
         ((AbstractUserComparator)this.field3515).method5345(var1);
      }

   }

   protected final int method5349(User var1, User var2) {
      return this.field3515 == null ? 0 : this.field3515.compare(var1, var2);
   }

   public boolean equals(Object var1) {
      return super.equals(var1);
   }
}
