public class UserComparator6 extends AbstractUserComparator {
   static java.awt.Font field1629;
   final boolean field1627;

   public UserComparator6(boolean var1) {
      this.field1627 = var1;
   }

   int method2885(Buddy var1, Buddy var2) {
      if (var1.world != 0 && var2.world != 0) {
         return this.field1627 ? var1.method5384().compareTo0(var2.method5384()) : var2.method5384().compareTo0(var1.method5384());
      } else {
         return this.method5349(var1, var2);
      }
   }

   public int compare(Object var1, Object var2) {
      return this.method2885((Buddy)var1, (Buddy)var2);
   }
}
