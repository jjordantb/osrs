public class class31 extends class177 {
   static int field368;
   static int field369;
   static int field364;
   static int field363;

   public boolean vmethod3287(int var1, int var2, int var3, CollisionMap var4) {
      return var2 == super.field1966 && var3 == super.field1962;
   }

   static int method707(int var0, Script var1, boolean var2) {
      int var3;
      if (var0 == 4200) {
         var3 = Interpreter.field467[--field364];
         Interpreter.field462[++Interpreter.field469 - 1] = Varcs.getItemDefinition(var3).name;
         return 1;
      } else {
         int var4;
         ItemDefinition var5;
         if (var0 == 4201) {
            field364 -= 2;
            var3 = Interpreter.field467[field364];
            var4 = Interpreter.field467[field364 + 1];
            var5 = Varcs.getItemDefinition(var3);
            if (var4 >= 1 && var4 <= 5 && var5.groundActions[var4 - 1] != null) {
               Interpreter.field462[++Interpreter.field469 - 1] = var5.groundActions[var4 - 1];
            } else {
               Interpreter.field462[++Interpreter.field469 - 1] = "";
            }

            return 1;
         } else if (var0 == 4202) {
            field364 -= 2;
            var3 = Interpreter.field467[field364];
            var4 = Interpreter.field467[field364 + 1];
            var5 = Varcs.getItemDefinition(var3);
            if (var4 >= 1 && var4 <= 5 && var5.inventoryActions[var4 - 1] != null) {
               Interpreter.field462[++Interpreter.field469 - 1] = var5.inventoryActions[var4 - 1];
            } else {
               Interpreter.field462[++Interpreter.field469 - 1] = "";
            }

            return 1;
         } else if (var0 == 4203) {
            var3 = Interpreter.field467[--field364];
            Interpreter.field467[++field364 - 1] = Varcs.getItemDefinition(var3).price;
            return 1;
         } else if (var0 == 4204) {
            var3 = Interpreter.field467[--field364];
            Interpreter.field467[++field364 - 1] = Varcs.getItemDefinition(var3).isStackable == 1 ? 1 : 0;
            return 1;
         } else {
            ItemDefinition var6;
            if (var0 == 4205) {
               var3 = Interpreter.field467[--field364];
               var6 = Varcs.getItemDefinition(var3);
               if (var6.noteTemplate == -1 && var6.note >= 0) {
                  Interpreter.field467[++field364 - 1] = var6.note;
               } else {
                  Interpreter.field467[++field364 - 1] = var3;
               }

               return 1;
            } else if (var0 == 4206) {
               var3 = Interpreter.field467[--field364];
               var6 = Varcs.getItemDefinition(var3);
               if (var6.noteTemplate >= 0 && var6.note >= 0) {
                  Interpreter.field467[++field364 - 1] = var6.note;
               } else {
                  Interpreter.field467[++field364 - 1] = var3;
               }

               return 1;
            } else if (var0 == 4207) {
               var3 = Interpreter.field467[--field364];
               Interpreter.field467[++field364 - 1] = Varcs.getItemDefinition(var3).isMembersOnly ? 1 : 0;
               return 1;
            } else if (var0 == 4208) {
               var3 = Interpreter.field467[--field364];
               var6 = Varcs.getItemDefinition(var3);
               if (var6.placeholderTemplate == -1 && var6.placeholder >= 0) {
                  Interpreter.field467[++field364 - 1] = var6.placeholder;
               } else {
                  Interpreter.field467[++field364 - 1] = var3;
               }

               return 1;
            } else if (var0 == 4209) {
               var3 = Interpreter.field467[--field364];
               var6 = Varcs.getItemDefinition(var3);
               if (var6.placeholderTemplate >= 0 && var6.placeholder >= 0) {
                  Interpreter.field467[++field364 - 1] = var6.placeholder;
               } else {
                  Interpreter.field467[++field364 - 1] = var3;
               }

               return 1;
            } else if (var0 == 4210) {
               String var7 = Interpreter.field462[--Interpreter.field469];
               var4 = Interpreter.field467[--field364];
               MouseHandler.method457(var7, var4 == 1);
               Interpreter.field467[++field364 - 1] = MilliClock.field1661;
               return 1;
            } else if (var0 != 4211) {
               if (var0 == 4212) {
                  class71.field843 = 0;
                  return 1;
               } else {
                  return 2;
               }
            } else {
               if (WorldMapData2.field106 != null && class71.field843 < MilliClock.field1661) {
                  Interpreter.field467[++field364 - 1] = WorldMapData2.field106[++class71.field843 - 1] & '\uffff';
               } else {
                  Interpreter.field467[++field364 - 1] = -1;
               }

               return 1;
            }
         }
      }
   }

   public static void method706() {
      VarpDefinition.field2927.clear();
   }
}
