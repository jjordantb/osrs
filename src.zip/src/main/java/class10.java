import javax.imageio.ImageIO;

public class class10 {
   static class76 field116;
   static long field114;

   static {
      ImageIO.setUseCache(false);
   }

   public static Enumerated method352(Enumerated[] var0, int var1) {
      Enumerated[] var2 = var0;

      for(int var3 = 0; var3 < var2.length; ++var3) {
         Enumerated var4 = var2[var3];
         if (var1 == var4.ordinal()) {
            return var4;
         }
      }

      return null;
   }

   static AttackOption[] method348() {
      return new AttackOption[]{AttackOption.field602, AttackOption.field600, AttackOption.field605, AttackOption.field607};
   }

   static final int method353(int var0, int var1) {
      int var2 = class196.method4198(var0 + '넵', var1 + 91923, 4) - 128 + (class196.method4198(var0 + 10294, var1 + '鎽', 2) - 128 >> 1) + (class196.method4198(var0, var1, 1) - 128 >> 2);
      var2 = (int)((double)var2 * 0.3D) + 35;
      if (var2 < 10) {
         var2 = 10;
      } else if (var2 > 60) {
         var2 = 60;
      }

      return var2;
   }

   static final void method351(class37 var0) {
      long var1 = 0L;
      int var3 = -1;
      int var4 = 0;
      int var5 = 0;
      if (var0.field450 == 0) {
         var1 = class243.field2904.method2251(var0.field458, var0.field446, var0.field449);
      }

      if (var0.field450 == 1) {
         var1 = class243.field2904.method2252(var0.field458, var0.field446, var0.field449);
      }

      if (var0.field450 == 2) {
         var1 = class243.field2904.method2253(var0.field458, var0.field446, var0.field449);
      }

      if (var0.field450 == 3) {
         var1 = class243.field2904.getFloorDecorationTag(var0.field458, var0.field446, var0.field449);
      }

      if (0L != var1) {
         int var6 = class243.field2904.getObjectFlags(var0.field458, var0.field446, var0.field449, var1);
         var3 = WidgetGroupParent.method1000(var1);
         var4 = var6 & 31;
         var5 = var6 >> 6 & 3;
      }

      var0.field447 = var3;
      var0.field448 = var4;
      var0.field459 = var5;
   }
}
