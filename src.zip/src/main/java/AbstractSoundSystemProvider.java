public interface AbstractSoundSystemProvider {
   AbstractSoundSystem soundSystem();
}
