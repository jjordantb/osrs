public class class5 {
   protected static boolean field52;

   static MusicPatch method155(AbstractIndexCache var0, int var1) {
      byte[] var2 = var0.takeRecordFlat(var1);
      return var2 == null ? null : new MusicPatch(var2);
   }

   public static int method156(byte[] var0, int var1, CharSequence var2) {
      int var3 = var2.length();
      int var4 = var1;

      for(int var5 = 0; var5 < var3; ++var5) {
         char var6 = var2.charAt(var5);
         if (var6 <= '\u007f') {
            var0[var4++] = (byte)var6;
         } else if (var6 <= '\u07ff') {
            var0[var4++] = (byte)(192 | var6 >> 6);
            var0[var4++] = (byte)(128 | var6 & 63);
         } else {
            var0[var4++] = (byte)(224 | var6 >> 12);
            var0[var4++] = (byte)(128 | var6 >> 6 & 63);
            var0[var4++] = (byte)(128 | var6 & 63);
         }
      }

      return var4 - var1;
   }

   static int method154(int var0, Script var1, boolean var2) {
      int var4 = -1;
      Widget var3;
      if (var0 >= 2000) {
         var0 -= 1000;
         var4 = Interpreter.field467[--class31.field364];
         var3 = WorldMapSection3.method1148(var4);
      } else {
         var3 = var2 ? class85.field961 : Interpreter.field477;
      }

      if (var0 == 1100) {
         class31.field364 -= 2;
         var3.scrollX = Interpreter.field467[class31.field364];
         if (var3.scrollX > var3.scrollWidth - var3.width) {
            var3.scrollX = var3.scrollWidth - var3.width;
         }

         if (var3.scrollX < 0) {
            var3.scrollX = 0;
         }

         var3.scrollY = Interpreter.field467[class31.field364 + 1];
         if (var3.scrollY > var3.scrollHeight - var3.height) {
            var3.scrollY = var3.scrollHeight - var3.height;
         }

         if (var3.scrollY < 0) {
            var3.scrollY = 0;
         }

         WorldMapSection1.method506(var3);
         return 1;
      } else if (var0 == 1101) {
         var3.color = Interpreter.field467[--class31.field364];
         WorldMapSection1.method506(var3);
         return 1;
      } else if (var0 == 1102) {
         var3.fill = Interpreter.field467[--class31.field364] == 1;
         WorldMapSection1.method506(var3);
         return 1;
      } else if (var0 == 1103) {
         var3.transparency = Interpreter.field467[--class31.field364];
         WorldMapSection1.method506(var3);
         return 1;
      } else if (var0 == 1104) {
         var3.lineWid = Interpreter.field467[--class31.field364];
         WorldMapSection1.method506(var3);
         return 1;
      } else if (var0 == 1105) {
         var3.spriteId2 = Interpreter.field467[--class31.field364];
         WorldMapSection1.method506(var3);
         return 1;
      } else if (var0 == 1106) {
         var3.spriteAngle = Interpreter.field467[--class31.field364];
         WorldMapSection1.method506(var3);
         return 1;
      } else if (var0 == 1107) {
         var3.spriteTiling = Interpreter.field467[--class31.field364] == 1;
         WorldMapSection1.method506(var3);
         return 1;
      } else if (var0 == 1108) {
         var3.modelType = 1;
         var3.modelId = Interpreter.field467[--class31.field364];
         WorldMapSection1.method506(var3);
         return 1;
      } else if (var0 == 1109) {
         class31.field364 -= 6;
         var3.modelOffsetX = Interpreter.field467[class31.field364];
         var3.modelOffsetY = Interpreter.field467[class31.field364 + 1];
         var3.modelAngleX = Interpreter.field467[class31.field364 + 2];
         var3.modelAngleY = Interpreter.field467[class31.field364 + 3];
         var3.modelAngleZ = Interpreter.field467[class31.field364 + 4];
         var3.modelZoom = Interpreter.field467[class31.field364 + 5];
         WorldMapSection1.method506(var3);
         return 1;
      } else {
         int var8;
         if (var0 == 1110) {
            var8 = Interpreter.field467[--class31.field364];
            if (var8 != var3.sequenceId) {
               var3.sequenceId = var8;
               var3.modelFrame = 0;
               var3.modelFrameCycle = 0;
               WorldMapSection1.method506(var3);
            }

            return 1;
         } else if (var0 == 1111) {
            var3.modelOrthog = Interpreter.field467[--class31.field364] == 1;
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1112) {
            String var7 = Interpreter.field462[--Interpreter.field469];
            if (!var7.equals(var3.text)) {
               var3.text = var7;
               WorldMapSection1.method506(var3);
            }

            return 1;
         } else if (var0 == 1113) {
            var3.fontId = Interpreter.field467[--class31.field364];
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1114) {
            class31.field364 -= 3;
            var3.textXAlignment = Interpreter.field467[class31.field364];
            var3.textYAlignment = Interpreter.field467[class31.field364 + 1];
            var3.textLineHeight = Interpreter.field467[class31.field364 + 2];
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1115) {
            var3.textShadowed = Interpreter.field467[--class31.field364] == 1;
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1116) {
            var3.outline = Interpreter.field467[--class31.field364];
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1117) {
            var3.spriteShadow = Interpreter.field467[--class31.field364];
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1118) {
            var3.spriteFlipH = Interpreter.field467[--class31.field364] == 1;
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1119) {
            var3.spriteFlipV = Interpreter.field467[--class31.field364] == 1;
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1120) {
            class31.field364 -= 2;
            var3.scrollWidth = Interpreter.field467[class31.field364];
            var3.scrollHeight = Interpreter.field467[class31.field364 + 1];
            WorldMapSection1.method506(var3);
            if (var4 != -1 && var3.type == 0) {
               MusicPatch.method4734(UserComparator3.field1708[var4 >> 16], var3, false);
            }

            return 1;
         } else if (var0 == 1121) {
            SequenceDefinition.method5247(var3.id, var3.childIndex);
            Client.field2323 = var3;
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1122) {
            var3.spriteId = Interpreter.field467[--class31.field364];
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1123) {
            var3.color2 = Interpreter.field467[--class31.field364];
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1124) {
            var3.field2620 = Interpreter.field467[--class31.field364];
            WorldMapSection1.method506(var3);
            return 1;
         } else if (var0 == 1125) {
            var8 = Interpreter.field467[--class31.field364];
            RectangleMode var6 = (RectangleMode)class10.method352(GameObject.method2904(), var8);
            if (var6 != null) {
               var3.rectangleMode = var6;
               WorldMapSection1.method506(var3);
            }

            return 1;
         } else {
            boolean var5;
            if (var0 == 1126) {
               var5 = Interpreter.field467[--class31.field364] == 1;
               var3.field2622 = var5;
               return 1;
            } else if (var0 == 1127) {
               var5 = Interpreter.field467[--class31.field364] == 1;
               var3.field2646 = var5;
               return 1;
            } else {
               return 2;
            }
         }
      }
   }
}
