public class class130 implements Enumerated {
   public static boolean[] field1567;
   public static final class130 field1561 = new class130(1, 2);
   public static final class130 field1564 = new class130(2, 0);
   public static final class130 field1563 = new class130(3, 3);
   public static final class130 field1562 = new class130(0, 1);
   public final int field1565;
   final int field1566;

   class130(int var1, int var2) {
      this.field1565 = var1;
      this.field1566 = var2;
   }

   public int ordinal() {
      return this.field1566;
   }

   static String method2826(IterableNodeHashTable var0, int var1, String var2) {
      if (var0 == null) {
         return var2;
      } else {
         ObjectNode var3 = (ObjectNode)var0.get((long)var1);
         return var3 == null ? var2 : (String)var3.obj;
      }
   }

   static void method2825() {
      for(ObjectSound var0 = (ObjectSound)ObjectSound.field577.last(); var0 != null; var0 = (ObjectSound)ObjectSound.field577.previous()) {
         if (var0.field590 != null) {
            class10.field116.method1564(var0.field590);
            var0.field590 = null;
         }

         if (var0.field586 != null) {
            class10.field116.method1564(var0.field586);
            var0.field586 = null;
         }
      }

      ObjectSound.field577.clear();
   }

   static int ordinal(IterableNodeHashTable var0, int var1, int var2) {
      if (var0 == null) {
         return var2;
      } else {
         IntegerNode var3 = (IntegerNode)var0.get((long)var1);
         return var3 == null ? var2 : var3.integer;
      }
   }

   static final void method2827(Actor var0, int var1) {
      int var2;
      int var3;
      int var4;
      if (var0.field323 > Client.field2098) {
         var2 = var0.field323 - Client.field2098;
         var3 = var0.field321 * 128 + var0.size * 64;
         var4 = var0.field333 * 128 + var0.size * 64;
         var0.x += (var3 - var0.x) / var2;
         var0.y += (var4 - var0.y) / var2;
         var0.field293 = 0;
         var0.orientation = var0.field335;
      } else if (var0.field315 >= Client.field2098) {
         if (var0.field315 == Client.field2098 || var0.sequence == -1 || var0.sequenceDelay != 0 || var0.sequenceFrameCycle + 1 > WorldMapCacheName.method547(var0.sequence).frameLengths[var0.sequenceFrame]) {
            var2 = var0.field315 - var0.field323;
            var3 = Client.field2098 - var0.field323;
            var4 = var0.field321 * 128 + var0.size * 64;
            int var5 = var0.field333 * 128 + var0.size * 64;
            int var6 = var0.field320 * 128 + var0.size * 64;
            int var7 = var0.field322 * 128 + var0.size * 64;
            var0.x = (var6 * var3 + var4 * (var2 - var3)) / var2;
            var0.y = (var7 * var3 + var5 * (var2 - var3)) / var2;
         }

         var0.field293 = 0;
         var0.orientation = var0.field335;
         var0.field278 = var0.orientation;
      } else {
         UnderlayDefinition.method5416(var0);
      }

      if (var0.x < 128 || var0.y < 128 || var0.x >= 13184 || var0.y >= 13184) {
         var0.sequence = -1;
         var0.spotAnimation = -1;
         var0.field323 = 0;
         var0.field315 = 0;
         var0.x = var0.pathX[0] * 128 + var0.size * 64;
         var0.y = var0.pathY[0] * 128 + var0.size * 64;
         var0.method619();
      }

      if (ObjectSound.field589 == var0 && (var0.x < 1536 || var0.y < 1536 || var0.x >= 11776 || var0.y >= 11776)) {
         var0.sequence = -1;
         var0.spotAnimation = -1;
         var0.field323 = 0;
         var0.field315 = 0;
         var0.x = var0.pathX[0] * 128 + var0.size * 64;
         var0.y = var0.pathY[0] * 128 + var0.size * 64;
         var0.method619();
      }

      KeyHandler.method26(var0);
      var0.field279 = false;
      SequenceDefinition var8;
      if (var0.movementSequence != -1) {
         var8 = WorldMapCacheName.method547(var0.movementSequence);
         if (var8 != null && var8.frameIds != null) {
            ++var0.movementFrameCycle;
            if (var0.movementFrame < var8.frameIds.length && var0.movementFrameCycle > var8.frameLengths[var0.movementFrame]) {
               var0.movementFrameCycle = 1;
               ++var0.movementFrame;
               Huffman.method3037(var8, var0.movementFrame, var0.x, var0.y);
            }

            if (var0.movementFrame >= var8.frameIds.length) {
               var0.movementFrameCycle = 0;
               var0.movementFrame = 0;
               Huffman.method3037(var8, var0.movementFrame, var0.x, var0.y);
            }
         } else {
            var0.movementSequence = -1;
         }
      }

      if (var0.spotAnimation != -1 && Client.field2098 >= var0.field317) {
         if (var0.spotAnimationFrame < 0) {
            var0.spotAnimationFrame = 0;
         }

         var2 = IndexStoreActionHandler.method4937(var0.spotAnimation).sequence;
         if (var2 != -1) {
            SequenceDefinition var9 = WorldMapCacheName.method547(var2);
            if (var9 != null && var9.frameIds != null) {
               ++var0.spotAnimationFrameCycle;
               if (var0.spotAnimationFrame < var9.frameIds.length && var0.spotAnimationFrameCycle > var9.frameLengths[var0.spotAnimationFrame]) {
                  var0.spotAnimationFrameCycle = 1;
                  ++var0.spotAnimationFrame;
                  Huffman.method3037(var9, var0.spotAnimationFrame, var0.x, var0.y);
               }

               if (var0.spotAnimationFrame >= var9.frameIds.length && (var0.spotAnimationFrame < 0 || var0.spotAnimationFrame >= var9.frameIds.length)) {
                  var0.spotAnimation = -1;
               }
            } else {
               var0.spotAnimation = -1;
            }
         } else {
            var0.spotAnimation = -1;
         }
      }

      if (var0.sequence != -1 && var0.sequenceDelay <= 1) {
         var8 = WorldMapCacheName.method547(var0.sequence);
         if (var8.field3470 == 1 && var0.field297 > 0 && var0.field323 <= Client.field2098 && var0.field315 < Client.field2098) {
            var0.sequenceDelay = 1;
            return;
         }
      }

      if (var0.sequence != -1 && var0.sequenceDelay == 0) {
         var8 = WorldMapCacheName.method547(var0.sequence);
         if (var8 != null && var8.frameIds != null) {
            ++var0.sequenceFrameCycle;
            if (var0.sequenceFrame < var8.frameIds.length && var0.sequenceFrameCycle > var8.frameLengths[var0.sequenceFrame]) {
               var0.sequenceFrameCycle = 1;
               ++var0.sequenceFrame;
               Huffman.method3037(var8, var0.sequenceFrame, var0.x, var0.y);
            }

            if (var0.sequenceFrame >= var8.frameIds.length) {
               var0.sequenceFrame -= var8.frameCount;
               ++var0.field313;
               if (var0.field313 >= var8.field3481) {
                  var0.sequence = -1;
               } else if (var0.sequenceFrame >= 0 && var0.sequenceFrame < var8.frameIds.length) {
                  Huffman.method3037(var8, var0.sequenceFrame, var0.x, var0.y);
               } else {
                  var0.sequence = -1;
               }
            }

            var0.field279 = var8.field3474;
         } else {
            var0.sequence = -1;
         }
      }

      if (var0.sequenceDelay > 0) {
         --var0.sequenceDelay;
      }

   }
}
