public class class205 {
   static NetFileRequest field2491;
   public static class214 field2492;

   static final boolean method4286(byte[] var0, int var1, int var2) {
      boolean var3 = true;
      Buffer var4 = new Buffer(var0);
      int var5 = -1;

      label68:
      while(true) {
         int var6 = var4.method3926();
         if (var6 == 0) {
            return var3;
         }

         var5 += var6;
         int var7 = 0;
         boolean var8 = false;

         while(true) {
            int var9;
            while(!var8) {
               var9 = var4.method3925();
               if (var9 == 0) {
                  continue label68;
               }

               var7 += var9 - 1;
               int var10 = var7 & 63;
               int var11 = var7 >> 6 & 63;
               int var12 = var4.readUnsignedByte() >> 2;
               int var13 = var11 + var1;
               int var14 = var10 + var2;
               if (var13 > 0 && var14 > 0 && var13 < 103 && var14 < 103) {
                  ObjectDefinition var15 = class252.method4958(var5);
                  if (var12 != 22 || !Client.field2091 || var15.int1 != 0 || var15.interactType == 1 || var15.boolean2) {
                     if (!var15.method5148()) {
                        ++Client.field2196;
                        var3 = false;
                     }

                     var8 = true;
                  }
               }
            }

            var9 = var4.method3925();
            if (var9 == 0) {
               break;
            }

            var4.readUnsignedByte();
         }
      }
   }
}
