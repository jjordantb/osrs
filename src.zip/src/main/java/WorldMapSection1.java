public class WorldMapSection1 implements WorldMapSection {
   static UrlRequester field186;
   static int[] field201;
   int field192;
   int field190;
   int field188;
   int field195;
   int field198;
   int field187;
   int field193;
   int field189;
   int field194;
   int field191;

   public TileLocation vmethod1861(int var1, int var2) {
      if (!this.vmethod1857(var1, var2)) {
         return null;
      } else {
         int var3 = this.field188 * 64 - this.field190 * 64 + (this.field192 * 8 - this.field193 * 8) + var1;
         int var4 = this.field189 * 64 - this.field187 * 64 + var2 + (this.field191 * 8 - this.field198 * 8);
         return new TileLocation(this.field195, var3, var4);
      }
   }

   public boolean vmethod1857(int var1, int var2) {
      return var1 >= (this.field190 << 6) + (this.field193 << 3) && var1 <= (this.field190 << 6) + (this.field193 << 3) + 7 && var2 >= (this.field187 << 6) + (this.field198 << 3) && var2 <= (this.field187 << 6) + (this.field198 << 3) + 7;
   }

   public void vmethod1855(WorldMapData var1) {
      if (var1.field881 > this.field190) {
         var1.field881 = this.field190;
      }

      if (var1.field882 < this.field190) {
         var1.field882 = this.field190;
      }

      if (var1.field877 > this.field187) {
         var1.field877 = this.field187;
      }

      if (var1.field886 < this.field187) {
         var1.field886 = this.field187;
      }

   }

   public void read(Buffer var1) {
      this.field195 = var1.readUnsignedByte();
      this.field194 = var1.readUnsignedByte();
      this.field188 = var1.method3913();
      this.field192 = var1.readUnsignedByte();
      this.field189 = var1.method3913();
      this.field191 = var1.readUnsignedByte();
      this.field190 = var1.method3913();
      this.field193 = var1.readUnsignedByte();
      this.field187 = var1.method3913();
      this.field198 = var1.readUnsignedByte();
      this.method485();
   }

   void method485() {
   }

   public int[] vmethod1858(int var1, int var2, int var3) {
      if (!this.vmethod1856(var1, var2, var3)) {
         return null;
      } else {
         int[] var4 = new int[]{this.field190 * 64 - this.field188 * 64 + var2 + (this.field193 * 8 - this.field192 * 8), var3 + (this.field187 * 64 - this.field189 * 64) + (this.field198 * 8 - this.field191 * 8)};
         return var4;
      }
   }

   public boolean vmethod1856(int var1, int var2, int var3) {
      if (var1 >= this.field195 && var1 < this.field194 + this.field195) {
         return var2 >= (this.field188 << 6) + (this.field192 << 3) && var2 <= (this.field188 << 6) + (this.field192 << 3) + 7 && var3 >= (this.field189 << 6) + (this.field191 << 3) && var3 <= (this.field189 << 6) + (this.field191 << 3) + 7;
      } else {
         return false;
      }
   }

   public static HealthBarDefinition method483(int var0) {
      HealthBarDefinition var1 = (HealthBarDefinition)HealthBarDefinition.field3452.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = HealthBarDefinition.field3456.takeRecord(33, var0);
         var1 = new HealthBarDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         HealthBarDefinition.field3452.put(var1, (long)var0);
         return var1;
      }
   }

   static void method506(Widget var0) {
      if (var0.cycle == Client.field2290) {
         Client.field2291[var0.rootIndex] = true;
      }

   }

   static final void method504(Widget var0) {
      int var1 = var0.contentType;
      if (var1 == 324) {
         if (Client.field2317 == -1) {
            Client.field2317 = var0.spriteId2;
            Client.field2353 = var0.spriteId;
         }

         if (Client.field2351.isFemale) {
            var0.spriteId2 = Client.field2317;
         } else {
            var0.spriteId2 = Client.field2353;
         }

      } else if (var1 == 325) {
         if (Client.field2317 == -1) {
            Client.field2317 = var0.spriteId2;
            Client.field2353 = var0.spriteId;
         }

         if (Client.field2351.isFemale) {
            var0.spriteId2 = Client.field2353;
         } else {
            var0.spriteId2 = Client.field2317;
         }

      } else if (var1 == 327) {
         var0.modelAngleX = 150;
         var0.modelAngleY = (int)(Math.sin((double) Client.field2098 / 40.0D) * 256.0D) & 2047;
         var0.modelType = 5;
         var0.modelId = 0;
      } else if (var1 == 328) {
         var0.modelAngleX = 150;
         var0.modelAngleY = (int)(Math.sin((double) Client.field2098 / 40.0D) * 256.0D) & 2047;
         var0.modelType = 5;
         var0.modelId = 1;
      }
   }
}
