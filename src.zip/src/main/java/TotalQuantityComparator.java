import java.lang.management.GarbageCollectorMXBean;
import java.util.Comparator;

final class TotalQuantityComparator implements Comparator {
   static ClanChat field983;
   static Sprite field986;
   static GarbageCollectorMXBean field981;
   static Font field982;

   int method1762(GrandExchangeEvent var1, GrandExchangeEvent var2) {
      return var1.grandExchangeOffer.totalQuantity < var2.grandExchangeOffer.totalQuantity ? -1 : (var2.grandExchangeOffer.totalQuantity == var1.grandExchangeOffer.totalQuantity ? 0 : 1);
   }

   public boolean equals(Object var1) {
      return super.equals(var1);
   }

   public int compare(Object var1, Object var2) {
      return this.method1762((GrandExchangeEvent)var1, (GrandExchangeEvent)var2);
   }

   public static int method1760(int var0) {
      --var0;
      var0 |= var0 >>> 1;
      var0 |= var0 >>> 2;
      var0 |= var0 >>> 4;
      var0 |= var0 >>> 8;
      var0 |= var0 >>> 16;
      return var0 + 1;
   }

   static final void method1768(int var0, int var1, int var2, int var3, boolean var4) {
      if (var2 < 1) {
         var2 = 1;
      }

      if (var3 < 1) {
         var3 = 1;
      }

      int var5 = var3 - 334;
      int var6;
      if (var5 < 0) {
         var6 = Client.field2092;
      } else if (var5 >= 100) {
         var6 = Client.field2339;
      } else {
         var6 = (Client.field2339 - Client.field2092) * var5 / 100 + Client.field2092;
      }

      int var7 = var3 * var6 * 512 / (var2 * 334);
      int var8;
      int var9;
      short var10;
      if (var7 < Client.field2344) {
         var10 = Client.field2344;
         var6 = var10 * var2 * 334 / (var3 * 512);
         if (var6 > Client.field2127) {
            var6 = Client.field2127;
            var8 = var3 * var6 * 512 / (var10 * 334);
            var9 = (var2 - var8) / 2;
            if (var4) {
               Rasterizer2D.method6213();
               Rasterizer2D.method6223(var0, var1, var9, var3, -16777216);
               Rasterizer2D.method6223(var0 + var2 - var9, var1, var9, var3, -16777216);
            }

            var0 += var9;
            var2 -= var9 * 2;
         }
      } else if (var7 > Client.field2197) {
         var10 = Client.field2197;
         var6 = var10 * var2 * 334 / (var3 * 512);
         if (var6 < Client.field2342) {
            var6 = Client.field2342;
            var8 = var10 * var2 * 334 / (var6 * 512);
            var9 = (var3 - var8) / 2;
            if (var4) {
               Rasterizer2D.method6213();
               Rasterizer2D.method6223(var0, var1, var2, var9, -16777216);
               Rasterizer2D.method6223(var0, var3 + var1 - var9, var2, var9, -16777216);
            }

            var1 += var9;
            var3 -= var9 * 2;
         }
      }

      Client.field2350 = var3 * var6 / 334;
      if (var2 != Client.field2087 || var3 != Client.field2207) {
         ScriptEvent.method1039(var2, var3);
      }

      Client.field2100 = var0;
      Client.field2136 = var1;
      Client.field2087 = var2;
      Client.field2207 = var3;
   }
}
