import java.util.HashMap;

public class class252 {
   static int field3263;
   int field3259 = 0;
   int[] field3255 = new int[2048];
   final HashMap field3258 = new HashMap();
   int[] field3260 = new int[2048];
   Bounds field3256 = new Bounds(0, 0);

   public class252() {
      class103.field1125 = new int[2000];
      int var1 = 0;
      int var2 = 240;

      int var4;
      for(byte var3 = 12; var1 < 16; var2 -= var3) {
         var4 = class57.method1225((double)((float)var2 / 360.0F), 0.9998999834060669D, (double)(0.075F + 0.425F * (float)var1 / 16.0F));
         class103.field1125[var1] = var4;
         ++var1;
      }

      var2 = 48;

      for(int var6 = var2 / 6; var1 < class103.field1125.length; var2 -= var6) {
         var4 = var1 * 2;

         for(int var5 = class57.method1225((double)((float)var2 / 360.0F), 0.9998999834060669D, 0.5D); var1 < var4 && var1 < class103.field1125.length; ++var1) {
            class103.field1125[var1] = var5;
         }
      }

   }

   public final void method4949(int var1, int var2, Sprite var3, float var4) {
      int var5 = (int)(var4 * 18.0F);
      Sprite var6 = this.method4946(var5);
      int var7 = var5 * 2 + 1;
      Bounds var8 = new Bounds(0, 0, var3.subWidth, var3.subHeight);
      Bounds var9 = new Bounds(0, 0);
      this.field3256.method5976(var7, var7);
      System.nanoTime();

      int var10;
      int var11;
      int var12;
      for(var10 = 0; var10 < this.field3259; ++var10) {
         var11 = this.field3255[var10];
         var12 = this.field3260[var10];
         int var13 = (int)(var4 * (float)(var11 - var1)) - var5;
         int var14 = (int)((float)var3.subHeight - (float)(var12 - var2) * var4) - var5;
         this.field3256.method5975(var13, var14);
         this.field3256.method5978(var8, var9);
         this.method4953(var6, var3, var9);
      }

      System.nanoTime();
      System.nanoTime();

      for(var10 = 0; var10 < var3.pixels.length; ++var10) {
         if (var3.pixels[var10] == 0) {
            var3.pixels[var10] = -16777216;
         } else {
            var11 = (var3.pixels[var10] + 64 - 1) / 256;
            if (var11 <= 0) {
               var3.pixels[var10] = -16777216;
            } else {
               if (var11 > class103.field1125.length) {
                  var11 = class103.field1125.length;
               }

               var12 = class103.field1125[var11 - 1];
               var3.pixels[var10] = -16777216 | var12;
            }
         }
      }

      System.nanoTime();
   }

   public final void method4947(int var1, int var2) {
      if (this.field3259 < this.field3255.length) {
         this.field3255[this.field3259] = var1;
         this.field3260[this.field3259] = var2;
         ++this.field3259;
      }
   }

   void method4945(int var1) {
      int var2 = var1 * 2 + 1;
      double[] var3 = UserComparator2.method6489(0.0D, (double)((float)var1 / 3.0F), var1);
      double var4 = var3[var1] * var3[var1];
      int[] var6 = new int[var2 * var2];
      boolean var7 = false;

      for(int var8 = 0; var8 < var2; ++var8) {
         for(int var9 = 0; var9 < var2; ++var9) {
            int var10 = var6[var9 + var2 * var8] = (int)(var3[var9] * var3[var8] / var4 * 256.0D);
            if (!var7 && var10 > 0) {
               var7 = true;
            }
         }
      }

      Sprite var11 = new Sprite(var6, var2, var2);
      this.field3258.put(var1, var11);
   }

   void method4953(Sprite var1, Sprite var2, Bounds var3) {
      if (var3.field3828 != 0 && var3.field3829 != 0) {
         int var4 = 0;
         int var5 = 0;
         if (var3.field3827 == 0) {
            var4 = var1.subWidth - var3.field3828;
         }

         if (var3.field3826 == 0) {
            var5 = var1.subHeight - var3.field3829;
         }

         int var6 = var4 + var5 * var1.subWidth;
         int var7 = var2.subWidth * var3.field3826 + var3.field3827;

         for(int var8 = 0; var8 < var3.field3829; ++var8) {
            for(int var9 = 0; var9 < var3.field3828; ++var9) {
               int var10001 = var7++;
               var2.pixels[var10001] += var1.pixels[var6++];
            }

            var6 += var1.subWidth - var3.field3828;
            var7 += var2.subWidth - var3.field3828;
         }

      }
   }

   public final void method4948() {
      this.field3259 = 0;
   }

   Sprite method4946(int var1) {
      if (!this.field3258.containsKey(var1)) {
         this.method4945(var1);
      }

      return (Sprite)this.field3258.get(var1);
   }

   public static ObjectDefinition method4958(int var0) {
      ObjectDefinition var1 = (ObjectDefinition)ObjectDefinition.field3390.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = ObjectDefinition.field3387.takeRecord(6, var0);
         var1 = new ObjectDefinition();
         var1.id = var0;
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         var1.init();
         if (var1.isSolid) {
            var1.interactType = 0;
            var1.boolean1 = false;
         }

         ObjectDefinition.field3390.put(var1, (long)var0);
         return var1;
      }
   }
}
