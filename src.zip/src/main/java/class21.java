public final class class21 {
   static int field230;
   static Sprite[] field229;

   static void method544(boolean var0) {
      Login.field671 = "";
      Login.field672 = "Enter your username/email & password.";
      Login.field673 = "";
      Login.field669 = 2;
      if (var0) {
         Login.field675 = "";
      }

      if (Login.field686 == null || Login.field686.length() <= 0) {
         if (GameShell.field72.rememberedUsername != null) {
            Login.field686 = GameShell.field72.rememberedUsername;
            Client.field2189 = true;
         } else {
            Client.field2189 = false;
         }
      }

      if (Client.field2189 && Login.field686 != null && Login.field686.length() > 0) {
         Login.field656 = 1;
      } else {
         Login.field656 = 0;
      }

   }

   public static void method543(int var0, int var1, int var2, boolean var3) {
      PacketBufferNode var4 = FaceNormal.method2884(ClientPacket.field1840, Client.field2133.isaacCipher);
      var4.packetBuffer.writeIntME(var3 ? Client.field2102 : 0);
      var4.packetBuffer.writeShortLE(var1);
      var4.packetBuffer.method3938(var2);
      var4.packetBuffer.writeShort(var0);
      Client.field2133.method1281(var4);
   }
}
