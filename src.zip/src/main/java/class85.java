public class class85 extends class69 {
   static String field968;
   static IndexedSprite[] field967;
   static IndexedSprite field963;
   static Widget field961;
   static IndexCache field966;
   static String field965;

   void method1724(Buffer var1, Buffer var2) {
      int var3 = var2.readUnsignedByte();
      if (var3 != class83.field945.field941) {
         throw new IllegalStateException("");
      } else {
         super.field828 = var2.readUnsignedByte();
         super.field826 = var2.readUnsignedByte();
         super.field824 = var2.method3913();
         super.field829 = var2.method3913();
         super.field825 = var2.method3913();
         super.field827 = var2.method3913();
         super.field826 = Math.min(super.field826, 4);
         super.field830 = new short[1][64][64];
         super.field831 = new short[super.field826][64][64];
         super.field832 = new byte[super.field826][64][64];
         super.field833 = new byte[super.field826][64][64];
         super.field834 = new class93[super.field826][64][64][];
         var3 = var1.readUnsignedByte();
         if (var3 != class95.field1042.field1038) {
            throw new IllegalStateException("");
         } else {
            int var4 = var1.readUnsignedByte();
            int var5 = var1.readUnsignedByte();
            if (var4 == super.field825 && var5 == super.field827) {
               for(int var6 = 0; var6 < 64; ++var6) {
                  for(int var7 = 0; var7 < 64; ++var7) {
                     this.method1422(var6, var7, var1);
                  }
               }

            } else {
               throw new IllegalStateException("");
            }
         }
      }
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof class85)) {
         return false;
      } else {
         class85 var2 = (class85)var1;
         return var2.field825 == super.field825 && var2.field827 == super.field827;
      }
   }

   public int hashCode() {
      return super.field825 | super.field827 << 8;
   }

   public static boolean method1735() {
      return class219.field2568 != 0 ? true : class205.field2492.method4459();
   }

   static final void method1733(PacketBuffer var0) {
      int var1 = 0;
      var0.importIndex();

      int var2;
      int var3;
      int var4;
      for(var2 = 0; var2 < Players.field951; ++var2) {
         var3 = Players.field947[var2];
         if ((Players.field948[var3] & 1) == 0) {
            if (var1 > 0) {
               --var1;
               Players.field948[var3] = (byte)(Players.field948[var3] | 2);
            } else {
               var4 = var0.readBits(1);
               if (var4 == 0) {
                  var1 = WorldMapLabel.method1782(var0);
                  Players.field948[var3] = (byte)(Players.field948[var3] | 2);
               } else {
                  PacketBufferNode.method3172(var0, var3);
               }
            }
         }
      }

      var0.exportIndex();
      if (var1 != 0) {
         throw new RuntimeException();
      } else {
         var0.importIndex();

         for(var2 = 0; var2 < Players.field951; ++var2) {
            var3 = Players.field947[var2];
            if ((Players.field948[var3] & 1) != 0) {
               if (var1 > 0) {
                  --var1;
                  Players.field948[var3] = (byte)(Players.field948[var3] | 2);
               } else {
                  var4 = var0.readBits(1);
                  if (var4 == 0) {
                     var1 = WorldMapLabel.method1782(var0);
                     Players.field948[var3] = (byte)(Players.field948[var3] | 2);
                  } else {
                     PacketBufferNode.method3172(var0, var3);
                  }
               }
            }
         }

         var0.exportIndex();
         if (var1 != 0) {
            throw new RuntimeException();
         } else {
            var0.importIndex();

            for(var2 = 0; var2 < Players.field953; ++var2) {
               var3 = Players.field950[var2];
               if ((Players.field948[var3] & 1) != 0) {
                  if (var1 > 0) {
                     --var1;
                     Players.field948[var3] = (byte)(Players.field948[var3] | 2);
                  } else {
                     var4 = var0.readBits(1);
                     if (var4 == 0) {
                        var1 = WorldMapLabel.method1782(var0);
                        Players.field948[var3] = (byte)(Players.field948[var3] | 2);
                     } else if (Script.method1814(var0, var3)) {
                        Players.field948[var3] = (byte)(Players.field948[var3] | 2);
                     }
                  }
               }
            }

            var0.exportIndex();
            if (var1 != 0) {
               throw new RuntimeException();
            } else {
               var0.importIndex();

               for(var2 = 0; var2 < Players.field953; ++var2) {
                  var3 = Players.field950[var2];
                  if ((Players.field948[var3] & 1) == 0) {
                     if (var1 > 0) {
                        --var1;
                        Players.field948[var3] = (byte)(Players.field948[var3] | 2);
                     } else {
                        var4 = var0.readBits(1);
                        if (var4 == 0) {
                           var1 = WorldMapLabel.method1782(var0);
                           Players.field948[var3] = (byte)(Players.field948[var3] | 2);
                        } else if (Script.method1814(var0, var3)) {
                           Players.field948[var3] = (byte)(Players.field948[var3] | 2);
                        }
                     }
                  }
               }

               var0.exportIndex();
               if (var1 != 0) {
                  throw new RuntimeException();
               } else {
                  Players.field951 = 0;
                  Players.field953 = 0;

                  for(var2 = 1; var2 < 2048; ++var2) {
                     Players.field948[var2] = (byte)(Players.field948[var2] >> 1);
                     Player var5 = Client.field2141[var2];
                     if (var5 != null) {
                        Players.field947[++Players.field951 - 1] = var2;
                     } else {
                        Players.field950[++Players.field953 - 1] = var2;
                     }
                  }

               }
            }
         }
      }
   }

   static void method1732(Sprite var0, int var1, int var2, int var3) {
      DemotingHashTable var4 = WorldMapRegion.field1112;
      long var6 = (long)(var3 << 16 | var1 << 8 | var2);
      var4.put(var0, var6, var0.pixels.length * 4);
   }

   public static int method1734(CharSequence var0, CharSequence var1, int var2) {
      int var3 = var0.length();
      int var4 = var1.length();
      int var5 = 0;
      int var6 = 0;
      char var7 = 0;
      char var8 = 0;

      while(var5 - var7 < var3 || var6 - var8 < var4) {
         if (var5 - var7 >= var3) {
            return -1;
         }

         if (var6 - var8 >= var4) {
            return 1;
         }

         char var9;
         if (var7 != 0) {
            var9 = var7;
            boolean var14 = false;
         } else {
            var9 = var0.charAt(var5++);
         }

         char var10;
         if (var8 != 0) {
            var10 = var8;
            boolean var15 = false;
         } else {
            var10 = var1.charAt(var6++);
         }

         var7 = class71.method1465(var9);
         var8 = class71.method1465(var10);
         var9 = SoundSystems.method1775(var9, var2);
         var10 = SoundSystems.method1775(var10, var2);
         if (var10 != var9 && Character.toUpperCase(var9) != Character.toUpperCase(var10)) {
            var9 = Character.toLowerCase(var9);
            var10 = Character.toLowerCase(var10);
            if (var10 != var9) {
               return Varcs.getString(var9, var2) - Varcs.getString(var10, var2);
            }
         }
      }

      int var16 = Math.min(var3, var4);

      char var12;
      int var17;
      for(var17 = 0; var17 < var16; ++var17) {
         char var11 = var0.charAt(var17);
         var12 = var1.charAt(var17);
         if (var11 != var12 && Character.toUpperCase(var11) != Character.toUpperCase(var12)) {
            var11 = Character.toLowerCase(var11);
            var12 = Character.toLowerCase(var12);
            if (var11 != var12) {
               return Varcs.getString(var11, var2) - Varcs.getString(var12, var2);
            }
         }
      }

      var17 = var3 - var4;
      if (var17 != 0) {
         return var17;
      } else {
         for(int var18 = 0; var18 < var16; ++var18) {
            var12 = var0.charAt(var18);
            char var13 = var1.charAt(var18);
            if (var13 != var12) {
               return Varcs.getString(var12, var2) - Varcs.getString(var13, var2);
            }
         }

         return 0;
      }
   }

   public static int method1728(int var0) {
      return var0 >> 17 & 7;
   }
}
