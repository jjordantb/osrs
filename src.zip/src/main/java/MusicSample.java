public class MusicSample extends Node {
   static int[] field792;
   static float[] field768;
   static float[] field789;
   static int[] field762;
   static float[] field777;
   static byte[] field778;
   static class86[] field791;
   static boolean field774 = false;
   static int[] field776;
   static int field790;
   static class100[] field775;
   static class70[] field773;
   static int field770;
   static float[] field787;
   static int field772;
   static float[] field784;
   static float[] field786;
   static boolean[] field788;
   static int field783;
   static class114[] field779;
   static float[] field785;
   byte[] field793;
   int field795;
   int field794;
   float[] field780;
   int field766;
   int field764;
   byte[][] field771;
   int field782;
   boolean field769;
   int field765;
   int field763;
   int field781;
   boolean field767;

   MusicSample(byte[] var1) {
      this.method1341(var1);
   }

   void method1341(byte[] var1) {
      Buffer var2 = new Buffer(var1);
      this.field763 = var2.readInt();
      this.field764 = var2.readInt();
      this.field765 = var2.readInt();
      this.field766 = var2.readInt();
      if (this.field766 < 0) {
         this.field766 = ~this.field766;
         this.field769 = true;
      }

      int var3 = var2.readInt();
      this.field771 = new byte[var3][];

      for(int var4 = 0; var4 < var3; ++var4) {
         int var5 = 0;

         int var6;
         do {
            var6 = var2.readUnsignedByte();
            var5 += var6;
         } while(var6 >= 255);

         byte[] var7 = new byte[var5];
         var2.method3923(var7, 0, var5);
         this.field771[var4] = var7;
      }

   }

   class88 method1349(int[] var1) {
      if (var1 != null && var1[0] <= 0) {
         return null;
      } else {
         if (this.field793 == null) {
            this.field781 = 0;
            this.field780 = new float[field772];
            this.field793 = new byte[this.field764];
            this.field794 = 0;
            this.field795 = 0;
         }

         for(; this.field795 < this.field771.length; ++this.field795) {
            if (var1 != null && var1[0] <= 0) {
               return null;
            }

            float[] var2 = this.method1346(this.field795);
            if (var2 != null) {
               int var3 = this.field794;
               int var4 = var2.length;
               if (var4 > this.field764 - var3) {
                  var4 = this.field764 - var3;
               }

               for(int var5 = 0; var5 < var4; ++var5) {
                  int var6 = (int)(128.0F + var2[var5] * 128.0F);
                  if ((var6 & -256) != 0) {
                     var6 = ~var6 >> 31;
                  }

                  this.field793[var3++] = (byte)(var6 - 128);
               }

               if (var1 != null) {
                  var1[0] -= var3 - this.field794;
               }

               this.field794 = var3;
            }
         }

         this.field780 = null;
         byte[] var7 = this.field793;
         this.field793 = null;
         return new class88(this.field763, var7, this.field765, this.field766, this.field769);
      }
   }

   float[] method1346(int var1) {
      method1356(this.field771[var1]);
      method1358();
      int var2 = method1343(class69.method1447(field776.length - 1));
      boolean var3 = field788[var2];
      int var4 = var3 ? field772 : field790;
      boolean var5 = false;
      boolean var6 = false;
      if (var3) {
         var5 = method1358() != 0;
         var6 = method1358() != 0;
      }

      int var7 = var4 >> 1;
      int var8;
      int var9;
      int var10;
      if (var3 && !var5) {
         var8 = (var4 >> 2) - (field790 >> 2);
         var9 = (field790 >> 2) + (var4 >> 2);
         var10 = field790 >> 1;
      } else {
         var8 = 0;
         var9 = var7;
         var10 = var4 >> 1;
      }

      int var11;
      int var12;
      int var13;
      if (var3 && !var6) {
         var11 = var4 - (var4 >> 2) - (field790 >> 2);
         var12 = (field790 >> 2) + (var4 - (var4 >> 2));
         var13 = field790 >> 1;
      } else {
         var11 = var7;
         var12 = var4;
         var13 = var4 >> 1;
      }

      class114 var14 = field779[field776[var2]];
      int var16 = var14.field1287;
      int var17 = var14.field1286[var16];
      boolean var15 = !field791[var17].method1753();
      boolean var45 = var15;

      for(var17 = 0; var17 < var14.field1285; ++var17) {
         class100 var18 = field775[var14.field1284[var17]];
         float[] var19 = field784;
         var18.method1849(var19, var4 >> 1, var45);
      }

      int var40;
      if (!var15) {
         var17 = var14.field1287;
         var40 = var14.field1286[var17];
         field791[var40].method1755(field784, var4 >> 1);
      }

      int var42;
      if (var15) {
         for(var17 = var4 >> 1; var17 < var4; ++var17) {
            field784[var17] = 0.0F;
         }
      } else {
         var17 = var4 >> 1;
         var40 = var4 >> 2;
         var42 = var4 >> 3;
         float[] var43 = field784;

         int var21;
         for(var21 = 0; var21 < var17; ++var21) {
            var43[var21] *= 0.5F;
         }

         for(var21 = var17; var21 < var4; ++var21) {
            var43[var21] = -var43[var4 - var21 - 1];
         }

         float[] var44 = var3 ? field768 : field785;
         float[] var22 = var3 ? field789 : field786;
         float[] var23 = var3 ? field777 : field787;
         int[] var24 = var3 ? field792 : field762;

         int var25;
         float var26;
         float var27;
         float var28;
         float var29;
         for(var25 = 0; var25 < var40; ++var25) {
            var26 = var43[var25 * 4] - var43[var4 - var25 * 4 - 1];
            var27 = var43[var25 * 4 + 2] - var43[var4 - var25 * 4 - 3];
            var28 = var44[var25 * 2];
            var29 = var44[var25 * 2 + 1];
            var43[var4 - var25 * 4 - 1] = var26 * var28 - var27 * var29;
            var43[var4 - var25 * 4 - 3] = var26 * var29 + var27 * var28;
         }

         float var30;
         float var31;
         for(var25 = 0; var25 < var42; ++var25) {
            var26 = var43[var17 + var25 * 4 + 3];
            var27 = var43[var17 + var25 * 4 + 1];
            var28 = var43[var25 * 4 + 3];
            var29 = var43[var25 * 4 + 1];
            var43[var17 + var25 * 4 + 3] = var26 + var28;
            var43[var17 + var25 * 4 + 1] = var27 + var29;
            var30 = var44[var17 - 4 - var25 * 4];
            var31 = var44[var17 - 3 - var25 * 4];
            var43[var25 * 4 + 3] = (var26 - var28) * var30 - (var27 - var29) * var31;
            var43[var25 * 4 + 1] = (var27 - var29) * var30 + (var26 - var28) * var31;
         }

         var25 = class69.method1447(var4 - 1);

         int var47;
         int var48;
         int var49;
         int var50;
         for(var47 = 0; var47 < var25 - 3; ++var47) {
            var48 = var4 >> var47 + 2;
            var49 = 8 << var47;

            for(var50 = 0; var50 < 2 << var47; ++var50) {
               int var51 = var4 - var48 * var50 * 2;
               int var52 = var4 - var48 * (var50 * 2 + 1);

               for(int var32 = 0; var32 < var4 >> var47 + 4; ++var32) {
                  int var33 = var32 * 4;
                  float var34 = var43[var51 - 1 - var33];
                  float var35 = var43[var51 - 3 - var33];
                  float var36 = var43[var52 - 1 - var33];
                  float var37 = var43[var52 - 3 - var33];
                  var43[var51 - 1 - var33] = var34 + var36;
                  var43[var51 - 3 - var33] = var35 + var37;
                  float var38 = var44[var32 * var49];
                  float var39 = var44[var32 * var49 + 1];
                  var43[var52 - 1 - var33] = (var34 - var36) * var38 - (var35 - var37) * var39;
                  var43[var52 - 3 - var33] = (var35 - var37) * var38 + (var34 - var36) * var39;
               }
            }
         }

         for(var47 = 1; var47 < var42 - 1; ++var47) {
            var48 = var24[var47];
            if (var47 < var48) {
               var49 = var47 * 8;
               var50 = var48 * 8;
               var30 = var43[var49 + 1];
               var43[var49 + 1] = var43[var50 + 1];
               var43[var50 + 1] = var30;
               var30 = var43[var49 + 3];
               var43[var49 + 3] = var43[var50 + 3];
               var43[var50 + 3] = var30;
               var30 = var43[var49 + 5];
               var43[var49 + 5] = var43[var50 + 5];
               var43[var50 + 5] = var30;
               var30 = var43[var49 + 7];
               var43[var49 + 7] = var43[var50 + 7];
               var43[var50 + 7] = var30;
            }
         }

         for(var47 = 0; var47 < var17; ++var47) {
            var43[var47] = var43[var47 * 2 + 1];
         }

         for(var47 = 0; var47 < var42; ++var47) {
            var43[var4 - 1 - var47 * 2] = var43[var47 * 4];
            var43[var4 - 2 - var47 * 2] = var43[var47 * 4 + 1];
            var43[var4 - var40 - 1 - var47 * 2] = var43[var47 * 4 + 2];
            var43[var4 - var40 - 2 - var47 * 2] = var43[var47 * 4 + 3];
         }

         for(var47 = 0; var47 < var42; ++var47) {
            var27 = var23[var47 * 2];
            var28 = var23[var47 * 2 + 1];
            var29 = var43[var17 + var47 * 2];
            var30 = var43[var17 + var47 * 2 + 1];
            var31 = var43[var4 - 2 - var47 * 2];
            float var53 = var43[var4 - 1 - var47 * 2];
            float var54 = var28 * (var29 - var31) + var27 * (var30 + var53);
            var43[var17 + var47 * 2] = (var29 + var31 + var54) * 0.5F;
            var43[var4 - 2 - var47 * 2] = (var29 + var31 - var54) * 0.5F;
            var54 = var28 * (var30 + var53) - var27 * (var29 - var31);
            var43[var17 + var47 * 2 + 1] = (var30 - var53 + var54) * 0.5F;
            var43[var4 - 1 - var47 * 2] = (-var30 + var53 + var54) * 0.5F;
         }

         for(var47 = 0; var47 < var40; ++var47) {
            var43[var47] = var43[var17 + var47 * 2] * var22[var47 * 2] + var43[var17 + var47 * 2 + 1] * var22[var47 * 2 + 1];
            var43[var17 - 1 - var47] = var43[var17 + var47 * 2] * var22[var47 * 2 + 1] - var43[var17 + var47 * 2 + 1] * var22[var47 * 2];
         }

         for(var47 = 0; var47 < var40; ++var47) {
            var43[var47 + (var4 - var40)] = -var43[var47];
         }

         for(var47 = 0; var47 < var40; ++var47) {
            var43[var47] = var43[var40 + var47];
         }

         for(var47 = 0; var47 < var40; ++var47) {
            var43[var40 + var47] = -var43[var40 - var47 - 1];
         }

         for(var47 = 0; var47 < var40; ++var47) {
            var43[var17 + var47] = var43[var4 - var47 - 1];
         }

         for(var47 = var8; var47 < var9; ++var47) {
            var27 = (float)Math.sin(((double)(var47 - var8) + 0.5D) / (double)var10 * 0.5D * 3.141592653589793D);
            field784[var47] *= (float)Math.sin(1.5707963267948966D * (double)var27 * (double)var27);
         }

         for(var47 = var11; var47 < var12; ++var47) {
            var27 = (float)Math.sin(((double)(var47 - var11) + 0.5D) / (double)var13 * 0.5D * 3.141592653589793D + 1.5707963267948966D);
            field784[var47] *= (float)Math.sin(1.5707963267948966D * (double)var27 * (double)var27);
         }
      }

      float[] var41 = null;
      if (this.field781 > 0) {
         var40 = var4 + this.field781 >> 2;
         var41 = new float[var40];
         int var20;
         if (!this.field767) {
            for(var42 = 0; var42 < this.field782; ++var42) {
               var20 = var42 + (this.field781 >> 1);
               var41[var42] += this.field780[var20];
            }
         }

         if (!var15) {
            for(var42 = var8; var42 < var4 >> 1; ++var42) {
               var20 = var41.length - (var4 >> 1) + var42;
               var41[var20] += field784[var42];
            }
         }
      }

      float[] var46 = this.field780;
      this.field780 = field784;
      field784 = var46;
      this.field781 = var4;
      this.field782 = var12 - (var4 >> 1);
      this.field767 = var15;
      return var41;
   }

   static MusicSample method1348(AbstractIndexCache var0, int var1, int var2) {
      if (!method1354(var0)) {
         var0.tryLoadRecord(var1, var2);
         return null;
      } else {
         byte[] var3 = var0.takeRecord(var1, var2);
         return var3 == null ? null : new MusicSample(var3);
      }
   }

   static int method1358() {
      int var0 = field778[field783] >> field770 & 1;
      ++field770;
      field783 += field770 >> 3;
      field770 &= 7;
      return var0;
   }

   static float method1345(int var0) {
      int var1 = var0 & 2097151;
      int var2 = var0 & Integer.MIN_VALUE;
      int var3 = (var0 & 2145386496) >> 21;
      if (var2 != 0) {
         var1 = -var1;
      }

      return (float)((double)var1 * Math.pow(2.0D, (double)(var3 - 788)));
   }

   static void method1347(byte[] var0) {
      method1356(var0);
      field790 = 1 << method1343(4);
      field772 = 1 << method1343(4);
      field784 = new float[field772];

      int var1;
      int var2;
      int var3;
      int var4;
      int var5;
      for(var1 = 0; var1 < 2; ++var1) {
         var2 = var1 != 0 ? field772 : field790;
         var3 = var2 >> 1;
         var4 = var2 >> 2;
         var5 = var2 >> 3;
         float[] var6 = new float[var3];

         for(int var7 = 0; var7 < var4; ++var7) {
            var6[var7 * 2] = (float)Math.cos((double)(var7 * 4) * 3.141592653589793D / (double)var2);
            var6[var7 * 2 + 1] = -((float)Math.sin((double)(var7 * 4) * 3.141592653589793D / (double)var2));
         }

         float[] var18 = new float[var3];

         for(int var8 = 0; var8 < var4; ++var8) {
            var18[var8 * 2] = (float)Math.cos((double)(var8 * 2 + 1) * 3.141592653589793D / (double)(var2 * 2));
            var18[var8 * 2 + 1] = (float)Math.sin((double)(var8 * 2 + 1) * 3.141592653589793D / (double)(var2 * 2));
         }

         float[] var19 = new float[var4];

         for(int var9 = 0; var9 < var5; ++var9) {
            var19[var9 * 2] = (float)Math.cos((double)(var9 * 4 + 2) * 3.141592653589793D / (double)var2);
            var19[var9 * 2 + 1] = -((float)Math.sin((double)(var9 * 4 + 2) * 3.141592653589793D / (double)var2));
         }

         int[] var20 = new int[var5];
         int var10 = class69.method1447(var5 - 1);

         for(int var11 = 0; var11 < var5; ++var11) {
            int var15 = var11;
            int var16 = var10;

            int var17;
            for(var17 = 0; var16 > 0; --var16) {
               var17 = var17 << 1 | var15 & 1;
               var15 >>>= 1;
            }

            var20[var11] = var17;
         }

         if (var1 != 0) {
            field768 = var6;
            field789 = var18;
            field777 = var19;
            field792 = var20;
         } else {
            field785 = var6;
            field786 = var18;
            field787 = var19;
            field762 = var20;
         }
      }

      var1 = method1343(8) + 1;
      field773 = new class70[var1];

      for(var2 = 0; var2 < var1; ++var2) {
         field773[var2] = new class70();
      }

      var2 = method1343(6) + 1;

      for(var3 = 0; var3 < var2; ++var3) {
         method1343(16);
      }

      var2 = method1343(6) + 1;
      field791 = new class86[var2];

      for(var3 = 0; var3 < var2; ++var3) {
         field791[var3] = new class86();
      }

      var3 = method1343(6) + 1;
      field775 = new class100[var3];

      for(var4 = 0; var4 < var3; ++var4) {
         field775[var4] = new class100();
      }

      var4 = method1343(6) + 1;
      field779 = new class114[var4];

      for(var5 = 0; var5 < var4; ++var5) {
         field779[var5] = new class114();
         System.out.println("KEK " + var5 + ", " + var4);
      }

      var5 = method1343(6) + 1;
      field788 = new boolean[var5];
      field776 = new int[var5];

      for(int var21 = 0; var21 < var5; ++var21) {
         field788[var21] = method1358() != 0;
         method1343(16);
         method1343(16);
         field776[var21] = method1343(8);
      }

   }

   static boolean method1354(AbstractIndexCache var0) {
      if (!field774) {
         byte[] var1 = var0.takeRecord(0, 0);
         if (var1 == null) {
            return false;
         }
         method1347(var1);
         field774 = true;
      }

      return true;
   }

   static int method1343(int var0) {
      System.out.println("CALLED " + var0 + " -> " + field778.length + " -> " + field783);
      int var1 = 0;

      int var2;
      int var3;
      for(var2 = 0; var0 >= 8 - field770; var0 -= var3) {
         var3 = 8 - field770;
         int var4 = (1 << var3) - 1;
         var1 += (field778[field783] >> field770 & var4) << var2;
         field770 = 0;
         ++field783;
         var2 += var3;
      }

      if (var0 > 0) {
         var3 = (1 << var0) - 1;
         var1 += (field778[field783] >> field770 & var3) << var2;
         field770 += var0;
      }

      System.out.println("Return " + var1);
      return var1;
   }

   static void method1356(byte[] var0) {
      field778 = var0;
      field783 = 0;
      field770 = 0;
   }

}
