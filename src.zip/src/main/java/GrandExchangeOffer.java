public class GrandExchangeOffer {
   static AbstractIndexCache field690;
   public static Track field697;
   public int currentQuantity;
   public int unitPrice;
   byte state;
   public int currentPrice;
   public int totalQuantity;
   public int id;

   public GrandExchangeOffer() {
   }

   public GrandExchangeOffer(Buffer var1, boolean var2) {
      this.state = var1.readByte();
      this.id = var1.method3913();
      this.unitPrice = var1.readInt();
      this.totalQuantity = var1.readInt();
      this.currentQuantity = var1.readInt();
      this.currentPrice = var1.readInt();
   }

   void method1255(int var1) {
      this.state &= -9;
      if (var1 == 1) {
         this.state = (byte)(this.state | 8);
      }

   }

   public int type() {
      return (this.state & 8) == 8 ? 1 : 0;
   }

   void method1273(int var1) {
      this.state &= -8;
      this.state = (byte)(this.state | var1 & 7);
   }

   public int status() {
      return this.state & 7;
   }

   static int method1272(int var0, int var1) {
      ItemContainer var2 = (ItemContainer)ItemContainer.field267.get((long)var0);
      if (var2 == null) {
         return -1;
      } else {
         return var1 >= 0 && var1 < var2.ids.length ? var2.ids[var1] : -1;
      }
   }

   static final void method1260(String var0) {
      if (TotalQuantityComparator.field983 != null) {
         PacketBufferNode var1 = FaceNormal.method2884(ClientPacket.field1849, Client.field2133.isaacCipher);
         var1.packetBuffer.writeByte(AbstractSoundSystem.method1696(var0));
         var1.packetBuffer.writeStringCp1252NullTerminated(var0);
         Client.field2133.method1281(var1);
      }
   }
}
