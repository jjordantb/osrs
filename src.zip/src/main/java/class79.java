import java.net.URL;

public class class79 {
   static int field902;

   static boolean method1622() {
      try {
         if (World.field346 == null) {
            World.field346 = WorldMapSection1.field186.request(new URL(AccessFile.field1367));
         } else if (World.field346.isDone()) {
            byte[] var0 = World.field346.getResponse();
            Buffer var1 = new Buffer(var0);
            var1.readInt();
            World.field349 = var1.method3913();
            World.field353 = new World[World.field349];

            World var3;
            for(int var2 = 0; var2 < World.field349; var3.index = var2++) {
               var3 = World.field353[var2] = new World();
               var3.id = var1.method3913();
               var3.properties = var1.readInt();
               var3.host = var1.readStringCp1252NullTerminated();
               var3.activity = var1.readStringCp1252NullTerminated();
               var3.location = var1.readUnsignedByte();
               var3.population = var1.method3956();
            }

            class296.method5737(World.field353, 0, World.field353.length - 1, World.field352, World.field354);
            World.field346 = null;
            return true;
         }
      } catch (Exception var4) {
         var4.printStackTrace();
         World.field346 = null;
      }

      return false;
   }

   static Message method1620(int var0) {
      return (Message)Messages.field611.get((long)var0);
   }

   static final void method1621(boolean var0, PacketBuffer var1) {
      Client.field2145 = var0;
      int var2;
      int var3;
      int var5;
      int var6;
      int var7;
      int var8;
      if (!Client.field2145) {
         var2 = var1.method3934();
         var3 = var1.method3950();
         int var4 = var1.method3913();
         IndexStoreActionHandler.field2951 = new int[var4][4];

         for(var5 = 0; var5 < var4; ++var5) {
            for(var6 = 0; var6 < 4; ++var6) {
               IndexStoreActionHandler.field2951[var5][var6] = var1.readInt();
            }
         }

         WorldMapSection1.field201 = new int[var4];
         class219.field2571 = new int[var4];
         WorldMapCacheName.field239 = new int[var4];
         IsaacCipher.field2482 = new byte[var4][];
         BufferedFile.field1421 = new byte[var4][];
         boolean var16 = false;
         if ((var3 / 8 == 48 || var3 / 8 == 49) && var2 / 8 == 48) {
            var16 = true;
         }

         if (var3 / 8 == 48 && var2 / 8 == 148) {
            var16 = true;
         }

         var4 = 0;

         for(var6 = (var3 - 6) / 8; var6 <= (var3 + 6) / 8; ++var6) {
            for(var7 = (var2 - 6) / 8; var7 <= (var2 + 6) / 8; ++var7) {
               var8 = var7 + (var6 << 8);
               if (!var16 || var7 != 49 && var7 != 149 && var7 != 147 && var6 != 50 && (var6 != 49 || var7 != 47)) {
                  WorldMapSection1.field201[var4] = var8;
                  class219.field2571[var4] = class320.field3912.getArchiveId("m" + var6 + "_" + var7);
                  WorldMapCacheName.field239[var4] = class320.field3912.getArchiveId("l" + var6 + "_" + var7);
                  ++var4;
               }
            }
         }

         TaskHandler.method3070(var3, var2, true);
      } else {
         var2 = var1.method3950();
         var3 = var1.method3934();
         boolean var15 = var1.readUnsignedByte() == 1;
         var5 = var1.method3913();
         var1.importIndex();

         int var9;
         for(var6 = 0; var6 < 4; ++var6) {
            for(var7 = 0; var7 < 13; ++var7) {
               for(var8 = 0; var8 < 13; ++var8) {
                  var9 = var1.readBits(1);
                  if (var9 == 1) {
                     Client.field2146[var6][var7][var8] = var1.readBits(26);
                  } else {
                     Client.field2146[var6][var7][var8] = -1;
                  }
               }
            }
         }

         var1.exportIndex();
         IndexStoreActionHandler.field2951 = new int[var5][4];

         for(var6 = 0; var6 < var5; ++var6) {
            for(var7 = 0; var7 < 4; ++var7) {
               IndexStoreActionHandler.field2951[var6][var7] = var1.readInt();
            }
         }

         WorldMapSection1.field201 = new int[var5];
         class219.field2571 = new int[var5];
         WorldMapCacheName.field239 = new int[var5];
         IsaacCipher.field2482 = new byte[var5][];
         BufferedFile.field1421 = new byte[var5][];
         var5 = 0;

         for(var6 = 0; var6 < 4; ++var6) {
            for(var7 = 0; var7 < 13; ++var7) {
               for(var8 = 0; var8 < 13; ++var8) {
                  var9 = Client.field2146[var6][var7][var8];
                  if (var9 != -1) {
                     int var10 = var9 >> 14 & 1023;
                     int var11 = var9 >> 3 & 2047;
                     int var12 = (var10 / 8 << 8) + var11 / 8;

                     int var13;
                     for(var13 = 0; var13 < var5; ++var13) {
                        if (WorldMapSection1.field201[var13] == var12) {
                           var12 = -1;
                           break;
                        }
                     }

                     if (var12 != -1) {
                        WorldMapSection1.field201[var5] = var12;
                        var13 = var12 >> 8 & 255;
                        int var14 = var12 & 255;
                        class219.field2571[var5] = class320.field3912.getArchiveId("m" + var13 + "_" + var14);
                        WorldMapCacheName.field239[var5] = class320.field3912.getArchiveId("l" + var13 + "_" + var14);
                        ++var5;
                     }
                  }
               }
            }
         }

         TaskHandler.method3070(var3, var2, !var15);
      }

   }
}
