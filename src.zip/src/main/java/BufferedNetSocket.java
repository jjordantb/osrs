import java.io.IOException;
import java.net.Socket;
import java.util.Date;

public class BufferedNetSocket extends AbstractSocket {
   static int field1786;
   static int[] field1783;
   BufferedSink sink;
   Socket socket;
   BufferedSource source;

   public BufferedNetSocket(Socket var1, int var2, int var3) throws IOException {
      this.socket = var1;
      this.socket.setSoTimeout(30000);
      this.socket.setTcpNoDelay(true);
      this.socket.setReceiveBufferSize(65536);
      this.socket.setSendBufferSize(65536);
      this.source = new BufferedSource(this.socket.getInputStream(), var2);
      this.sink = new BufferedSink(this.socket.getOutputStream(), var3);
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      return this.source.read(var1, var2, var3);
   }

   public int available() throws IOException {
      return this.source.available();
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      this.sink.write(var1, var2, var3);
   }

   public void close() {
      this.sink.close();

      try {
         this.socket.close();
      } catch (IOException var2) {
         ;
      }

      this.source.close();
   }

   public int readUnsignedByte() throws IOException {
      return this.source.readUnsignedByte();
   }

   public boolean isAvailable(int var1) throws IOException {
      return this.source.isAvailable(var1);
   }

   protected void finalize() {
      this.close();
   }

   static int method3133(int var0, Script var1, boolean var2) {
      String var3;
      int var4;
      if (var0 == 4100) {
         var3 = Interpreter.field462[--Interpreter.field469];
         var4 = Interpreter.field467[--class31.field364];
         Interpreter.field462[++Interpreter.field469 - 1] = var3 + var4;
         return 1;
      } else {
         String var9;
         if (var0 == 4101) {
            Interpreter.field469 -= 2;
            var3 = Interpreter.field462[Interpreter.field469];
            var9 = Interpreter.field462[Interpreter.field469 + 1];
            Interpreter.field462[++Interpreter.field469 - 1] = var3 + var9;
            return 1;
         } else if (var0 == 4102) {
            var3 = Interpreter.field462[--Interpreter.field469];
            var4 = Interpreter.field467[--class31.field364];
            Interpreter.field462[++Interpreter.field469 - 1] = var3 + WorldMapData2.method347(var4, true);
            return 1;
         } else if (var0 == 4103) {
            var3 = Interpreter.field462[--Interpreter.field469];
            Interpreter.field462[++Interpreter.field469 - 1] = var3.toLowerCase();
            return 1;
         } else {
            int var6;
            int var10;
            if (var0 == 4104) {
               var10 = Interpreter.field467[--class31.field364];
               long var11 = (11745L + (long)var10) * 86400000L;
               Interpreter.field473.setTime(new Date(var11));
               var6 = Interpreter.field473.get(5);
               int var16 = Interpreter.field473.get(2);
               int var8 = Interpreter.field473.get(1);
               Interpreter.field462[++Interpreter.field469 - 1] = var6 + "-" + Interpreter.field468[var16] + "-" + var8;
               return 1;
            } else if (var0 != 4105) {
               if (var0 == 4106) {
                  var10 = Interpreter.field467[--class31.field364];
                  Interpreter.field462[++Interpreter.field469 - 1] = Integer.toString(var10);
                  return 1;
               } else if (var0 == 4107) {
                  Interpreter.field469 -= 2;
                  Interpreter.field467[++class31.field364 - 1] = Occluder.method2990(class85.method1734(Interpreter.field462[Interpreter.field469], Interpreter.field462[Interpreter.field469 + 1], Client.field2228));
                  return 1;
               } else {
                  int var5;
                  byte[] var13;
                  Font var14;
                  if (var0 == 4108) {
                     var3 = Interpreter.field462[--Interpreter.field469];
                     class31.field364 -= 2;
                     var4 = Interpreter.field467[class31.field364];
                     var5 = Interpreter.field467[class31.field364 + 1];
                     var13 = GraphicsObject.field569.takeRecord(var5, 0);
                     var14 = new Font(var13);
                     Interpreter.field467[++class31.field364 - 1] = var14.lineCount(var3, var4);
                     return 1;
                  } else if (var0 == 4109) {
                     var3 = Interpreter.field462[--Interpreter.field469];
                     class31.field364 -= 2;
                     var4 = Interpreter.field467[class31.field364];
                     var5 = Interpreter.field467[class31.field364 + 1];
                     var13 = GraphicsObject.field569.takeRecord(var5, 0);
                     var14 = new Font(var13);
                     Interpreter.field467[++class31.field364 - 1] = var14.lineWidth(var3, var4);
                     return 1;
                  } else if (var0 == 4110) {
                     Interpreter.field469 -= 2;
                     var3 = Interpreter.field462[Interpreter.field469];
                     var9 = Interpreter.field462[Interpreter.field469 + 1];
                     if (Interpreter.field467[--class31.field364] == 1) {
                        Interpreter.field462[++Interpreter.field469 - 1] = var3;
                     } else {
                        Interpreter.field462[++Interpreter.field469 - 1] = var9;
                     }

                     return 1;
                  } else if (var0 == 4111) {
                     var3 = Interpreter.field462[--Interpreter.field469];
                     Interpreter.field462[++Interpreter.field469 - 1] = AbstractFont.method5851(var3);
                     return 1;
                  } else if (var0 == 4112) {
                     var3 = Interpreter.field462[--Interpreter.field469];
                     var4 = Interpreter.field467[--class31.field364];
                     Interpreter.field462[++Interpreter.field469 - 1] = var3 + (char)var4;
                     return 1;
                  } else if (var0 == 4113) {
                     var10 = Interpreter.field467[--class31.field364];
                     Interpreter.field467[++class31.field364 - 1] = class95.method1798((char)var10) ? 1 : 0;
                     return 1;
                  } else if (var0 == 4114) {
                     var10 = Interpreter.field467[--class31.field364];
                     Interpreter.field467[++class31.field364 - 1] = class257.method5070((char)var10) ? 1 : 0;
                     return 1;
                  } else if (var0 == 4115) {
                     var10 = Interpreter.field467[--class31.field364];
                     Interpreter.field467[++class31.field364 - 1] = StudioGame.method5085((char)var10) ? 1 : 0;
                     return 1;
                  } else if (var0 == 4116) {
                     var10 = Interpreter.field467[--class31.field364];
                     Interpreter.field467[++class31.field364 - 1] = Strings.method4940((char)var10) ? 1 : 0;
                     return 1;
                  } else if (var0 == 4117) {
                     var3 = Interpreter.field462[--Interpreter.field469];
                     if (var3 != null) {
                        Interpreter.field467[++class31.field364 - 1] = var3.length();
                     } else {
                        Interpreter.field467[++class31.field364 - 1] = 0;
                     }

                     return 1;
                  } else if (var0 == 4118) {
                     var3 = Interpreter.field462[--Interpreter.field469];
                     class31.field364 -= 2;
                     var4 = Interpreter.field467[class31.field364];
                     var5 = Interpreter.field467[class31.field364 + 1];
                     Interpreter.field462[++Interpreter.field469 - 1] = var3.substring(var4, var5);
                     return 1;
                  } else if (var0 == 4119) {
                     var3 = Interpreter.field462[--Interpreter.field469];
                     StringBuilder var17 = new StringBuilder(var3.length());
                     boolean var15 = false;

                     for(var6 = 0; var6 < var3.length(); ++var6) {
                        char var7 = var3.charAt(var6);
                        if (var7 == '<') {
                           var15 = true;
                        } else if (var7 == '>') {
                           var15 = false;
                        } else if (!var15) {
                           var17.append(var7);
                        }
                     }

                     Interpreter.field462[++Interpreter.field469 - 1] = var17.toString();
                     return 1;
                  } else if (var0 == 4120) {
                     var3 = Interpreter.field462[--Interpreter.field469];
                     var4 = Interpreter.field467[--class31.field364];
                     Interpreter.field467[++class31.field364 - 1] = var3.indexOf(var4);
                     return 1;
                  } else if (var0 == 4121) {
                     Interpreter.field469 -= 2;
                     var3 = Interpreter.field462[Interpreter.field469];
                     var9 = Interpreter.field462[Interpreter.field469 + 1];
                     var5 = Interpreter.field467[--class31.field364];
                     Interpreter.field467[++class31.field364 - 1] = var3.indexOf(var9, var5);
                     return 1;
                  } else {
                     return 2;
                  }
               }
            } else {
               Interpreter.field469 -= 2;
               var3 = Interpreter.field462[Interpreter.field469];
               var9 = Interpreter.field462[Interpreter.field469 + 1];
               if (ObjectSound.field589.appearance != null && ObjectSound.field589.appearance.isFemale) {
                  Interpreter.field462[++Interpreter.field469 - 1] = var9;
               } else {
                  Interpreter.field462[++Interpreter.field469 - 1] = var3;
               }

               return 1;
            }
         }
      }
   }

   public static int read(CharSequence var0, int var1, boolean var2) {
      if (var1 >= 2 && var1 <= 36) {
         boolean var3 = false;
         boolean var4 = false;
         int var5 = 0;
         int var6 = var0.length();

         for(int var7 = 0; var7 < var6; ++var7) {
            char var8 = var0.charAt(var7);
            if (var7 == 0) {
               if (var8 == '-') {
                  var3 = true;
                  continue;
               }

               if (var8 == '+') {
                  continue;
               }
            }

            int var10;
            if (var8 >= '0' && var8 <= '9') {
               var10 = var8 - 48;
            } else if (var8 >= 'A' && var8 <= 'Z') {
               var10 = var8 - 55;
            } else {
               if (var8 < 'a' || var8 > 'z') {
                  throw new NumberFormatException();
               }

               var10 = var8 - 87;
            }

            if (var10 >= var1) {
               throw new NumberFormatException();
            }

            if (var3) {
               var10 = -var10;
            }

            int var9 = var10 + var5 * var1;
            if (var9 / var1 != var5) {
               throw new NumberFormatException();
            }

            var5 = var9;
            var4 = true;
         }

         if (!var4) {
            throw new NumberFormatException();
         } else {
            return var5;
         }
      } else {
         throw new IllegalArgumentException("");
      }
   }

   public static void available(AbstractIndexCache var0, int var1, int var2, int var3, boolean var4) {
      class219.field2568 = 1;
      UrlRequester.field1584 = var0;
      class219.field2572 = var1;
      IndexStore.field1832 = var2;
      class321.field3913 = var3;
      class219.field2573 = var4;
      WorldComparator.field810 = 10000;
   }
}
