public class FontName {
   static int field3737;
   public static final FontName field3739 = new FontName("verdana_13pt_regular");
   static int[] field3736;
   public static final FontName field3743 = new FontName("b12_full");
   public static final FontName field3741 = new FontName("p11_full");
   public static final FontName field3740 = new FontName("verdana_15pt_regular");
   public static final FontName field3738 = new FontName("verdana_11pt_regular");
   public static final FontName field3735 = new FontName("p12_full");
   static Fonts field3744;
   String field3745;

   FontName(String var1) {
      this.field3745 = var1;
   }

   static int method5760(int var0) {
      return (int)Math.pow(2.0D, (double)(7.0F + (float)var0 / 256.0F));
   }

   static int method5759(int var0, Script var1, boolean var2) {
      int var3;
      int var4;
      if (var0 == 4000) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         Interpreter.field467[++class31.field364 - 1] = var4 + var3;
         return 1;
      } else if (var0 == 4001) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         Interpreter.field467[++class31.field364 - 1] = var3 - var4;
         return 1;
      } else if (var0 == 4002) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         Interpreter.field467[++class31.field364 - 1] = var3 * var4;
         return 1;
      } else if (var0 == 4003) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         Interpreter.field467[++class31.field364 - 1] = var3 / var4;
         return 1;
      } else if (var0 == 4004) {
         var3 = Interpreter.field467[--class31.field364];
         Interpreter.field467[++class31.field364 - 1] = (int)(Math.random() * (double)var3);
         return 1;
      } else if (var0 == 4005) {
         var3 = Interpreter.field467[--class31.field364];
         Interpreter.field467[++class31.field364 - 1] = (int)(Math.random() * (double)(var3 + 1));
         return 1;
      } else if (var0 == 4006) {
         class31.field364 -= 5;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         int var5 = Interpreter.field467[class31.field364 + 2];
         int var6 = Interpreter.field467[class31.field364 + 3];
         int var7 = Interpreter.field467[class31.field364 + 4];
         Interpreter.field467[++class31.field364 - 1] = var3 + (var4 - var3) * (var7 - var5) / (var6 - var5);
         return 1;
      } else if (var0 == 4007) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         Interpreter.field467[++class31.field364 - 1] = var3 + var4 * var3 / 100;
         return 1;
      } else if (var0 == 4008) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         Interpreter.field467[++class31.field364 - 1] = var3 | 1 << var4;
         return 1;
      } else if (var0 == 4009) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         Interpreter.field467[++class31.field364 - 1] = var3 & -1 - (1 << var4);
         return 1;
      } else if (var0 == 4010) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         Interpreter.field467[++class31.field364 - 1] = (var3 & 1 << var4) != 0 ? 1 : 0;
         return 1;
      } else if (var0 == 4011) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         Interpreter.field467[++class31.field364 - 1] = var3 % var4;
         return 1;
      } else if (var0 == 4012) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         if (var3 == 0) {
            Interpreter.field467[++class31.field364 - 1] = 0;
         } else {
            Interpreter.field467[++class31.field364 - 1] = (int)Math.pow((double)var3, (double)var4);
         }

         return 1;
      } else if (var0 == 4013) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         if (var3 == 0) {
            Interpreter.field467[++class31.field364 - 1] = 0;
            return 1;
         } else {
            switch(var4) {
            case 0:
               Interpreter.field467[++class31.field364 - 1] = Integer.MAX_VALUE;
               break;
            case 1:
               Interpreter.field467[++class31.field364 - 1] = var3;
               break;
            case 2:
               Interpreter.field467[++class31.field364 - 1] = (int)Math.sqrt((double)var3);
               break;
            case 3:
               Interpreter.field467[++class31.field364 - 1] = (int)Math.cbrt((double)var3);
               break;
            case 4:
               Interpreter.field467[++class31.field364 - 1] = (int)Math.sqrt(Math.sqrt((double)var3));
               break;
            default:
               Interpreter.field467[++class31.field364 - 1] = (int)Math.pow((double)var3, 1.0D / (double)var4);
            }

            return 1;
         }
      } else if (var0 == 4014) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         Interpreter.field467[++class31.field364 - 1] = var3 & var4;
         return 1;
      } else if (var0 == 4015) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         Interpreter.field467[++class31.field364 - 1] = var3 | var4;
         return 1;
      } else if (var0 == 4018) {
         class31.field364 -= 3;
         long var9 = (long)Interpreter.field467[class31.field364];
         long var11 = (long)Interpreter.field467[class31.field364 + 1];
         long var13 = (long)Interpreter.field467[class31.field364 + 2];
         Interpreter.field467[++class31.field364 - 1] = (int)(var9 * var13 / var11);
         return 1;
      } else {
         return 2;
      }
   }
}
