import java.applet.Applet;

public class class12 {
   static WorldMap field123;
   public static Applet field124 = null;
   public static String field125 = "";

   static void method366(int var0, int var1) {
      int[] var2 = new int[4];
      int[] var3 = new int[4];
      var2[0] = var0;
      var3[0] = var1;
      int var4 = 1;

      for(int var5 = 0; var5 < 4; ++var5) {
         if (World.field352[var5] != var0) {
            var2[var4] = World.field352[var5];
            var3[var4] = World.field354[var5];
            ++var4;
         }
      }

      World.field352 = var2;
      World.field354 = var3;
      class296.method5737(World.field353, 0, World.field353.length - 1, World.field352, World.field354);
   }

   static final void method376(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      if (class196.method4189(var0)) {
         WorldMapSection3.field615 = null;
         AbstractSoundSystem.method1659(UserComparator3.field1708[var0], -1, var1, var2, var3, var4, var5, var6, var7);
         if (WorldMapSection3.field615 != null) {
            AbstractSoundSystem.method1659(WorldMapSection3.field615, -1412584499, var1, var2, var3, var4, GrandExchangeEvents.field1001, BufferedNetSocket.field1786, var7);
            WorldMapSection3.field615 = null;
         }

      } else {
         if (var7 != -1) {
            Client.field2291[var7] = true;
         } else {
            for(int var8 = 0; var8 < 100; ++var8) {
               Client.field2291[var8] = true;
            }
         }

      }
   }

   static void method374(int var0, int var1) {
      MenuAction var2 = ScriptFrame.field172;
      WorldMapSectionType.method1828(var2.argument1, var2.argument2, var2.opcode, var2.argument0, var2.action, var2.action, var0, var1);
      ScriptFrame.field172 = null;
   }

   static final void method375(Widget[] var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      for(int var8 = 0; var8 < var0.length; ++var8) {
         Widget var9 = var0[var8];
         if (var9 != null && var9.parentId == var1 && (!var9.isIf3 || var9.type == 0 || var9.hasListener || class257.method5068(var9) != 0 || var9 == Client.field2260 || var9.contentType == 1338)) {
            if (var9.isIf3) {
               if (Canvas.method361(var9)) {
                  continue;
               }
            } else if (var9.type == 0 && var9 != BufferedSource.field1671 && Canvas.method361(var9)) {
               continue;
            }

            int var10 = var9.x + var6;
            int var11 = var7 + var9.y;
            int var12;
            int var13;
            int var14;
            int var15;
            int var17;
            int var18;
            if (var9.type == 2) {
               var12 = var2;
               var13 = var3;
               var14 = var4;
               var15 = var5;
            } else {
               int var16;
               if (var9.type == 9) {
                  var16 = var10;
                  var17 = var11;
                  var18 = var10 + var9.width;
                  int var19 = var11 + var9.height;
                  if (var18 < var10) {
                     var16 = var18;
                     var18 = var10;
                  }

                  if (var19 < var11) {
                     var17 = var19;
                     var19 = var11;
                  }

                  ++var18;
                  ++var19;
                  var12 = var16 > var2 ? var16 : var2;
                  var13 = var17 > var3 ? var17 : var3;
                  var14 = var18 < var4 ? var18 : var4;
                  var15 = var19 < var5 ? var19 : var5;
               } else {
                  var16 = var10 + var9.width;
                  var17 = var11 + var9.height;
                  var12 = var10 > var2 ? var10 : var2;
                  var13 = var11 > var3 ? var11 : var3;
                  var14 = var16 < var4 ? var16 : var4;
                  var15 = var17 < var5 ? var17 : var5;
               }
            }

            if (var9 == Client.field2259) {
               Client.field2267 = true;
               Client.field2268 = var10;
               Client.field2269 = var11;
            }

            boolean var32 = false;
            if (var9.field2645) {
               switch(Client.field2248) {
               case 0:
                  var32 = true;
               case 1:
               default:
                  break;
               case 2:
                  if (Client.field2085 == var9.id >>> 16) {
                     var32 = true;
                  }
                  break;
               case 3:
                  if (var9.id == Client.field2085) {
                     var32 = true;
                  }
               }
            }

            if (var32 || !var9.isIf3 || var12 < var14 && var13 < var15) {
               if (var9.isIf3) {
                  ScriptEvent var26;
                  if (var9.noClickThrough) {
                     if (MouseHandler.field154 >= var12 && MouseHandler.field145 * -976212263 >= var13 && MouseHandler.field154 < var14 && MouseHandler.field145 * -976212263 < var15) {
                        for(var26 = (ScriptEvent) Client.field2285.last(); var26 != null; var26 = (ScriptEvent) Client.field2285.previous()) {
                           if (var26.boolean1) {
                              var26.remove();
                              var26.widget.field2719 = false;
                           }
                        }

                        if (class251.field3254 == 0) {
                           Client.field2259 = null;
                           Client.field2260 = null;
                        }

                        if (!Client.field2276) {
                           WorldMapSection0.method1872();
                        }
                     }
                  } else if (var9.field2667 && MouseHandler.field154 >= var12 && MouseHandler.field145 * -976212263 >= var13 && MouseHandler.field154 < var14 && MouseHandler.field145 * -976212263 < var15) {
                     for(var26 = (ScriptEvent) Client.field2285.last(); var26 != null; var26 = (ScriptEvent) Client.field2285.previous()) {
                        if (var26.boolean1 && var26.widget.onScroll == var26.args) {
                           var26.remove();
                        }
                     }
                  }
               }

               var17 = MouseHandler.field154;
               var18 = MouseHandler.field145 * -976212263;
               if (MouseHandler.field158 != 0) {
                  var17 = MouseHandler.field159;
                  var18 = MouseHandler.field148;
               }

               boolean var33 = var17 >= var12 && var18 >= var13 && var17 < var14 && var18 < var15;
               if (var9.contentType == 1337) {
                  if (!Client.field2097 && !Client.field2276 && var33) {
                     World.method672(var17, var18, var12, var13);
                  }
               } else if (var9.contentType == 1338) {
                  class209.method4320(var9, var10, var11);
               } else {
                  if (var9.contentType == 1400) {
                     field123.method6015(MouseHandler.field154, MouseHandler.field145 * -976212263, var33, var10, var11, var9.width, var9.height);
                  }

                  if (!Client.field2276 && var33) {
                     if (var9.contentType == 1400) {
                        field123.method6114(var10, var11, var9.width, var9.height, var17, var18);
                     } else {
                        GraphicsObject.method1075(var9, var17 - var10, var18 - var11);
                     }
                  }

                  boolean var21;
                  int var23;
                  if (var32) {
                     for(int var20 = 0; var20 < var9.field2631.length; ++var20) {
                        var21 = false;
                        boolean var22 = false;
                        if (!var21 && var9.field2631[var20] != null) {
                           for(var23 = 0; var23 < var9.field2631[var20].length; ++var23) {
                              boolean var24 = false;
                              if (var9.field2727 != null) {
                                 var24 = KeyHandler.field11[var9.field2631[var20][var23]];
                              }

                              if (class93.method1785(var9.field2631[var20][var23]) || var24) {
                                 var21 = true;
                                 if (var9.field2727 != null && var9.field2727[var20] > Client.field2098) {
                                    break;
                                 }

                                 byte var25 = var9.field2664[var20][var23];
                                 if (var25 == 0 || ((var25 & 8) == 0 || !KeyHandler.field11[86] && !KeyHandler.field11[82] && !KeyHandler.field11[81]) && ((var25 & 2) == 0 || KeyHandler.field11[86]) && ((var25 & 1) == 0 || KeyHandler.field11[82]) && ((var25 & 4) == 0 || KeyHandler.field11[81])) {
                                    var22 = true;
                                    break;
                                 }
                              }
                           }
                        }

                        if (var22) {
                           if (var20 < 10) {
                              class1.method67(var20 + 1, var9.id, var9.childIndex, var9.itemId, "");
                           } else if (var20 == 10) {
                              Occluder.method2991();
                              OwnWorldComparator.method616(var9.id, var9.childIndex, class71.method1463(class257.method5068(var9)), var9.itemId);
                              Client.field2244 = Script.method1819(var9);
                              if (Client.field2244 == null) {
                                 Client.field2244 = "null";
                              }

                              Client.field2159 = var9.dataText + ModelData0.method2792(16777215);
                           }

                           var23 = var9.field2686[var20];
                           if (var9.field2727 == null) {
                              var9.field2727 = new int[var9.field2631.length];
                           }

                           if (var9.field2666 == null) {
                              var9.field2666 = new int[var9.field2631.length];
                           }

                           if (var23 != 0) {
                              if (var9.field2727[var20] == 0) {
                                 var9.field2727[var20] = var23 + Client.field2098 + var9.field2666[var20];
                              } else {
                                 var9.field2727[var20] = var23 + Client.field2098;
                              }
                           } else {
                              var9.field2727[var20] = Integer.MAX_VALUE;
                           }
                        }

                        if (!var21 && var9.field2727 != null) {
                           var9.field2727[var20] = 0;
                        }
                     }
                  }

                  if (var9.isIf3) {
                     if (MouseHandler.field154 >= var12 && MouseHandler.field145 * -976212263 >= var13 && MouseHandler.field154 < var14 && MouseHandler.field145 * -976212263 < var15) {
                        var33 = true;
                     } else {
                        var33 = false;
                     }

                     boolean var34 = false;
                     if ((MouseHandler.field150 == 1 || !WorldMapSection0.field1101 && MouseHandler.field150 == 4) && var33) {
                        var34 = true;
                     }

                     var21 = false;
                     if ((MouseHandler.field158 == 1 || !WorldMapSection0.field1101 && MouseHandler.field158 == 4) && MouseHandler.field159 >= var12 && MouseHandler.field148 >= var13 && MouseHandler.field159 < var14 && MouseHandler.field148 < var15) {
                        var21 = true;
                     }

                     if (var21) {
                        Occluder.method2989(var9, MouseHandler.field159 - var10, MouseHandler.field148 - var11);
                     }

                     if (var9.contentType == 1400) {
                        field123.method6175(var17, var18, var33 & var34, var33 & var21);
                     }

                     if (Client.field2259 != null && var9 != Client.field2259 && var33 && class192.method3891(class257.method5068(var9))) {
                        Client.field2254 = var9;
                     }

                     if (var9 == Client.field2260) {
                        Client.field2264 = true;
                        Client.field2156 = var10;
                        Client.field2266 = var11;
                     }

                     if (var9.hasListener) {
                        ScriptEvent var27;
                        if (var33 && Client.field2284 != 0 && var9.onScroll != null) {
                           var27 = new ScriptEvent();
                           var27.boolean1 = true;
                           var27.widget = var9;
                           var27.mouseY = Client.field2284;
                           var27.args = var9.onScroll;
                           Client.field2285.addFirst(var27);
                        }

                        if (Client.field2259 != null || World.field361 != null || Client.field2276) {
                           var21 = false;
                           var34 = false;
                           var33 = false;
                        }

                        if (!var9.field2590 && var21) {
                           var9.field2590 = true;
                           if (var9.onClick != null) {
                              var27 = new ScriptEvent();
                              var27.boolean1 = true;
                              var27.widget = var9;
                              var27.mouseX = MouseHandler.field159 - var10;
                              var27.mouseY = MouseHandler.field148 - var11;
                              var27.args = var9.onClick;
                              Client.field2285.addFirst(var27);
                           }
                        }

                        if (var9.field2590 && var34 && var9.onClickRepeat != null) {
                           var27 = new ScriptEvent();
                           var27.boolean1 = true;
                           var27.widget = var9;
                           var27.mouseX = MouseHandler.field154 - var10;
                           var27.mouseY = MouseHandler.field145 * -976212263 - var11;
                           var27.args = var9.onClickRepeat;
                           Client.field2285.addFirst(var27);
                        }

                        if (var9.field2590 && !var34) {
                           var9.field2590 = false;
                           if (var9.onRelease != null) {
                              var27 = new ScriptEvent();
                              var27.boolean1 = true;
                              var27.widget = var9;
                              var27.mouseX = MouseHandler.field154 - var10;
                              var27.mouseY = MouseHandler.field145 * -976212263 - var11;
                              var27.args = var9.onRelease;
                              Client.field2287.addFirst(var27);
                           }
                        }

                        if (var34 && var9.onHold != null) {
                           var27 = new ScriptEvent();
                           var27.boolean1 = true;
                           var27.widget = var9;
                           var27.mouseX = MouseHandler.field154 - var10;
                           var27.mouseY = MouseHandler.field145 * -976212263 - var11;
                           var27.args = var9.onHold;
                           Client.field2285.addFirst(var27);
                        }

                        if (!var9.field2719 && var33) {
                           var9.field2719 = true;
                           if (var9.onMouseOver != null) {
                              var27 = new ScriptEvent();
                              var27.boolean1 = true;
                              var27.widget = var9;
                              var27.mouseX = MouseHandler.field154 - var10;
                              var27.mouseY = MouseHandler.field145 * -976212263 - var11;
                              var27.args = var9.onMouseOver;
                              Client.field2285.addFirst(var27);
                           }
                        }

                        if (var9.field2719 && var33 && var9.onMouseRepeat != null) {
                           var27 = new ScriptEvent();
                           var27.boolean1 = true;
                           var27.widget = var9;
                           var27.mouseX = MouseHandler.field154 - var10;
                           var27.mouseY = MouseHandler.field145 * -976212263 - var11;
                           var27.args = var9.onMouseRepeat;
                           Client.field2285.addFirst(var27);
                        }

                        if (var9.field2719 && !var33) {
                           var9.field2719 = false;
                           if (var9.onMouseLeave != null) {
                              var27 = new ScriptEvent();
                              var27.boolean1 = true;
                              var27.widget = var9;
                              var27.mouseX = MouseHandler.field154 - var10;
                              var27.mouseY = MouseHandler.field145 * -976212263 - var11;
                              var27.args = var9.onMouseLeave;
                              Client.field2287.addFirst(var27);
                           }
                        }

                        if (var9.onTimer != null) {
                           var27 = new ScriptEvent();
                           var27.widget = var9;
                           var27.args = var9.onTimer;
                           Client.field2286.addFirst(var27);
                        }

                        ScriptEvent var28;
                        int var35;
                        int var36;
                        if (var9.onVarTransmit != null && Client.field2273 > var9.field2722) {
                           if (var9.varTransmitTriggers != null && Client.field2273 - var9.field2722 <= 32) {
                              label873:
                              for(var35 = var9.field2722; var35 < Client.field2273; ++var35) {
                                 var23 = Client.field2096[var35 & 31];

                                 for(var36 = 0; var36 < var9.varTransmitTriggers.length; ++var36) {
                                    if (var23 == var9.varTransmitTriggers[var36]) {
                                       var28 = new ScriptEvent();
                                       var28.widget = var9;
                                       var28.args = var9.onVarTransmit;
                                       Client.field2285.addFirst(var28);
                                       break label873;
                                    }
                                 }
                              }
                           } else {
                              var27 = new ScriptEvent();
                              var27.widget = var9;
                              var27.args = var9.onVarTransmit;
                              Client.field2285.addFirst(var27);
                           }

                           var9.field2722 = Client.field2273;
                        }

                        if (var9.onInvTransmit != null && Client.field2275 > var9.field2723) {
                           if (var9.invTransmitTriggers != null && Client.field2275 - var9.field2723 <= 32) {
                              label849:
                              for(var35 = var9.field2723; var35 < Client.field2275; ++var35) {
                                 var23 = Client.field2274[var35 & 31];

                                 for(var36 = 0; var36 < var9.invTransmitTriggers.length; ++var36) {
                                    if (var23 == var9.invTransmitTriggers[var36]) {
                                       var28 = new ScriptEvent();
                                       var28.widget = var9;
                                       var28.args = var9.onInvTransmit;
                                       Client.field2285.addFirst(var28);
                                       break label849;
                                    }
                                 }
                              }
                           } else {
                              var27 = new ScriptEvent();
                              var27.widget = var9;
                              var27.args = var9.onInvTransmit;
                              Client.field2285.addFirst(var27);
                           }

                           var9.field2723 = Client.field2275;
                        }

                        if (var9.onStatTransmit != null && Client.field2277 > var9.field2656) {
                           if (var9.statTransmitTriggers != null && Client.field2277 - var9.field2656 <= 32) {
                              label825:
                              for(var35 = var9.field2656; var35 < Client.field2277; ++var35) {
                                 var23 = Client.field2217[var35 & 31];

                                 for(var36 = 0; var36 < var9.statTransmitTriggers.length; ++var36) {
                                    if (var23 == var9.statTransmitTriggers[var36]) {
                                       var28 = new ScriptEvent();
                                       var28.widget = var9;
                                       var28.args = var9.onStatTransmit;
                                       Client.field2285.addFirst(var28);
                                       break label825;
                                    }
                                 }
                              }
                           } else {
                              var27 = new ScriptEvent();
                              var27.widget = var9;
                              var27.args = var9.onStatTransmit;
                              Client.field2285.addFirst(var27);
                           }

                           var9.field2656 = Client.field2277;
                        }

                        if (Client.field2278 > var9.field2721 && var9.field2696 != null) {
                           var27 = new ScriptEvent();
                           var27.widget = var9;
                           var27.args = var9.field2696;
                           Client.field2285.addFirst(var27);
                        }

                        if (Client.field2279 > var9.field2721 && var9.field2698 != null) {
                           var27 = new ScriptEvent();
                           var27.widget = var9;
                           var27.args = var9.field2698;
                           Client.field2285.addFirst(var27);
                        }

                        if (Client.field2280 > var9.field2721 && var9.field2668 != null) {
                           var27 = new ScriptEvent();
                           var27.widget = var9;
                           var27.args = var9.field2668;
                           Client.field2285.addFirst(var27);
                        }

                        if (Client.field2301 > var9.field2721 && var9.field2704 != null) {
                           var27 = new ScriptEvent();
                           var27.widget = var9;
                           var27.args = var9.field2704;
                           Client.field2285.addFirst(var27);
                        }

                        if (Client.field2282 > var9.field2721 && var9.field2717 != null) {
                           var27 = new ScriptEvent();
                           var27.widget = var9;
                           var27.args = var9.field2717;
                           Client.field2285.addFirst(var27);
                        }

                        if (Client.field2128 > var9.field2721 && var9.field2700 != null) {
                           var27 = new ScriptEvent();
                           var27.widget = var9;
                           var27.args = var9.field2700;
                           Client.field2285.addFirst(var27);
                        }

                        var9.field2721 = Client.field2271;
                        if (var9.field2587 != null) {
                           for(var35 = 0; var35 < Client.field2308; ++var35) {
                              ScriptEvent var31 = new ScriptEvent();
                              var31.widget = var9;
                              var31.keyTyped = Client.field2310[var35];
                              var31.keyPressed = Client.field2289[var35];
                              var31.args = var9.field2587;
                              Client.field2285.addFirst(var31);
                           }
                        }
                     }
                  }

                  if (!var9.isIf3) {
                     if (Client.field2259 != null || World.field361 != null || Client.field2276) {
                        continue;
                     }

                     if ((var9.mouseOverRedirect >= 0 || var9.mouseOverColor != 0) && MouseHandler.field154 >= var12 && MouseHandler.field145 * -976212263 >= var13 && MouseHandler.field154 < var14 && MouseHandler.field145 * -976212263 < var15) {
                        if (var9.mouseOverRedirect >= 0) {
                           BufferedSource.field1671 = var0[var9.mouseOverRedirect];
                        } else {
                           BufferedSource.field1671 = var9;
                        }
                     }

                     if (var9.type == 8 && MouseHandler.field154 >= var12 && MouseHandler.field145 * -976212263 >= var13 && MouseHandler.field154 < var14 && MouseHandler.field145 * -976212263 < var15) {
                        Tiles.field206 = var9;
                     }

                     if (var9.scrollHeight > var9.height) {
                        IndexCacheLoader.method1100(var9, var10 + var9.width, var11, var9.height, var9.scrollHeight, MouseHandler.field154, MouseHandler.field145 * -976212263);
                     }
                  }

                  if (var9.type == 0) {
                     method375(var0, var9.id, var12, var13, var14, var15, var10 - var9.scrollX, var11 - var9.scrollY);
                     if (var9.children != null) {
                        method375(var9.children, var9.id, var12, var13, var14, var15, var10 - var9.scrollX, var11 - var9.scrollY);
                     }

                     WidgetGroupParent var29 = (WidgetGroupParent) Client.field2247.get((long)var9.id);
                     if (var29 != null) {
                        if (var29.type == 0 && MouseHandler.field154 >= var12 && MouseHandler.field145 * -976212263 >= var13 && MouseHandler.field154 < var14 && MouseHandler.field145 * -976212263 < var15 && !Client.field2276) {
                           for(ScriptEvent var30 = (ScriptEvent) Client.field2285.last(); var30 != null; var30 = (ScriptEvent) Client.field2285.previous()) {
                              if (var30.boolean1) {
                                 var30.remove();
                                 var30.widget.field2719 = false;
                              }
                           }

                           if (class251.field3254 == 0) {
                              Client.field2259 = null;
                              Client.field2260 = null;
                           }

                           if (!Client.field2276) {
                              WorldMapSection0.method1872();
                           }
                        }

                        class57.method1228(var29.group, var12, var13, var14, var15, var10, var11);
                     }
                  }
               }
            }
         }
      }

   }
}
