import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;

public class EnumDefinition extends DualNode {
   static AbstractIndexCache field3492;
   static EvictingDualNodeHashTable field3487 = new EvictingDualNodeHashTable(64);
   public int size0 = 0;
   public String defaultString = "null";
   public char keyType;
   public String[] stringVals;
   public int defaultInt;
   public int[] intVals;
   public char valType;
   public int[] keys;

   public int size() {
      return this.size0;
   }

   void read(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.readNext(var1, var2);
      }
   }

   void readNext(Buffer var1, int var2) {
      if (var2 == 1) {
         this.keyType = (char)var1.readUnsignedByte();
      } else if (var2 == 2) {
         this.valType = (char)var1.readUnsignedByte();
      } else if (var2 == 3) {
         this.defaultString = var1.readStringCp1252NullTerminated();
      } else if (var2 == 4) {
         this.defaultInt = var1.readInt();
      } else {
         int var3;
         if (var2 == 5) {
            this.size0 = var1.method3913();
            this.keys = new int[this.size0];
            this.stringVals = new String[this.size0];

            for(var3 = 0; var3 < this.size0; ++var3) {
               this.keys[var3] = var1.readInt();
               this.stringVals[var3] = var1.readStringCp1252NullTerminated();
            }
         } else if (var2 == 6) {
            this.size0 = var1.method3913();
            this.keys = new int[this.size0];
            this.intVals = new int[this.size0];

            for(var3 = 0; var3 < this.size0; ++var3) {
               this.keys[var3] = var1.readInt();
               this.intVals[var3] = var1.readInt();
            }
         }
      }

   }

   static long method5299() {
      try {
         URL var0 = new URL(WidgetGroupParent.method999("services", false) + "m=accountappeal/login.ws");
         URLConnection var1 = var0.openConnection();
         var1.setRequestProperty("connection", "close");
         var1.setDoInput(true);
         var1.setDoOutput(true);
         var1.setConnectTimeout(5000);
         OutputStreamWriter var2 = new OutputStreamWriter(var1.getOutputStream());
         var2.write("data1=req");
         var2.flush();
         InputStream var3 = var1.getInputStream();
         Buffer var4 = new Buffer(new byte[1000]);

         do {
            int var5 = var3.read(var4.array, var4.index, 1000 - var4.index);
            if (var5 == -1) {
               var4.index = 0;
               long var7 = var4.readLong();
               return var7;
            }

            var4.index += var5;
         } while(var4.index < 1000);

         return 0L;
      } catch (Exception var9) {
         return 0L;
      }
   }

   static void method5305() {
      if (ObjectSound.field589.x >> 7 == Client.field2165 && ObjectSound.field589.y >> 7 == Client.field2318) {
         Client.field2165 = 0;
      }

   }
}
