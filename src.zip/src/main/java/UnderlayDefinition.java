public class UnderlayDefinition extends DualNode {
   public static AbstractIndexCache field3567;
   public static EvictingDualNodeHashTable field3561 = new EvictingDualNodeHashTable(64);
   public int hueMultiplier;
   public int saturation;
   int rgb = 0;
   public int lightness;
   public int hue;

   void setHsl(int var1) {
      double var2 = (double)(var1 >> 16 & 255) / 256.0D;
      double var4 = (double)(var1 >> 8 & 255) / 256.0D;
      double var6 = (double)(var1 & 255) / 256.0D;
      double var8 = var2;
      if (var4 < var2) {
         var8 = var4;
      }

      if (var6 < var8) {
         var8 = var6;
      }

      double var10 = var2;
      if (var4 > var2) {
         var10 = var4;
      }

      if (var6 > var10) {
         var10 = var6;
      }

      double var12 = 0.0D;
      double var14 = 0.0D;
      double var16 = (var8 + var10) / 2.0D;
      if (var8 != var10) {
         if (var16 < 0.5D) {
            var14 = (var10 - var8) / (var10 + var8);
         }

         if (var16 >= 0.5D) {
            var14 = (var10 - var8) / (2.0D - var10 - var8);
         }

         if (var10 == var2) {
            var12 = (var4 - var6) / (var10 - var8);
         } else if (var4 == var10) {
            var12 = 2.0D + (var6 - var2) / (var10 - var8);
         } else if (var6 == var10) {
            var12 = (var2 - var4) / (var10 - var8) + 4.0D;
         }
      }

      var12 /= 6.0D;
      this.saturation = (int)(256.0D * var14);
      this.lightness = (int)(var16 * 256.0D);
      if (this.saturation < 0) {
         this.saturation = 0;
      } else if (this.saturation > 255) {
         this.saturation = 255;
      }

      if (this.lightness < 0) {
         this.lightness = 0;
      } else if (this.lightness > 255) {
         this.lightness = 255;
      }

      if (var16 > 0.5D) {
         this.hueMultiplier = (int)((1.0D - var16) * var14 * 512.0D);
      } else {
         this.hueMultiplier = (int)(512.0D * var14 * var16);
      }

      if (this.hueMultiplier < 1) {
         this.hueMultiplier = 1;
      }

      this.hue = (int)((double)this.hueMultiplier * var12);
   }

   void read(Buffer var1, int var2) {
      while(true) {
         int var3 = var1.readUnsignedByte();
         if (var3 == 0) {
            return;
         }

         this.readNext(var1, var3, var2);
      }
   }

   void readNext(Buffer var1, int var2, int var3) {
      if (var2 == 1) {
         this.rgb = var1.readMedium();
      }

   }

   void init() {
      this.setHsl(this.rgb);
   }

   static final void method5416(Actor var0) {
      var0.movementSequence = var0.idleSequence;
      if (var0.pathLength == 0) {
         var0.field293 = 0;
      } else {
         if (var0.sequence != -1 && var0.sequenceDelay == 0) {
            SequenceDefinition var1 = WorldMapCacheName.method547(var0.sequence);
            if (var0.field297 > 0 && var1.field3470 == 0) {
               ++var0.field293;
               return;
            }

            if (var0.field297 <= 0 && var1.field3480 == 0) {
               ++var0.field293;
               return;
            }
         }

         int var10 = var0.x;
         int var2 = var0.y;
         int var3 = var0.pathX[var0.pathLength - 1] * 128 + var0.size * 64;
         int var4 = var0.pathY[var0.pathLength - 1] * 128 + var0.size * 64;
         if (var10 < var3) {
            if (var2 < var4) {
               var0.orientation = 1280;
            } else if (var2 > var4) {
               var0.orientation = 1792;
            } else {
               var0.orientation = 1536;
            }
         } else if (var10 > var3) {
            if (var2 < var4) {
               var0.orientation = 768;
            } else if (var2 > var4) {
               var0.orientation = 256;
            } else {
               var0.orientation = 512;
            }
         } else if (var2 < var4) {
            var0.orientation = 1024;
         } else if (var2 > var4) {
            var0.orientation = 0;
         }

         byte var5 = var0.pathTraversed[var0.pathLength - 1];
         if (var3 - var10 <= 256 && var3 - var10 >= -256 && var4 - var2 <= 256 && var4 - var2 >= -256) {
            int var6 = var0.orientation - var0.field278 & 2047;
            if (var6 > 1024) {
               var6 -= 2048;
            }

            int var7 = var0.walkTurnSequence;
            if (var6 >= -256 && var6 <= 256) {
               var7 = var0.walkSequence;
            } else if (var6 >= 256 && var6 < 768) {
               var7 = var0.walkTurnRightSequence;
            } else if (var6 >= -768 && var6 <= -256) {
               var7 = var0.walkTurnLeftSequence;
            }

            if (var7 == -1) {
               var7 = var0.walkSequence;
            }

            var0.movementSequence = var7;
            int var8 = 4;
            boolean var9 = true;
            if (var0 instanceof Npc) {
               var9 = ((Npc)var0).definition.field3602;
            }

            if (var9) {
               if (var0.field278 != var0.orientation && var0.targetIndex == -1 && var0.field285 != 0) {
                  var8 = 2;
               }

               if (var0.pathLength > 2) {
                  var8 = 6;
               }

               if (var0.pathLength > 3) {
                  var8 = 8;
               }

               if (var0.field293 > 0 && var0.pathLength > 1) {
                  var8 = 8;
                  --var0.field293;
               }
            } else {
               if (var0.pathLength > 1) {
                  var8 = 6;
               }

               if (var0.pathLength > 2) {
                  var8 = 8;
               }

               if (var0.field293 > 0 && var0.pathLength > 1) {
                  var8 = 8;
                  --var0.field293;
               }
            }

            if (var5 == 2) {
               var8 <<= 1;
            }

            if (var8 >= 8 && var0.movementSequence == var0.walkSequence && var0.runSequence != -1) {
               var0.movementSequence = var0.runSequence;
            }

            if (var10 != var3 || var4 != var2) {
               if (var10 < var3) {
                  var0.x += var8;
                  if (var0.x > var3) {
                     var0.x = var3;
                  }
               } else if (var10 > var3) {
                  var0.x -= var8;
                  if (var0.x < var3) {
                     var0.x = var3;
                  }
               }

               if (var2 < var4) {
                  var0.y += var8;
                  if (var0.y > var4) {
                     var0.y = var4;
                  }
               } else if (var2 > var4) {
                  var0.y -= var8;
                  if (var0.y < var4) {
                     var0.y = var4;
                  }
               }
            }

            if (var3 == var0.x && var4 == var0.y) {
               --var0.pathLength;
               if (var0.field297 > 0) {
                  --var0.field297;
               }
            }

         } else {
            var0.x = var3;
            var0.y = var4;
            --var0.pathLength;
            if (var0.field297 > 0) {
               --var0.field297;
            }

         }
      }
   }
}
