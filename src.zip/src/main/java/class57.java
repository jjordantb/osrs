import java.util.Comparator;

final class class57 implements Comparator {
   static AbstractSoundSystem field642;
   static String field644;
   static IndexedSprite[] field640;
   public static AbstractIndexCache field645;
   static int field647;

   int method1214(GrandExchangeEvent var1, GrandExchangeEvent var2) {
      return var1.method1333().compareTo(var2.method1333());
   }

   public int compare(Object var1, Object var2) {
      return this.method1214((GrandExchangeEvent)var1, (GrandExchangeEvent)var2);
   }

   public boolean equals(Object var1) {
      return super.equals(var1);
   }

   public static PlayerType[] method1226() {
      return new PlayerType[]{PlayerType.field2855, PlayerType.field2863, PlayerType.field2858, PlayerType.field2865, PlayerType.field2856, PlayerType.field2857};
   }

   public static final int method1225(double var0, double var2, double var4) {
      double var6 = var4;
      double var8 = var4;
      double var10 = var4;
      if (var2 != 0.0D) {
         double var12;
         if (var4 < 0.5D) {
            var12 = var4 * (1.0D + var2);
         } else {
            var12 = var2 + var4 - var4 * var2;
         }

         double var14 = var4 * 2.0D - var12;
         double var16 = var0 + 0.3333333333333333D;
         if (var16 > 1.0D) {
            --var16;
         }

         double var20 = var0 - 0.3333333333333333D;
         if (var20 < 0.0D) {
            ++var20;
         }

         if (var16 * 6.0D < 1.0D) {
            var6 = var14 + 6.0D * (var12 - var14) * var16;
         } else if (2.0D * var16 < 1.0D) {
            var6 = var12;
         } else if (var16 * 3.0D < 2.0D) {
            var6 = var14 + (0.6666666666666666D - var16) * (var12 - var14) * 6.0D;
         } else {
            var6 = var14;
         }

         if (6.0D * var0 < 1.0D) {
            var8 = var14 + var0 * (var12 - var14) * 6.0D;
         } else if (2.0D * var0 < 1.0D) {
            var8 = var12;
         } else if (var0 * 3.0D < 2.0D) {
            var8 = var14 + 6.0D * (0.6666666666666666D - var0) * (var12 - var14);
         } else {
            var8 = var14;
         }

         if (6.0D * var20 < 1.0D) {
            var10 = var14 + var20 * 6.0D * (var12 - var14);
         } else if (2.0D * var20 < 1.0D) {
            var10 = var12;
         } else if (var20 * 3.0D < 2.0D) {
            var10 = var14 + 6.0D * (var12 - var14) * (0.6666666666666666D - var20);
         } else {
            var10 = var14;
         }
      }

      int var22 = (int)(var6 * 256.0D);
      int var13 = (int)(256.0D * var8);
      int var23 = (int)(var10 * 256.0D);
      int var15 = var23 + (var13 << 8) + (var22 << 16);
      return var15;
   }

   static LoginPacket[] method1216() {
      return new LoginPacket[]{LoginPacket.field1953, LoginPacket.field1958, LoginPacket.field1956, LoginPacket.field1954, LoginPacket.field1955};
   }

   static final void method1228(int var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      if (class196.method4189(var0)) {
         class12.method375(UserComparator3.field1708[var0], -1, var1, var2, var3, var4, var5, var6);
      }
   }

   static final void method1213(WidgetGroupParent var0, boolean var1) {
      int var2 = var0.group;
      int var3 = (int)var0.key;
      var0.remove();
      if (var1) {
         Login.method1250(var2);
      }

      class217.method4536(var2);
      Widget var4 = WorldMapSection3.method1148(var3);
      if (var4 != null) {
         WorldMapSection1.method506(var4);
      }

      for(int var5 = 0; var5 < Client.field2223; ++var5) {
         if (VarcString.method4905(Client.field2226[var5])) {
            if (var5 < Client.field2223 - 1) {
               for(int var6 = var5; var6 < Client.field2223 - 1; ++var6) {
                  Client.field2359[var6] = Client.field2359[var6 + 1];
                  Client.field2229[var6] = Client.field2229[var6 + 1];
                  Client.field2226[var6] = Client.field2226[var6 + 1];
                  Client.field2227[var6] = Client.field2227[var6 + 1];
                  Client.field2224[var6] = Client.field2224[var6 + 1];
                  Client.field2225[var6] = Client.field2225[var6 + 1];
                  Client.field2215[var6] = Client.field2215[var6 + 1];
               }
            }

            --var5;
            --Client.field2223;
         }
      }

      Formatting.method1028();
      if (Client.field2246 != -1) {
         WorldMapData2.method338(Client.field2246, 1);
      }

   }
}
