import java.io.File;
import java.util.Iterator;

public class class178 {
   static Client field1984;
   public static BufferedFile field1975 = null;
   public static BufferedFile field1976 = null;
   static int buildNumber;
   public static BufferedFile field1985 = null;
   static File field1970;
   static int field1980;
   public static BufferedFile[] field1977;
   static IndexCache field1967;
   static int field1983;

   public static void method3310(AbstractIndexCache var0) {
      VarpDefinition.field2926 = var0;
      VarpDefinition.field2925 = VarpDefinition.field2926.method5025(16);
   }

   static void method3308() {
      Iterator var0 = Messages.field611.iterator();

      while(var0.hasNext()) {
         Message var1 = (Message)var0.next();
         var1.method1048();
      }

   }

   static boolean method3304(Player var0) {
      if (Client.field2119 == 0) {
         return false;
      } else if (ObjectSound.field589 == var0) {
         return class251.method4941();
      } else {
         return World.method692() || WorldMapLabelSize.method1315() && var0.method811() || class167.method3168() && var0.method814();
      }
   }

   static final void method3311(int var0, int var1, int var2) {
      if (var0 >= 128 && var1 >= 128 && var0 <= 13056 && var1 <= 13056) {
         int var3 = MilliClock.method2923(var0, var1, class31.field363) - var2;
         var0 -= field1983;
         var3 -= Buffer.field2445;
         var1 -= Tiles.field219;
         int var4 = Rasterizer3D.field1446[ScriptEvent.field547];
         int var5 = Rasterizer3D.field1453[ScriptEvent.field547];
         int var6 = Rasterizer3D.field1446[WorldMapSectionType.field1062];
         int var7 = Rasterizer3D.field1453[WorldMapSectionType.field1062];
         int var8 = var6 * var1 + var0 * var7 >> 16;
         var1 = var7 * var1 - var0 * var6 >> 16;
         var0 = var8;
         var8 = var3 * var5 - var4 * var1 >> 16;
         var1 = var3 * var4 + var5 * var1 >> 16;
         if (var1 >= 50) {
            Client.field2095 = var0 * Client.field2350 / var1 + Client.field2087 / 2;
            Client.field2346 = Client.field2207 / 2 + var8 * Client.field2350 / var1;
         } else {
            Client.field2095 = -1;
            Client.field2346 = -1;
         }

      } else {
         Client.field2095 = -1;
         Client.field2346 = -1;
      }
   }
}
