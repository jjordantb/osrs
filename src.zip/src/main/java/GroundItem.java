public final class GroundItem extends Entity {
   int id;
   int quantity;

   protected final Model getModel() {
      return Varcs.getItemDefinition(this.id).getModel(this.quantity);
   }
}
