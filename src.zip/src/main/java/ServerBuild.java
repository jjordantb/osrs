public class ServerBuild {
   static final ServerBuild field2934 = new ServerBuild("RC", 1);
   static final ServerBuild field2941 = new ServerBuild("LIVE", 0);
   static final ServerBuild field2935 = new ServerBuild("WIP", 2);
   static final ServerBuild field2939 = new ServerBuild("BUILDLIVE", 3);
   public final String name;
   final int id;

   ServerBuild(String var1, int var2) {
      this.name = var1;
      this.id = var2;
   }

   public static void method4931(AbstractIndexCache var0) {
      VarcString.field2914 = var0;
   }
}
