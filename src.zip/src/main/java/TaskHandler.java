import java.io.DataInputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;

public class TaskHandler implements Runnable {
   public static String field1771;
   public static String field1767;
   Thread thread;
   Task current = null;
   boolean isClosed = false;
   Task task0 = null;

   public TaskHandler() {
      field1771 = "Unknown";
      field1767 = "1.6";

      try {
         field1771 = System.getProperty("java.vendor");
         field1767 = System.getProperty("java.version");
      } catch (Exception var2) {
         ;
      }

      this.isClosed = false;
      this.thread = new Thread(this);
      this.thread.setPriority(10);
      this.thread.setDaemon(true);
      this.thread.start();
   }

   public final Task newSocketTask(String var1, int var2) {
      return this.newTask(1, var2, 0, var1);
   }

   public final void close() {
      synchronized(this) {
         this.isClosed = true;
         this.notifyAll();
      }

      try {
         this.thread.join();
      } catch (InterruptedException var3) {
         ;
      }

   }

   public final Task newThreadTask(Runnable var1, int var2) {
      return this.newTask(2, var2, 0, var1);
   }

   final Task newTask(int var1, int var2, int var3, Object var4) {
      Task var5 = new Task();
      var5.type = var1;
      var5.intArgument = var2;
      var5.objectArgument = var4;
      synchronized(this) {
         if (this.task0 != null) {
            this.task0.next = var5;
            this.task0 = var5;
         } else {
            this.task0 = this.current = var5;
         }

         this.notify();
         return var5;
      }
   }

   public final void run() {
      while(true) {
         Task var1;
         synchronized(this) {
            while(true) {
               if (this.isClosed) {
                  return;
               }

               if (this.current != null) {
                  var1 = this.current;
                  this.current = this.current.next;
                  if (this.current == null) {
                     this.task0 = null;
                  }
                  break;
               }

               try {
                  this.wait();
               } catch (InterruptedException var8) {
                  ;
               }
            }
         }

         try {
            int var5 = var1.type;
            if (var5 == 1) {
               var1.result = new Socket(InetAddress.getByName((String)var1.objectArgument), var1.intArgument);
            } else if (var5 == 2) {
               Thread var3 = new Thread((Runnable)var1.objectArgument);
               var3.setDaemon(true);
               var3.start();
               var3.setPriority(var1.intArgument);
               var1.result = var3;
            } else if (var5 == 4) {
               var1.result = new DataInputStream(((URL)var1.objectArgument).openStream());
            }

            var1.status = 1;
         } catch (ThreadDeath var6) {
            throw var6;
         } catch (Throwable var7) {
            var1.status = 2;
         }
      }
   }

   static IndexedSprite close(AbstractIndexCache var0, int var1, int var2) {
      byte[] var4 = var0.takeRecord(var1, var2);
      boolean var3;
      if (var4 == null) {
         var3 = false;
      } else {
         TilePaint.method2436(var4);
         var3 = true;
      }

      return !var3 ? null : OverlayDefinition.method5557();
   }

   static final void method3070(int var0, int var1, boolean var2) {
      if (!var2 || var0 != VertexNormal.field1238 || IndexStore.field1834 != var1) {
         VertexNormal.field1238 = var0;
         IndexStore.field1834 = var1;
         class69.method1443(25);
         MouseRecorder.method1009("Loading - please wait.", true);
         int var3 = class21.field230;
         int var4 = class79.field902;
         class21.field230 = (var0 - 6) * 8;
         class79.field902 = (var1 - 6) * 8;
         int var5 = class21.field230 - var3;
         int var6 = class79.field902 - var4;
         var3 = class21.field230;
         var4 = class79.field902;

         int var7;
         int var9;
         for(var7 = 0; var7 < 32768; ++var7) {
            Npc var8 = Client.field2249[var7];
            if (var8 != null) {
               for(var9 = 0; var9 < 10; ++var9) {
                  var8.pathX[var9] -= var5;
                  var8.pathY[var9] -= var6;
               }

               var8.x -= var5 * 128;
               var8.y -= var6 * 128;
            }
         }

         for(var7 = 0; var7 < 2048; ++var7) {
            Player var21 = Client.field2141[var7];
            if (var21 != null) {
               for(var9 = 0; var9 < 10; ++var9) {
                  var21.pathX[var9] -= var5;
                  var21.pathY[var9] -= var6;
               }

               var21.x -= var5 * 128;
               var21.y -= var6 * 128;
            }
         }

         byte var20 = 0;
         byte var18 = 104;
         byte var22 = 1;
         if (var5 < 0) {
            var20 = 103;
            var18 = -1;
            var22 = -1;
         }

         byte var10 = 0;
         byte var11 = 104;
         byte var12 = 1;
         if (var6 < 0) {
            var10 = 103;
            var11 = -1;
            var12 = -1;
         }

         int var14;
         for(int var13 = var20; var13 != var18; var13 += var22) {
            for(var14 = var10; var14 != var11; var14 += var12) {
               int var15 = var13 + var5;
               int var16 = var14 + var6;

               for(int var17 = 0; var17 < 4; ++var17) {
                  if (var15 >= 0 && var16 >= 0 && var15 < 104 && var16 < 104) {
                     Client.field2272[var17][var13][var14] = Client.field2272[var17][var15][var16];
                  } else {
                     Client.field2272[var17][var13][var14] = null;
                  }
               }
            }
         }

         for(class37 var19 = (class37) Client.field2131.last(); var19 != null; var19 = (class37) Client.field2131.previous()) {
            var19.field446 -= var5;
            var19.field449 -= var6;
            if (var19.field446 < 0 || var19.field449 < 0 || var19.field446 >= 104 || var19.field449 >= 104) {
               var19.remove();
            }
         }

         if (Client.field2165 != 0) {
            Client.field2165 -= var5;
            Client.field2318 -= var6;
         }

         Client.field2348 = 0;
         Client.field2332 = false;
         class178.field1983 -= var5 << 7;
         Tiles.field219 -= var6 << 7;
         class71.field842 -= var5 << 7;
         class71.field844 -= var6 << 7;
         Client.field2104 = -1;
         Client.field2154.clear();
         Client.field2216.clear();

         for(var14 = 0; var14 < 4; ++var14) {
            Client.field2144[var14].method3182();
         }

      }
   }
}
