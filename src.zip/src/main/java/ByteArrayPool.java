public class ByteArrayPool {
   static byte[][] field2471 = new byte[250][];
   static int field2466 = 0;
   static int field2468 = 0;
   static IndexedSprite field2470;
   static byte[][] field2469 = new byte[50][];
   static byte[][] field2467 = new byte[1000][];
   static int field2465 = 0;
   static int[] field2464;

   static void method4250(String var0, String var1, String var2) {
      Login.field671 = var0;
      Login.field672 = var1;
      Login.field673 = var2;
   }

   static synchronized byte[] method4243(int var0, boolean var1) {
      byte[] var2;
      if (var0 != 100) {
         if (var0 < 100) {
            ;
         }
      } else if (field2468 > 0) {
         var2 = field2467[--field2468];
         field2467[field2468] = null;
         return var2;
      }

      if (var0 != 5000) {
         if (var0 < 5000) {
            ;
         }
      } else if (field2465 > 0) {
         var2 = field2471[--field2465];
         field2471[field2465] = null;
         return var2;
      }

      if (var0 != 30000) {
         if (var0 < 30000) {
            ;
         }
      } else if (field2466 > 0) {
         var2 = field2469[--field2466];
         field2469[field2466] = null;
         return var2;
      }

      if (FriendLoginUpdate.field3772 != null) {
         for(int var4 = 0; var4 < class83.field940.length; ++var4) {
            if (class83.field940[var4] != var0) {
               if (var0 < class83.field940[var4]) {
                  ;
               }
            } else if (field2464[var4] > 0) {
               byte[] var3 = FriendLoginUpdate.field3772[var4][--field2464[var4]];
               FriendLoginUpdate.field3772[var4][field2464[var4]] = null;
               return var3;
            }
         }
      }

      return new byte[var0];
   }
}
