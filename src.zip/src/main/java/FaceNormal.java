public class FaceNormal {
   public static char field1622;
   int field1620;
   int field1618;
   int field1619;

   public static byte method2883(char var0) {
      byte var1;
      if (var0 > 0 && var0 < '\u0080' || var0 >= ' ' && var0 <= 'ÿ') {
         var1 = (byte)var0;
      } else if (var0 == '€') {
         var1 = -128;
      } else if (var0 == '‚') {
         var1 = -126;
      } else if (var0 == 'ƒ') {
         var1 = -125;
      } else if (var0 == '„') {
         var1 = -124;
      } else if (var0 == '…') {
         var1 = -123;
      } else if (var0 == '†') {
         var1 = -122;
      } else if (var0 == '‡') {
         var1 = -121;
      } else if (var0 == 'ˆ') {
         var1 = -120;
      } else if (var0 == '‰') {
         var1 = -119;
      } else if (var0 == 'Š') {
         var1 = -118;
      } else if (var0 == '‹') {
         var1 = -117;
      } else if (var0 == 'Œ') {
         var1 = -116;
      } else if (var0 == 'Ž') {
         var1 = -114;
      } else if (var0 == '‘') {
         var1 = -111;
      } else if (var0 == '’') {
         var1 = -110;
      } else if (var0 == '“') {
         var1 = -109;
      } else if (var0 == '”') {
         var1 = -108;
      } else if (var0 == '•') {
         var1 = -107;
      } else if (var0 == '–') {
         var1 = -106;
      } else if (var0 == '—') {
         var1 = -105;
      } else if (var0 == '˜') {
         var1 = -104;
      } else if (var0 == '™') {
         var1 = -103;
      } else if (var0 == 'š') {
         var1 = -102;
      } else if (var0 == '›') {
         var1 = -101;
      } else if (var0 == 'œ') {
         var1 = -100;
      } else if (var0 == 'ž') {
         var1 = -98;
      } else if (var0 == 'Ÿ') {
         var1 = -97;
      } else {
         var1 = 63;
      }

      return var1;
   }

   public static PacketBufferNode method2884(ClientPacket var0, IsaacCipher var1) {
      PacketBufferNode var2 = ClientPacket.method3232();
      var2.field1803 = var0;
      var2.field1802 = var0.length;
      if (var2.field1802 == -1) {
         var2.packetBuffer = new PacketBuffer(260);
      } else if (var2.field1802 == -2) {
         var2.packetBuffer = new PacketBuffer(10000);
      } else if (var2.field1802 <= 18) {
         var2.packetBuffer = new PacketBuffer(20);
      } else if (var2.field1802 <= 98) {
         var2.packetBuffer = new PacketBuffer(100);
      } else {
         var2.packetBuffer = new PacketBuffer(260);
      }

      var2.packetBuffer.setIsaacCipher(var1);
      var2.packetBuffer.writeByteIsaac(var2.field1803.id);
      var2.field1805 = 0;
      return var2;
   }
}
