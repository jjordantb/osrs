import java.awt.image.BufferedImage;
import java.awt.image.PixelGrabber;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Calendar;
import javax.imageio.ImageIO;

public class Interpreter {
   static boolean field476 = false;
   static int[] field467 = new int[1000];
   static int[] field465 = new int[5];
   static Widget field477;
   static int[] field474;
   static boolean field475 = false;
   static int field469;
   static int[][] field466 = new int[5][5000];
   static ScriptFrame[] field471 = new ScriptFrame[50];
   static String[] field462 = new String[1000];
   static int field480 = 0;
   static String[] field464;
   static int field472 = 0;
   static final String[] field468 = new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
   static Calendar field473 = Calendar.getInstance();
   static final double field478 = Math.log(2.0D);

   static void method969() {
      if (TaskHandler.field1771.toLowerCase().indexOf("microsoft") != -1) {
         KeyHandler.field23[186] = 57;
         KeyHandler.field23[187] = 27;
         KeyHandler.field23[188] = 71;
         KeyHandler.field23[189] = 26;
         KeyHandler.field23[190] = 72;
         KeyHandler.field23[191] = 73;
         KeyHandler.field23[192] = 58;
         KeyHandler.field23[219] = 42;
         KeyHandler.field23[220] = 74;
         KeyHandler.field23[221] = 43;
         KeyHandler.field23[222] = 59;
         KeyHandler.field23[223] = 28;
      } else {
         KeyHandler.field23[44] = 71;
         KeyHandler.field23[45] = 26;
         KeyHandler.field23[46] = 72;
         KeyHandler.field23[47] = 73;
         KeyHandler.field23[59] = 57;
         KeyHandler.field23[61] = 27;
         KeyHandler.field23[91] = 42;
         KeyHandler.field23[92] = 74;
         KeyHandler.field23[93] = 43;
         KeyHandler.field23[192] = 28;
         KeyHandler.field23[222] = 58;
         KeyHandler.field23[520] = 59;
      }

   }

   public static final Sprite method966(byte[] var0) {
      BufferedImage var1 = null;

      try {
         var1 = ImageIO.read(new ByteArrayInputStream(var0));
         int var2 = var1.getWidth();
         int var3 = var1.getHeight();
         int[] var4 = new int[var3 * var2];
         PixelGrabber var5 = new PixelGrabber(var1, 0, 0, var2, var3, var4, 0, var2);
         var5.grabPixels();
         return new Sprite(var4, var2, var3);
      } catch (IOException var7) {
         ;
      } catch (InterruptedException var8) {
         ;
      }

      return new Sprite(0, 0);
   }

   static void method967(IndexCache var0, int var1, int var2, int var3, byte var4, boolean var5) {
      long var6 = (long)((var1 << 16) + var2);
      NetFileRequest var8 = (NetFileRequest)NetCache.field2840.get(var6);
      if (var8 == null) {
         var8 = (NetFileRequest)NetCache.field2831.get(var6);
         if (var8 == null) {
            var8 = (NetFileRequest)NetCache.field2836.get(var6);
            if (var8 != null) {
               if (var5) {
                  var8.removeDual();
                  NetCache.field2840.put(var8, var6);
                  --NetCache.field2837;
                  ++NetCache.field2832;
               }

            } else {
               if (!var5) {
                  var8 = (NetFileRequest)NetCache.field2838.get(var6);
                  if (var8 != null) {
                     return;
                  }
               }

               var8 = new NetFileRequest();
               var8.indexCache = var0;
               var8.crc = var3;
               var8.padding = var4;
               if (var5) {
                  NetCache.field2840.put(var8, var6);
                  ++NetCache.field2832;
               } else {
                  NetCache.field2835.addFirst(var8);
                  NetCache.field2836.put(var8, var6);
                  ++NetCache.field2837;
               }

            }
         }
      }
   }

   static void method968() {
      PacketBufferNode var0 = FaceNormal.method2884(ClientPacket.field1871, Client.field2133.isaacCipher);
      var0.packetBuffer.writeByte(class65.method1381());
      var0.packetBuffer.writeShort(FriendSystem.field379);
      var0.packetBuffer.writeShort(UserComparator8.field1678);
      Client.field2133.method1281(var0);
   }
}
