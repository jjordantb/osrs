public class Bounds {
   public int field3828;
   public int field3827;
   public int field3829;
   public int field3826;

   public Bounds(int var1, int var2, int var3, int var4) {
      this.method5975(var1, var2);
      this.method5976(var3, var4);
   }

   public Bounds(int var1, int var2) {
      this(0, 0, var1, var2);
   }

   void method5979(Bounds var1, Bounds var2) {
      var2.field3826 = this.field3826;
      var2.field3829 = this.field3829;
      if (this.field3826 < var1.field3826) {
         var2.field3829 -= var1.field3826 - this.field3826;
         var2.field3826 = var1.field3826;
      }

      if (var2.method5981() > var1.method5981()) {
         var2.field3829 -= var2.method5981() - var1.method5981();
      }

      if (var2.field3829 < 0) {
         var2.field3829 = 0;
      }

   }

   public void method5978(Bounds var1, Bounds var2) {
      this.method6007(var1, var2);
      this.method5979(var1, var2);
   }

   public void method5975(int var1, int var2) {
      this.field3827 = var1;
      this.field3826 = var2;
   }

   int method5980() {
      return this.field3828 + this.field3827;
   }

   int method5981() {
      return this.field3829 + this.field3826;
   }

   void method6007(Bounds var1, Bounds var2) {
      var2.field3827 = this.field3827;
      var2.field3828 = this.field3828;
      if (this.field3827 < var1.field3827) {
         var2.field3828 -= var1.field3827 - this.field3827;
         var2.field3827 = var1.field3827;
      }

      if (var2.method5980() > var1.method5980()) {
         var2.field3828 -= var2.method5980() - var1.method5980();
      }

      if (var2.field3828 < 0) {
         var2.field3828 = 0;
      }

   }

   public void method5976(int var1, int var2) {
      this.field3828 = var1;
      this.field3829 = var2;
   }

   public String toString() {
      return null;
   }
}
