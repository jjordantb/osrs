public class class267 {
   static int method5266(int var0, Script var1, boolean var2) {
      Widget var3 = var2 ? class85.field961 : Interpreter.field477;
      if (var0 == 1600) {
         Interpreter.field467[++class31.field364 - 1] = var3.scrollX;
         return 1;
      } else if (var0 == 1601) {
         Interpreter.field467[++class31.field364 - 1] = var3.scrollY;
         return 1;
      } else if (var0 == 1602) {
         Interpreter.field462[++Interpreter.field469 - 1] = var3.text;
         return 1;
      } else if (var0 == 1603) {
         Interpreter.field467[++class31.field364 - 1] = var3.scrollWidth;
         return 1;
      } else if (var0 == 1604) {
         Interpreter.field467[++class31.field364 - 1] = var3.scrollHeight;
         return 1;
      } else if (var0 == 1605) {
         Interpreter.field467[++class31.field364 - 1] = var3.modelZoom;
         return 1;
      } else if (var0 == 1606) {
         Interpreter.field467[++class31.field364 - 1] = var3.modelAngleX;
         return 1;
      } else if (var0 == 1607) {
         Interpreter.field467[++class31.field364 - 1] = var3.modelAngleZ;
         return 1;
      } else if (var0 == 1608) {
         Interpreter.field467[++class31.field364 - 1] = var3.modelAngleY;
         return 1;
      } else if (var0 == 1609) {
         Interpreter.field467[++class31.field364 - 1] = var3.transparency;
         return 1;
      } else if (var0 == 1610) {
         Interpreter.field467[++class31.field364 - 1] = var3.field2620;
         return 1;
      } else if (var0 == 1611) {
         Interpreter.field467[++class31.field364 - 1] = var3.color;
         return 1;
      } else if (var0 == 1612) {
         Interpreter.field467[++class31.field364 - 1] = var3.color2;
         return 1;
      } else if (var0 == 1613) {
         Interpreter.field467[++class31.field364 - 1] = var3.rectangleMode.ordinal();
         return 1;
      } else if (var0 == 1614) {
         Interpreter.field467[++class31.field364 - 1] = var3.field2646 ? 1 : 0;
         return 1;
      } else {
         return 2;
      }
   }
}
