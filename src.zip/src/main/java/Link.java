public class Link {
   Link field2576;
   Link field2575;

   public void remove() {
      if (this.field2575 != null) {
         this.field2575.field2576 = this.field2576;
         this.field2576.field2575 = this.field2575;
         this.field2576 = null;
         this.field2575 = null;
      }
   }
}
