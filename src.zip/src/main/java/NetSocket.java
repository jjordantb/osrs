import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public final class NetSocket extends AbstractSocket implements Runnable {
   static Font field1950;
   static int field1951;
   byte[] array;
   TaskHandler taskHandler;
   Socket socket;
   InputStream inputStream;
   boolean exceptionWriting = false;
   Task task;
   final int field1949;
   int field1944 = 0;
   final int field1948;
   boolean isClosed = false;
   OutputStream outputStream;
   int field1942 = 0;

   public NetSocket(Socket var1, TaskHandler var2, int var3) throws IOException {
      this.taskHandler = var2;
      this.socket = var1;
      this.field1948 = var3;
      this.field1949 = var3 - 100;
      this.socket.setSoTimeout(30000);
      this.socket.setTcpNoDelay(true);
      this.socket.setReceiveBufferSize(65536);
      this.socket.setSendBufferSize(65536);
      this.inputStream = this.socket.getInputStream();
      this.outputStream = this.socket.getOutputStream();
   }

   void write0(byte[] var1, int var2, int var3) throws IOException {
      if (!this.isClosed) {
         if (this.exceptionWriting) {
            this.exceptionWriting = false;
            throw new IOException();
         } else {
            if (this.array == null) {
               this.array = new byte[this.field1948];
            }

            synchronized(this) {
               for(int var5 = 0; var5 < var3; ++var5) {
                  this.array[this.field1944] = var1[var5 + var2];
                  this.field1944 = (this.field1944 + 1) % this.field1948;
                  if ((this.field1942 + this.field1949) % this.field1948 == this.field1944) {
                     throw new IOException();
                  }
               }

               if (this.task == null) {
                  this.task = this.taskHandler.newThreadTask(this, 3);
               }

               this.notifyAll();
            }
         }
      }
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      if (this.isClosed) {
         return 0;
      } else {
         int var4;
         int var5;
         for(var4 = var3; var3 > 0; var3 -= var5) {
            var5 = this.inputStream.read(var1, var2, var3);
            if (var5 <= 0) {
               throw new EOFException();
            }

            var2 += var5;
         }

         return var4;
      }
   }

   public int available() throws IOException {
      return this.isClosed ? 0 : this.inputStream.available();
   }

   public void write(byte[] var1, int var2, int var3) throws IOException {
      this.write0(var1, var2, var3);
   }

   public void close() {
      if (!this.isClosed) {
         synchronized(this) {
            this.isClosed = true;
            this.notifyAll();
         }

         if (this.task != null) {
            while(this.task.status == 0) {
               class276.method5382(1L);
            }

            if (this.task.status == 1) {
               try {
                  ((Thread)this.task.result).join();
               } catch (InterruptedException var3) {
                  ;
               }
            }
         }

         this.task = null;
      }
   }

   public int readUnsignedByte() throws IOException {
      return this.isClosed ? 0 : this.inputStream.read();
   }

   public boolean isAvailable(int var1) throws IOException {
      if (this.isClosed) {
         return false;
      } else {
         return this.inputStream.available() >= var1;
      }
   }

   protected void finalize() {
      this.close();
   }

   public void run() {
      try {
         while(true) {
            label84: {
               int var1;
               int var2;
               synchronized(this) {
                  if (this.field1944 == this.field1942) {
                     if (this.isClosed) {
                        break label84;
                     }

                     try {
                        this.wait();
                     } catch (InterruptedException var10) {
                        ;
                     }
                  }

                  var2 = this.field1942;
                  if (this.field1944 >= this.field1942) {
                     var1 = this.field1944 - this.field1942;
                  } else {
                     var1 = this.field1948 - this.field1942;
                  }
               }

               if (var1 <= 0) {
                  continue;
               }

               try {
                  this.outputStream.write(this.array, var2, var1);
               } catch (IOException var9) {
                  this.exceptionWriting = true;
               }

               this.field1942 = (var1 + this.field1942) % this.field1948;

               try {
                  if (this.field1942 == this.field1944) {
                     this.outputStream.flush();
                  }
               } catch (IOException var8) {
                  this.exceptionWriting = true;
               }
               continue;
            }

            try {
               if (this.inputStream != null) {
                  this.inputStream.close();
               }

               if (this.outputStream != null) {
                  this.outputStream.close();
               }

               if (this.socket != null) {
                  this.socket.close();
               }
            } catch (IOException var7) {
               ;
            }

            this.array = null;
            break;
         }
      } catch (Exception var12) {
         Projectile.setDestination((String)null, var12);
      }

   }
}
