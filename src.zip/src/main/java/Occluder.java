public final class Occluder {
   int maxX;
   int type;
   int field1711;
   int minTileY;
   int field1727;
   int minTileX;
   int field1722;
   int minY;
   int field1723;
   int minX;
   int field1721;
   int maxZ;
   int maxY;
   int maxTileY;
   int maxTileX;
   int field1725;
   int minZ;
   int field1724;

   public static int method2990(int var0) {
      if (var0 > 0) {
         return 1;
      } else {
         return var0 < 0 ? -1 : 0;
      }
   }

   static IndexCache method2988(int var0, boolean var1, boolean var2, boolean var3) {
      IndexStore var4 = null;
      if (class178.field1975 != null) {
         var4 = new IndexStore(var0, class178.field1975, class178.field1977[var0], 1000000);
      }

      return new IndexCache(var4, class34.field391, var0, var1, var2, var3);
   }

   static void method2991() {
      if (Client.field2241) {
         Widget var0 = class71.method1467(class299.field3748, Client.field2242);
         if (var0 != null && var0.onTargetLeave != null) {
            ScriptEvent var1 = new ScriptEvent();
            var1.widget = var0;
            var1.args = var0.onTargetLeave;
            IndexCacheLoader.method1096(var1);
         }

         Client.field2241 = false;
         WorldMapSection1.method506(var0);
      }
   }

   static final void method2989(Widget var0, int var1, int var2) {
      if (Client.field2259 == null && !Client.field2276) {
         if (var0 != null) {
            Widget var4 = PlayerType.method4811(var0);
            if (var4 == null) {
               var4 = var0.parent;
            }

            if (var4 != null) {
               Client.field2259 = var0;
               var4 = PlayerType.method4811(var0);
               if (var4 == null) {
                  var4 = var0.parent;
               }

               Client.field2260 = var4;
               Client.field2349 = var1;
               Client.field2281 = var2;
               class251.field3254 = 0;
               Client.field2270 = false;
               int var6 = Client.field2223 - 1;
               if (var6 != -1) {
                  WorldComparator.method1402(var6);
               }

               return;
            }
         }

      }
   }
}
