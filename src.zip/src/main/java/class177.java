public abstract class class177 {
   public int field1964;
   public int field1966;
   public int field1965;
   public int field1962;

   public abstract boolean vmethod3287(int var1, int var2, int var3, CollisionMap var4);

   public static void method3291(AbstractIndexCache var0) {
      VarbitDefinition.field3504 = var0;
   }

   static void method3290() {
      if (class12.field123 != null) {
         class12.field123.method6025(class31.field363, (ObjectSound.field589.x >> 7) + class21.field230, (ObjectSound.field589.y >> 7) + class79.field902, false);
         class12.field123.loadCache();
      }

   }
}
