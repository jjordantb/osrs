public class class100 {
   int[] field1084;
   int field1083 = MusicSample.method1343(6) + 1;
   int field1080 = MusicSample.method1343(24);
   int field1081 = MusicSample.method1343(16);
   int field1082 = MusicSample.method1343(8);
   int field1078 = MusicSample.method1343(24) + 1;
   int field1079 = MusicSample.method1343(24);

   class100() {
      int[] var1 = new int[this.field1083];

      int var2;
      for(var2 = 0; var2 < this.field1083; ++var2) {
         int var3 = 0;
         int var4 = MusicSample.method1343(3);
         boolean var5 = MusicSample.method1358() != 0;
         if (var5) {
            var3 = MusicSample.method1343(5);
         }

         var1[var2] = var3 << 3 | var4;
      }

      this.field1084 = new int[this.field1083 * 8];

      for(var2 = 0; var2 < this.field1083 * 8; ++var2) {
         this.field1084[var2] = (var1[var2 >> 3] & 1 << (var2 & 7)) != 0 ? MusicSample.method1343(8) : -1;
      }

   }

   void method1849(float[] var1, int var2, boolean var3) {
      int var4;
      for(var4 = 0; var4 < var2; ++var4) {
         var1[var4] = 0.0F;
      }

      if (!var3) {
         var4 = MusicSample.field773[this.field1082].field835;
         int var5 = this.field1080 - this.field1079;
         int var6 = var5 / this.field1078;
         int[] var7 = new int[var6];

         for(int var8 = 0; var8 < 8; ++var8) {
            int var9 = 0;

            while(var9 < var6) {
               int var10;
               int var11;
               if (var8 == 0) {
                  var10 = MusicSample.field773[this.field1082].method1451();

                  for(var11 = var4 - 1; var11 >= 0; --var11) {
                     if (var9 + var11 < var6) {
                        var7[var9 + var11] = var10 % this.field1083;
                     }

                     var10 /= this.field1083;
                  }
               }

               for(var10 = 0; var10 < var4; ++var10) {
                  var11 = var7[var9];
                  int var12 = this.field1084[var8 + var11 * 8];
                  if (var12 >= 0) {
                     int var13 = var9 * this.field1078 + this.field1079;
                     class70 var14 = MusicSample.field773[var12];
                     int var15;
                     if (this.field1081 == 0) {
                        var15 = this.field1078 / var14.field835;

                        for(int var16 = 0; var16 < var15; ++var16) {
                           float[] var17 = var14.method1459();

                           for(int var18 = 0; var18 < var14.field835; ++var18) {
                              var1[var13 + var16 + var18 * var15] += var17[var18];
                           }
                        }
                     } else {
                        var15 = 0;

                        while(var15 < this.field1078) {
                           float[] var19 = var14.method1459();

                           for(int var20 = 0; var20 < var14.field835; ++var20) {
                              var1[var13 + var15] += var19[var20];
                              ++var15;
                           }
                        }
                     }
                  }

                  ++var9;
                  if (var9 >= var6) {
                     break;
                  }
               }
            }
         }

      }
   }
}
