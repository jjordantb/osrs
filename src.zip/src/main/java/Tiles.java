public final class Tiles {
   static IndexedSprite[] field224;
   static final int[] field202 = new int[]{1, 2, 4, 8};
   static int field204 = 99;
   static int[][][] field217 = new int[4][105][105];
   static final int[] field208 = new int[]{1, 0, -1, 0};
   static byte[][][] field205;
   static int[][] field207;
   static int field209 = (int)(Math.random() * 33.0D) - 16;
   static int[] field221;
   static byte[][][] field203 = new byte[4][104][104];
   static final int[] field213 = new int[]{1, -1, -1, 1};
   static final int[] field210 = new int[]{16, 32, 64, 128};
   static int field215 = (int)(Math.random() * 17.0D) - 8;
   static byte[][][] field214;
   static final int[] field218 = new int[]{-1, -1, 1, 1};
   static final int[] field212 = new int[]{0, -1, 0, 1};
   static IndexCache field216;
   static int field219;
   static Widget field206;

   public static int method540(boolean var0, boolean var1) {
      byte var2 = 0;
      int var3 = var2 + NetCache.field2832 + NetCache.field2834;
      return var3;
   }

   static int method513(int var0, Script var1, boolean var2) {
      int var3;
      int var4;
      if (var0 == 100) {
         class31.field364 -= 3;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         int var5 = Interpreter.field467[class31.field364 + 2];
         if (var4 == 0) {
            throw new RuntimeException();
         } else {
            Widget var6 = WorldMapSection3.method1148(var3);
            if (var6.children == null) {
               var6.children = new Widget[var5 + 1];
            }

            if (var6.children.length <= var5) {
               Widget[] var7 = new Widget[var5 + 1];

               for(int var8 = 0; var8 < var6.children.length; ++var8) {
                  var7[var8] = var6.children[var8];
               }

               var6.children = var7;
            }

            if (var5 > 0 && var6.children[var5 - 1] == null) {
               throw new RuntimeException("" + (var5 - 1));
            } else {
               Widget var12 = new Widget();
               var12.type = var4;
               var12.parentId = var12.id = var6.id;
               var12.childIndex = var5;
               var12.isIf3 = true;
               var6.children[var5] = var12;
               if (var2) {
                  class85.field961 = var12;
               } else {
                  Interpreter.field477 = var12;
               }

               WorldMapSection1.method506(var6);
               return 1;
            }
         }
      } else {
         Widget var9;
         if (var0 == 101) {
            var9 = var2 ? class85.field961 : Interpreter.field477;
            Widget var10 = WorldMapSection3.method1148(var9.id);
            var10.children[var9.childIndex] = null;
            WorldMapSection1.method506(var10);
            return 1;
         } else if (var0 == 102) {
            var9 = WorldMapSection3.method1148(Interpreter.field467[--class31.field364]);
            var9.children = null;
            WorldMapSection1.method506(var9);
            return 1;
         } else if (var0 != 200) {
            if (var0 == 201) {
               var9 = WorldMapSection3.method1148(Interpreter.field467[--class31.field364]);
               if (var9 != null) {
                  Interpreter.field467[++class31.field364 - 1] = 1;
                  if (var2) {
                     class85.field961 = var9;
                  } else {
                     Interpreter.field477 = var9;
                  }
               } else {
                  Interpreter.field467[++class31.field364 - 1] = 0;
               }

               return 1;
            } else {
               return 2;
            }
         } else {
            class31.field364 -= 2;
            var3 = Interpreter.field467[class31.field364];
            var4 = Interpreter.field467[class31.field364 + 1];
            Widget var11 = class71.method1467(var3, var4);
            if (var11 != null && var4 != -1) {
               Interpreter.field467[++class31.field364 - 1] = 1;
               if (var2) {
                  class85.field961 = var11;
               } else {
                  Interpreter.field477 = var11;
               }
            } else {
               Interpreter.field467[++class31.field364 - 1] = 0;
            }

            return 1;
         }
      }
   }
}
