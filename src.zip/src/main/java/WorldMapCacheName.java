public class WorldMapCacheName {
   public static final WorldMapCacheName field236 = new WorldMapCacheName("labels");
   public static final WorldMapCacheName field233 = new WorldMapCacheName("compositetexture");
   public static final WorldMapCacheName field235 = new WorldMapCacheName("details");
   public static final WorldMapCacheName field234 = new WorldMapCacheName("area");
   public static final WorldMapCacheName field232 = new WorldMapCacheName("compositemap");
   static int[] field239;
   public final String name;

   WorldMapCacheName(String var1) {
      this.name = var1;
   }

   static boolean method548(long var0) {
      int var2 = (int)(var0 >>> 14 & 3L);
      return var2 == 2;
   }

   static int method545(int var0, Script var1, boolean var2) {
      Widget var3;
      if (var0 >= 2000) {
         var0 -= 1000;
         var3 = WorldMapSection3.method1148(Interpreter.field467[--class31.field364]);
      } else {
         var3 = var2 ? class85.field961 : Interpreter.field477;
      }

      WorldMapSection1.method506(var3);
      if (var0 != 1200 && var0 != 1205 && var0 != 1212) {
         if (var0 == 1201) {
            var3.modelType = 2;
            var3.modelId = Interpreter.field467[--class31.field364];
            return 1;
         } else if (var0 == 1202) {
            var3.modelType = 3;
            var3.modelId = ObjectSound.field589.appearance.getChatHeadId();
            return 1;
         } else {
            return 2;
         }
      } else {
         class31.field364 -= 2;
         int var4 = Interpreter.field467[class31.field364];
         int var5 = Interpreter.field467[class31.field364 + 1];
         var3.itemId = var4;
         var3.itemQuantity = var5;
         ItemDefinition var6 = Varcs.getItemDefinition(var4);
         var3.modelAngleX = var6.xan2d;
         var3.modelAngleY = var6.yan2d;
         var3.modelAngleZ = var6.zan2d;
         var3.modelOffsetX = var6.offsetX2d;
         var3.modelOffsetY = var6.offsetY2d;
         var3.modelZoom = var6.zoom2d;
         if (var0 == 1205) {
            var3.field2718 = 0;
         } else if (var0 == 1212 | var6.isStackable == 1) {
            var3.field2718 = 1;
         } else {
            var3.field2718 = 2;
         }

         if (var3.field2643 > 0) {
            var3.modelZoom = var3.modelZoom * 32 / var3.field2643;
         } else if (var3.rawWidth > 0) {
            var3.modelZoom = var3.modelZoom * 32 / var3.rawWidth;
         }

         return 1;
      }
   }

   public static SequenceDefinition method547(int var0) {
      SequenceDefinition var1 = (SequenceDefinition)SequenceDefinition.field3466.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = SequenceDefinition.field3479.takeRecord(12, var0);
         var1 = new SequenceDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         var1.init();
         SequenceDefinition.field3466.put(var1, (long)var0);
         return var1;
      }
   }

   public static final Sprite method546(int var0, int var1, int var2, int var3, int var4, boolean var5) {
      if (var1 == -1) {
         var4 = 0;
      } else if (var4 == 2 && var1 != 1) {
         var4 = 1;
      }

      long var6 = ((long)var4 << 40) + (long)var0 + ((long)var1 << 16) + ((long)var2 << 38) + ((long)var3 << 42);
      Sprite var8;
      if (!var5) {
         var8 = (Sprite)ItemDefinition.field3649.get(var6);
         if (var8 != null) {
            return var8;
         }
      }

      ItemDefinition var9 = Varcs.getItemDefinition(var0);
      if (var1 > 1 && var9.field3656 != null) {
         int var10 = -1;

         for(int var11 = 0; var11 < 10; ++var11) {
            if (var1 >= var9.field3645[var11] && var9.field3645[var11] != 0) {
               var10 = var9.field3656[var11];
            }
         }

         if (var10 != -1) {
            var9 = Varcs.getItemDefinition(var10);
         }
      }

      Model var21 = var9.getModel(1);
      if (var21 == null) {
         return null;
      } else {
         Sprite var22 = null;
         if (var9.noteTemplate != -1) {
            var22 = method546(var9.note, 10, 1, 0, 0, true);
            if (var22 == null) {
               return null;
            }
         } else if (var9.notedId != -1) {
            var22 = method546(var9.unnotedId, var1, var2, var3, 0, false);
            if (var22 == null) {
               return null;
            }
         } else if (var9.placeholderTemplate != -1) {
            var22 = method546(var9.placeholder, var1, 0, 0, 0, false);
            if (var22 == null) {
               return null;
            }
         }

         int[] var12 = Rasterizer2D.field3900;
         int var13 = Rasterizer2D.field3898;
         int var14 = Rasterizer2D.field3899;
         int[] var15 = new int[4];
         Rasterizer2D.method6286(var15);
         var8 = new Sprite(36, 32);
         Rasterizer2D.method6214(var8.pixels, 36, 32);
         Rasterizer2D.method6219();
         Rasterizer3D.method2615();
         Rasterizer3D.method2601(16, 16);
         Rasterizer3D.field1430 = false;
         if (var9.placeholderTemplate != -1) {
            var22.method6348(0, 0);
         }

         int var16 = var9.zoom2d;
         if (var5) {
            var16 = (int)(1.5D * (double)var16);
         } else if (var2 == 2) {
            var16 = (int)((double)var16 * 1.04D);
         }

         int var17 = var16 * Rasterizer3D.field1446[var9.xan2d] >> 16;
         int var18 = var16 * Rasterizer3D.field1453[var9.xan2d] >> 16;
         var21.calculateBoundsCylinder();
         var21.method2496(0, var9.yan2d, var9.zan2d, var9.xan2d, var9.offsetX2d, var21.height / 2 + var17 + var9.offsetY2d, var18 + var9.offsetY2d);
         if (var9.notedId != -1) {
            var22.method6348(0, 0);
         }

         if (var2 >= 1) {
            var8.method6344(1);
         }

         if (var2 >= 2) {
            var8.method6344(16777215);
         }

         if (var3 != 0) {
            var8.method6345(var3);
         }

         Rasterizer2D.method6214(var8.pixels, 36, 32);
         if (var9.noteTemplate != -1) {
            var22.method6348(0, 0);
         }

         if (var4 == 1 || var4 == 2 && var9.isStackable == 1) {
            Font var19 = UserComparator9.field1596;
            String var20;
            if (var1 < 100000) {
               var20 = "<col=ffff00>" + var1 + "</col>";
            } else if (var1 < 10000000) {
               var20 = "<col=ffffff>" + var1 / 1000 + "K" + "</col>";
            } else {
               var20 = "<col=00ff80>" + var1 / 1000000 + "M" + "</col>";
            }

            var19.draw(var20, 0, 9, 16776960, 1);
         }

         if (!var5) {
            ItemDefinition.field3649.put(var8, var6);
         }

         Rasterizer2D.method6214(var12, var13, var14);
         Rasterizer2D.method6226(var15);
         Rasterizer3D.method2615();
         Rasterizer3D.field1430 = true;
         return var8;
      }
   }
}
