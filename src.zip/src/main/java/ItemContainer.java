public class ItemContainer extends Node {
   static NodeHashTable field267 = new NodeHashTable(32);
   int[] quantities = new int[]{0};
   int[] ids = new int[]{-1};

   static int method604(int var0, Script var1, boolean var2) {
      Widget var3;
      if (var0 >= 2000) {
         var0 -= 1000;
         var3 = WorldMapSection3.method1148(Interpreter.field467[--class31.field364]);
      } else {
         var3 = var2 ? class85.field961 : Interpreter.field477;
      }

      if (var0 == 1927) {
         if (Interpreter.field472 >= 10) {
            throw new RuntimeException();
         } else if (var3.field2703 == null) {
            return 0;
         } else {
            ScriptEvent var4 = new ScriptEvent();
            var4.widget = var3;
            var4.args = var3.field2703;
            var4.field543 = Interpreter.field472 + 1;
            Client.field2285.addFirst(var4);
            return 1;
         }
      } else {
         return 2;
      }
   }

   public static int method587(CharSequence var0) {
      int var1 = var0.length();
      int var2 = 0;

      for(int var3 = 0; var3 < var1; ++var3) {
         var2 = (var2 << 5) - var2 + FaceNormal.method2883(var0.charAt(var3));
      }

      return var2;
   }
}
