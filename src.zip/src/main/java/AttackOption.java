public class AttackOption implements Enumerated {
   static Sprite[] field603;
   static final AttackOption field602 = new AttackOption(2);
   static final AttackOption field607 = new AttackOption(0);
   static final AttackOption field600 = new AttackOption(3);
   static final AttackOption field605 = new AttackOption(1);
   final int id;

   AttackOption(int var1) {
      this.id = var1;
   }

   public int ordinal() {
      return this.id;
   }
}
