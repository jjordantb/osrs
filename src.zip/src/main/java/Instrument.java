import java.util.Random;

public class Instrument {
   static int[] field1262 = new int['耀'];
   static int[] field1250;
   static int[] field1275;
   static int[] field1272;
   static int[] field1269;
   static int[] field1266;
   static int[] field1260;
   static int[] field1271;
   SoundEnvelope field1256;
   SoundEnvelope field1254;
   int delayDecay = 100;
   SoundEnvelope field1252;
   SoundEnvelope field1264;
   int offset = 0;
   int[] oscillatorPitch = new int[]{0, 0, 0, 0, 0};
   class106 field1274;
   SoundEnvelope field1255;
   int delayTime = 0;
   int[] oscillatorVolume = new int[]{0, 0, 0, 0, 0};
   int[] oscillatorDelays = new int[]{0, 0, 0, 0, 0};
   SoundEnvelope field1263;
   SoundEnvelope field1251;
   int duration = 500;
   SoundEnvelope field1257;
   SoundEnvelope field1273;

   static {
      Random var0 = new Random(0L);

      int var1;
      for(var1 = 0; var1 < 32768; ++var1) {
         field1262[var1] = (var0.nextInt() & 2) - 1;
      }

      field1269 = new int['耀'];

      for(var1 = 0; var1 < 32768; ++var1) {
         field1269[var1] = (int)(Math.sin((double)var1 / 5215.1903D) * 16384.0D);
      }

      field1250 = new int[220500];
      field1271 = new int[5];
      field1272 = new int[5];
      field1260 = new int[5];
      field1266 = new int[5];
      field1275 = new int[5];
   }

   final void decode(Buffer var1) {
      this.field1264 = new SoundEnvelope();
      this.field1264.decode(var1);
      this.field1251 = new SoundEnvelope();
      this.field1251.decode(var1);
      int var2 = var1.readUnsignedByte();
      if (var2 != 0) {
         --var1.index;
         this.field1252 = new SoundEnvelope();
         this.field1252.decode(var1);
         this.field1263 = new SoundEnvelope();
         this.field1263.decode(var1);
      }

      var2 = var1.readUnsignedByte();
      if (var2 != 0) {
         --var1.index;
         this.field1254 = new SoundEnvelope();
         this.field1254.decode(var1);
         this.field1255 = new SoundEnvelope();
         this.field1255.decode(var1);
      }

      var2 = var1.readUnsignedByte();
      if (var2 != 0) {
         --var1.index;
         this.field1256 = new SoundEnvelope();
         this.field1256.decode(var1);
         this.field1257 = new SoundEnvelope();
         this.field1257.decode(var1);
      }

      for(int var3 = 0; var3 < 10; ++var3) {
         int var4 = var1.method3925();
         if (var4 == 0) {
            break;
         }

         this.oscillatorVolume[var3] = var4;
         this.oscillatorPitch[var3] = var1.method3924();
         this.oscillatorDelays[var3] = var1.method3925();
      }

      this.delayTime = var1.method3925();
      this.delayDecay = var1.method3925();
      this.duration = var1.method3913();
      this.offset = var1.method3913();
      this.field1274 = new class106();
      this.field1273 = new SoundEnvelope();
      this.field1274.method2205(var1, this.field1273);
   }

   final int[] synthesize(int var1, int var2) {
      class195.method4153(field1250, 0, var1);
      if (var2 < 10) {
         return field1250;
      } else {
         double var3 = (double)var1 / ((double)var2 + 0.0D);
         this.field1264.reset();
         this.field1251.reset();
         int var5 = 0;
         int var6 = 0;
         int var7 = 0;
         if (this.field1252 != null) {
            this.field1252.reset();
            this.field1263.reset();
            var5 = (int)((double)(this.field1252.end - this.field1252.start) * 32.768D / var3);
            var6 = (int)((double)this.field1252.start * 32.768D / var3);
         }

         int var8 = 0;
         int var9 = 0;
         int var10 = 0;
         if (this.field1254 != null) {
            this.field1254.reset();
            this.field1255.reset();
            var8 = (int)((double)(this.field1254.end - this.field1254.start) * 32.768D / var3);
            var9 = (int)((double)this.field1254.start * 32.768D / var3);
         }

         int var11;
         for(var11 = 0; var11 < 5; ++var11) {
            if (this.oscillatorVolume[var11] != 0) {
               field1271[var11] = 0;
               field1272[var11] = (int)((double)this.oscillatorDelays[var11] * var3);
               field1260[var11] = (this.oscillatorVolume[var11] << 14) / 100;
               field1266[var11] = (int)((double)(this.field1264.end - this.field1264.start) * 32.768D * Math.pow(1.0057929410678534D, (double)this.oscillatorPitch[var11]) / var3);
               field1275[var11] = (int)((double)this.field1264.start * 32.768D / var3);
            }
         }

         int var12;
         int var13;
         int var14;
         int var15;
         for(var11 = 0; var11 < var1; ++var11) {
            var12 = this.field1264.doStep(var1);
            var13 = this.field1251.doStep(var1);
            if (this.field1252 != null) {
               var14 = this.field1252.doStep(var1);
               var15 = this.field1263.doStep(var1);
               var12 += this.evaluateWave(var7, var15, this.field1252.form) >> 1;
               var7 = var7 + var6 + (var14 * var5 >> 16);
            }

            if (this.field1254 != null) {
               var14 = this.field1254.doStep(var1);
               var15 = this.field1255.doStep(var1);
               var13 = var13 * ((this.evaluateWave(var10, var15, this.field1254.form) >> 1) + '耀') >> 15;
               var10 = var10 + var9 + (var14 * var8 >> 16);
            }

            for(var14 = 0; var14 < 5; ++var14) {
               if (this.oscillatorVolume[var14] != 0) {
                  var15 = field1272[var14] + var11;
                  if (var15 < var1) {
                     field1250[var15] += this.evaluateWave(field1271[var14], var13 * field1260[var14] >> 15, this.field1264.form);
                     field1271[var14] += (var12 * field1266[var14] >> 16) + field1275[var14];
                  }
               }
            }
         }

         int var16;
         if (this.field1256 != null) {
            this.field1256.reset();
            this.field1257.reset();
            var11 = 0;
            boolean var19 = false;
            boolean var20 = true;

            for(var14 = 0; var14 < var1; ++var14) {
               var15 = this.field1256.doStep(var1);
               var16 = this.field1257.doStep(var1);
               if (var20) {
                  var12 = (var15 * (this.field1256.end - this.field1256.start) >> 8) + this.field1256.start;
               } else {
                  var12 = (var16 * (this.field1256.end - this.field1256.start) >> 8) + this.field1256.start;
               }

               var11 += 256;
               if (var11 >= var12) {
                  var11 = 0;
                  var20 = !var20;
               }

               if (var20) {
                  field1250[var14] = 0;
               }
            }
         }

         if (this.delayTime > 0 && this.delayDecay > 0) {
            var11 = (int)((double)this.delayTime * var3);

            for(var12 = var11; var12 < var1; ++var12) {
               field1250[var12] += field1250[var12 - var11] * this.delayDecay / 100;
            }
         }

         if (this.field1274.field1154[0] > 0 || this.field1274.field1154[1] > 0) {
            this.field1273.reset();
            var11 = this.field1273.doStep(var1 + 1);
            var12 = this.field1274.method2217(0, (float)var11 / 65536.0F);
            var13 = this.field1274.method2217(1, (float)var11 / 65536.0F);
            if (var1 >= var12 + var13) {
               var14 = 0;
               var15 = var13;
               if (var13 > var1 - var12) {
                  var15 = var1 - var12;
               }

               int var17;
               while(var14 < var15) {
                  var16 = (int)((long)field1250[var14 + var12] * (long)class106.field1159 >> 16);

                  for(var17 = 0; var17 < var12; ++var17) {
                     var16 += (int)((long)field1250[var14 + var12 - 1 - var17] * (long)class106.field1158[0][var17] >> 16);
                  }

                  for(var17 = 0; var17 < var14; ++var17) {
                     var16 -= (int)((long)field1250[var14 - 1 - var17] * (long)class106.field1158[1][var17] >> 16);
                  }

                  field1250[var14] = var16;
                  var11 = this.field1273.doStep(var1 + 1);
                  ++var14;
               }

               var15 = 128;

               while(true) {
                  if (var15 > var1 - var12) {
                     var15 = var1 - var12;
                  }

                  int var18;
                  while(var14 < var15) {
                     var17 = (int)((long)field1250[var14 + var12] * (long)class106.field1159 >> 16);

                     for(var18 = 0; var18 < var12; ++var18) {
                        var17 += (int)((long)field1250[var14 + var12 - 1 - var18] * (long)class106.field1158[0][var18] >> 16);
                     }

                     for(var18 = 0; var18 < var13; ++var18) {
                        var17 -= (int)((long)field1250[var14 - 1 - var18] * (long)class106.field1158[1][var18] >> 16);
                     }

                     field1250[var14] = var17;
                     var11 = this.field1273.doStep(var1 + 1);
                     ++var14;
                  }

                  if (var14 >= var1 - var12) {
                     while(var14 < var1) {
                        var17 = 0;

                        for(var18 = var14 + var12 - var1; var18 < var12; ++var18) {
                           var17 += (int)((long)field1250[var14 + var12 - 1 - var18] * (long)class106.field1158[0][var18] >> 16);
                        }

                        for(var18 = 0; var18 < var13; ++var18) {
                           var17 -= (int)((long)field1250[var14 - 1 - var18] * (long)class106.field1158[1][var18] >> 16);
                        }

                        field1250[var14] = var17;
                        this.field1273.doStep(var1 + 1);
                        ++var14;
                     }
                     break;
                  }

                  var12 = this.field1274.method2217(0, (float)var11 / 65536.0F);
                  var13 = this.field1274.method2217(1, (float)var11 / 65536.0F);
                  var15 += 128;
               }
            }
         }

         for(var11 = 0; var11 < var1; ++var11) {
            if (field1250[var11] < -32768) {
               field1250[var11] = -32768;
            }

            if (field1250[var11] > 32767) {
               field1250[var11] = 32767;
            }
         }

         return field1250;
      }
   }

   final int evaluateWave(int var1, int var2, int var3) {
      if (var3 == 1) {
         return (var1 & 32767) < 16384 ? var2 : -var2;
      } else if (var3 == 2) {
         return field1269[var1 & 32767] * var2 >> 14;
      } else if (var3 == 3) {
         return (var2 * (var1 & 32767) >> 14) - var2;
      } else {
         return var3 == 4 ? var2 * field1262[var1 / 2607 & 32767] : 0;
      }
   }
}
