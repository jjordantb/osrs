public abstract class AbstractRasterProvider {
   static int field4008;
   public int height;
   public int[] pixels;
   public int width;

   public final void apply() {
      Rasterizer2D.method6214(this.pixels, this.width, this.height);
   }

   public abstract void draw(int var1, int var2, int var3, int var4);

   public abstract void drawFull(int var1, int var2);
}
