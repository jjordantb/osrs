import java.io.File;

public final class class294 {
   static IndexedSprite field3719;
   static File field3720;
}
