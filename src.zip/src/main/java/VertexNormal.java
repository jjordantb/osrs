public class VertexNormal {
   static int field1238;
   int field1233;
   int field1236;
   int field1235;
   int field1232;

   VertexNormal() {
   }

   VertexNormal(VertexNormal var1) {
      this.field1236 = var1.field1236;
      this.field1232 = var1.field1232;
      this.field1233 = var1.field1233;
      this.field1235 = var1.field1235;
   }

   static int method2401(int var0, int var1) {
      if (var0 == -2) {
         return 12345678;
      } else if (var0 == -1) {
         if (var1 < 0) {
            var1 = 0;
         } else if (var1 > 127) {
            var1 = 127;
         }

         var1 = 127 - var1;
         return var1;
      } else {
         var1 = (var0 & 127) * var1 / 128;
         if (var1 < 2) {
            var1 = 2;
         } else if (var1 > 126) {
            var1 = 126;
         }

         return (var0 & 'ﾀ') + var1;
      }
   }
}
