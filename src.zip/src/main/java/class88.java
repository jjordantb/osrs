public class class88 extends AbstractIntNode {
   public boolean field987;
   public int field989;
   public int field990;
   int field991;
   public byte[] field988;

   class88(int var1, byte[] var2, int var3, int var4) {
      this.field990 = var1;
      this.field988 = var2;
      this.field989 = var3;
      this.field991 = var4;
   }

   class88(int var1, byte[] var2, int var3, int var4, boolean var5) {
      this.field990 = var1;
      this.field988 = var2;
      this.field989 = var3;
      this.field991 = var4;
      this.field987 = var5;
   }

   public class88 method1770(class116 var1) {
      this.field988 = var1.method2517(this.field988);
      this.field990 = var1.method2522(this.field990);
      if (this.field989 == this.field991) {
         this.field989 = this.field991 = var1.method2518(this.field989);
      } else {
         this.field989 = var1.method2518(this.field989);
         this.field991 = var1.method2518(this.field991);
         if (this.field989 == this.field991) {
            --this.field989;
         }
      }

      return this;
   }
}
