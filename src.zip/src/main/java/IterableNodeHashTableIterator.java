import java.util.Iterator;

public class IterableNodeHashTableIterator implements Iterator {
   int field2502;
   IterableNodeHashTable hashTable;
   Node field2503 = null;
   Node field2501;

   IterableNodeHashTableIterator(IterableNodeHashTable var1) {
      this.hashTable = var1;
      this.method4309();
   }

   void method4309() {
      this.field2501 = this.hashTable.buckets[0].previous;
      this.field2502 = 1;
      this.field2503 = null;
   }

   public boolean hasNext() {
      if (this.hashTable.buckets[this.field2502 - 1] != this.field2501) {
         return true;
      } else {
         while(this.field2502 < this.hashTable.size) {
            if (this.hashTable.buckets[this.field2502++].previous != this.hashTable.buckets[this.field2502 - 1]) {
               this.field2501 = this.hashTable.buckets[this.field2502 - 1].previous;
               return true;
            }

            this.field2501 = this.hashTable.buckets[this.field2502 - 1];
         }

         return false;
      }
   }

   public Object next() {
      Node var1;
      if (this.hashTable.buckets[this.field2502 - 1] != this.field2501) {
         var1 = this.field2501;
         this.field2501 = var1.previous;
         this.field2503 = var1;
         return var1;
      } else {
         do {
            if (this.field2502 >= this.hashTable.size) {
               return null;
            }

            var1 = this.hashTable.buckets[this.field2502++].previous;
         } while(var1 == this.hashTable.buckets[this.field2502 - 1]);

         this.field2501 = var1.previous;
         this.field2503 = var1;
         return var1;
      }
   }

   public void remove() {
      this.field2503.remove();
      this.field2503 = null;
   }
}
