import java.io.File;

public class UserComparator10 extends AbstractUserComparator {
   final boolean field1653;

   public UserComparator10(boolean var1) {
      this.field1653 = var1;
   }

   int method2907(Buddy var1, Buddy var2) {
      if (Client.field2134 == var1.world && var2.world == Client.field2134) {
         return this.field1653 ? var1.int2 - var2.int2 : var2.int2 - var1.int2;
      } else {
         return this.method5349(var1, var2);
      }
   }

   public int compare(Object var1, Object var2) {
      return this.method2907((Buddy)var1, (Buddy)var2);
   }

   static void method2913(File var0) {
      class294.field3720 = var0;
      if (!class294.field3720.exists()) {
         throw new RuntimeException("");
      } else {
         class162.field1777 = true;
      }
   }

   public static VarpDefinition method2912(int var0) {
      VarpDefinition var1 = (VarpDefinition)VarpDefinition.field2927.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = VarpDefinition.field2926.takeRecord(16, var0);
         var1 = new VarpDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         VarpDefinition.field2927.put(var1, (long)var0);
         return var1;
      }
   }
}
