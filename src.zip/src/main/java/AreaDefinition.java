public class AreaDefinition extends DualNode {
   public static int field2901;
   public static AbstractIndexCache field2879;
   public static EvictingDualNodeHashTable field2884 = new EvictingDualNodeHashTable(256);
   public static AreaDefinition[] field2880;
   public class276 field2894;
   int field2881 = -1;
   public final int field2883;
   public String string1;
   int field2902 = Integer.MIN_VALUE;
   int field2895 = Integer.MIN_VALUE;
   public int field2888 = 0;
   int[] field2892;
   int[] field2899;
   public int field2885 = -1;
   public String[] strings = new String[5];
   public int field2897;
   public int field2887;
   public class257 field2898;
   int field2896 = Integer.MAX_VALUE;
   public String field2886;
   int field2893 = Integer.MAX_VALUE;
   byte[] field2900;

   public AreaDefinition(int var1) {
      this.field2894 = class276.field3527;
      this.field2898 = class257.field3316;
      this.field2887 = -1;
      this.field2883 = var1;
   }

   public Sprite getSprite(boolean var1) {
      int var2 = this.field2885;
      return this.getSprite0(var2);
   }

   void readNext(Buffer var1, int var2) {
      if (var2 == 1) {
         this.field2885 = var1.method4040();
      } else if (var2 == 2) {
         this.field2881 = var1.method4040();
      } else if (var2 == 3) {
         this.field2886 = var1.readStringCp1252NullTerminated();
      } else if (var2 == 4) {
         this.field2897 = var1.readMedium();
      } else if (var2 == 5) {
         var1.readMedium();
      } else if (var2 == 6) {
         this.field2888 = var1.readUnsignedByte();
      } else {
         int var3;
         if (var2 == 7) {
            var3 = var1.readUnsignedByte();
            if ((var3 & 1) == 0) {
               ;
            }

            if ((var3 & 2) == 2) {
               ;
            }
         } else if (var2 == 8) {
            var1.readUnsignedByte();
         } else if (var2 >= 10 && var2 <= 14) {
            this.strings[var2 - 10] = var1.readStringCp1252NullTerminated();
         } else if (var2 == 15) {
            var3 = var1.readUnsignedByte();
            this.field2892 = new int[var3 * 2];

            int var4;
            for(var4 = 0; var4 < var3 * 2; ++var4) {
               this.field2892[var4] = var1.method3956();
            }

            var1.readInt();
            var4 = var1.readUnsignedByte();
            this.field2899 = new int[var4];

            int var5;
            for(var5 = 0; var5 < this.field2899.length; ++var5) {
               this.field2899[var5] = var1.readInt();
            }

            this.field2900 = new byte[var3];

            for(var5 = 0; var5 < var3; ++var5) {
               this.field2900[var5] = var1.readByte();
            }
         } else if (var2 != 16) {
            if (var2 == 17) {
               this.string1 = var1.readStringCp1252NullTerminated();
            } else if (var2 == 18) {
               var1.method4040();
            } else if (var2 == 19) {
               this.field2887 = var1.method3913();
            } else if (var2 == 21) {
               var1.readInt();
            } else if (var2 == 22) {
               var1.readInt();
            } else if (var2 == 23) {
               var1.readUnsignedByte();
               var1.readUnsignedByte();
               var1.readUnsignedByte();
            } else if (var2 == 24) {
               var1.method3956();
               var1.method3956();
            } else if (var2 == 25) {
               var1.method4040();
            } else if (var2 == 28) {
               var1.readUnsignedByte();
            } else if (var2 == 29) {
               this.field2894 = (class276)class10.method352(class243.method4894(), var1.readUnsignedByte());
            } else if (var2 == 30) {
               class257[] var6 = new class257[]{class257.field3321, class257.field3316, class257.field3315};
               this.field2898 = (class257)class10.method352(var6, var1.readUnsignedByte());
            }
         }
      }

   }

   Sprite getSprite0(int var1) {
      if (var1 < 0) {
         return null;
      } else {
         Sprite var2 = (Sprite)field2884.get((long)var1);
         if (var2 != null) {
            return var2;
         } else {
            var2 = UserComparator3.method2971(field2879, var1, 0);
            if (var2 != null) {
               field2884.put(var2, (long)var1);
            }

            return var2;
         }
      }
   }

   public int method4872() {
      return this.field2883;
   }

   public void method4869() {
      if (this.field2892 != null) {
         for(int var1 = 0; var1 < this.field2892.length; var1 += 2) {
            if (this.field2892[var1] < this.field2893) {
               this.field2893 = this.field2892[var1];
            } else if (this.field2892[var1] > this.field2895) {
               this.field2895 = this.field2892[var1];
            }

            if (this.field2892[var1 + 1] < this.field2896) {
               this.field2896 = this.field2892[var1 + 1];
            } else if (this.field2892[var1 + 1] > this.field2902) {
               this.field2902 = this.field2892[var1 + 1];
            }
         }
      }

   }

   public void read(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.readNext(var1, var2);
      }
   }

   public static IndexedSprite readNext(AbstractIndexCache var0, String var1, String var2) {
      int var3 = var0.getArchiveId(var1);
      int var4 = var0.getRecordId(var3, var2);
      return TaskHandler.close(var0, var3, var4);
   }

   public static void method4892(AbstractIndexCache var0, AbstractIndexCache var1, boolean var2) {
      ObjectDefinition.field3387 = var0;
      ObjectDefinition.field3389 = var1;
      ObjectDefinition.field3391 = var2;
   }

   static final void method4891(int var0, int var1, int var2, int var3, Sprite var4, SpriteMask var5) {
      int var6 = var3 * var3 + var2 * var2;
      if (var6 > 4225 && var6 < 90000) {
         int var7 = Client.field2101 & 2047;
         int var8 = Rasterizer3D.field1446[var7];
         int var9 = Rasterizer3D.field1453[var7];
         int var10 = var9 * var2 + var3 * var8 >> 16;
         int var11 = var3 * var9 - var8 * var2 >> 16;
         double var12 = Math.atan2((double)var10, (double)var11);
         int var14 = var5.width / 2 - 25;
         int var15 = (int)(Math.sin(var12) * (double)var14);
         int var16 = (int)(Math.cos(var12) * (double)var14);
         byte var17 = 20;
         WorldMapLabelSize.field723.method6351(var15 + (var0 + var5.width / 2 - var17 / 2), var5.height / 2 + var1 - var17 / 2 - var16 - 10, var17, var17, 15, 15, var12, 256);
      } else {
         WidgetGroupParent.method1001(var0, var1, var2, var3, var4, var5);
      }

   }
}
