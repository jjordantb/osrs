public class Friend extends Buddy {
   static int field3823;
   boolean field3821;
   boolean field3822;

   public int vmethod5942(User var1) {
      return this.compareTo00((Friend)var1);
   }

   int compareTo00(Friend var1) {
      if (super.world == Client.field2134 && Client.field2134 != var1.world) {
         return -1;
      } else if (Client.field2134 == var1.world && super.world != Client.field2134) {
         return 1;
      } else if (super.world != 0 && var1.world == 0) {
         return -1;
      } else if (var1.world != 0 && super.world == 0) {
         return 1;
      } else if (this.field3821 && !var1.field3821) {
         return -1;
      } else if (!this.field3821 && var1.field3821) {
         return 1;
      } else if (this.field3822 && !var1.field3822) {
         return -1;
      } else if (!this.field3822 && var1.field3822) {
         return 1;
      } else {
         return super.world != 0 ? super.int2 - var1.int2 : var1.int2 - super.int2;
      }
   }

   public int compareTo(Object var1) {
      return this.compareTo00((Friend)var1);
   }

   public static int method5940(int var0) {
      return WorldMapLabel.method1783(ViewportMouse.field1509[var0]);
   }
}
