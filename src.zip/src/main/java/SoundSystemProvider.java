public class SoundSystemProvider implements AbstractSoundSystemProvider {
   static int field101;

   public AbstractSoundSystem soundSystem() {
      return new SoundSystem();
   }

   public static final void method334() {
      ViewportMouse.field1506 = false;
      ViewportMouse.field1508 = 0;
   }

   public static void method336(int var0, int var1) {
      VarbitDefinition var2 = class45.method1021(var0);
      int var3 = var2.varp;
      int var4 = var2.lowBit;
      int var5 = var2.highBit;
      int var6 = Varps.field2760[var5 - var4];
      if (var1 < 0 || var1 > var6) {
         var1 = 0;
      }

      var6 <<= var4;
      Varps.field2762[var3] = Varps.field2762[var3] & ~var6 | var1 << var4 & var6;
   }

   static final void method331(String var0) {
      if (var0.equalsIgnoreCase("toggleroof")) {
         GameShell.field72.roofsHidden = !GameShell.field72.roofsHidden;
         Player.method840();
         if (GameShell.field72.roofsHidden) {
            Message.set(99, "", "Roofs are now all hidden");
         } else {
            Message.set(99, "", "Roofs will only be removed selectively");
         }
      }

      if (var0.equalsIgnoreCase("displayfps")) {
         Client.field2329 = !Client.field2329;
      }

      if (var0.equalsIgnoreCase("renderself")) {
         Client.field2205 = !Client.field2205;
      }

      if (var0.equalsIgnoreCase("mouseovertext")) {
         Client.field2234 = !Client.field2234;
      }

      if (Client.field2255 >= 2) {
         if (var0.equalsIgnoreCase("errortest")) {
            throw new RuntimeException();
         }

         if (var0.equalsIgnoreCase("showcoord")) {
            class12.field123.field3891 = !class12.field123.field3891;
         }

         if (var0.equalsIgnoreCase("fpson")) {
            Client.field2329 = true;
         }

         if (var0.equalsIgnoreCase("fpsoff")) {
            Client.field2329 = false;
         }

         if (var0.equalsIgnoreCase("gc")) {
            System.gc();
         }

         if (var0.equalsIgnoreCase("clientdrop")) {
            class93.method1784();
         }
      }

      PacketBufferNode var1 = FaceNormal.method2884(ClientPacket.field1896, Client.field2133.isaacCipher);
      var1.packetBuffer.writeByte(var0.length() + 1);
      var1.packetBuffer.writeStringCp1252NullTerminated(var0);
      Client.field2133.method1281(var1);
   }

   static final void method330() {
      Client.field2280 = Client.field2271;
      WorldMapLabel.field1015 = true;
   }
}
