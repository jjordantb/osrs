import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class ReflectionCheck extends Node {
   Method[] methods;
   Field[] fields;
   int[] operations;
   int id;
   int[] intReplaceValues;
   int[] creationErrors;
   int size;
   byte[][][] arguments;
}
