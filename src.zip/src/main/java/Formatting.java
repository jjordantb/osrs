public class Formatting {
   static Class method1026(String var0) throws ClassNotFoundException {
      if (var0.equals("B")) {
         return Byte.TYPE;
      } else if (var0.equals("I")) {
         return Integer.TYPE;
      } else if (var0.equals("S")) {
         return Short.TYPE;
      } else if (var0.equals("J")) {
         return Long.TYPE;
      } else if (var0.equals("Z")) {
         return Boolean.TYPE;
      } else if (var0.equals("F")) {
         return Float.TYPE;
      } else if (var0.equals("D")) {
         return Double.TYPE;
      } else if (var0.equals("C")) {
         return Character.TYPE;
      } else {
         return var0.equals("void") ? Void.TYPE : Class.forName(var0);
      }
   }

   public static ServerBuild method1027(int var0) {
      ServerBuild[] var1 = LoginPacket.method3271();

      for(int var2 = 0; var2 < var1.length; ++var2) {
         ServerBuild var3 = var1[var2];
         if (var0 == var3.id) {
            return var3;
         }
      }

      return null;
   }

   static void method1028() {
      WidgetGroupParent.method998(class39.field491 / 2 + NetSocket.field1951, Script.field1051);
   }
}
