public class UserComparator3 extends AbstractUserComparator {
   public static Widget[][] field1708;
   static IndexCache field1709;
   final boolean field1707;

   public UserComparator3(boolean var1) {
      this.field1707 = var1;
   }

   int method2965(Buddy var1, Buddy var2) {
      if (var2.world != var1.world) {
         return this.field1707 ? var1.world - var2.world : var2.world - var1.world;
      } else {
         return this.method5349(var1, var2);
      }
   }

   public int compare(Object var1, Object var2) {
      return this.method2965((Buddy)var1, (Buddy)var2);
   }

   public static Sprite method2971(AbstractIndexCache var0, int var1, int var2) {
      return !class65.method1382(var0, var1, var2) ? null : NetFileRequest.method4960();
   }
}
