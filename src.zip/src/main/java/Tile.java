public final class Tile extends Node {
   int drawGameObjectEdges;
   BoundaryObject boundaryObject;
   TilePaint paint;
   int[] gameObjectEdgeMasks = new int[5];
   int y;
   boolean drawGameObjects;
   int plane;
   boolean drawSecondary;
   GroundItemPile groundItemPile;
   int gameObjectsEdgeMask = 0;
   int field1515;
   TileModel model;
   GameObject[] gameObjects = new GameObject[5];
   FloorDecoration floorDecoration;
   int gameObjectsCount;
   int originalPlane;
   int x;
   Tile linkedBelowTile;
   int field1534;
   boolean drawPrimary;
   WallDecoration wallDecoration;
   int minPlane;
   int field1536;

   Tile(int var1, int var2, int var3) {
      this.originalPlane = this.plane = var1;
      this.x = var2;
      this.y = var3;
   }

   public static synchronized long method2779() {
      long var0 = System.currentTimeMillis();
      if (var0 < class192.field2437) {
         class192.field2436 += class192.field2437 - var0;
      }

      class192.field2437 = var0;
      return class192.field2436 + var0;
   }

   static String method2778(Buffer var0, int var1) {
      try {
         int var2 = var0.method3925();
         if (var2 > var1) {
            var2 = var1;
         }

         byte[] var3 = new byte[var2];
         var0.index += class303.field3768.method3036(var0.array, var0.index, var3, 0, var2);
         String var4 = IsaacCipher.method4258(var3, 0, var2);
         return var4;
      } catch (Exception var6) {
         return "Cabbage";
      }
   }
}
