public final class FloorDecoration {
   public long tag;
   int y;
   int tileHeight;
   int flags;
   public Entity entity;
   int x;

   static final void method2555(boolean var0) {
      for(int var1 = 0; var1 < Client.field2129; ++var1) {
         Npc var2 = Client.field2249[Client.field2130[var1]];
         if (var2 != null && var2.isVisible() && var2.definition.field3576 == var0 && var2.definition.method5432()) {
            int var3 = var2.x >> 7;
            int var4 = var2.y >> 7;
            if (var3 >= 0 && var3 < 104 && var4 >= 0 && var4 < 104) {
               if (var2.size == 1 && (var2.x & 127) == 64 && (var2.y & 127) == 64) {
                  if (Client.field2183[var3][var4] == Client.field2184) {
                     continue;
                  }

                  Client.field2183[var3][var4] = Client.field2184;
               }

               long var5 = WorldComparator.method1404(0, 0, 1, !var2.definition.isInteractable, Client.field2130[var1]);
               var2.playerCycle = Client.field2098;
               class243.field2904.method2260(class31.field363, var2.x, var2.y, MilliClock.method2923(var2.size * 64 - 64 + var2.x, var2.size * 64 - 64 + var2.y, class31.field363), var2.size * 64 - 64 + 60, var2, var2.field278, var5, var2.field279);
            }
         }
      }

   }

   static void method2556(Widget var0, int var1, int var2) {
      if (var0.xAlignment == 0) {
         var0.x = var0.rawX;
      } else if (var0.xAlignment == 1) {
         var0.x = var0.rawX + (var1 - var0.width) / 2;
      } else if (var0.xAlignment == 2) {
         var0.x = var1 - var0.width - var0.rawX;
      } else if (var0.xAlignment == 3) {
         var0.x = var0.rawX * var1 >> 14;
      } else if (var0.xAlignment == 4) {
         var0.x = (var0.rawX * var1 >> 14) + (var1 - var0.width) / 2;
      } else {
         var0.x = var1 - var0.width - (var0.rawX * var1 >> 14);
      }

      if (var0.yAlignment == 0) {
         var0.y = var0.rawY;
      } else if (var0.yAlignment == 1) {
         var0.y = (var2 - var0.height) / 2 + var0.rawY;
      } else if (var0.yAlignment == 2) {
         var0.y = var2 - var0.height - var0.rawY;
      } else if (var0.yAlignment == 3) {
         var0.y = var2 * var0.rawY >> 14;
      } else if (var0.yAlignment == 4) {
         var0.y = (var2 - var0.height) / 2 + (var2 * var0.rawY >> 14);
      } else {
         var0.y = var2 - var0.height - (var2 * var0.rawY >> 14);
      }

   }
}
