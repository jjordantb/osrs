public class WorldMapSectionType implements Enumerated {
   static final WorldMapSectionType field1063 = new WorldMapSectionType(0, (byte)2);
   static final WorldMapSectionType field1055 = new WorldMapSectionType(3, (byte)0);
   static final WorldMapSectionType field1060 = new WorldMapSectionType(2, (byte)3);
   static final WorldMapSectionType field1054 = new WorldMapSectionType(1, (byte)1);
   static int field1062;
   final int type;
   final byte id;

   WorldMapSectionType(int var1, byte var2) {
      this.type = var1;
      this.id = var2;
   }

   public int ordinal() {
      return this.id;
   }

   static WorldMapSectionType[] method1820() {
      return new WorldMapSectionType[]{field1055, field1063, field1060, field1054};
   }

   public static int method1829(int var0) {
      return WidgetGroupParent.method1000(ViewportMouse.field1509[var0]);
   }

   static final void method1828(int var0, int var1, int var2, int var3, String var4, String var5, int var6, int var7) {
      if (var2 >= 2000) {
         var2 -= 2000;
      }

      PacketBufferNode var8;
      if (var2 == 1) {
         Client.field2187 = var6;
         Client.field2188 = var7;
         Client.field2202 = 2;
         Client.field2252 = 0;
         Client.field2165 = var0;
         Client.field2318 = var1;
         var8 = FaceNormal.method2884(ClientPacket.field1881, Client.field2133.isaacCipher);
         var8.packetBuffer.method3948(class79.field902 + var1);
         var8.packetBuffer.writeShortLE(WorldMapLabel.field1014);
         var8.packetBuffer.method3937(KeyHandler.field11[82] ? 1 : 0);
         var8.packetBuffer.writeIntLE(ChatChannel.field598);
         var8.packetBuffer.method3948(var0 + class21.field230);
         var8.packetBuffer.writeShort(var3);
         var8.packetBuffer.writeShortLE(class57.field647);
         Client.field2133.method1281(var8);
      } else if (var2 == 2) {
         Client.field2187 = var6;
         Client.field2188 = var7;
         Client.field2202 = 2;
         Client.field2252 = 0;
         Client.field2165 = var0;
         Client.field2318 = var1;
         var8 = FaceNormal.method2884(ClientPacket.field1928, Client.field2133.isaacCipher);
         var8.packetBuffer.writeByte(KeyHandler.field11[82] ? 1 : 0);
         var8.packetBuffer.writeShort(var0 + class21.field230);
         var8.packetBuffer.method4029(var3);
         var8.packetBuffer.writeIntLE16(class299.field3748);
         var8.packetBuffer.writeShort(Client.field2242);
         var8.packetBuffer.writeShortLE(class79.field902 + var1);
         Client.field2133.method1281(var8);
      } else if (var2 == 3) {
         Client.field2187 = var6;
         Client.field2188 = var7;
         Client.field2202 = 2;
         Client.field2252 = 0;
         Client.field2165 = var0;
         Client.field2318 = var1;
         var8 = FaceNormal.method2884(ClientPacket.field1933, Client.field2133.isaacCipher);
         var8.packetBuffer.writeShort(class79.field902 + var1);
         var8.packetBuffer.method3939(KeyHandler.field11[82] ? 1 : 0);
         var8.packetBuffer.method4029(var3);
         var8.packetBuffer.method3948(var0 + class21.field230);
         Client.field2133.method1281(var8);
      } else if (var2 == 4) {
         Client.field2187 = var6;
         Client.field2188 = var7;
         Client.field2202 = 2;
         Client.field2252 = 0;
         Client.field2165 = var0;
         Client.field2318 = var1;
         var8 = FaceNormal.method2884(ClientPacket.field1915, Client.field2133.isaacCipher);
         var8.packetBuffer.method3937(KeyHandler.field11[82] ? 1 : 0);
         var8.packetBuffer.writeShort(var3);
         var8.packetBuffer.writeShort(class79.field902 + var1);
         var8.packetBuffer.writeShort(var0 + class21.field230);
         Client.field2133.method1281(var8);
      } else if (var2 == 5) {
         Client.field2187 = var6;
         Client.field2188 = var7;
         Client.field2202 = 2;
         Client.field2252 = 0;
         Client.field2165 = var0;
         Client.field2318 = var1;
         var8 = FaceNormal.method2884(ClientPacket.field1888, Client.field2133.isaacCipher);
         var8.packetBuffer.method3948(var0 + class21.field230);
         var8.packetBuffer.method4029(var3);
         var8.packetBuffer.method3948(class79.field902 + var1);
         var8.packetBuffer.method3937(KeyHandler.field11[82] ? 1 : 0);
         Client.field2133.method1281(var8);
      } else if (var2 == 6) {
         Client.field2187 = var6;
         Client.field2188 = var7;
         Client.field2202 = 2;
         Client.field2252 = 0;
         Client.field2165 = var0;
         Client.field2318 = var1;
         var8 = FaceNormal.method2884(ClientPacket.field1839, Client.field2133.isaacCipher);
         var8.packetBuffer.method3937(KeyHandler.field11[82] ? 1 : 0);
         var8.packetBuffer.method4029(class79.field902 + var1);
         var8.packetBuffer.method4029(var0 + class21.field230);
         var8.packetBuffer.writeShortLE(var3);
         Client.field2133.method1281(var8);
      } else {
         PacketBufferNode var9;
         Npc var13;
         if (var2 == 7) {
            var13 = Client.field2249[var3];
            if (var13 != null) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var9 = FaceNormal.method2884(ClientPacket.field1846, Client.field2133.isaacCipher);
               var9.packetBuffer.method3948(class57.field647);
               var9.packetBuffer.writeShort(WorldMapLabel.field1014);
               var9.packetBuffer.method3948(var3);
               var9.packetBuffer.method3938(KeyHandler.field11[82] ? 1 : 0);
               var9.packetBuffer.writeInt(ChatChannel.field598);
               Client.field2133.method1281(var9);
            }
         } else if (var2 == 8) {
            var13 = Client.field2249[var3];
            if (var13 != null) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var9 = FaceNormal.method2884(ClientPacket.field1842, Client.field2133.isaacCipher);
               var9.packetBuffer.method3948(var3);
               var9.packetBuffer.method3938(KeyHandler.field11[82] ? 1 : 0);
               var9.packetBuffer.writeIntLE(class299.field3748);
               var9.packetBuffer.method4029(Client.field2242);
               Client.field2133.method1281(var9);
            }
         } else if (var2 == 9) {
            var13 = Client.field2249[var3];
            if (var13 != null) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var9 = FaceNormal.method2884(ClientPacket.field1841, Client.field2133.isaacCipher);
               var9.packetBuffer.method3938(KeyHandler.field11[82] ? 1 : 0);
               var9.packetBuffer.writeShortLE(var3);
               Client.field2133.method1281(var9);
            }
         } else if (var2 == 10) {
            var13 = Client.field2249[var3];
            if (var13 != null) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var9 = FaceNormal.method2884(ClientPacket.field1837, Client.field2133.isaacCipher);
               var9.packetBuffer.method4029(var3);
               var9.packetBuffer.writeByte(KeyHandler.field11[82] ? 1 : 0);
               Client.field2133.method1281(var9);
            }
         } else if (var2 == 11) {
            var13 = Client.field2249[var3];
            if (var13 != null) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var9 = FaceNormal.method2884(ClientPacket.field1906, Client.field2133.isaacCipher);
               var9.packetBuffer.method3948(var3);
               var9.packetBuffer.writeByte(KeyHandler.field11[82] ? 1 : 0);
               Client.field2133.method1281(var9);
            }
         } else if (var2 == 12) {
            var13 = Client.field2249[var3];
            if (var13 != null) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var9 = FaceNormal.method2884(ClientPacket.field1895, Client.field2133.isaacCipher);
               var9.packetBuffer.writeShort(var3);
               var9.packetBuffer.method3937(KeyHandler.field11[82] ? 1 : 0);
               Client.field2133.method1281(var9);
            }
         } else if (var2 == 13) {
            var13 = Client.field2249[var3];
            if (var13 != null) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var9 = FaceNormal.method2884(ClientPacket.field1891, Client.field2133.isaacCipher);
               var9.packetBuffer.writeByte(KeyHandler.field11[82] ? 1 : 0);
               var9.packetBuffer.method4029(var3);
               Client.field2133.method1281(var9);
            }
         } else {
            Player var15;
            if (var2 == 14) {
               var15 = Client.field2141[var3];
               if (var15 != null) {
                  Client.field2187 = var6;
                  Client.field2188 = var7;
                  Client.field2202 = 2;
                  Client.field2252 = 0;
                  Client.field2165 = var0;
                  Client.field2318 = var1;
                  var9 = FaceNormal.method2884(ClientPacket.field1917, Client.field2133.isaacCipher);
                  var9.packetBuffer.method3948(WorldMapLabel.field1014);
                  var9.packetBuffer.method3939(KeyHandler.field11[82] ? 1 : 0);
                  var9.packetBuffer.writeIntME(ChatChannel.field598);
                  var9.packetBuffer.writeShort(var3);
                  var9.packetBuffer.writeShort(class57.field647);
                  Client.field2133.method1281(var9);
               }
            } else if (var2 == 15) {
               var15 = Client.field2141[var3];
               if (var15 != null) {
                  Client.field2187 = var6;
                  Client.field2188 = var7;
                  Client.field2202 = 2;
                  Client.field2252 = 0;
                  Client.field2165 = var0;
                  Client.field2318 = var1;
                  var9 = FaceNormal.method2884(ClientPacket.field1873, Client.field2133.isaacCipher);
                  var9.packetBuffer.writeIntLE16(class299.field3748);
                  var9.packetBuffer.method3939(KeyHandler.field11[82] ? 1 : 0);
                  var9.packetBuffer.method4029(Client.field2242);
                  var9.packetBuffer.writeShort(var3);
                  Client.field2133.method1281(var9);
               }
            } else if (var2 == 16) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var8 = FaceNormal.method2884(ClientPacket.field1854, Client.field2133.isaacCipher);
               var8.packetBuffer.writeIntME(ChatChannel.field598);
               var8.packetBuffer.method3948(class57.field647);
               var8.packetBuffer.method3937(KeyHandler.field11[82] ? 1 : 0);
               var8.packetBuffer.writeShortLE(WorldMapLabel.field1014);
               var8.packetBuffer.method3948(var3);
               var8.packetBuffer.method3948(var0 + class21.field230);
               var8.packetBuffer.writeShortLE(class79.field902 + var1);
               Client.field2133.method1281(var8);
            } else if (var2 == 17) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var8 = FaceNormal.method2884(ClientPacket.field1880, Client.field2133.isaacCipher);
               var8.packetBuffer.writeIntME(class299.field3748);
               var8.packetBuffer.writeShort(Client.field2242);
               var8.packetBuffer.method4029(class79.field902 + var1);
               var8.packetBuffer.method4029(var0 + class21.field230);
               var8.packetBuffer.method3937(KeyHandler.field11[82] ? 1 : 0);
               var8.packetBuffer.writeShortLE(var3);
               Client.field2133.method1281(var8);
            } else if (var2 == 18) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var8 = FaceNormal.method2884(ClientPacket.field1845, Client.field2133.isaacCipher);
               var8.packetBuffer.method3948(class79.field902 + var1);
               var8.packetBuffer.writeShortLE(var3);
               var8.packetBuffer.writeShortLE(var0 + class21.field230);
               var8.packetBuffer.writeByte(KeyHandler.field11[82] ? 1 : 0);
               Client.field2133.method1281(var8);
            } else if (var2 == 19) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var8 = FaceNormal.method2884(ClientPacket.field1910, Client.field2133.isaacCipher);
               var8.packetBuffer.method3948(var3);
               var8.packetBuffer.method4029(var0 + class21.field230);
               var8.packetBuffer.writeShort(class79.field902 + var1);
               var8.packetBuffer.writeByte(KeyHandler.field11[82] ? 1 : 0);
               Client.field2133.method1281(var8);
            } else if (var2 == 20) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var8 = FaceNormal.method2884(ClientPacket.field1908, Client.field2133.isaacCipher);
               var8.packetBuffer.writeShortLE(class79.field902 + var1);
               var8.packetBuffer.method3939(KeyHandler.field11[82] ? 1 : 0);
               var8.packetBuffer.writeShortLE(var0 + class21.field230);
               var8.packetBuffer.writeShortLE(var3);
               Client.field2133.method1281(var8);
            } else if (var2 == 21) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var8 = FaceNormal.method2884(ClientPacket.field1922, Client.field2133.isaacCipher);
               var8.packetBuffer.method4029(class79.field902 + var1);
               var8.packetBuffer.writeShortLE(var3);
               var8.packetBuffer.writeShort(var0 + class21.field230);
               var8.packetBuffer.method3939(KeyHandler.field11[82] ? 1 : 0);
               Client.field2133.method1281(var8);
            } else if (var2 == 22) {
               Client.field2187 = var6;
               Client.field2188 = var7;
               Client.field2202 = 2;
               Client.field2252 = 0;
               Client.field2165 = var0;
               Client.field2318 = var1;
               var8 = FaceNormal.method2884(ClientPacket.field1887, Client.field2133.isaacCipher);
               var8.packetBuffer.writeByte(KeyHandler.field11[82] ? 1 : 0);
               var8.packetBuffer.method3948(var3);
               var8.packetBuffer.method4029(class79.field902 + var1);
               var8.packetBuffer.writeShort(var0 + class21.field230);
               Client.field2133.method1281(var8);
            } else if (var2 == 23) {
               if (Client.field2276) {
                  class243.field2904.method2263();
               } else {
                  class243.field2904.method2248(class31.field363, var0, var1, true);
               }
            } else {
               PacketBufferNode var10;
               Widget var16;
               if (var2 == 24) {
                  var16 = WorldMapSection3.method1148(var1);
                  boolean var11 = true;
                  if (var16.contentType > 0) {
                     var11 = WorldMapSection0.method1854(var16);
                  }

                  if (var11) {
                     var10 = FaceNormal.method2884(ClientPacket.field1905, Client.field2133.isaacCipher);
                     var10.packetBuffer.writeInt(var1);
                     Client.field2133.method1281(var10);
                  }
               } else {
                  if (var2 == 25) {
                     var16 = class71.method1467(var1, var0);
                     if (var16 != null) {
                        Occluder.method2991();
                        OwnWorldComparator.method616(var1, var0, class71.method1463(class257.method5068(var16)), var16.itemId);
                        Client.field2239 = 0;
                        Client.field2244 = Script.method1819(var16);
                        if (Client.field2244 == null) {
                           Client.field2244 = "null";
                        }

                        if (var16.isIf3) {
                           Client.field2159 = var16.dataText + ModelData0.method2792(16777215);
                        } else {
                           Client.field2159 = ModelData0.method2792(65280) + var16.spellName + ModelData0.method2792(16777215);
                        }
                     }

                     return;
                  }

                  if (var2 == 26) {
                     Canvas.method360();
                  } else {
                     int var12;
                     Widget var14;
                     if (var2 == 28) {
                        var8 = FaceNormal.method2884(ClientPacket.field1905, Client.field2133.isaacCipher);
                        var8.packetBuffer.writeInt(var1);
                        Client.field2133.method1281(var8);
                        var14 = WorldMapSection3.method1148(var1);
                        if (var14.cs1Instructions != null && var14.cs1Instructions[0][0] == 5) {
                           var12 = var14.cs1Instructions[0][1];
                           Varps.field2762[var12] = 1 - Varps.field2762[var12];
                           MusicPatch.method4735(var12);
                        }
                     } else if (var2 == 29) {
                        var8 = FaceNormal.method2884(ClientPacket.field1905, Client.field2133.isaacCipher);
                        var8.packetBuffer.writeInt(var1);
                        Client.field2133.method1281(var8);
                        var14 = WorldMapSection3.method1148(var1);
                        if (var14.cs1Instructions != null && var14.cs1Instructions[0][0] == 5) {
                           var12 = var14.cs1Instructions[0][1];
                           if (Varps.field2762[var12] != var14.cs1ComparisonValues[0]) {
                              Varps.field2762[var12] = var14.cs1ComparisonValues[0];
                              MusicPatch.method4735(var12);
                           }
                        }
                     } else if (var2 == 30) {
                        if (Client.field2323 == null) {
                           SequenceDefinition.method5247(var1, var0);
                           Client.field2323 = class71.method1467(var1, var0);
                           WorldMapSection1.method506(Client.field2323);
                        }
                     } else if (var2 == 31) {
                        var8 = FaceNormal.method2884(ClientPacket.field1899, Client.field2133.isaacCipher);
                        var8.packetBuffer.writeIntME(var1);
                        var8.packetBuffer.writeIntLE16(ChatChannel.field598);
                        var8.packetBuffer.method3948(WorldMapLabel.field1014);
                        var8.packetBuffer.writeShortLE(class57.field647);
                        var8.packetBuffer.writeShortLE(var0);
                        var8.packetBuffer.method3948(var3);
                        Client.field2133.method1281(var8);
                        Client.field2192 = 0;
                        class176.field1961 = WorldMapSection3.method1148(var1);
                        Client.field2193 = var0;
                     } else if (var2 == 32) {
                        var8 = FaceNormal.method2884(ClientPacket.field1838, Client.field2133.isaacCipher);
                        var8.packetBuffer.writeIntME(class299.field3748);
                        var8.packetBuffer.writeInt(var1);
                        var8.packetBuffer.writeShort(var0);
                        var8.packetBuffer.writeShortLE(var3);
                        var8.packetBuffer.writeShortLE(Client.field2242);
                        Client.field2133.method1281(var8);
                        Client.field2192 = 0;
                        class176.field1961 = WorldMapSection3.method1148(var1);
                        Client.field2193 = var0;
                     } else if (var2 == 33) {
                        var8 = FaceNormal.method2884(ClientPacket.field1923, Client.field2133.isaacCipher);
                        var8.packetBuffer.writeShortLE(var3);
                        var8.packetBuffer.writeIntME(var1);
                        var8.packetBuffer.writeShort(var0);
                        Client.field2133.method1281(var8);
                        Client.field2192 = 0;
                        class176.field1961 = WorldMapSection3.method1148(var1);
                        Client.field2193 = var0;
                     } else if (var2 == 34) {
                        var8 = FaceNormal.method2884(ClientPacket.field1934, Client.field2133.isaacCipher);
                        var8.packetBuffer.method4029(var3);
                        var8.packetBuffer.writeIntLE16(var1);
                        var8.packetBuffer.method3948(var0);
                        Client.field2133.method1281(var8);
                        Client.field2192 = 0;
                        class176.field1961 = WorldMapSection3.method1148(var1);
                        Client.field2193 = var0;
                     } else if (var2 == 35) {
                        var8 = FaceNormal.method2884(ClientPacket.field1925, Client.field2133.isaacCipher);
                        var8.packetBuffer.writeIntLE(var1);
                        var8.packetBuffer.method3948(var0);
                        var8.packetBuffer.method3948(var3);
                        Client.field2133.method1281(var8);
                        Client.field2192 = 0;
                        class176.field1961 = WorldMapSection3.method1148(var1);
                        Client.field2193 = var0;
                     } else if (var2 == 36) {
                        var8 = FaceNormal.method2884(ClientPacket.field1869, Client.field2133.isaacCipher);
                        var8.packetBuffer.method3948(var3);
                        var8.packetBuffer.writeInt(var1);
                        var8.packetBuffer.method3948(var0);
                        Client.field2133.method1281(var8);
                        Client.field2192 = 0;
                        class176.field1961 = WorldMapSection3.method1148(var1);
                        Client.field2193 = var0;
                     } else if (var2 == 37) {
                        var8 = FaceNormal.method2884(ClientPacket.field1894, Client.field2133.isaacCipher);
                        var8.packetBuffer.writeInt(var1);
                        var8.packetBuffer.writeShort(var0);
                        var8.packetBuffer.writeShort(var3);
                        Client.field2133.method1281(var8);
                        Client.field2192 = 0;
                        class176.field1961 = WorldMapSection3.method1148(var1);
                        Client.field2193 = var0;
                     } else {
                        if (var2 == 38) {
                           Occluder.method2991();
                           var16 = WorldMapSection3.method1148(var1);
                           Client.field2239 = 1;
                           WorldMapLabel.field1014 = var0;
                           ChatChannel.field598 = var1;
                           class57.field647 = var3;
                           WorldMapSection1.method506(var16);
                           Client.field2209 = ModelData0.method2792(16748608) + Varcs.getItemDefinition(var3).name + ModelData0.method2792(16777215);
                           if (Client.field2209 == null) {
                              Client.field2209 = "null";
                           }

                           return;
                        }

                        if (var2 == 39) {
                           var8 = FaceNormal.method2884(ClientPacket.field1883, Client.field2133.isaacCipher);
                           var8.packetBuffer.method3948(var3);
                           var8.packetBuffer.writeIntLE16(var1);
                           var8.packetBuffer.writeShortLE(var0);
                           Client.field2133.method1281(var8);
                           Client.field2192 = 0;
                           class176.field1961 = WorldMapSection3.method1148(var1);
                           Client.field2193 = var0;
                        } else if (var2 == 40) {
                           var8 = FaceNormal.method2884(ClientPacket.field1862, Client.field2133.isaacCipher);
                           var8.packetBuffer.writeIntLE16(var1);
                           var8.packetBuffer.writeShortLE(var0);
                           var8.packetBuffer.method4029(var3);
                           Client.field2133.method1281(var8);
                           Client.field2192 = 0;
                           class176.field1961 = WorldMapSection3.method1148(var1);
                           Client.field2193 = var0;
                        } else if (var2 == 41) {
                           var8 = FaceNormal.method2884(ClientPacket.field1897, Client.field2133.isaacCipher);
                           var8.packetBuffer.writeIntLE(var1);
                           var8.packetBuffer.method4029(var0);
                           var8.packetBuffer.writeShort(var3);
                           Client.field2133.method1281(var8);
                           Client.field2192 = 0;
                           class176.field1961 = WorldMapSection3.method1148(var1);
                           Client.field2193 = var0;
                        } else if (var2 == 42) {
                           var8 = FaceNormal.method2884(ClientPacket.field1900, Client.field2133.isaacCipher);
                           var8.packetBuffer.writeInt(var1);
                           var8.packetBuffer.method4029(var0);
                           var8.packetBuffer.writeShort(var3);
                           Client.field2133.method1281(var8);
                           Client.field2192 = 0;
                           class176.field1961 = WorldMapSection3.method1148(var1);
                           Client.field2193 = var0;
                        } else if (var2 == 43) {
                           var8 = FaceNormal.method2884(ClientPacket.field1868, Client.field2133.isaacCipher);
                           var8.packetBuffer.writeShort(var3);
                           var8.packetBuffer.writeIntME(var1);
                           var8.packetBuffer.writeShort(var0);
                           Client.field2133.method1281(var8);
                           Client.field2192 = 0;
                           class176.field1961 = WorldMapSection3.method1148(var1);
                           Client.field2193 = var0;
                        } else if (var2 == 44) {
                           var15 = Client.field2141[var3];
                           if (var15 != null) {
                              Client.field2187 = var6;
                              Client.field2188 = var7;
                              Client.field2202 = 2;
                              Client.field2252 = 0;
                              Client.field2165 = var0;
                              Client.field2318 = var1;
                              var9 = FaceNormal.method2884(ClientPacket.field1937, Client.field2133.isaacCipher);
                              var9.packetBuffer.writeShort(var3);
                              var9.packetBuffer.method3938(KeyHandler.field11[82] ? 1 : 0);
                              Client.field2133.method1281(var9);
                           }
                        } else if (var2 == 45) {
                           var15 = Client.field2141[var3];
                           if (var15 != null) {
                              Client.field2187 = var6;
                              Client.field2188 = var7;
                              Client.field2202 = 2;
                              Client.field2252 = 0;
                              Client.field2165 = var0;
                              Client.field2318 = var1;
                              var9 = FaceNormal.method2884(ClientPacket.field1892, Client.field2133.isaacCipher);
                              var9.packetBuffer.method3937(KeyHandler.field11[82] ? 1 : 0);
                              var9.packetBuffer.method4029(var3);
                              Client.field2133.method1281(var9);
                           }
                        } else if (var2 == 46) {
                           var15 = Client.field2141[var3];
                           if (var15 != null) {
                              Client.field2187 = var6;
                              Client.field2188 = var7;
                              Client.field2202 = 2;
                              Client.field2252 = 0;
                              Client.field2165 = var0;
                              Client.field2318 = var1;
                              var9 = FaceNormal.method2884(ClientPacket.field1877, Client.field2133.isaacCipher);
                              var9.packetBuffer.method4029(var3);
                              var9.packetBuffer.writeByte(KeyHandler.field11[82] ? 1 : 0);
                              Client.field2133.method1281(var9);
                           }
                        } else if (var2 == 47) {
                           var15 = Client.field2141[var3];
                           if (var15 != null) {
                              Client.field2187 = var6;
                              Client.field2188 = var7;
                              Client.field2202 = 2;
                              Client.field2252 = 0;
                              Client.field2165 = var0;
                              Client.field2318 = var1;
                              var9 = FaceNormal.method2884(ClientPacket.field1865, Client.field2133.isaacCipher);
                              var9.packetBuffer.method3948(var3);
                              var9.packetBuffer.method3938(KeyHandler.field11[82] ? 1 : 0);
                              Client.field2133.method1281(var9);
                           }
                        } else if (var2 == 48) {
                           var15 = Client.field2141[var3];
                           if (var15 != null) {
                              Client.field2187 = var6;
                              Client.field2188 = var7;
                              Client.field2202 = 2;
                              Client.field2252 = 0;
                              Client.field2165 = var0;
                              Client.field2318 = var1;
                              var9 = FaceNormal.method2884(ClientPacket.field1919, Client.field2133.isaacCipher);
                              var9.packetBuffer.method3937(KeyHandler.field11[82] ? 1 : 0);
                              var9.packetBuffer.method4029(var3);
                              Client.field2133.method1281(var9);
                           }
                        } else if (var2 == 49) {
                           var15 = Client.field2141[var3];
                           if (var15 != null) {
                              Client.field2187 = var6;
                              Client.field2188 = var7;
                              Client.field2202 = 2;
                              Client.field2252 = 0;
                              Client.field2165 = var0;
                              Client.field2318 = var1;
                              var9 = FaceNormal.method2884(ClientPacket.field1929, Client.field2133.isaacCipher);
                              var9.packetBuffer.method4029(var3);
                              var9.packetBuffer.method3939(KeyHandler.field11[82] ? 1 : 0);
                              Client.field2133.method1281(var9);
                           }
                        } else if (var2 == 50) {
                           var15 = Client.field2141[var3];
                           if (var15 != null) {
                              Client.field2187 = var6;
                              Client.field2188 = var7;
                              Client.field2202 = 2;
                              Client.field2252 = 0;
                              Client.field2165 = var0;
                              Client.field2318 = var1;
                              var9 = FaceNormal.method2884(ClientPacket.field1911, Client.field2133.isaacCipher);
                              var9.packetBuffer.method3939(KeyHandler.field11[82] ? 1 : 0);
                              var9.packetBuffer.writeShortLE(var3);
                              Client.field2133.method1281(var9);
                           }
                        } else if (var2 == 51) {
                           var15 = Client.field2141[var3];
                           if (var15 != null) {
                              Client.field2187 = var6;
                              Client.field2188 = var7;
                              Client.field2202 = 2;
                              Client.field2252 = 0;
                              Client.field2165 = var0;
                              Client.field2318 = var1;
                              var9 = FaceNormal.method2884(ClientPacket.field1890, Client.field2133.isaacCipher);
                              var9.packetBuffer.method3938(KeyHandler.field11[82] ? 1 : 0);
                              var9.packetBuffer.method3948(var3);
                              Client.field2133.method1281(var9);
                           }
                        } else {
                           label1001: {
                              if (var2 != 57) {
                                 if (var2 == 58) {
                                    var16 = class71.method1467(var1, var0);
                                    if (var16 != null) {
                                       var9 = FaceNormal.method2884(ClientPacket.field1918, Client.field2133.isaacCipher);
                                       var9.packetBuffer.writeShortLE(Client.field2242);
                                       var9.packetBuffer.writeIntLE16(var1);
                                       var9.packetBuffer.writeShortLE(Client.field2177);
                                       var9.packetBuffer.method3948(var0);
                                       var9.packetBuffer.writeInt(class299.field3748);
                                       var9.packetBuffer.method3948(var16.itemId);
                                       Client.field2133.method1281(var9);
                                    }
                                    break label1001;
                                 }

                                 if (var2 == 1001) {
                                    Client.field2187 = var6;
                                    Client.field2188 = var7;
                                    Client.field2202 = 2;
                                    Client.field2252 = 0;
                                    Client.field2165 = var0;
                                    Client.field2318 = var1;
                                    var8 = FaceNormal.method2884(ClientPacket.field1930, Client.field2133.isaacCipher);
                                    var8.packetBuffer.writeShort(var3);
                                    var8.packetBuffer.method3937(KeyHandler.field11[82] ? 1 : 0);
                                    var8.packetBuffer.method4029(var0 + class21.field230);
                                    var8.packetBuffer.method3948(class79.field902 + var1);
                                    Client.field2133.method1281(var8);
                                    break label1001;
                                 }

                                 if (var2 == 1002) {
                                    Client.field2187 = var6;
                                    Client.field2188 = var7;
                                    Client.field2202 = 2;
                                    Client.field2252 = 0;
                                    var8 = FaceNormal.method2884(ClientPacket.field1872, Client.field2133.isaacCipher);
                                    var8.packetBuffer.method4029(var3);
                                    Client.field2133.method1281(var8);
                                    break label1001;
                                 }

                                 if (var2 == 1003) {
                                    Client.field2187 = var6;
                                    Client.field2188 = var7;
                                    Client.field2202 = 2;
                                    Client.field2252 = 0;
                                    var13 = Client.field2249[var3];
                                    if (var13 != null) {
                                       NpcDefinition var17 = var13.definition;
                                       if (var17.transforms != null) {
                                          var17 = var17.transform();
                                       }

                                       if (var17 != null) {
                                          var10 = FaceNormal.method2884(ClientPacket.field1866, Client.field2133.isaacCipher);
                                          var10.packetBuffer.method4029(var17.id);
                                          Client.field2133.method1281(var10);
                                       }
                                    }
                                    break label1001;
                                 }

                                 if (var2 == 1004) {
                                    Client.field2187 = var6;
                                    Client.field2188 = var7;
                                    Client.field2202 = 2;
                                    Client.field2252 = 0;
                                    var8 = FaceNormal.method2884(ClientPacket.field1843, Client.field2133.isaacCipher);
                                    var8.packetBuffer.writeShortLE(var3);
                                    Client.field2133.method1281(var8);
                                    break label1001;
                                 }

                                 if (var2 == 1005) {
                                    var16 = WorldMapSection3.method1148(var1);
                                    if (var16 != null && var16.itemQuantities[var0] >= 100000) {
                                       Message.set(27, "", var16.itemQuantities[var0] + " x " + Varcs.getItemDefinition(var3).name);
                                    } else {
                                       var9 = FaceNormal.method2884(ClientPacket.field1843, Client.field2133.isaacCipher);
                                       var9.packetBuffer.writeShortLE(var3);
                                       Client.field2133.method1281(var9);
                                    }

                                    Client.field2192 = 0;
                                    class176.field1961 = WorldMapSection3.method1148(var1);
                                    Client.field2193 = var0;
                                    break label1001;
                                 }

                                 if (var2 != 1007) {
                                    if (var2 == 1008 || var2 == 1009 || var2 == 1011 || var2 == 1010 || var2 == 1012) {
                                       class12.field123.method6070(var2, var3, new TileLocation(var0), new TileLocation(var1));
                                    }
                                    break label1001;
                                 }
                              }

                              var16 = class71.method1467(var1, var0);
                              if (var16 != null) {
                                 class1.method67(var3, var1, var0, var16.itemId, var5);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      if (Client.field2239 != 0) {
         Client.field2239 = 0;
         WorldMapSection1.method506(WorldMapSection3.method1148(ChatChannel.field598));
      }

      if (Client.field2241) {
         Occluder.method2991();
      }

      if (class176.field1961 != null && Client.field2192 == 0) {
         WorldMapSection1.method506(class176.field1961);
      }

   }
}
