public class VarbitDefinition extends DualNode {
   static AbstractIndexCache field3504;
   public static EvictingDualNodeHashTable field3500 = new EvictingDualNodeHashTable(64);
   static IndexedSprite field3505;
   public int highBit;
   public int varp;
   public int lowBit;

   void read(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.readNext(var1, var2);
      }
   }

   void readNext(Buffer var1, int var2) {
      if (var2 == 1) {
         this.varp = var1.method3913();
         this.lowBit = var1.readUnsignedByte();
         this.highBit = var1.readUnsignedByte();
      }

   }
}
