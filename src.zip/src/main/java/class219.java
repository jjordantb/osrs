public class class219 {
   static int field2572;
   public static int field2568 = 0;
   static AbstractIndexCache field2570;
   static AbstractIndexCache field2574;
   static boolean field2573;
   static AbstractIndexCache field2569;
   static int[] field2571;

   public static void method4546(AbstractIndexCache var0, AbstractIndexCache var1, AbstractIndexCache var2, AbstractIndexCache var3) {
      Widget.field2678 = var0;
      Frames.field1632 = var1;
      Buddy.field3791 = var2;
      WorldMapIcon.field249 = var3;
      UserComparator3.field1708 = new Widget[Widget.field2678.method4977()][];
      class130.field1567 = new boolean[Widget.field2678.method4977()];
   }

   public static int method4567(int var0, int var1) {
      return (var0 << 8) + var1;
   }

   public static boolean method4549(CharSequence var0) {
      return ClanChat.method5784(var0, 10, true);
   }
}
