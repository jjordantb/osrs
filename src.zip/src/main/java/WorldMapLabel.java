public class WorldMapLabel {
   static boolean field1015;
   protected static String field1016;
   static int field1014;
   int height;
   String text;
   WorldMapLabelSize size;
   int width;

   WorldMapLabel(String var1, int var2, int var3, WorldMapLabelSize var4) {
      this.text = var1;
      this.width = var2;
      this.height = var3;
      this.size = var4;
   }

   public static String method1781(Buffer var0) {
      return Tile.method2778(var0, 32767);
   }

   static int method1782(PacketBuffer var0) {
      int var1 = var0.readBits(2);
      int var2;
      if (var1 == 0) {
         var2 = 0;
      } else if (var1 == 1) {
         var2 = var0.readBits(5);
      } else if (var1 == 2) {
         var2 = var0.readBits(8);
      } else {
         var2 = var0.readBits(11);
      }

      return var2;
   }

   public static int method1783(long var0) {
      return (int)(var0 >>> 0 & 127L);
   }
}
