import java.io.File;
import java.io.IOException;
import java.util.Comparator;

final class class99 implements Comparator {
   int method1836(GrandExchangeEvent var1, GrandExchangeEvent var2) {
      return var1.field754 < var2.field754 ? -1 : (var1.field754 == var2.field754 ? 0 : 1);
   }

   public boolean equals(Object var1) {
      return super.equals(var1);
   }

   public int compare(Object var1, Object var2) {
      return this.method1836((GrandExchangeEvent)var1, (GrandExchangeEvent)var2);
   }

   static int method1847(int var0, Script var1, boolean var2) {
      int var3;
      if (var0 == 6600) {
         var3 = class31.field363;
         int var9 = (ObjectSound.field589.x >> 7) + class21.field230;
         int var5 = (ObjectSound.field589.y >> 7) + class79.field902;
         method1840().method6025(var3, var9, var5, true);
         return 1;
      } else {
         WorldMapData var11;
         if (var0 == 6601) {
            var3 = Interpreter.field467[--class31.field364];
            String var16 = "";
            var11 = method1840().method6043(var3);
            if (var11 != null) {
               var16 = var11.method1510();
            }

            Interpreter.field462[++Interpreter.field469 - 1] = var16;
            return 1;
         } else if (var0 == 6602) {
            var3 = Interpreter.field467[--class31.field364];
            method1840().method6026(var3);
            return 1;
         } else if (var0 == 6603) {
            Interpreter.field467[++class31.field364 - 1] = method1840().method6085();
            return 1;
         } else if (var0 == 6604) {
            var3 = Interpreter.field467[--class31.field364];
            method1840().method6020(var3);
            return 1;
         } else if (var0 == 6605) {
            Interpreter.field467[++class31.field364 - 1] = method1840().isCacheLoaded() ? 1 : 0;
            return 1;
         } else {
            TileLocation var15;
            if (var0 == 6606) {
               var15 = new TileLocation(Interpreter.field467[--class31.field364]);
               method1840().method6182(var15.x, var15.y);
               return 1;
            } else if (var0 == 6607) {
               var15 = new TileLocation(Interpreter.field467[--class31.field364]);
               method1840().method6133(var15.x, var15.y);
               return 1;
            } else if (var0 == 6608) {
               var15 = new TileLocation(Interpreter.field467[--class31.field364]);
               method1840().method6046(var15.plane, var15.x, var15.y);
               return 1;
            } else if (var0 == 6609) {
               var15 = new TileLocation(Interpreter.field467[--class31.field364]);
               method1840().method6047(var15.plane, var15.x, var15.y);
               return 1;
            } else if (var0 == 6610) {
               Interpreter.field467[++class31.field364 - 1] = method1840().method6063();
               Interpreter.field467[++class31.field364 - 1] = method1840().method6049();
               return 1;
            } else {
               WorldMapData var13;
               if (var0 == 6611) {
                  var3 = Interpreter.field467[--class31.field364];
                  var13 = method1840().method6043(var3);
                  if (var13 == null) {
                     Interpreter.field467[++class31.field364 - 1] = 0;
                  } else {
                     Interpreter.field467[++class31.field364 - 1] = var13.method1509().method4751();
                  }

                  return 1;
               } else if (var0 == 6612) {
                  var3 = Interpreter.field467[--class31.field364];
                  var13 = method1840().method6043(var3);
                  if (var13 == null) {
                     Interpreter.field467[++class31.field364 - 1] = 0;
                     Interpreter.field467[++class31.field364 - 1] = 0;
                  } else {
                     Interpreter.field467[++class31.field364 - 1] = (var13.method1503() - var13.method1523() + 1) * 64;
                     Interpreter.field467[++class31.field364 - 1] = (var13.method1514() - var13.method1494() + 1) * 64;
                  }

                  return 1;
               } else if (var0 == 6613) {
                  var3 = Interpreter.field467[--class31.field364];
                  var13 = method1840().method6043(var3);
                  if (var13 == null) {
                     Interpreter.field467[++class31.field364 - 1] = 0;
                     Interpreter.field467[++class31.field364 - 1] = 0;
                     Interpreter.field467[++class31.field364 - 1] = 0;
                     Interpreter.field467[++class31.field364 - 1] = 0;
                  } else {
                     Interpreter.field467[++class31.field364 - 1] = var13.method1523() * 64;
                     Interpreter.field467[++class31.field364 - 1] = var13.method1494() * 64;
                     Interpreter.field467[++class31.field364 - 1] = var13.method1503() * 64 + 64 - 1;
                     Interpreter.field467[++class31.field364 - 1] = var13.method1514() * 64 + 64 - 1;
                  }

                  return 1;
               } else if (var0 == 6614) {
                  var3 = Interpreter.field467[--class31.field364];
                  var13 = method1840().method6043(var3);
                  if (var13 == null) {
                     Interpreter.field467[++class31.field364 - 1] = -1;
                  } else {
                     Interpreter.field467[++class31.field364 - 1] = var13.method1501();
                  }

                  return 1;
               } else if (var0 == 6615) {
                  var15 = method1840().method6050();
                  if (var15 == null) {
                     Interpreter.field467[++class31.field364 - 1] = -1;
                     Interpreter.field467[++class31.field364 - 1] = -1;
                  } else {
                     Interpreter.field467[++class31.field364 - 1] = var15.x;
                     Interpreter.field467[++class31.field364 - 1] = var15.y;
                  }

                  return 1;
               } else if (var0 == 6616) {
                  Interpreter.field467[++class31.field364 - 1] = method1840().method6032();
                  return 1;
               } else if (var0 == 6617) {
                  var15 = new TileLocation(Interpreter.field467[--class31.field364]);
                  var13 = method1840().method6028();
                  if (var13 == null) {
                     Interpreter.field467[++class31.field364 - 1] = -1;
                     Interpreter.field467[++class31.field364 - 1] = -1;
                     return 1;
                  } else {
                     int[] var14 = var13.method1493(var15.plane, var15.x, var15.y);
                     if (var14 == null) {
                        Interpreter.field467[++class31.field364 - 1] = -1;
                        Interpreter.field467[++class31.field364 - 1] = -1;
                     } else {
                        Interpreter.field467[++class31.field364 - 1] = var14[0];
                        Interpreter.field467[++class31.field364 - 1] = var14[1];
                     }

                     return 1;
                  }
               } else {
                  TileLocation var7;
                  if (var0 == 6618) {
                     var15 = new TileLocation(Interpreter.field467[--class31.field364]);
                     var13 = method1840().method6028();
                     if (var13 == null) {
                        Interpreter.field467[++class31.field364 - 1] = -1;
                        Interpreter.field467[++class31.field364 - 1] = -1;
                        return 1;
                     } else {
                        var7 = var13.method1522(var15.x, var15.y);
                        if (var7 == null) {
                           Interpreter.field467[++class31.field364 - 1] = -1;
                        } else {
                           Interpreter.field467[++class31.field364 - 1] = var7.method4751();
                        }

                        return 1;
                     }
                  } else {
                     TileLocation var12;
                     if (var0 == 6619) {
                        class31.field364 -= 2;
                        var3 = Interpreter.field467[class31.field364];
                        var12 = new TileLocation(Interpreter.field467[class31.field364 + 1]);
                        class34.method795(var3, var12, false);
                        return 1;
                     } else if (var0 == 6620) {
                        class31.field364 -= 2;
                        var3 = Interpreter.field467[class31.field364];
                        var12 = new TileLocation(Interpreter.field467[class31.field364 + 1]);
                        class34.method795(var3, var12, true);
                        return 1;
                     } else if (var0 == 6621) {
                        class31.field364 -= 2;
                        var3 = Interpreter.field467[class31.field364];
                        var12 = new TileLocation(Interpreter.field467[class31.field364 + 1]);
                        var11 = method1840().method6043(var3);
                        if (var11 == null) {
                           Interpreter.field467[++class31.field364 - 1] = 0;
                           return 1;
                        } else {
                           Interpreter.field467[++class31.field364 - 1] = var11.method1491(var12.plane, var12.x, var12.y) ? 1 : 0;
                           return 1;
                        }
                     } else if (var0 == 6622) {
                        Interpreter.field467[++class31.field364 - 1] = method1840().method6051();
                        Interpreter.field467[++class31.field364 - 1] = method1840().method6052();
                        return 1;
                     } else if (var0 == 6623) {
                        var15 = new TileLocation(Interpreter.field467[--class31.field364]);
                        var13 = method1840().method6024(var15.plane, var15.x, var15.y);
                        if (var13 == null) {
                           Interpreter.field467[++class31.field364 - 1] = -1;
                        } else {
                           Interpreter.field467[++class31.field364 - 1] = var13.method1496();
                        }

                        return 1;
                     } else if (var0 == 6624) {
                        method1840().method6053(Interpreter.field467[--class31.field364]);
                        return 1;
                     } else if (var0 == 6625) {
                        method1840().method6054();
                        return 1;
                     } else if (var0 == 6626) {
                        method1840().method6055(Interpreter.field467[--class31.field364]);
                        return 1;
                     } else if (var0 == 6627) {
                        method1840().method6056();
                        return 1;
                     } else {
                        boolean var10;
                        if (var0 == 6628) {
                           var10 = Interpreter.field467[--class31.field364] == 1;
                           method1840().method6110(var10);
                           return 1;
                        } else if (var0 == 6629) {
                           var3 = Interpreter.field467[--class31.field364];
                           method1840().method6071(var3);
                           return 1;
                        } else if (var0 == 6630) {
                           var3 = Interpreter.field467[--class31.field364];
                           method1840().method6059(var3);
                           return 1;
                        } else if (var0 == 6631) {
                           method1840().method6060();
                           return 1;
                        } else if (var0 == 6632) {
                           var10 = Interpreter.field467[--class31.field364] == 1;
                           method1840().method6188(var10);
                           return 1;
                        } else {
                           boolean var4;
                           if (var0 == 6633) {
                              class31.field364 -= 2;
                              var3 = Interpreter.field467[class31.field364];
                              var4 = Interpreter.field467[class31.field364 + 1] == 1;
                              method1840().method6019(var3, var4);
                              return 1;
                           } else if (var0 == 6634) {
                              class31.field364 -= 2;
                              var3 = Interpreter.field467[class31.field364];
                              var4 = Interpreter.field467[class31.field364 + 1] == 1;
                              method1840().method6016(var3, var4);
                              return 1;
                           } else if (var0 == 6635) {
                              Interpreter.field467[++class31.field364 - 1] = method1840().method6064() ? 1 : 0;
                              return 1;
                           } else if (var0 == 6636) {
                              var3 = Interpreter.field467[--class31.field364];
                              Interpreter.field467[++class31.field364 - 1] = method1840().method6066(var3) ? 1 : 0;
                              return 1;
                           } else if (var0 == 6637) {
                              var3 = Interpreter.field467[--class31.field364];
                              Interpreter.field467[++class31.field364 - 1] = method1840().method6068(var3) ? 1 : 0;
                              return 1;
                           } else if (var0 == 6638) {
                              class31.field364 -= 2;
                              var3 = Interpreter.field467[class31.field364];
                              var12 = new TileLocation(Interpreter.field467[class31.field364 + 1]);
                              var7 = method1840().method6069(var3, var12);
                              if (var7 == null) {
                                 Interpreter.field467[++class31.field364 - 1] = -1;
                              } else {
                                 Interpreter.field467[++class31.field364 - 1] = var7.method4751();
                              }

                              return 1;
                           } else {
                              WorldMapIcon var8;
                              if (var0 == 6639) {
                                 var8 = method1840().method6202();
                                 if (var8 == null) {
                                    Interpreter.field467[++class31.field364 - 1] = -1;
                                    Interpreter.field467[++class31.field364 - 1] = -1;
                                 } else {
                                    Interpreter.field467[++class31.field364 - 1] = var8.field252;
                                    Interpreter.field467[++class31.field364 - 1] = var8.field244.method4751();
                                 }

                                 return 1;
                              } else if (var0 == 6640) {
                                 var8 = method1840().method6072();
                                 if (var8 == null) {
                                    Interpreter.field467[++class31.field364 - 1] = -1;
                                    Interpreter.field467[++class31.field364 - 1] = -1;
                                 } else {
                                    Interpreter.field467[++class31.field364 - 1] = var8.field252;
                                    Interpreter.field467[++class31.field364 - 1] = var8.field244.method4751();
                                 }

                                 return 1;
                              } else {
                                 AreaDefinition var6;
                                 if (var0 == 6693) {
                                    var3 = Interpreter.field467[--class31.field364];
                                    var6 = Clock.mark(var3);
                                    if (var6.field2886 == null) {
                                       Interpreter.field462[++Interpreter.field469 - 1] = "";
                                    } else {
                                       Interpreter.field462[++Interpreter.field469 - 1] = var6.field2886;
                                    }

                                    return 1;
                                 } else if (var0 == 6694) {
                                    var3 = Interpreter.field467[--class31.field364];
                                    var6 = Clock.mark(var3);
                                    Interpreter.field467[++class31.field364 - 1] = var6.field2888;
                                    return 1;
                                 } else if (var0 == 6695) {
                                    var3 = Interpreter.field467[--class31.field364];
                                    var6 = Clock.mark(var3);
                                    if (var6 == null) {
                                       Interpreter.field467[++class31.field364 - 1] = -1;
                                    } else {
                                       Interpreter.field467[++class31.field364 - 1] = var6.field2887;
                                    }

                                    return 1;
                                 } else if (var0 == 6696) {
                                    var3 = Interpreter.field467[--class31.field364];
                                    var6 = Clock.mark(var3);
                                    if (var6 == null) {
                                       Interpreter.field467[++class31.field364 - 1] = -1;
                                    } else {
                                       Interpreter.field467[++class31.field364 - 1] = var6.field2885;
                                    }

                                    return 1;
                                 } else if (var0 == 6697) {
                                    Interpreter.field467[++class31.field364 - 1] = MilliClock.field1663.field176;
                                    return 1;
                                 } else if (var0 == 6698) {
                                    Interpreter.field467[++class31.field364 - 1] = MilliClock.field1663.field177.method4751();
                                    return 1;
                                 } else if (var0 == 6699) {
                                    Interpreter.field467[++class31.field364 - 1] = MilliClock.field1663.field178.method4751();
                                    return 1;
                                 } else {
                                    return 2;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public static AccessFile method1837(String var0, String var1, boolean var2) {
      File var3 = new File(ScriptFrame.field171, "preferences" + var0 + ".dat");
      if (var3.exists()) {
         try {
            AccessFile var10 = new AccessFile(var3, "rw", 10000L);
            return var10;
         } catch (IOException var9) {
            ;
         }
      }

      String var4 = "";
      if (class178.field1980 == 33) {
         var4 = "_rc";
      } else if (class178.field1980 == 34) {
         var4 = "_wip";
      }

      File var5 = new File(class103.homeDirectory, "jagex_" + var1 + "_preferences" + var0 + var4 + ".dat");
      AccessFile var6;
      if (!var2 && var5.exists()) {
         try {
            var6 = new AccessFile(var5, "rw", 10000L);
            return var6;
         } catch (IOException var8) {
            ;
         }
      }

      try {
         var6 = new AccessFile(var3, "rw", 10000L);
         return var6;
      } catch (IOException var7) {
         throw new RuntimeException();
      }
   }

   static void method1841() {
      if (class79.method1622()) {
         Login.field682 = true;
      }

   }

   static WorldMap method1840() {
      return class12.field123;
   }
}
