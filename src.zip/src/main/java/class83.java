public class class83 {
   static int[] field940;
   static final class83 field945 = new class83(0);
   public static int field943;
   static final class83 field939 = new class83(1);
   final int field941;

   class83(int var1) {
      this.field941 = var1;
   }

   static void method1702(int var0) {
      if (var0 != -1) {
         if (class196.method4189(var0)) {
            Widget[] var1 = UserComparator3.field1708[var0];

            for(int var2 = 0; var2 < var1.length; ++var2) {
               Widget var3 = var1[var2];
               if (var3.onLoad != null) {
                  ScriptEvent var4 = new ScriptEvent();
                  var4.widget = var3;
                  var4.args = var3.onLoad;
                  Client.method3739(var4, 5000000);
               }
            }

         }
      }
   }

   public static ParamKeyDefinition method1701(int var0) {
      ParamKeyDefinition var1 = (ParamKeyDefinition)ParamKeyDefinition.field3443.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = class57.field645.takeRecord(11, var0);
         var1 = new ParamKeyDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         var1.init();
         ParamKeyDefinition.field3443.put(var1, (long)var0);
         return var1;
      }
   }

   public static String method1699(CharSequence[] var0, int var1, int var2) {
      if (var2 == 0) {
         return "";
      } else if (var2 == 1) {
         CharSequence var3 = var0[var1];
         return var3 == null ? "null" : var3.toString();
      } else {
         int var8 = var2 + var1;
         int var4 = 0;

         for(int var5 = var1; var5 < var8; ++var5) {
            CharSequence var6 = var0[var5];
            if (var6 == null) {
               var4 += 4;
            } else {
               var4 += var6.length();
            }
         }

         StringBuilder var9 = new StringBuilder(var4);

         for(int var10 = var1; var10 < var8; ++var10) {
            CharSequence var7 = var0[var10];
            if (var7 == null) {
               var9.append("null");
            } else {
               var9.append(var7);
            }
         }

         return var9.toString();
      }
   }

   public static void method1700(int var0, AbstractIndexCache var1, int var2, int var3, int var4, boolean var5) {
      class219.field2568 = 1;
      UrlRequester.field1584 = var1;
      class219.field2572 = var2;
      IndexStore.field1832 = var3;
      class321.field3913 = var4;
      class219.field2573 = var5;
      WorldComparator.field810 = var0;
   }

   static final void method1698() {
      for(class37 var0 = (class37) Client.field2131.last(); var0 != null; var0 = (class37) Client.field2131.previous()) {
         if (var0.field457 > 0) {
            --var0.field457;
         }

         if (var0.field457 == 0) {
            if (var0.field447 < 0 || GroundItemPile.method2667(var0.field447, var0.field448)) {
               ObjectSound.method1083(var0.field458, var0.field450, var0.field446, var0.field449, var0.field447, var0.field459, var0.field448);
               var0.remove();
            }
         } else {
            if (var0.field456 > 0) {
               --var0.field456;
            }

            if (var0.field456 == 0 && var0.field446 >= 1 && var0.field449 >= 1 && var0.field446 <= 102 && var0.field449 <= 102 && (var0.field453 < 0 || GroundItemPile.method2667(var0.field453, var0.field455))) {
               ObjectSound.method1083(var0.field458, var0.field450, var0.field446, var0.field449, var0.field453, var0.field454, var0.field455);
               var0.field456 = -1;
               if (var0.field447 == var0.field453 && var0.field447 == -1) {
                  var0.remove();
               } else if (var0.field453 == var0.field447 && var0.field454 == var0.field459 && var0.field455 == var0.field448) {
                  var0.remove();
               }
            }
         }
      }

   }
}
