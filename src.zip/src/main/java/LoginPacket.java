public class LoginPacket implements ClientPacketMarker {
   static final LoginPacket[] field1952 = new LoginPacket[32];
   static final LoginPacket field1958 = new LoginPacket(27, 0);
   public static final LoginPacket field1954 = new LoginPacket(16, -2);
   public static final LoginPacket field1956 = new LoginPacket(14, 0);
   public static final LoginPacket field1955 = new LoginPacket(18, -2);
   static final LoginPacket field1953 = new LoginPacket(15, 4);
   public final int id;

   static {
      LoginPacket[] var0 = class57.method1216();

      for(int var1 = 0; var1 < var0.length; ++var1) {
         field1952[var0[var1].id] = var0[var1];
      }

   }

   LoginPacket(int var1, int var2) {
      this.id = var1;
   }

   public static boolean method3275(int var0) {
      return (var0 >> 30 & 1) != 0;
   }

   static ServerBuild[] method3271() {
      return new ServerBuild[]{ServerBuild.field2934, ServerBuild.field2939, ServerBuild.field2935, ServerBuild.field2941};
   }

   public static int method3276(CharSequence var0) {
      return BufferedNetSocket.read(var0, 10, true);
   }

   static final void method3277(String var0) {
      class6.method183(var0 + " is already on your ignore list");
   }
}
