public class class1 {
   int field30;
   byte[][][] field28;

   class1(int var1) {
      this.field30 = var1;
   }

   void method44() {
      byte[] var1 = new byte[this.field30 * this.field30];
      int var2 = 0;

      int var3;
      int var4;
      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 <= var3) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[0][0] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 <= var3) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[0][1] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 >= var3) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[0][2] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 >= var3) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[0][3] = var1;
   }

   void method36() {
      byte[] var1 = new byte[this.field30 * this.field30];
      int var2 = 0;

      int var3;
      int var4;
      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 >= var3 >> 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[4][0] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 <= var3 << 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[4][1] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 >= var3 >> 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[4][2] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 <= var3 << 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[4][3] = var1;
   }

   int method54(int var1) {
      if (var1 != 9 && var1 != 10) {
         return var1 == 11 ? 8 : var1;
      } else {
         return 1;
      }
   }

   void method69(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      if (var7 != 0 && this.field30 != 0 && this.field28 != null) {
         var8 = this.method30(var8, var7);
         var7 = this.method54(var7);
         Rasterizer2D.method6225(var1, var2, var5, var6, var3, var4, this.field28[var7 - 1][var8], this.field30);
      }
   }

   void method28() {
      byte[] var1 = new byte[this.field30 * this.field30];
      int var2 = 0;

      int var3;
      int var4;
      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 <= var3 >> 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[1][0] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var2 >= 0 && var2 < var1.length) {
               if (var4 >= var3 << 1) {
                  var1[var2] = -1;
               }

               ++var2;
            } else {
               ++var2;
            }
         }
      }

      this.field28[1][1] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 <= var3 >> 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[1][2] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 >= var3 << 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[1][3] = var1;
   }

   void method41() {
      byte[] var1 = new byte[this.field30 * this.field30];
      boolean var2 = false;
      var1 = new byte[this.field30 * this.field30];
      int var5 = 0;

      int var3;
      int var4;
      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 <= this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[5][0] = var1;
      var1 = new byte[this.field30 * this.field30];
      var5 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var3 <= this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[5][1] = var1;
      var1 = new byte[this.field30 * this.field30];
      var5 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 >= this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[5][2] = var1;
      var1 = new byte[this.field30 * this.field30];
      var5 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var3 >= this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[5][3] = var1;
   }

   void method35() {
      byte[] var1 = new byte[this.field30 * this.field30];
      int var2 = 0;

      int var3;
      int var4;
      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 >= var3 >> 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[3][0] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 <= var3 << 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[3][1] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 >= var3 >> 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[3][2] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 <= var3 << 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[3][3] = var1;
   }

   void method53() {
      byte[] var1 = new byte[this.field30 * this.field30];
      int var2 = 0;

      int var3;
      int var4;
      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 <= var3 >> 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[2][0] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 >= var3 << 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[2][1] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 <= var3 >> 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[2][2] = var1;
      var1 = new byte[this.field30 * this.field30];
      var2 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 >= var3 << 1) {
               var1[var2] = -1;
            }

            ++var2;
         }
      }

      this.field28[2][3] = var1;
   }

   void method31() {
      if (this.field28 == null) {
         this.field28 = new byte[8][4][];
         this.method44();
         this.method28();
         this.method53();
         this.method35();
         this.method36();
         this.method41();
         this.method68();
         this.method39();
      }
   }

   int method30(int var1, int var2) {
      if (var2 == 9) {
         var1 = var1 + 1 & 3;
      }

      if (var2 == 10) {
         var1 = var1 + 3 & 3;
      }

      if (var2 == 11) {
         var1 = var1 + 3 & 3;
      }

      return var1;
   }

   void method39() {
      byte[] var1 = new byte[this.field30 * this.field30];
      boolean var2 = false;
      var1 = new byte[this.field30 * this.field30];
      int var5 = 0;

      int var3;
      int var4;
      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 >= var3 - this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[7][0] = var1;
      var1 = new byte[this.field30 * this.field30];
      var5 = 0;

      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 >= var3 - this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[7][1] = var1;
      var1 = new byte[this.field30 * this.field30];
      var5 = 0;

      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 >= var3 - this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[7][2] = var1;
      var1 = new byte[this.field30 * this.field30];
      var5 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 >= var3 - this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[7][3] = var1;
   }

   void method68() {
      byte[] var1 = new byte[this.field30 * this.field30];
      boolean var2 = false;
      var1 = new byte[this.field30 * this.field30];
      int var5 = 0;

      int var3;
      int var4;
      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 <= var3 - this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[6][0] = var1;
      var1 = new byte[this.field30 * this.field30];
      var5 = 0;

      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = 0; var4 < this.field30; ++var4) {
            if (var4 <= var3 - this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[6][1] = var1;
      var1 = new byte[this.field30 * this.field30];
      var5 = 0;

      for(var3 = this.field30 - 1; var3 >= 0; --var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 <= var3 - this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[6][2] = var1;
      var1 = new byte[this.field30 * this.field30];
      var5 = 0;

      for(var3 = 0; var3 < this.field30; ++var3) {
         for(var4 = this.field30 - 1; var4 >= 0; --var4) {
            if (var4 <= var3 - this.field30 / 2) {
               var1[var5] = -1;
            }

            ++var5;
         }
      }

      this.field28[6][3] = var1;
   }

   public static int method33(int var0) {
      long var2 = ViewportMouse.field1509[var0];
      int var1 = (int)(var2 >>> 14 & 3L);
      return var1;
   }

   static void method67(int var0, int var1, int var2, int var3, String var4) {
      Widget var5 = class71.method1467(var1, var2);
      if (var5 != null) {
         if (var5.onOp != null) {
            ScriptEvent var6 = new ScriptEvent();
            var6.widget = var5;
            var6.opIndex = var0;
            var6.targetName = var4;
            var6.args = var5.onOp;
            IndexCacheLoader.method1096(var6);
         }

         boolean var11 = true;
         if (var5.contentType > 0) {
            var11 = WorldMapSection0.method1854(var5);
         }

         if (var11) {
            int var8 = class257.method5068(var5);
            int var9 = var0 - 1;
            boolean var7 = (var8 >> var9 + 1 & 1) != 0;
            if (var7) {
               PacketBufferNode var10;
               if (var0 == 1) {
                  var10 = FaceNormal.method2884(ClientPacket.field1904, Client.field2133.isaacCipher);
                  var10.packetBuffer.writeInt(var1);
                  var10.packetBuffer.writeShort(var2);
                  var10.packetBuffer.writeShort(var3);
                  Client.field2133.method1281(var10);
               }

               if (var0 == 2) {
                  var10 = FaceNormal.method2884(ClientPacket.field1857, Client.field2133.isaacCipher);
                  var10.packetBuffer.writeInt(var1);
                  var10.packetBuffer.writeShort(var2);
                  var10.packetBuffer.writeShort(var3);
                  Client.field2133.method1281(var10);
               }

               if (var0 == 3) {
                  var10 = FaceNormal.method2884(ClientPacket.field1884, Client.field2133.isaacCipher);
                  var10.packetBuffer.writeInt(var1);
                  var10.packetBuffer.writeShort(var2);
                  var10.packetBuffer.writeShort(var3);
                  Client.field2133.method1281(var10);
               }

               if (var0 == 4) {
                  var10 = FaceNormal.method2884(ClientPacket.field1855, Client.field2133.isaacCipher);
                  var10.packetBuffer.writeInt(var1);
                  var10.packetBuffer.writeShort(var2);
                  var10.packetBuffer.writeShort(var3);
                  Client.field2133.method1281(var10);
               }

               if (var0 == 5) {
                  var10 = FaceNormal.method2884(ClientPacket.field1876, Client.field2133.isaacCipher);
                  var10.packetBuffer.writeInt(var1);
                  var10.packetBuffer.writeShort(var2);
                  var10.packetBuffer.writeShort(var3);
                  Client.field2133.method1281(var10);
               }

               if (var0 == 6) {
                  var10 = FaceNormal.method2884(ClientPacket.field1902, Client.field2133.isaacCipher);
                  var10.packetBuffer.writeInt(var1);
                  var10.packetBuffer.writeShort(var2);
                  var10.packetBuffer.writeShort(var3);
                  Client.field2133.method1281(var10);
               }

               if (var0 == 7) {
                  var10 = FaceNormal.method2884(ClientPacket.field1921, Client.field2133.isaacCipher);
                  var10.packetBuffer.writeInt(var1);
                  var10.packetBuffer.writeShort(var2);
                  var10.packetBuffer.writeShort(var3);
                  Client.field2133.method1281(var10);
               }

               if (var0 == 8) {
                  var10 = FaceNormal.method2884(ClientPacket.field1850, Client.field2133.isaacCipher);
                  var10.packetBuffer.writeInt(var1);
                  var10.packetBuffer.writeShort(var2);
                  var10.packetBuffer.writeShort(var3);
                  Client.field2133.method1281(var10);
               }

               if (var0 == 9) {
                  var10 = FaceNormal.method2884(ClientPacket.field1924, Client.field2133.isaacCipher);
                  var10.packetBuffer.writeInt(var1);
                  var10.packetBuffer.writeShort(var2);
                  var10.packetBuffer.writeShort(var3);
                  Client.field2133.method1281(var10);
               }

               if (var0 == 10) {
                  var10 = FaceNormal.method2884(ClientPacket.field1875, Client.field2133.isaacCipher);
                  var10.packetBuffer.writeInt(var1);
                  var10.packetBuffer.writeShort(var2);
                  var10.packetBuffer.writeShort(var3);
                  Client.field2133.method1281(var10);
               }

            }
         }
      }
   }
}
