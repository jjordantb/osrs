public final class class243 {
   static Scene field2904;

   static class276[] method4894() {
      return new class276[]{class276.field3531, class276.field3527, class276.field3528};
   }
}
