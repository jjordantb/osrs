public class class302 {
   static final class302 field3764 = new class302(3);
   final int field3763;

   class302(int var1) {
      this.field3763 = var1;
   }
}
