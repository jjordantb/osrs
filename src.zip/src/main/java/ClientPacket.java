public class ClientPacket implements ClientPacketMarker {
   public static final ClientPacket field1898 = new ClientPacket(39, 4);
   public static final ClientPacket field1871 = new ClientPacket(35, 5);
   public static final ClientPacket field1891 = new ClientPacket(31, 3);
   public static final ClientPacket field1932 = new ClientPacket(41, 6);
   public static final ClientPacket field1866 = new ClientPacket(30, 2);
   public static final ClientPacket field1862 = new ClientPacket(26, 8);
   public static final ClientPacket field1901 = new ClientPacket(34, -1);
   public static final ClientPacket field1937 = new ClientPacket(47, 3);
   public static final ClientPacket field1876 = new ClientPacket(40, 8);
   public static final ClientPacket field1906 = new ClientPacket(33, 3);
   static final ClientPacket field1879 = new ClientPacket(43, -1);
   public static final ClientPacket field1878 = new ClientPacket(42, 2);
   public static final ClientPacket field1858 = new ClientPacket(45, 4);
   public static final ClientPacket field1865 = new ClientPacket(27, 3);
   public static final ClientPacket field1881 = new ClientPacket(44, 15);
   public static final ClientPacket field1884 = new ClientPacket(48, 8);
   public static final ClientPacket field1887 = new ClientPacket(51, 7);
   public static final ClientPacket field1872 = new ClientPacket(36, 2);
   public static final ClientPacket field1874 = new ClientPacket(38, -1);
   public static final ClientPacket field1914 = new ClientPacket(37, 0);
   public static final ClientPacket field1890 = new ClientPacket(50, 3);
   public static final ClientPacket field1885 = new ClientPacket(49, 0);
   public static final ClientPacket field1922 = new ClientPacket(29, 7);
   public static final ClientPacket field1864 = new ClientPacket(28, -1);
   public static final ClientPacket field1883 = new ClientPacket(46, 8);
   public static final ClientPacket field1868 = new ClientPacket(32, 8);
   public static final ClientPacket field1860 = new ClientPacket(54, -1);
   public static final ClientPacket field1877 = new ClientPacket(62, 3);
   public static final ClientPacket field1900 = new ClientPacket(64, 8);
   public static final ClientPacket field1925 = new ClientPacket(72, 8);
   public static final ClientPacket field1902 = new ClientPacket(66, 8);
   public static final ClientPacket field1896 = new ClientPacket(60, -1);
   public static final ClientPacket field1897 = new ClientPacket(65, 8);
   public static final ClientPacket field1904 = new ClientPacket(68, 8);
   public static final ClientPacket field1873 = new ClientPacket(55, 9);
   public static final ClientPacket field1903 = new ClientPacket(67, -2);
   public static final ClientPacket field1840 = new ClientPacket(61, 9);
   public static final ClientPacket field1899 = new ClientPacket(63, 16);
   public static final ClientPacket field1836 = new ClientPacket(70, 6);
   public static final ClientPacket field1910 = new ClientPacket(74, 7);
   public static final ClientPacket field1870 = new ClientPacket(73, 1);
   public static final ClientPacket field1892 = new ClientPacket(56, 3);
   public static final ClientPacket field1894 = new ClientPacket(58, 8);
   public static final ClientPacket field1912 = new ClientPacket(76, 0);
   public static final ClientPacket field1867 = new ClientPacket(52, -1);
   public static final ClientPacket field1913 = new ClientPacket(77, -1);
   public static final ClientPacket field1911 = new ClientPacket(75, 3);
   public static final ClientPacket field1893 = new ClientPacket(57, 16);
   public static final ClientPacket field1895 = new ClientPacket(59, 3);
   public static final ClientPacket field1841 = new ClientPacket(71, 3);
   public static final ClientPacket field1905 = new ClientPacket(69, 4);
   public static final ClientPacket field1880 = new ClientPacket(53, 13);
   public static final ClientPacket field1907 = new ClientPacket(88, -1);
   public static final ClientPacket field1920 = new ClientPacket(78, -1);
   public static final ClientPacket field1921 = new ClientPacket(85, 8);
   public static final ClientPacket field1854 = new ClientPacket(18, 15);
   public static final ClientPacket field1924 = new ClientPacket(84, 8);
   public static final ClientPacket field1908 = new ClientPacket(6, 7);
   public static final ClientPacket field1915 = new ClientPacket(79, 7);
   public static final ClientPacket field1886 = new ClientPacket(4, -1);
   public static final ClientPacket field1888 = new ClientPacket(89, 7);
   public static final ClientPacket field1848 = new ClientPacket(12, 13);
   public static final ClientPacket field1916 = new ClientPacket(80, 9);
   public static final ClientPacket field1838 = new ClientPacket(2, 14);
   public static final ClientPacket field1930 = new ClientPacket(94, 7);
   public static final ClientPacket field1889 = new ClientPacket(17, 4);
   public static final ClientPacket field1875 = new ClientPacket(0, 8);
   public static final ClientPacket field1934 = new ClientPacket(98, 8);
   public static final ClientPacket field1852 = new ClientPacket(16, -2);
   public static final ClientPacket field1928 = new ClientPacket(92, 13);
   public static final ClientPacket field1863 = new ClientPacket(9, 4);
   public static final ClientPacket field1918 = new ClientPacket(82, 16);
   public static final ClientPacket field1849 = new ClientPacket(13, -1);
   public static final ClientPacket field1917 = new ClientPacket(81, 11);
   public static final ClientPacket field1856 = new ClientPacket(20, 0);
   public static final ClientPacket field1926 = new ClientPacket(90, -1);
   public static final ClientPacket field1845 = new ClientPacket(5, 7);
   public static final ClientPacket field1927 = new ClientPacket(91, -1);
   public static final ClientPacket field1847 = new ClientPacket(11, 10);
   public static final ClientPacket field1929 = new ClientPacket(93, 3);
   public static final ClientPacket field1844 = new ClientPacket(8, -1);
   public static final ClientPacket field1859 = new ClientPacket(97, -1);
   public static final ClientPacket field1861 = new ClientPacket(25, -2);
   public static final ClientPacket field1919 = new ClientPacket(83, 3);
   public static final ClientPacket field1933 = new ClientPacket(10, 7);
   public static final ClientPacket field1851 = new ClientPacket(96, -1);
   public static final ClientPacket field1839 = new ClientPacket(3, 7);
   public static final ClientPacket field1931 = new ClientPacket(95, -1);
   public static final ClientPacket field1837 = new ClientPacket(1, 3);
   static final ClientPacket field1935 = new ClientPacket(99, 7);
   public static final ClientPacket field1853 = new ClientPacket(22, 0);
   public static final ClientPacket field1855 = new ClientPacket(19, 8);
   public static final ClientPacket field1843 = new ClientPacket(24, 2);
   public static final ClientPacket field1842 = new ClientPacket(86, 9);
   public static final ClientPacket field1882 = new ClientPacket(15, 3);
   public static final ClientPacket field1923 = new ClientPacket(87, 8);
   public static final ClientPacket field1869 = new ClientPacket(7, 8);
   public static final ClientPacket field1850 = new ClientPacket(14, 8);
   public static final ClientPacket field1846 = new ClientPacket(23, 11);
   public static final ClientPacket field1857 = new ClientPacket(21, 8);
   final int id;
   final int length;

   ClientPacket(int var1, int var2) {
      this.id = var1;
      this.length = var2;
   }

   public static KitDefinition method3233(int var0) {
      KitDefinition var1 = (KitDefinition)KitDefinition.field3345.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = KitDefinition.field3354.takeRecord(3, var0);
         var1 = new KitDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         KitDefinition.field3345.put(var1, (long)var0);
         return var1;
      }
   }

   static PacketBufferNode method3232() {
      return PacketBufferNode.field1807 == 0 ? new PacketBufferNode() : PacketBufferNode.field1806[--PacketBufferNode.field1807];
   }

   static final void method3231() {
      Scene.field1172 = false;
      Client.field2091 = false;
   }

   static final void method3234(int var0, int var1, int var2, int var3, int var4, int var5) {
      int var6 = var2 - var0;
      int var7 = var3 - var1;
      int var8 = var6 >= 0 ? var6 : -var6;
      int var9 = var7 >= 0 ? var7 : -var7;
      int var10 = var8;
      if (var8 < var9) {
         var10 = var9;
      }

      if (var10 != 0) {
         int var11 = (var6 << 16) / var10;
         int var12 = (var7 << 16) / var10;
         if (var12 <= var11) {
            var11 = -var11;
         } else {
            var12 = -var12;
         }

         int var13 = var5 * var12 >> 17;
         int var14 = var5 * var12 + 1 >> 17;
         int var15 = var5 * var11 >> 17;
         int var16 = var5 * var11 + 1 >> 17;
         var0 -= Rasterizer2D.field3897;
         var1 -= Rasterizer2D.field3902;
         int var17 = var0 + var13;
         int var18 = var0 - var14;
         int var19 = var0 + var6 - var14;
         int var20 = var0 + var13 + var6;
         int var21 = var15 + var1;
         int var22 = var1 - var16;
         int var23 = var7 + var1 - var16;
         int var24 = var7 + var15 + var1;
         Rasterizer3D.method2599(var17, var18, var19);
         Rasterizer3D.method2602(var21, var22, var23, var17, var18, var19, var4);
         Rasterizer3D.method2599(var17, var19, var20);
         Rasterizer3D.method2602(var21, var23, var24, var17, var19, var20, var4);
      }
   }
}
