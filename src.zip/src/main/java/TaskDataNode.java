public abstract class TaskDataNode extends Node {
   AbstractIntNode field1557;
   int field1558;
   TaskDataNode field1559;
   volatile boolean field1560 = true;

   int vmethod2806() {
      return 255;
   }

   protected abstract void vmethod4652(int[] var1, int var2, int var3);

   protected abstract TaskDataNode vmethod4628();

   protected abstract int vmethod4641();

   protected abstract TaskDataNode vmethod4630();

   protected abstract void vmethod4633(int var1);

   final void method2799(int[] var1, int var2, int var3) {
      if (this.field1560) {
         this.vmethod4652(var1, var2, var3);
      } else {
         this.vmethod4633(var3);
      }

   }
}
