public class Settings {

    public static final String CACHE_DIR = "fastcache";
    public static final String CACHE_SUB_DIR = "FastScape";

}
