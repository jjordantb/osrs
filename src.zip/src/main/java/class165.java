public class class165 {
   static int field1790;

   public static void method3138() {
      WorldMapRegion.field1112.demote(5);
      WorldMapRegion.field1109.demote(5);
   }

   static final void method3135(int var0, int var1, int var2, int var3) {
      for(int var4 = var1; var4 <= var3 + var1; ++var4) {
         for(int var5 = var0; var5 <= var0 + var2; ++var5) {
            if (var5 >= 0 && var5 < 104 && var4 >= 0 && var4 < 104) {
               Tiles.field214[0][var5][var4] = 127;
               if (var0 == var5 && var5 > 0) {
                  Tiles.field217[0][var5][var4] = Tiles.field217[0][var5 - 1][var4];
               }

               if (var5 == var0 + var2 && var5 < 103) {
                  Tiles.field217[0][var5][var4] = Tiles.field217[0][var5 + 1][var4];
               }

               if (var4 == var1 && var4 > 0) {
                  Tiles.field217[0][var5][var4] = Tiles.field217[0][var5][var4 - 1];
               }

               if (var3 + var1 == var4 && var4 < 103) {
                  Tiles.field217[0][var5][var4] = Tiles.field217[0][var5][var4 + 1];
               }
            }
         }
      }

   }

   public static boolean method3137() {
      try {
         if (class219.field2568 == 2) {
            if (GrandExchangeOffer.field697 == null) {
               GrandExchangeOffer.field697 = Track.method4491(UrlRequester.field1584, class219.field2572, IndexStore.field1832);
               if (GrandExchangeOffer.field697 == null) {
                  return false;
               }
            }

            if (SecureRandomFuture.field851 == null) {
               SecureRandomFuture.field851 = new class66(class219.field2570, class219.field2569);
            }

            if (class205.field2492.method4365(GrandExchangeOffer.field697, class219.field2574, SecureRandomFuture.field851, 22050)) {
               class205.field2492.method4366();
               class205.field2492.method4393(class321.field3913);
               class205.field2492.method4368(GrandExchangeOffer.field697, class219.field2573);
               class219.field2568 = 0;
               GrandExchangeOffer.field697 = null;
               SecureRandomFuture.field851 = null;
               UrlRequester.field1584 = null;
               return true;
            }
         }
      } catch (Exception var1) {
         var1.printStackTrace();
         class205.field2492.method4488();
         class219.field2568 = 0;
         GrandExchangeOffer.field697 = null;
         SecureRandomFuture.field851 = null;
         UrlRequester.field1584 = null;
      }

      return false;
   }

   public static void method3136(int var0) {
      class219.field2568 = 1;
      UrlRequester.field1584 = null;
      class219.field2572 = -1;
      IndexStore.field1832 = -1;
      class321.field3913 = 0;
      class219.field2573 = false;
      WorldComparator.field810 = var0;
   }
}
