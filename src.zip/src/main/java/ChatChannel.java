public class ChatChannel {
   static int field598;
   int count;
   Message[] messages = new Message[100];

   int size() {
      return this.count;
   }

   Message addMessage(int var1, String var2, String var3, String var4) {
      Message var5 = this.messages[99];

      for(int var6 = this.count; var6 > 0; --var6) {
         if (var6 != 100) {
            this.messages[var6] = this.messages[var6 - 1];
         }
      }

      if (var5 == null) {
         var5 = new Message(var1, var2, var4, var3);
      } else {
         var5.remove();
         var5.removeDual();
         var5.set(var1, var2, var4, var3);
      }

      this.messages[0] = var5;
      if (this.count < 100) {
         ++this.count;
      }

      return var5;
   }

   Message getMessage(int var1) {
      return var1 >= 0 && var1 < this.count ? this.messages[var1] : null;
   }

   static synchronized byte[] size(int var0) {
      return ByteArrayPool.method4243(var0, false);
   }

   public static String addMessage(byte[] var0, int var1, int var2) {
      StringBuilder var3 = new StringBuilder();

      for(int var4 = var1; var4 < var2 + var1; var4 += 3) {
         int var5 = var0[var4] & 255;
         var3.append(class299.field3752[var5 >>> 2]);
         if (var4 < var2 - 1) {
            int var6 = var0[var4 + 1] & 255;
            var3.append(class299.field3752[(var5 & 3) << 4 | var6 >>> 4]);
            if (var4 < var2 - 2) {
               int var7 = var0[var4 + 2] & 255;
               var3.append(class299.field3752[(var6 & 15) << 2 | var7 >>> 6]).append(class299.field3752[var7 & 63]);
            } else {
               var3.append(class299.field3752[(var6 & 15) << 2]).append("=");
            }
         } else {
            var3.append(class299.field3752[(var5 & 3) << 4]).append("==");
         }
      }

      return var3.toString();
   }

   static final void method1115(Widget var0, int var1, int var2, int var3) {
      class162.method3077();
      SpriteMask var4 = var0.getSpriteMask(false);
      if (var4 != null) {
         Rasterizer2D.method6243(var1, var2, var4.width + var1, var2 + var4.height);
         if (Client.field2319 != 2 && Client.field2319 != 5) {
            int var5 = Client.field2101 & 2047;
            int var6 = ObjectSound.field589.x / 32 + 48;
            int var7 = 464 - ObjectSound.field589.y / 32;
            TotalQuantityComparator.field986.method6364(var1, var2, var4.width, var4.height, var6, var7, var5, 256, var4.xStarts, var4.xWidths);

            int var8;
            int var9;
            int var10;
            for(var8 = 0; var8 < Client.field2263; ++var8) {
               var9 = Client.field2314[var8] * 4 + 2 - ObjectSound.field589.x / 32;
               var10 = Client.field2315[var8] * 4 + 2 - ObjectSound.field589.y / 32;
               WidgetGroupParent.method1001(var1, var2, var9, var10, Client.field2316[var8], var4);
            }

            int var11;
            int var12;
            for(var8 = 0; var8 < 104; ++var8) {
               for(var9 = 0; var9 < 104; ++var9) {
                  NodeDeque var15 = Client.field2272[class31.field363][var8][var9];
                  if (var15 != null) {
                     var11 = var8 * 4 + 2 - ObjectSound.field589.x / 32;
                     var12 = var9 * 4 + 2 - ObjectSound.field589.y / 32;
                     WidgetGroupParent.method1001(var1, var2, var11, var12, GameShell.field98[0], var4);
                  }
               }
            }

            for(var8 = 0; var8 < Client.field2129; ++var8) {
               Npc var16 = Client.field2249[Client.field2130[var8]];
               if (var16 != null && var16.isVisible()) {
                  NpcDefinition var18 = var16.definition;
                  if (var18 != null && var18.transforms != null) {
                     var18 = var18.transform();
                  }

                  if (var18 != null && var18.drawMapDot && var18.isInteractable) {
                     var11 = var16.x / 32 - ObjectSound.field589.x / 32;
                     var12 = var16.y / 32 - ObjectSound.field589.y / 32;
                     WidgetGroupParent.method1001(var1, var2, var11, var12, GameShell.field98[1], var4);
                  }
               }
            }

            var8 = Players.field951;
            int[] var19 = Players.field947;

            for(var10 = 0; var10 < var8; ++var10) {
               Player var17 = Client.field2141[var19[var10]];
               if (var17 != null && var17.isVisible() && !var17.isHidden && var17 != ObjectSound.field589) {
                  var12 = var17.x / 32 - ObjectSound.field589.x / 32;
                  int var13 = var17.y / 32 - ObjectSound.field589.y / 32;
                  boolean var14 = false;
                  if (ObjectSound.field589.team != 0 && var17.team != 0 && var17.team == ObjectSound.field589.team) {
                     var14 = true;
                  }

                  if (var17.method811()) {
                     WidgetGroupParent.method1001(var1, var2, var12, var13, GameShell.field98[3], var4);
                  } else if (var14) {
                     WidgetGroupParent.method1001(var1, var2, var12, var13, GameShell.field98[4], var4);
                  } else if (var17.method814()) {
                     WidgetGroupParent.method1001(var1, var2, var12, var13, GameShell.field98[5], var4);
                  } else {
                     WidgetGroupParent.method1001(var1, var2, var12, var13, GameShell.field98[2], var4);
                  }
               }
            }

            if (Client.field2106 != 0 && Client.field2098 % 20 < 10) {
               if (Client.field2106 == 1 && Client.field2107 >= 0 && Client.field2107 < Client.field2249.length) {
                  Npc var20 = Client.field2249[Client.field2107];
                  if (var20 != null) {
                     var11 = var20.x / 32 - ObjectSound.field589.x / 32;
                     var12 = var20.y / 32 - ObjectSound.field589.y / 32;
                     AreaDefinition.method4891(var1, var2, var11, var12, class192.field2438[1], var4);
                  }
               }

               if (Client.field2106 == 2) {
                  var10 = Client.field2109 * 4 - class21.field230 * 4 + 2 - ObjectSound.field589.x / 32;
                  var11 = Client.field2110 * 4 - class79.field902 * 4 + 2 - ObjectSound.field589.y / 32;
                  AreaDefinition.method4891(var1, var2, var10, var11, class192.field2438[1], var4);
               }

               if (Client.field2106 == 10 && Client.field2108 >= 0 && Client.field2108 < Client.field2141.length) {
                  Player var21 = Client.field2141[Client.field2108];
                  if (var21 != null) {
                     var11 = var21.x / 32 - ObjectSound.field589.x / 32;
                     var12 = var21.y / 32 - ObjectSound.field589.y / 32;
                     AreaDefinition.method4891(var1, var2, var11, var12, class192.field2438[1], var4);
                  }
               }
            }

            if (Client.field2165 != 0) {
               var10 = Client.field2165 * 4 + 2 - ObjectSound.field589.x / 32;
               var11 = Client.field2318 * 4 + 2 - ObjectSound.field589.y / 32;
               WidgetGroupParent.method1001(var1, var2, var10, var11, class192.field2438[0], var4);
            }

            if (!ObjectSound.field589.isHidden) {
               Rasterizer2D.method6223(var4.width / 2 + var1 - 1, var4.height / 2 + var2 - 1, 3, 3, 16777215);
            }
         } else {
            Rasterizer2D.method6234(var1, var2, 0, var4.xStarts, var4.xWidths);
         }

         Client.field2292[var3] = true;
      }
   }
}
