public class FriendLoginUpdate extends Link {
   static byte[][][] field3772;
   public short world;
   public int time = (int)(Tile.method2779() / 1000L);
   public Username username;

   FriendLoginUpdate(Username var1, int var2) {
      this.username = var1;
      this.world = (short)var2;
   }
}
