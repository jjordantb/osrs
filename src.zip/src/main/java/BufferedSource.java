import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public class BufferedSource implements Runnable {
   static Widget field1671;
   IOException exception;
   int position = 0;
   int capacity;
   Thread thread;
   int limit = 0;
   byte[] buffer;
   InputStream inputStream;

   BufferedSource(InputStream var1, int var2) {
      this.inputStream = var1;
      this.capacity = var2 + 1;
      this.buffer = new byte[this.capacity];
      this.thread = new Thread(this);
      this.thread.setDaemon(true);
      this.thread.start();
   }

   void close() {
      synchronized(this) {
         if (this.exception == null) {
            this.exception = new IOException("");
         }

         this.notifyAll();
      }

      try {
         this.thread.join();
      } catch (InterruptedException var3) {
         ;
      }

   }

   int readUnsignedByte() throws IOException {
      synchronized(this) {
         if (this.limit == this.position) {
            if (this.exception != null) {
               throw new IOException(this.exception.toString());
            } else {
               return -1;
            }
         } else {
            int var2 = this.buffer[this.position] & 255;
            this.position = (this.position + 1) % this.capacity;
            this.notifyAll();
            return var2;
         }
      }
   }

   boolean isAvailable(int var1) throws IOException {
      if (var1 == 0) {
         return true;
      } else if (var1 > 0 && var1 < this.capacity) {
         synchronized(this) {
            int var3;
            if (this.position <= this.limit) {
               var3 = this.limit - this.position;
            } else {
               var3 = this.capacity - this.position + this.limit;
            }

            if (var3 < var1) {
               if (this.exception != null) {
                  throw new IOException(this.exception.toString());
               } else {
                  this.notifyAll();
                  return false;
               }
            } else {
               return true;
            }
         }
      } else {
         throw new IOException();
      }
   }

   int read(byte[] var1, int var2, int var3) throws IOException {
      if (var3 >= 0 && var2 >= 0 && var3 + var2 <= var1.length) {
         synchronized(this) {
            int var5;
            if (this.position <= this.limit) {
               var5 = this.limit - this.position;
            } else {
               var5 = this.capacity - this.position + this.limit;
            }

            if (var3 > var5) {
               var3 = var5;
            }

            if (var3 == 0 && this.exception != null) {
               throw new IOException(this.exception.toString());
            } else {
               if (var3 + this.position <= this.capacity) {
                  System.arraycopy(this.buffer, this.position, var1, var2, var3);
               } else {
                  int var6 = this.capacity - this.position;
                  System.arraycopy(this.buffer, this.position, var1, var2, var6);
                  System.arraycopy(this.buffer, 0, var1, var6 + var2, var3 - var6);
               }

               this.position = (var3 + this.position) % this.capacity;
               this.notifyAll();
               return var3;
            }
         }
      } else {
         throw new IOException();
      }
   }

   int available() throws IOException {
      synchronized(this) {
         int var2;
         if (this.position <= this.limit) {
            var2 = this.limit - this.position;
         } else {
            var2 = this.capacity - this.position + this.limit;
         }

         if (var2 <= 0 && this.exception != null) {
            throw new IOException(this.exception.toString());
         } else {
            this.notifyAll();
            return var2;
         }
      }
   }

   public void run() {
      while(true) {
         int var1;
         synchronized(this) {
            while(true) {
               if (this.exception != null) {
                  return;
               }

               if (this.position == 0) {
                  var1 = this.capacity - this.limit - 1;
               } else if (this.position <= this.limit) {
                  var1 = this.capacity - this.limit;
               } else {
                  var1 = this.position - this.limit - 1;
               }

               if (var1 > 0) {
                  break;
               }

               try {
                  this.wait();
               } catch (InterruptedException var10) {
                  ;
               }
            }
         }

         int var7;
         try {
            var7 = this.inputStream.read(this.buffer, this.limit, var1);
            if (var7 == -1) {
               throw new EOFException();
            }
         } catch (IOException var11) {
            IOException var3 = var11;
            synchronized(this) {
               this.exception = var3;
               return;
            }
         }

         synchronized(this) {
            this.limit = (var7 + this.limit) % this.capacity;
         }
      }
   }

   static int method2925(int var0, Script var1, boolean var2) {
      int var3;
      if (var0 == 5504) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         int var4 = Interpreter.field467[class31.field364 + 1];
         if (!Client.field2332) {
            Client.field2155 = var3;
            Client.field2101 = var4;
         }

         return 1;
      } else if (var0 == 5505) {
         Interpreter.field467[++class31.field364 - 1] = Client.field2155;
         return 1;
      } else if (var0 == 5506) {
         Interpreter.field467[++class31.field364 - 1] = Client.field2101;
         return 1;
      } else if (var0 == 5530) {
         var3 = Interpreter.field467[--class31.field364];
         if (var3 < 0) {
            var3 = 0;
         }

         Client.field2162 = var3;
         return 1;
      } else if (var0 == 5531) {
         Interpreter.field467[++class31.field364 - 1] = Client.field2162;
         return 1;
      } else {
         return 2;
      }
   }

   static final void method2941(PacketBuffer var0) {
      for(int var1 = 0; var1 < Players.field952; ++var1) {
         int var2 = Players.field959[var1];
         Player var3 = Client.field2141[var2];
         int var4 = var0.readUnsignedByte();
         if ((var4 & 8) != 0) {
            var4 += var0.readUnsignedByte() << 8;
         }

         byte var5 = -1;
         int var6;
         int var7;
         int var9;
         int var10;
         int var13;
         if ((var4 & 64) != 0) {
            var6 = var0.method4025();
            int var8;
            int var11;
            int var12;
            if (var6 > 0) {
               for(var7 = 0; var7 < var6; ++var7) {
                  var9 = -1;
                  var10 = -1;
                  var11 = -1;
                  var8 = var0.method3925();
                  if (var8 == 32767) {
                     var8 = var0.method3925();
                     var10 = var0.method3925();
                     var9 = var0.method3925();
                     var11 = var0.method3925();
                  } else if (var8 != 32766) {
                     var10 = var0.method3925();
                  } else {
                     var8 = -1;
                  }

                  var12 = var0.method3925();
                  var3.addHitSplat(var8, var10, var9, var11, Client.field2098, var12);
               }
            }

            var7 = var0.readUnsignedByteNegate();
            if (var7 > 0) {
               for(var8 = 0; var8 < var7; ++var8) {
                  var9 = var0.method3925();
                  var10 = var0.method3925();
                  if (var10 != 32767) {
                     var11 = var0.method3925();
                     var12 = var0.method4025();
                     var13 = var10 > 0 ? var0.readUnsignedByte() : var12;
                     var3.addHealthBar(var9, Client.field2098, var10, var11, var12, var13);
                  } else {
                     var3.removeHealthBar(var9);
                  }
               }
            }
         }

         if ((var4 & 512) != 0) {
            var3.spotAnimation = var0.method3934();
            var6 = var0.method4106();
            var3.heightOffset = var6 >> 16;
            var3.field317 = (var6 & '\uffff') + Client.field2098;
            var3.spotAnimationFrame = 0;
            var3.spotAnimationFrameCycle = 0;
            if (var3.field317 > Client.field2098) {
               var3.spotAnimationFrame = -1;
            }

            if (var3.spotAnimation == 65535) {
               var3.spotAnimation = -1;
            }
         }

         if ((var4 & 4096) != 0) {
            var5 = var0.method4110();
         }

         if ((var4 & 1024) != 0) {
            var3.field321 = var0.method3945();
            var3.field333 = var0.method4110();
            var3.field320 = var0.method4110();
            var3.field322 = var0.method3945();
            var3.field323 = var0.method3950() + Client.field2098;
            var3.field315 = var0.method3949() + Client.field2098;
            var3.field335 = var0.method3913();
            if (var3.field441) {
               var3.field321 += var3.tileX;
               var3.field333 += var3.tileY;
               var3.field320 += var3.tileX;
               var3.field322 += var3.tileY;
               var3.pathLength = 0;
            } else {
               var3.field321 += var3.pathX[0];
               var3.field333 += var3.pathY[0];
               var3.field320 += var3.pathX[0];
               var3.field322 += var3.pathY[0];
               var3.pathLength = 1;
            }

            var3.field297 = 0;
         }

         if ((var4 & 32) != 0) {
            var3.overheadText = var0.readStringCp1252NullTerminated();
            if (var3.overheadText.charAt(0) == '~') {
               var3.overheadText = var3.overheadText.substring(1);
               Message.set(2, var3.username.name(), var3.overheadText);
            } else if (var3 == ObjectSound.field589) {
               Message.set(2, var3.username.name(), var3.overheadText);
            }

            var3.isAutoChatting = false;
            var3.overheadTextColor = 0;
            var3.overheadTextEffect = 0;
            var3.overheadTextCyclesRemaining = 150;
         }

         if ((var4 & 4) != 0) {
            var3.field305 = var0.method3949();
            if (var3.pathLength == 0) {
               var3.orientation = var3.field305;
               var3.field305 = -1;
            }
         }

         if ((var4 & 1) != 0) {
            var6 = var0.method4033();
            byte[] var14 = new byte[var6];
            Buffer var15 = new Buffer(var14);
            var0.method4061(var14, 0, var6);
            Players.field958[var2] = var15;
            var3.read(var15);
         }

         if ((var4 & 2) != 0) {
            var3.targetIndex = var0.method3950();
            if (var3.targetIndex == 65535) {
               var3.targetIndex = -1;
            }
         }

         if ((var4 & 2048) != 0) {
            Players.field949[var2] = var0.method4110();
         }

         if ((var4 & 16) != 0) {
            var6 = var0.method3950();
            PlayerType var20 = (PlayerType)class10.method352(class57.method1226(), var0.readUnsignedByte());
            boolean var18 = var0.readUnsignedByteNegate() == 1;
            var9 = var0.readUnsignedByte();
            var10 = var0.index;
            if (var3.username != null && var3.appearance != null) {
               boolean var19 = false;
               if (var20.isUser && ServerPacket.field2028.method766(var3.username)) {
                  var19 = true;
               }

               if (!var19 && Client.field2123 == 0 && !var3.isHidden) {
                  Players.field960.index = 0;
                  var0.method3923(Players.field960.array, 0, var9);
                  Players.field960.index = 0;
                  String var16 = AbstractFont.method5851(class255.method5060(WorldMapLabel.method1781(Players.field960)));
                  var3.overheadText = var16.trim();
                  var3.overheadTextColor = var6 >> 8;
                  var3.overheadTextEffect = var6 & 255;
                  var3.overheadTextCyclesRemaining = 150;
                  var3.isAutoChatting = var18;
                  var3.field292 = var3 != ObjectSound.field589 && var20.isUser && "" != Client.field2305 && var16.toLowerCase().indexOf(Client.field2305) == -1;
                  if (var20.isPrivileged) {
                     var13 = var18 ? 91 : 1;
                  } else {
                     var13 = var18 ? 90 : 2;
                  }

                  if (var20.modIcon != -1) {
                     Message.set(var13, class93.method1786(var20.modIcon) + var3.username.name(), var16);
                  } else {
                     Message.set(var13, var3.username.name(), var16);
                  }
               }
            }

            var0.index = var10 + var9;
         }

         if ((var4 & 256) != 0) {
            for(var6 = 0; var6 < 3; ++var6) {
               var3.actions[var6] = var0.readStringCp1252NullTerminated();
            }
         }

         if ((var4 & 128) != 0) {
            var6 = var0.method3913();
            if (var6 == 65535) {
               var6 = -1;
            }

            var7 = var0.readUnsignedByte();
            class6.method157(var3, var6, var7);
         }

         if (var3.field441) {
            if (var5 == 127) {
               var3.resetPath(var3.tileX, var3.tileY);
            } else {
               byte var17;
               if (var5 != -1) {
                  var17 = var5;
               } else {
                  var17 = Players.field949[var2];
               }

               var3.method818(var3.tileX, var3.tileY, var17);
            }
         }
      }

   }
}
