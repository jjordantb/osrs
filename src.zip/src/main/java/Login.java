import java.text.DecimalFormat;
import java.util.concurrent.ScheduledExecutorService;

public class Login {
   static int field664;
   static int field666;
   static int field659;
   static int field663;
   static Bounds field683;
   static int field662;
   static int field648;
   static int field667;
   static int field669;
   static String field672;
   static String field665;
   static String field671;
   static String field674;
   static int field679;
   static String field675;
   static boolean field677;
   static int field656;
   static boolean field678;
   static boolean field676;
   static boolean field682;
   static int field670;
   static String field673;
   static long field684;
   static String field686;
   static long field685;
   static Sprite field652;
   static IndexedSprite field655;
   static int field650;
   static boolean field680;
   static int[] field668;
   static Sprite field651;
   static IndexedSprite[] field653;
   static int field658;
   static IndexedSprite field654;
   static int field649 = 0;
   static int[] field657;
   static Buffer field687;
   static ScheduledExecutorService field661;

   static {
      field650 = field649 + 202;
      field668 = new int[256];
      field658 = 0;
      field659 = 0;
      field666 = 0;
      field679 = 0;
      field662 = 0;
      field663 = 0;
      field664 = 10;
      field665 = "";
      field648 = -1;
      field667 = 1;
      field669 = 0;
      field674 = "";
      field671 = "";
      field672 = "";
      field673 = "";
      field686 = "";
      field675 = "";
      field676 = false;
      field677 = false;
      field678 = true;
      field656 = 0;
      field682 = false;
      field670 = -1;
      new DecimalFormat("##0.00");
      new class137();
      field684 = -1L;
      field685 = -1L;
   }

   public static void method1250(int var0) {
      if (var0 != -1) {
         if (class130.field1567[var0]) {
            Widget.field2678.method4979(var0);
            if (UserComparator3.field1708[var0] != null) {
               boolean var1 = true;

               for(int var2 = 0; var2 < UserComparator3.field1708[var0].length; ++var2) {
                  if (UserComparator3.field1708[var0][var2] != null) {
                     if (UserComparator3.field1708[var0][var2].type != 2) {
                        UserComparator3.field1708[var0][var2] = null;
                     } else {
                        var1 = false;
                     }
                  }
               }

               if (var1) {
                  UserComparator3.field1708[var0] = null;
               }

               class130.field1567[var0] = false;
            }
         }
      }
   }

   static final int method1254(int var0, int var1, int var2) {
      int var3 = 256 - var2;
      return ((var1 & '\uff00') * var2 + (var0 & '\uff00') * var3 & 16711680) + ((var1 & 16711935) * var2 + var3 * (var0 & 16711935) & -16711936) >> 8;
   }

   public static final void method1253(String var0, String var1, int var2, int var3, int var4, int var5) {
      Bzip2State.method3887(var0, var1, var2, var3, var4, var5, false);
   }
}
