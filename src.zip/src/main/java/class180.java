public class class180 {
   protected static boolean field1994;
   public static int[][] field1988 = new int[128][128];
   public static int field1990;
   public static int[] field1993 = new int[4096];
   public static int[][] field1986 = new int[128][128];
   public static int[] field1989 = new int[4096];
}
