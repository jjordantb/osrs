import java.awt.Component;
import java.util.HashMap;
import java.util.Map;

public class Messages {
   static final IterableDualNodeQueue field609 = new IterableDualNodeQueue();
   static final Map field610 = new HashMap();
   static int field608 = 0;
   static final IterableNodeHashTable field611 = new IterableNodeHashTable(1024);
   static int[] field613;

   public static int method1125(long var0) {
      return (int)(var0 >>> 7 & 127L);
   }

   static int method1147(int var0) {
      ChatChannel var1 = (ChatChannel)field610.get(var0);
      return var1 == null ? 0 : var1.size();
   }

   static void method1143(Component var0) {
      var0.removeKeyListener(KeyHandler.field17);
      var0.removeFocusListener(KeyHandler.field17);
      KeyHandler.field14 = -1;
   }

   public static void method1145(AbstractIndexCache var0, AbstractIndexCache var1) {
      SpotAnimationDefinition.field3667 = var0;
      SpotAnimationDefinition.field3663 = var1;
   }

   static String method1144(String var0) {
      PlayerType[] var1 = class57.method1226();

      for(int var2 = 0; var2 < var1.length; ++var2) {
         PlayerType var3 = var1[var2];
         if (var3.modIcon != -1 && var0.startsWith(class93.method1786(var3.modIcon))) {
            var0 = var0.substring(6 + Integer.toString(var3.modIcon).length());
            break;
         }
      }

      return var0;
   }
}
