public interface Enumerated {
   int ordinal();
}
