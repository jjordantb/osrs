import java.io.File;
import java.io.IOException;

public abstract class Clock {
   public abstract void mark();

   public abstract int wait(int var1, int var2);

   static void method3019() {
      Login.field686 = Login.field686.trim();
      if (Login.field686.length() == 0) {
         ByteArrayPool.method4250("Please enter your username.", "If you created your account after November", "2010, this will be the creation email address.");
      } else {
         long var1 = EnumDefinition.method5299();
         int var0;
         if (var1 == 0L) {
            var0 = 5;
         } else {
            var0 = GroundItemPile.method2666(var1, Login.field686);
         }

         switch(var0) {
         case 2:
            ByteArrayPool.method4250(Strings.field3041, Strings.field3216, Strings.field3179);
            Login.field669 = 6;
            break;
         case 3:
            ByteArrayPool.method4250("", "Error connecting to server.", "");
            break;
         case 4:
            ByteArrayPool.method4250("The part of the website you are trying", "to connect to is offline at the moment.", "Please try again later.");
            break;
         case 5:
            ByteArrayPool.method4250("Sorry, there was an error trying to", "log you in to this part of the website.", "Please try again later.");
            break;
         case 6:
            ByteArrayPool.method4250("", "Error connecting to server.", "");
            break;
         case 7:
            ByteArrayPool.method4250("You must enter a valid login to proceed. For accounts", "created after 24th November 2010, please use your", "email address. Otherwise please use your username.");
         }

      }
   }

   public static AreaDefinition mark(int var0) {
      return var0 >= 0 && var0 < AreaDefinition.field2880.length && AreaDefinition.field2880[var0] != null ? AreaDefinition.field2880[var0] : new AreaDefinition(var0);
   }

   static void wait(File var0, File var1) {
      try {
         AccessFile var2 = new AccessFile(class178.field1970, "rw", 10000L);
         Buffer var3 = new Buffer(500);
         var3.writeByte(3);
         var3.writeByte(var1 != null ? 1 : 0);
         var3.method4131(var0.getPath());
         if (var1 != null) {
            var3.method4131("");
         }

         var2.write(var3.array, 0, var3.index);
         var2.close();
      } catch (IOException var4) {
         var4.printStackTrace();
      }

   }

   public static byte[] method3018(Object var0, boolean var1) {
      if (var0 == null) {
         return null;
      } else if (var0 instanceof byte[]) {
         byte[] var6 = (byte[])((byte[])var0);
         if (var1) {
            int var4 = var6.length;
            byte[] var5 = new byte[var4];
            System.arraycopy(var6, 0, var5, 0, var4);
            return var5;
         } else {
            return var6;
         }
      } else if (var0 instanceof AbstractByteArrayCopier) {
         AbstractByteArrayCopier var2 = (AbstractByteArrayCopier)var0;
         return var2.get();
      } else {
         throw new IllegalArgumentException();
      }
   }

   static void method3016(Widget[] var0, int var1, int var2, int var3, boolean var4) {
      for(int var5 = 0; var5 < var0.length; ++var5) {
         Widget var6 = var0[var5];
         if (var6 != null && var6.parentId == var1) {
            GameObject.method2903(var6, var2, var3, var4);
            FloorDecoration.method2556(var6, var2, var3);
            if (var6.scrollX > var6.scrollWidth - var6.width) {
               var6.scrollX = var6.scrollWidth - var6.width;
            }

            if (var6.scrollX < 0) {
               var6.scrollX = 0;
            }

            if (var6.scrollY > var6.scrollHeight - var6.height) {
               var6.scrollY = var6.scrollHeight - var6.height;
            }

            if (var6.scrollY < 0) {
               var6.scrollY = 0;
            }

            if (var6.type == 0) {
               MusicPatch.method4734(var0, var6, var4);
            }
         }
      }

   }
}
