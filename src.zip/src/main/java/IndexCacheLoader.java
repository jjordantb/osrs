public class IndexCacheLoader {
   int field593 = 0;
   final IndexCache field591;
   final int field592;

   IndexCacheLoader(IndexCache var1, String var2) {
      this.field591 = var1;
      this.field592 = var1.method4977();
   }

   boolean method1095() {
      this.field593 = 0;

      for(int var1 = 0; var1 < this.field592; ++var1) {
         if (!this.field591.method4863(var1) || this.field591.method4833(var1)) {
            ++this.field593;
         }
      }

      return this.field593 >= this.field592;
   }

   public static void method1096(ScriptEvent var0) {
      Client.method3739(var0, 500000);
   }

   static final void method1102(boolean var0, PacketBuffer var1) {
      Client.field2293 = 0;
      Client.field2222 = 0;
      PacketBuffer var2 = Client.field2133.packetBuffer;
      var2.importIndex();
      int var3 = var2.readBits(8);
      int var4;
      if (var3 < Client.field2129) {
         for(var4 = var3; var4 < Client.field2129; ++var4) {
            Client.field2186[++Client.field2293 - 1] = Client.field2130[var4];
         }
      }

      if (var3 > Client.field2129) {
         throw new RuntimeException("");
      } else {
         Client.field2129 = 0;

         int var5;
         int var7;
         int var8;
         int var9;
         int var10;
         int var11;
         for(var4 = 0; var4 < var3; ++var4) {
            var5 = Client.field2130[var4];
            Npc var6 = Client.field2249[var5];
            var7 = var2.readBits(1);
            if (var7 == 0) {
               Client.field2130[++Client.field2129 - 1] = var5;
               var6.npcCycle = Client.field2098;
            } else {
               var8 = var2.readBits(2);
               if (var8 == 0) {
                  Client.field2130[++Client.field2129 - 1] = var5;
                  var6.npcCycle = Client.field2098;
                  Client.field2132[++Client.field2222 - 1] = var5;
               } else if (var8 == 1) {
                  Client.field2130[++Client.field2129 - 1] = var5;
                  var6.npcCycle = Client.field2098;
                  var9 = var2.readBits(3);
                  var6.method984(var9, (byte)1);
                  var10 = var2.readBits(1);
                  if (var10 == 1) {
                     Client.field2132[++Client.field2222 - 1] = var5;
                  }
               } else if (var8 == 2) {
                  Client.field2130[++Client.field2129 - 1] = var5;
                  var6.npcCycle = Client.field2098;
                  var9 = var2.readBits(3);
                  var6.method984(var9, (byte)2);
                  var10 = var2.readBits(3);
                  var6.method984(var10, (byte)2);
                  var11 = var2.readBits(1);
                  if (var11 == 1) {
                     Client.field2132[++Client.field2222 - 1] = var5;
                  }
               } else if (var8 == 3) {
                  Client.field2186[++Client.field2293 - 1] = var5;
               }
            }
         }

         int var14;
         Npc var15;
         int var16;
         while(var1.bitsRemaining(Client.field2133.serverPacket0Length) >= 27) {
            var14 = var1.readBits(15);
            if (var14 == 32767) {
               break;
            }

            boolean var17 = false;
            if (Client.field2249[var14] == null) {
               Client.field2249[var14] = new Npc();
               var17 = true;
            }

            var15 = Client.field2249[var14];
            Client.field2130[++Client.field2129 - 1] = var14;
            var15.npcCycle = Client.field2098;
            if (var0) {
               var5 = var1.readBits(8);
               if (var5 > 127) {
                  var5 -= 256;
               }
            } else {
               var5 = var1.readBits(5);
               if (var5 > 15) {
                  var5 -= 32;
               }
            }

            var16 = var1.readBits(1);
            var7 = Client.field2142[var1.readBits(3)];
            if (var17) {
               var15.orientation = var15.field278 = var7;
            }

            var8 = var1.readBits(1);
            if (var8 == 1) {
               Client.field2132[++Client.field2222 - 1] = var14;
            }

            if (var0) {
               var9 = var1.readBits(8);
               if (var9 > 127) {
                  var9 -= 256;
               }
            } else {
               var9 = var1.readBits(5);
               if (var9 > 15) {
                  var9 -= 32;
               }
            }

            var15.definition = NetFileRequest.method4959(var1.readBits(14));
            var15.size = var15.definition.size;
            var15.field285 = var15.definition.field3603;
            if (var15.field285 == 0) {
               var15.field278 = 0;
            }

            var15.walkSequence = var15.definition.walkSequence;
            var15.walkTurnSequence = var15.definition.walkTurnSequence;
            var15.walkTurnLeftSequence = var15.definition.walkTurnLeftSequence;
            var15.walkTurnRightSequence = var15.definition.walkTurnRightSequence;
            var15.idleSequence = var15.definition.idleSequence;
            var15.turnLeftSequence = var15.definition.turnLeftSequence;
            var15.turnRightSequence = var15.definition.turnRightSequence;
            var15.method996(ObjectSound.field589.pathX[0] + var5, ObjectSound.field589.pathY[0] + var9, var16 == 1);
         }

         var1.exportIndex();

         for(var14 = 0; var14 < Client.field2222; ++var14) {
            var3 = Client.field2132[var14];
            var15 = Client.field2249[var3];
            var5 = var1.readUnsignedByte();
            if ((var5 & 1) != 0) {
               var15.targetIndex = var1.method3949();
               if (var15.targetIndex == 65535) {
                  var15.targetIndex = -1;
               }
            }

            if ((var5 & 64) != 0) {
               var16 = var1.method3934();
               var7 = var1.method3934();
               var8 = var15.x - (var16 - class21.field230 - class21.field230) * 64;
               var9 = var15.y - (var7 - class79.field902 - class79.field902) * 64;
               if (var8 != 0 || var9 != 0) {
                  var15.field305 = (int)(Math.atan2((double)var8, (double)var9) * 325.949D) & 2047;
               }
            }

            if ((var5 & 32) != 0) {
               var16 = var1.method3913();
               if (var16 == 65535) {
                  var16 = -1;
               }

               var7 = var1.method4033();
               if (var16 == var15.sequence && var16 != -1) {
                  var8 = WorldMapCacheName.method547(var16).field3463;
                  if (var8 == 1) {
                     var15.sequenceFrame = 0;
                     var15.sequenceFrameCycle = 0;
                     var15.sequenceDelay = var7;
                     var15.field313 = 0;
                  }

                  if (var8 == 2) {
                     var15.field313 = 0;
                  }
               } else if (var16 == -1 || var15.sequence == -1 || WorldMapCacheName.method547(var16).field3475 >= WorldMapCacheName.method547(var15.sequence).field3475) {
                  var15.sequence = var16;
                  var15.sequenceFrame = 0;
                  var15.sequenceFrameCycle = 0;
                  var15.sequenceDelay = var7;
                  var15.field313 = 0;
                  var15.field297 = var15.pathLength;
               }
            }

            if ((var5 & 4) != 0) {
               var15.definition = NetFileRequest.method4959(var1.method3913());
               var15.size = var15.definition.size;
               var15.field285 = var15.definition.field3603;
               var15.walkSequence = var15.definition.walkSequence;
               var15.walkTurnSequence = var15.definition.walkTurnSequence;
               var15.walkTurnLeftSequence = var15.definition.walkTurnLeftSequence;
               var15.walkTurnRightSequence = var15.definition.walkTurnRightSequence;
               var15.idleSequence = var15.definition.idleSequence;
               var15.turnLeftSequence = var15.definition.turnLeftSequence;
               var15.turnRightSequence = var15.definition.turnRightSequence;
            }

            if ((var5 & 16) != 0) {
               var16 = var1.readUnsignedByteNegate();
               int var12;
               if (var16 > 0) {
                  for(var7 = 0; var7 < var16; ++var7) {
                     var9 = -1;
                     var10 = -1;
                     var11 = -1;
                     var8 = var1.method3925();
                     if (var8 == 32767) {
                        var8 = var1.method3925();
                        var10 = var1.method3925();
                        var9 = var1.method3925();
                        var11 = var1.method3925();
                     } else if (var8 != 32766) {
                        var10 = var1.method3925();
                     } else {
                        var8 = -1;
                     }

                     var12 = var1.method3925();
                     var15.addHitSplat(var8, var10, var9, var11, Client.field2098, var12);
                  }
               }

               var7 = var1.method4025();
               if (var7 > 0) {
                  for(var8 = 0; var8 < var7; ++var8) {
                     var9 = var1.method3925();
                     var10 = var1.method3925();
                     if (var10 != 32767) {
                        var11 = var1.method3925();
                        var12 = var1.readUnsignedByte();
                        int var13 = var10 > 0 ? var1.method4033() : var12;
                        var15.addHealthBar(var9, Client.field2098, var10, var11, var12, var13);
                     } else {
                        var15.removeHealthBar(var9);
                     }
                  }
               }
            }

            if ((var5 & 8) != 0) {
               var15.spotAnimation = var1.method3949();
               var16 = var1.method4106();
               var15.heightOffset = var16 >> 16;
               var15.field317 = (var16 & '\uffff') + Client.field2098;
               var15.spotAnimationFrame = 0;
               var15.spotAnimationFrameCycle = 0;
               if (var15.field317 > Client.field2098) {
                  var15.spotAnimationFrame = -1;
               }

               if (var15.spotAnimation == 65535) {
                  var15.spotAnimation = -1;
               }
            }

            if ((var5 & 2) != 0) {
               var15.overheadText = var1.readStringCp1252NullTerminated();
               var15.overheadTextCyclesRemaining = 100;
            }
         }

         for(var14 = 0; var14 < Client.field2293; ++var14) {
            var3 = Client.field2186[var14];
            if (Client.field2249[var3].npcCycle != Client.field2098) {
               Client.field2249[var3].definition = null;
               Client.field2249[var3] = null;
            }
         }

         if (var1.index != Client.field2133.serverPacket0Length) {
            throw new RuntimeException(var1.index + "," + Client.field2133.serverPacket0Length);
         } else {
            for(var14 = 0; var14 < Client.field2129; ++var14) {
               if (Client.field2249[Client.field2130[var14]] == null) {
                  throw new RuntimeException(var14 + "," + Client.field2129);
               }
            }

         }
      }
   }

   static final void method1100(Widget var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      if (Client.field2137) {
         Client.field2245 = 32;
      } else {
         Client.field2245 = 0;
      }

      Client.field2137 = false;
      int var7;
      if (MouseHandler.field150 == 1 || !WorldMapSection0.field1101 && MouseHandler.field150 == 4) {
         if (var5 >= var1 && var5 < var1 + 16 && var6 >= var2 && var6 < var2 + 16) {
            var0.scrollY -= 4;
            WorldMapSection1.method506(var0);
         } else if (var5 >= var1 && var5 < var1 + 16 && var6 >= var3 + var2 - 16 && var6 < var3 + var2) {
            var0.scrollY += 4;
            WorldMapSection1.method506(var0);
         } else if (var5 >= var1 - Client.field2245 && var5 < Client.field2245 + var1 + 16 && var6 >= var2 + 16 && var6 < var3 + var2 - 16) {
            var7 = var3 * (var3 - 32) / var4;
            if (var7 < 8) {
               var7 = 8;
            }

            int var8 = var6 - var2 - 16 - var7 / 2;
            int var9 = var3 - 32 - var7;
            var0.scrollY = var8 * (var4 - var3) / var9;
            WorldMapSection1.method506(var0);
            Client.field2137 = true;
         }
      }

      if (Client.field2284 != 0) {
         var7 = var0.width;
         if (var5 >= var1 - var7 && var6 >= var2 && var5 < var1 + 16 && var6 <= var3 + var2) {
            var0.scrollY += Client.field2284 * 45;
            WorldMapSection1.method506(var0);
         }
      }

   }

   static final void method1097(Widget[] var0, int var1) {
      for(int var2 = 0; var2 < var0.length; ++var2) {
         Widget var3 = var0[var2];
         if (var3 != null && var3.parentId == var1 && (!var3.isIf3 || !Canvas.method361(var3))) {
            int var5;
            if (var3.type == 0) {
               if (!var3.isIf3 && Canvas.method361(var3) && var3 != BufferedSource.field1671) {
                  continue;
               }

               method1097(var0, var3.id);
               if (var3.children != null) {
                  method1097(var3.children, var3.id);
               }

               WidgetGroupParent var4 = (WidgetGroupParent) Client.field2247.get((long)var3.id);
               if (var4 != null) {
                  var5 = var4.group;
                  if (class196.method4189(var5)) {
                     method1097(UserComparator3.field1708[var5], -1);
                  }
               }
            }

            if (var3.type == 6) {
               if (var3.sequenceId != -1 || var3.sequenceId2 != -1) {
                  boolean var7 = WorldMapSection3.method1174(var3);
                  if (var7) {
                     var5 = var3.sequenceId2;
                  } else {
                     var5 = var3.sequenceId;
                  }

                  if (var5 != -1) {
                     SequenceDefinition var6 = WorldMapCacheName.method547(var5);

                     for(var3.modelFrameCycle += Client.field2148; var3.modelFrameCycle > var6.frameLengths[var3.modelFrame]; WorldMapSection1.method506(var3)) {
                        var3.modelFrameCycle -= var6.frameLengths[var3.modelFrame];
                        ++var3.modelFrame;
                        if (var3.modelFrame >= var6.frameIds.length) {
                           var3.modelFrame -= var6.frameCount;
                           if (var3.modelFrame < 0 || var3.modelFrame >= var6.frameIds.length) {
                              var3.modelFrame = 0;
                           }
                        }
                     }
                  }
               }

               if (var3.field2644 != 0 && !var3.isIf3) {
                  int var8 = var3.field2644 >> 16;
                  var5 = var3.field2644 << 16 >> 16;
                  var8 *= Client.field2148;
                  var5 *= Client.field2148;
                  var3.modelAngleX = var8 + var3.modelAngleX & 2047;
                  var3.modelAngleY = var5 + var3.modelAngleY & 2047;
                  WorldMapSection1.method506(var3);
               }
            }
         }
      }

   }
}
