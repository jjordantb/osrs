public final class Bzip2State {
   int[][] field2416 = new int[6][258];
   byte[] field2428 = new byte[18002];
   int[] field2405 = new int[16];
   boolean[] field2425 = new boolean[256];
   int[][] field2431 = new int[6][258];
   byte[][] field2415 = new byte[6][258];
   boolean[] field2424 = new boolean[16];
   int[][] field2433 = new int[6][258];
   int field2435;
   int[] field2434 = new int[6];
   byte[] field2426 = new byte[4096];
   byte[] field2427 = new byte[256];
   byte[] field2429 = new byte[18002];
   int field2419;
   byte[] field2404;
   final int field2402 = 50;
   int field2410;
   final int field2400 = 258;
   int field2420;
   final int field2413 = 4096;
   int field2408;
   byte[] field2423;
   byte field2411;
   int field2418;
   final int field2403 = 18002;
   int field2414;
   int field2406;
   int field2422;
   int field2399 = 0;
   final int field2401 = 6;
   final int field2432 = 16;
   int field2398;
   int field2417;
   int field2407;
   int field2430 = 0;
   int field2412;
   int[] field2409 = new int[257];
   int[] field2421 = new int[256];

   static final void method3887(String var0, String var1, int var2, int var3, int var4, int var5, boolean var6) {
      if (!Client.field2276) {
         if (Client.field2223 < 500) {
            Client.field2359[Client.field2223] = var0;
            Client.field2229[Client.field2223] = var1;
            Client.field2226[Client.field2223] = var2;
            Client.field2227[Client.field2223] = var3;
            Client.field2224[Client.field2223] = var4;
            Client.field2225[Client.field2223] = var5;
            Client.field2215[Client.field2223] = var6;
            ++Client.field2223;
         }

      }
   }
}
