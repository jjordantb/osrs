import java.util.concurrent.Callable;

public class SecureRandomCallable implements Callable {
   static AbstractSocket field515;

   public Object call() {
      return NpcDefinition.method5437();
   }

   static final void method1018(Widget var0, int var1, byte[] var2, byte[] var3) {
      if (var0.field2631 == null) {
         if (var2 == null) {
            return;
         }

         var0.field2631 = new byte[11][];
         var0.field2664 = new byte[11][];
         var0.field2686 = new int[11];
         var0.field2666 = new int[11];
      }

      var0.field2631[var1] = var2;
      if (var2 != null) {
         var0.field2645 = true;
      } else {
         var0.field2645 = false;

         for(int var4 = 0; var4 < var0.field2631.length; ++var4) {
            if (var0.field2631[var4] != null) {
               var0.field2645 = true;
               break;
            }
         }
      }

      var0.field2664[var1] = var3;
   }

   public static int method1017(int var0) {
      var0 = (var0 & 1431655765) + (var0 >>> 1 & 1431655765);
      var0 = (var0 >>> 2 & 858993459) + (var0 & 858993459);
      var0 = var0 + (var0 >>> 4) & 252645135;
      var0 += var0 >>> 8;
      var0 += var0 >>> 16;
      return var0 & 255;
   }

   public static void method1020() {
      ParamsDefinition.field3486.clear();
   }

   static final void method1011() {
      PacketBufferNode var0 = FaceNormal.method2884(ClientPacket.field1920, Client.field2133.isaacCipher);
      var0.packetBuffer.writeByte(0);
      Client.field2133.method1281(var0);
   }

   public static boolean method1019() {
      return Client.field2255 >= 2;
   }
}
