public class ClanMate extends Buddy {
   TriBool isFriend;
   TriBool isIgnored;

   ClanMate() {
      this.isFriend = TriBool.field3723;
      this.isIgnored = TriBool.field3723;
   }

   public final boolean method5327() {
      if (this.isIgnored == TriBool.field3723) {
         this.method5337();
      }

      return this.isIgnored == TriBool.field3722;
   }

   void method5339() {
      this.isFriend = ServerPacket.field2028.friendsList.contains(super.username) ? TriBool.field3722 : TriBool.field3721;
   }

   void method5323() {
      this.isFriend = TriBool.field3723;
   }

   void method5337() {
      this.isIgnored = ServerPacket.field2028.ignoreList.contains(super.username) ? TriBool.field3722 : TriBool.field3721;
   }

   void method5326() {
      this.isIgnored = TriBool.field3723;
   }

   public final boolean method5324() {
      if (this.isFriend == TriBool.field3723) {
         this.method5339();
      }

      return this.isFriend == TriBool.field3722;
   }

   public static final boolean method5342() {
      KeyHandler var0 = KeyHandler.field17;
      synchronized(KeyHandler.field17) {
         if (KeyHandler.field19 == KeyHandler.field21) {
            return false;
         } else {
            Message.field561 = KeyHandler.field0[KeyHandler.field19];
            FaceNormal.field1622 = KeyHandler.field15[KeyHandler.field19];
            KeyHandler.field19 = KeyHandler.field19 + 1 & 127;
            return true;
         }
      }
   }
}
