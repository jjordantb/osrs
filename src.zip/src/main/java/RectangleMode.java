public class RectangleMode implements Enumerated {
   static final RectangleMode field4002 = new RectangleMode(2, 2);
   public static final RectangleMode field4001 = new RectangleMode(0, 0);
   static final RectangleMode field4000 = new RectangleMode(1, 1);
   final int id2;
   public final int id;

   RectangleMode(int var1, int var2) {
      this.id = var1;
      this.id2 = var2;
   }

   public int ordinal() {
      return this.id2;
   }
}
