public abstract class class94 extends Node {
   int field1035;

   abstract void method1789();

   abstract int method1790();
}
