public class PlayerType implements Enumerated {
   static final PlayerType field2857 = new PlayerType(4, 3, false, false, true);
   static final PlayerType field2855 = new PlayerType(2, 1, true, true, false);
   static final PlayerType field2865 = new PlayerType(0, -1, true, false, true);
   static final PlayerType field2863 = new PlayerType(5, 10, false, false, true);
   static final PlayerType field2858 = new PlayerType(3, 2, false, false, true);
   static final PlayerType field2856 = new PlayerType(1, 0, true, true, true);
   final int id;
   public final boolean isUser;
   public final boolean isPrivileged;
   public final int modIcon;

   PlayerType(int var1, int var2, boolean var3, boolean var4, boolean var5) {
      this.id = var1;
      this.modIcon = var2;
      this.isPrivileged = var4;
      this.isUser = var5;
   }

   public int ordinal() {
      return this.id;
   }

   static Widget method4811(Widget var0) {
      int var1 = class85.method1728(class257.method5068(var0));
      if (var1 == 0) {
         return null;
      } else {
         for(int var2 = 0; var2 < var1; ++var2) {
            var0 = WorldMapSection3.method1148(var0.parentId);
            if (var0 == null) {
               return null;
            }
         }

         return var0;
      }
   }
}
