import java.io.IOException;

public class PacketWriter {
   ServerPacket serverPacket0 = null;
   public IsaacCipher isaacCipher;
   ServerPacket field705;
   int field711 = 0;
   AbstractSocket socket0;
   int field708 = 0;
   ServerPacket field699;
   PacketBuffer packetBuffer = new PacketBuffer(40000);
   ServerPacket field716;
   boolean field707 = true;
   int field709 = 0;
   Buffer buffer = new Buffer(5000);
   IterableNodeDeque packetBufferNodes = new IterableNodeDeque();
   int serverPacket0Length = 0;

   void close() {
      if (this.socket0 != null) {
         this.socket0.close();
         this.socket0 = null;
      }

   }

   public final void method1281(PacketBufferNode var1) {
      this.packetBufferNodes.addFirst(var1);
      var1.field1805 = var1.packetBuffer.index;
      var1.packetBuffer.index = 0;
      this.field711 += var1.field1805;
   }

   final void method1282() {
      this.packetBufferNodes.clear();
      this.field711 = 0;
   }

   void removeSocket() {
      this.socket0 = null;
   }

   AbstractSocket getSocket() {
      return this.socket0;
   }

   void setSocket(AbstractSocket var1) {
      this.socket0 = var1;
   }

   final void method1275() throws IOException {
      if (this.socket0 != null && this.field711 > 0) {
         this.buffer.index = 0;

         while(true) {
            PacketBufferNode var1 = (PacketBufferNode)this.packetBufferNodes.last();
            if (var1 == null || var1.field1805 > this.buffer.array.length - this.buffer.index) {
               this.socket0.write(this.buffer.array, 0, this.buffer.index);
               this.field709 = 0;
               break;
            }

            this.buffer.method3905(var1.packetBuffer.array, 0, var1.field1805);
            this.field711 -= var1.field1805;
            var1.remove();
            var1.packetBuffer.method3894();
            var1.method3170();
         }
      }

   }

   public static void method1288() {
      ItemDefinition.field3610.clear();
      ItemDefinition.field3611.clear();
      ItemDefinition.field3649.clear();
   }

   static int method1298(int var0, Script var1, boolean var2) {
      Widget var3;
      if (var0 == 2700) {
         var3 = WorldMapSection3.method1148(Interpreter.field467[--class31.field364]);
         Interpreter.field467[++class31.field364 - 1] = var3.itemId;
         return 1;
      } else if (var0 == 2701) {
         var3 = WorldMapSection3.method1148(Interpreter.field467[--class31.field364]);
         if (var3.itemId != -1) {
            Interpreter.field467[++class31.field364 - 1] = var3.itemQuantity;
         } else {
            Interpreter.field467[++class31.field364 - 1] = 0;
         }

         return 1;
      } else if (var0 == 2702) {
         int var5 = Interpreter.field467[--class31.field364];
         WidgetGroupParent var4 = (WidgetGroupParent) Client.field2247.get((long)var5);
         if (var4 != null) {
            Interpreter.field467[++class31.field364 - 1] = 1;
         } else {
            Interpreter.field467[++class31.field364 - 1] = 0;
         }

         return 1;
      } else if (var0 == 2706) {
         Interpreter.field467[++class31.field364 - 1] = Client.field2246;
         return 1;
      } else {
         return 2;
      }
   }
}
