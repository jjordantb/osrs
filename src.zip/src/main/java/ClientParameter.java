public class ClientParameter {
   static final ClientParameter field3540 = new ClientParameter("3", "3");
   static final ClientParameter field3538 = new ClientParameter("16", "16");
   public static final ClientParameter field3546 = new ClientParameter("18", "18");
   static final ClientParameter field3536 = new ClientParameter("7", "7");
   static final ClientParameter field3535 = new ClientParameter("2", "2");
   static final ClientParameter field3544 = new ClientParameter("8", "8");
   static final ClientParameter field3550 = new ClientParameter("11", "11");
   static final ClientParameter field3539 = new ClientParameter("5", "5");
   public static final ClientParameter field3549 = new ClientParameter("13", "13");
   static final ClientParameter field3534 = new ClientParameter("12", "12");
   static final ClientParameter field3545 = new ClientParameter("14", "14");
   static final ClientParameter field3542 = new ClientParameter("17", "17");
   static final ClientParameter field3547 = new ClientParameter("9", "9");
   static final ClientParameter field3548 = new ClientParameter("10", "10");
   static final ClientParameter field3551 = new ClientParameter("15", "15");
   static final ClientParameter field3537 = new ClientParameter("1", "1");
   static final ClientParameter field3541 = new ClientParameter("6", "6");
   static final ClientParameter field3543 = new ClientParameter("4", "4");
   public final String id;

   ClientParameter(String var1, String var2) {
      this.id = var2;
   }
}
