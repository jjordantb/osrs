public class class223 extends TaskDataNode {
   class76 field2756 = new class76();
   class214 field2755;
   NodeDeque field2754 = new NodeDeque();

   class223(class214 var1) {
      this.field2755 = var1;
   }

   protected void vmethod4652(int[] var1, int var2, int var3) {
      this.field2756.vmethod4652(var1, var2, var3);

      for(class222 var6 = (class222)this.field2754.last(); var6 != null; var6 = (class222)this.field2754.previous()) {
         if (!this.field2755.method4396(var6)) {
            int var4 = var2;
            int var5 = var3;

            do {
               if (var5 <= var6.field2743) {
                  this.method4632(var6, var1, var4, var5, var4 + var5);
                  var6.field2743 -= var5;
                  break;
               }

               this.method4632(var6, var1, var4, var6.field2743, var4 + var5);
               var4 += var6.field2743;
               var5 -= var6.field2743;
            } while(!this.field2755.method4475(var6, var1, var4, var5));
         }
      }

   }

   void method4632(class222 var1, int[] var2, int var3, int var4, int var5) {
      if ((this.field2755.field2531[var1.field2752] & 4) != 0 && var1.field2744 < 0) {
         int var6 = this.field2755.field2529[var1.field2752] / AbstractSoundSystem.field936;

         while(true) {
            int var7 = (var6 + 1048575 - var1.field2734) / var6;
            if (var7 > var4) {
               var1.field2734 += var6 * var4;
               break;
            }

            var1.field2748.vmethod4652(var2, var3, var7);
            var3 += var7;
            var4 -= var7;
            var1.field2734 += var7 * var6 - 1048576;
            int var8 = AbstractSoundSystem.field936 / 100;
            int var9 = 262144 / var6;
            if (var9 < var8) {
               var8 = var9;
            }

            class104 var10 = var1.field2748;
            if (this.field2755.field2523[var1.field2752] == 0) {
               var1.field2748 = class104.method2035(var1.field2732, var10.method2032(), var10.method2041(), var10.method2042());
            } else {
               var1.field2748 = class104.method2035(var1.field2732, var10.method2032(), 0, var10.method2042());
               this.field2755.method4375(var1, var1.field2738.field2780[var1.field2735] < 0);
               var1.field2748.method2138(var8, var10.method2041());
            }

            if (var1.field2738.field2780[var1.field2735] < 0) {
               var1.field2748.method2037(-1);
            }

            var10.method2048(var8);
            var10.vmethod4652(var2, var3, var5 - var3);
            if (var10.method2052()) {
               this.field2756.method1565(var10);
            }
         }
      }

      var1.field2748.vmethod4652(var2, var3, var4);
   }

   protected TaskDataNode vmethod4628() {
      class222 var1 = (class222)this.field2754.last();
      if (var1 == null) {
         return null;
      } else {
         return (TaskDataNode)(var1.field2748 != null ? var1.field2748 : this.vmethod4630());
      }
   }

   protected int vmethod4641() {
      return 0;
   }

   protected TaskDataNode vmethod4630() {
      class222 var1;
      do {
         var1 = (class222)this.field2754.previous();
         if (var1 == null) {
            return null;
         }
      } while(var1.field2748 == null);

      return var1.field2748;
   }

   void method4635(class222 var1, int var2) {
      if ((this.field2755.field2531[var1.field2752] & 4) != 0 && var1.field2744 < 0) {
         int var3 = this.field2755.field2529[var1.field2752] / AbstractSoundSystem.field936;
         int var4 = (var3 + 1048575 - var1.field2734) / var3;
         var1.field2734 = var3 * var2 + var1.field2734 & 1048575;
         if (var4 <= var2) {
            if (this.field2755.field2523[var1.field2752] == 0) {
               var1.field2748 = class104.method2035(var1.field2732, var1.field2748.method2032(), var1.field2748.method2041(), var1.field2748.method2042());
            } else {
               var1.field2748 = class104.method2035(var1.field2732, var1.field2748.method2032(), 0, var1.field2748.method2042());
               this.field2755.method4375(var1, var1.field2738.field2780[var1.field2735] < 0);
            }

            if (var1.field2738.field2780[var1.field2735] < 0) {
               var1.field2748.method2037(-1);
            }

            var2 = var1.field2734 / var3;
         }
      }

      var1.field2748.vmethod4633(var2);
   }

   protected void vmethod4633(int var1) {
      this.field2756.vmethod4633(var1);

      for(class222 var3 = (class222)this.field2754.last(); var3 != null; var3 = (class222)this.field2754.previous()) {
         if (!this.field2755.method4396(var3)) {
            int var2 = var1;

            do {
               if (var2 <= var3.field2743) {
                  this.method4635(var3, var2);
                  var3.field2743 -= var2;
                  break;
               }

               this.method4635(var3, var3.field2743);
               var2 -= var3.field2743;
            } while(!this.field2755.method4475(var3, (int[])null, 0, var2));
         }
      }

   }

   static int method4657(int var0, Script var1, boolean var2) {
      String var3;
      if (var0 == 3100) {
         var3 = Interpreter.field462[--Interpreter.field469];
         Message.set(0, "", var3);
         return 1;
      } else if (var0 == 3101) {
         class31.field364 -= 2;
         class6.method157(ObjectSound.field589, Interpreter.field467[class31.field364], Interpreter.field467[class31.field364 + 1]);
         return 1;
      } else if (var0 == 3103) {
         if (!Interpreter.field476) {
            Interpreter.field475 = true;
         }

         return 1;
      } else {
         int var10;
         if (var0 == 3104) {
            var3 = Interpreter.field462[--Interpreter.field469];
            var10 = 0;
            if (class219.method4549(var3)) {
               var10 = LoginPacket.method3276(var3);
            }

            PacketBufferNode var12 = FaceNormal.method2884(ClientPacket.field1889, Client.field2133.isaacCipher);
            var12.packetBuffer.writeInt(var10);
            Client.field2133.method1281(var12);
            return 1;
         } else {
            PacketBufferNode var14;
            if (var0 == 3105) {
               var3 = Interpreter.field462[--Interpreter.field469];
               var14 = FaceNormal.method2884(ClientPacket.field1931, Client.field2133.isaacCipher);
               var14.packetBuffer.writeByte(var3.length() + 1);
               var14.packetBuffer.writeStringCp1252NullTerminated(var3);
               Client.field2133.method1281(var14);
               return 1;
            } else if (var0 == 3106) {
               var3 = Interpreter.field462[--Interpreter.field469];
               var14 = FaceNormal.method2884(ClientPacket.field1844, Client.field2133.isaacCipher);
               var14.packetBuffer.writeByte(var3.length() + 1);
               var14.packetBuffer.writeStringCp1252NullTerminated(var3);
               Client.field2133.method1281(var14);
               return 1;
            } else {
               String var7;
               int var15;
               if (var0 == 3107) {
                  var15 = Interpreter.field467[--class31.field364];
                  var7 = Interpreter.field462[--Interpreter.field469];
                  class17.method465(var15, var7);
                  return 1;
               } else if (var0 == 3108) {
                  class31.field364 -= 3;
                  var15 = Interpreter.field467[class31.field364];
                  var10 = Interpreter.field467[class31.field364 + 1];
                  int var9 = Interpreter.field467[class31.field364 + 2];
                  Widget var13 = WorldMapSection3.method1148(var9);
                  Occluder.method2989(var13, var15, var10);
                  return 1;
               } else if (var0 == 3109) {
                  class31.field364 -= 2;
                  var15 = Interpreter.field467[class31.field364];
                  var10 = Interpreter.field467[class31.field364 + 1];
                  Widget var11 = var2 ? class85.field961 : Interpreter.field477;
                  Occluder.method2989(var11, var15, var10);
                  return 1;
               } else if (var0 == 3110) {
                  WorldMapSection0.field1101 = Interpreter.field467[--class31.field364] == 1;
                  return 1;
               } else if (var0 == 3111) {
                  Interpreter.field467[++class31.field364 - 1] = GameShell.field72.roofsHidden ? 1 : 0;
                  return 1;
               } else if (var0 == 3112) {
                  GameShell.field72.roofsHidden = Interpreter.field467[--class31.field364] == 1;
                  Player.method840();
                  return 1;
               } else if (var0 == 3113) {
                  var3 = Interpreter.field462[--Interpreter.field469];
                  boolean var4 = Interpreter.field467[--class31.field364] == 1;
                  UrlRequest.isDone(var3, var4, false);
                  return 1;
               } else if (var0 == 3115) {
                  var15 = Interpreter.field467[--class31.field364];
                  var14 = FaceNormal.method2884(ClientPacket.field1878, Client.field2133.isaacCipher);
                  var14.packetBuffer.writeShort(var15);
                  Client.field2133.method1281(var14);
                  return 1;
               } else if (var0 == 3116) {
                  var15 = Interpreter.field467[--class31.field364];
                  Interpreter.field469 -= 2;
                  var7 = Interpreter.field462[Interpreter.field469];
                  String var5 = Interpreter.field462[Interpreter.field469 + 1];
                  if (var7.length() > 500) {
                     return 1;
                  } else if (var5.length() > 500) {
                     return 1;
                  } else {
                     PacketBufferNode var6 = FaceNormal.method2884(ClientPacket.field1852, Client.field2133.isaacCipher);
                     var6.packetBuffer.writeShort(1 + AbstractSoundSystem.method1696(var7) + AbstractSoundSystem.method1696(var5));
                     var6.packetBuffer.writeStringCp1252NullTerminated(var7);
                     var6.packetBuffer.writeByte(var15);
                     var6.packetBuffer.writeStringCp1252NullTerminated(var5);
                     Client.field2133.method1281(var6);
                     return 1;
                  }
               } else if (var0 == 3117) {
                  Client.field2232 = Interpreter.field467[--class31.field364] == 1;
                  return 1;
               } else if (var0 == 3118) {
                  Client.field2234 = Interpreter.field467[--class31.field364] == 1;
                  return 1;
               } else if (var0 == 3119) {
                  Client.field2205 = Interpreter.field467[--class31.field364] == 1;
                  return 1;
               } else if (var0 == 3120) {
                  if (Interpreter.field467[--class31.field364] == 1) {
                     Client.field2119 |= 1;
                  } else {
                     Client.field2119 &= -2;
                  }

                  return 1;
               } else if (var0 == 3121) {
                  if (Interpreter.field467[--class31.field364] == 1) {
                     Client.field2119 |= 2;
                  } else {
                     Client.field2119 &= -3;
                  }

                  return 1;
               } else if (var0 == 3122) {
                  if (Interpreter.field467[--class31.field364] == 1) {
                     Client.field2119 |= 4;
                  } else {
                     Client.field2119 &= -5;
                  }

                  return 1;
               } else if (var0 == 3123) {
                  if (Interpreter.field467[--class31.field364] == 1) {
                     Client.field2119 |= 8;
                  } else {
                     Client.field2119 &= -9;
                  }

                  return 1;
               } else if (var0 == 3124) {
                  Client.field2119 = 0;
                  return 1;
               } else if (var0 == 3125) {
                  Client.field2191 = Interpreter.field467[--class31.field364] == 1;
                  return 1;
               } else if (var0 == 3126) {
                  Client.field2201 = Interpreter.field467[--class31.field364] == 1;
                  return 1;
               } else if (var0 == 3127) {
                  class39.method979(Interpreter.field467[--class31.field364] == 1);
                  return 1;
               } else if (var0 == 3128) {
                  Interpreter.field467[++class31.field364 - 1] = Message.method1074() ? 1 : 0;
                  return 1;
               } else if (var0 == 3129) {
                  class31.field364 -= 2;
                  Client.field2166 = Interpreter.field467[class31.field364];
                  Client.field2167 = Interpreter.field467[class31.field364 + 1];
                  return 1;
               } else if (var0 == 3130) {
                  class31.field364 -= 2;
                  return 1;
               } else if (var0 == 3131) {
                  --class31.field364;
                  return 1;
               } else if (var0 == 3132) {
                  Interpreter.field467[++class31.field364 - 1] = FriendSystem.field379;
                  Interpreter.field467[++class31.field364 - 1] = UserComparator8.field1678;
                  return 1;
               } else if (var0 == 3133) {
                  --class31.field364;
                  return 1;
               } else if (var0 == 3134) {
                  return 1;
               } else if (var0 == 3135) {
                  class31.field364 -= 2;
                  return 1;
               } else if (var0 == 3136) {
                  Client.field2248 = 3;
                  Client.field2085 = Interpreter.field467[--class31.field364];
                  return 1;
               } else if (var0 == 3137) {
                  Client.field2248 = 2;
                  Client.field2085 = Interpreter.field467[--class31.field364];
                  return 1;
               } else if (var0 == 3138) {
                  Client.field2248 = 0;
                  return 1;
               } else if (var0 == 3139) {
                  Client.field2248 = 1;
                  return 1;
               } else if (var0 == 3140) {
                  Client.field2248 = 3;
                  Client.field2085 = var2 ? class85.field961.id : Interpreter.field477.id;
                  return 1;
               } else {
                  boolean var8;
                  if (var0 == 3141) {
                     var8 = Interpreter.field467[--class31.field364] == 1;
                     GameShell.field72.hideUsername = var8;
                     Player.method840();
                     return 1;
                  } else if (var0 == 3142) {
                     Interpreter.field467[++class31.field364 - 1] = GameShell.field72.hideUsername ? 1 : 0;
                     return 1;
                  } else if (var0 == 3143) {
                     var8 = Interpreter.field467[--class31.field364] == 1;
                     Client.field2189 = var8;
                     if (!var8) {
                        GameShell.field72.rememberedUsername = "";
                        Player.method840();
                     }

                     return 1;
                  } else if (var0 == 3144) {
                     Interpreter.field467[++class31.field364 - 1] = Client.field2189 ? 1 : 0;
                     return 1;
                  } else {
                     return var0 == 3145 ? 1 : 2;
                  }
               }
            }
         }
      }
   }
}
