public class class157 {
   public static void method3021(AbstractIndexCache var0, AbstractIndexCache var1) {
      NpcDefinition.field3601 = var0;
      NpcDefinition.field3574 = var1;
   }
}
