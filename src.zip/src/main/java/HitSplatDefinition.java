public class HitSplatDefinition extends DualNode {
   public static EvictingDualNodeHashTable field3358 = new EvictingDualNodeHashTable(64);
   public static AbstractIndexCache field3367;
   public static EvictingDualNodeHashTable field3362 = new EvictingDualNodeHashTable(20);
   public static EvictingDualNodeHashTable field3357 = new EvictingDualNodeHashTable(64);
   public static AbstractIndexCache field3375;
   int transformVarp = -1;
   public int field3369 = 0;
   public int field3363 = 16777215;
   int field3364 = -1;
   int field3355 = -1;
   public int field3356 = 70;
   public int field3370 = -1;
   int fontId = -1;
   int transformVarbit = -1;
   public int field3373 = -1;
   public int field3359 = 0;
   public int[] transforms;
   int field3366 = -1;
   int field3365 = -1;
   public int field3374 = 0;
   String field3372 = "";

   public String getString(int var1) {
      String var2 = this.field3372;

      while(true) {
         int var3 = var2.indexOf("%1");
         if (var3 < 0) {
            return var2;
         }

         var2 = var2.substring(0, var3) + WorldMapData2.method347(var1, false) + var2.substring(var3 + 2);
      }
   }

   public Sprite method5115() {
      if (this.field3364 < 0) {
         return null;
      } else {
         Sprite var1 = (Sprite)field3358.get((long)this.field3364);
         if (var1 != null) {
            return var1;
         } else {
            var1 = UserComparator3.method2971(field3375, this.field3364, 0);
            if (var1 != null) {
               field3358.put(var1, (long)this.field3364);
            }

            return var1;
         }
      }
   }

   void readNext(Buffer var1, int var2) {
      if (var2 == 1) {
         this.fontId = var1.method4040();
      } else if (var2 == 2) {
         this.field3363 = var1.readMedium();
      } else if (var2 == 3) {
         this.field3365 = var1.method4040();
      } else if (var2 == 4) {
         this.field3355 = var1.method4040();
      } else if (var2 == 5) {
         this.field3366 = var1.method4040();
      } else if (var2 == 6) {
         this.field3364 = var1.method4040();
      } else if (var2 == 7) {
         this.field3369 = var1.method3956();
      } else if (var2 == 8) {
         this.field3372 = var1.readStringCp1252NullCircumfixed();
      } else if (var2 == 9) {
         this.field3356 = var1.method3913();
      } else if (var2 == 10) {
         this.field3359 = var1.method3956();
      } else if (var2 == 11) {
         this.field3370 = 0;
      } else if (var2 == 12) {
         this.field3373 = var1.readUnsignedByte();
      } else if (var2 == 13) {
         this.field3374 = var1.method3956();
      } else if (var2 == 14) {
         this.field3370 = var1.method3913();
      } else if (var2 == 17 || var2 == 18) {
         this.transformVarbit = var1.method3913();
         if (this.transformVarbit == 65535) {
            this.transformVarbit = -1;
         }

         this.transformVarp = var1.method3913();
         if (this.transformVarp == 65535) {
            this.transformVarp = -1;
         }

         int var3 = -1;
         if (var2 == 18) {
            var3 = var1.method3913();
            if (var3 == 65535) {
               var3 = -1;
            }
         }

         int var4 = var1.readUnsignedByte();
         this.transforms = new int[var4 + 2];

         for(int var5 = 0; var5 <= var4; ++var5) {
            this.transforms[var5] = var1.method3913();
            if (this.transforms[var5] == 65535) {
               this.transforms[var5] = -1;
            }
         }

         this.transforms[var4 + 1] = var3;
      }

   }

   public Sprite method5140() {
      if (this.field3365 < 0) {
         return null;
      } else {
         Sprite var1 = (Sprite)field3358.get((long)this.field3365);
         if (var1 != null) {
            return var1;
         } else {
            var1 = UserComparator3.method2971(field3375, this.field3365, 0);
            if (var1 != null) {
               field3358.put(var1, (long)this.field3365);
            }

            return var1;
         }
      }
   }

   public Font getFont() {
      if (this.fontId == -1) {
         return null;
      } else {
         Font var1 = (Font)field3362.get((long)this.fontId);
         if (var1 != null) {
            return var1;
         } else {
            AbstractIndexCache var3 = field3375;
            AbstractIndexCache var4 = field3367;
            int var5 = this.fontId;
            Font var2;
            if (!class65.method1382(var3, var5, 0)) {
               var2 = null;
            } else {
               byte[] var7 = var4.takeRecord(var5, 0);
               Font var6;
               if (var7 == null) {
                  var6 = null;
               } else {
                  Font var8 = new Font(var7, class328.field3982, class328.field3984, class328.field3987, VarcInt.field2811, class328.field3986, class328.field3989);
                  class328.field3982 = null;
                  class328.field3984 = null;
                  class328.field3987 = null;
                  VarcInt.field2811 = null;
                  class328.field3986 = null;
                  class328.field3989 = null;
                  var6 = var8;
               }

               var2 = var6;
            }

            if (var2 != null) {
               field3362.put(var2, (long)this.fontId);
            }

            return var2;
         }
      }
   }

   public Sprite method5117() {
      if (this.field3355 < 0) {
         return null;
      } else {
         Sprite var1 = (Sprite)field3358.get((long)this.field3355);
         if (var1 != null) {
            return var1;
         } else {
            var1 = UserComparator3.method2971(field3375, this.field3355, 0);
            if (var1 != null) {
               field3358.put(var1, (long)this.field3355);
            }

            return var1;
         }
      }
   }

   public Sprite method5110() {
      if (this.field3366 < 0) {
         return null;
      } else {
         Sprite var1 = (Sprite)field3358.get((long)this.field3366);
         if (var1 != null) {
            return var1;
         } else {
            var1 = UserComparator3.method2971(field3375, this.field3366, 0);
            if (var1 != null) {
               field3358.put(var1, (long)this.field3366);
            }

            return var1;
         }
      }
   }

   public final HitSplatDefinition transform() {
      int var1 = -1;
      if (this.transformVarbit != -1) {
         var1 = AbstractSoundSystem.method1697(this.transformVarbit);
      } else if (this.transformVarp != -1) {
         var1 = Varps.field2762[this.transformVarp];
      }

      int var2;
      if (var1 >= 0 && var1 < this.transforms.length - 1) {
         var2 = this.transforms[var1];
      } else {
         var2 = this.transforms[this.transforms.length - 1];
      }

      return var2 != -1 ? class222.method4627(var2) : null;
   }

   void read(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.readNext(var1, var2);
      }
   }

   static double method5141(double var0) {
      return Math.exp(-var0 * var0 / 2.0D) / Math.sqrt(6.283185307179586D);
   }

   static final int method5112(int var0, int var1, int var2) {
      if (var2 > 179) {
         var1 /= 2;
      }

      if (var2 > 192) {
         var1 /= 2;
      }

      if (var2 > 217) {
         var1 /= 2;
      }

      if (var2 > 243) {
         var1 /= 2;
      }

      int var3 = (var1 / 32 << 7) + (var0 / 4 << 10) + var2 / 2;
      return var3;
   }

   static final void method5129(String var0) {
      if (!var0.equals("")) {
         PacketBufferNode var1 = FaceNormal.method2884(ClientPacket.field1920, Client.field2133.isaacCipher);
         var1.packetBuffer.writeByte(AbstractSoundSystem.method1696(var0));
         var1.packetBuffer.writeStringCp1252NullTerminated(var0);
         Client.field2133.method1281(var1);
      }
   }
}
