public class ModelData0 {
   static int field1555;

   public static boolean method2793(int var0) {
      return var0 == 10 || var0 == 11 || var0 == 12 || var0 == 13 || var0 == 14 || var0 == 15 || var0 == 16 || var0 == 17;
   }

   static String method2792(int var0) {
      return "<col=" + Integer.toHexString(var0) + ">";
   }
}
