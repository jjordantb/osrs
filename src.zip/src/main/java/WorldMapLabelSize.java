import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.SecureRandom;

public class WorldMapLabelSize {
   public static final WorldMapLabelSize field719 = new WorldMapLabelSize(0, 2, 0);
   public static final WorldMapLabelSize field717 = new WorldMapLabelSize(2, 0, 4);
   public static final WorldMapLabelSize field718 = new WorldMapLabelSize(1, 1, 2);
   static IndexCache field724;
   static SecureRandom field725;
   static Sprite field723;
   final int field722;
   final int field721;
   final int field720;

   WorldMapLabelSize(int var1, int var2, int var3) {
      this.field720 = var1;
      this.field722 = var2;
      this.field721 = var3;
   }

   boolean method1307(float var1) {
      return var1 >= (float)this.field721;
   }

   static WorldMapLabelSize method1302(int var0) {
      WorldMapLabelSize[] var1 = method1300();

      for(int var2 = 0; var2 < var1.length; ++var2) {
         WorldMapLabelSize var3 = var1[var2];
         if (var0 == var3.field722) {
            return var3;
         }
      }

      return null;
   }

   static WorldMapLabelSize[] method1300() {
      return new WorldMapLabelSize[]{field717, field719, field718};
   }

   static void method1303() {
      ItemContainer.field267 = new NodeHashTable(32);
   }

   public static void method1319(Buffer var0, int var1) {
      ReflectionCheck var2 = new ReflectionCheck();
      var2.size = var0.readUnsignedByte();
      var2.id = var0.readInt();
      var2.operations = new int[var2.size];
      var2.creationErrors = new int[var2.size];
      var2.fields = new Field[var2.size];
      var2.intReplaceValues = new int[var2.size];
      var2.methods = new Method[var2.size];
      var2.arguments = new byte[var2.size][][];

      for(int var3 = 0; var3 < var2.size; ++var3) {
         try {
            int var4 = var0.readUnsignedByte();
            String var5;
            String var6;
            int var7;
            if (var4 != 0 && var4 != 1 && var4 != 2) {
               if (var4 == 3 || var4 == 4) {
                  var5 = var0.readStringCp1252NullTerminated();
                  var6 = var0.readStringCp1252NullTerminated();
                  var7 = var0.readUnsignedByte();
                  String[] var8 = new String[var7];

                  for(int var9 = 0; var9 < var7; ++var9) {
                     var8[var9] = var0.readStringCp1252NullTerminated();
                  }

                  String var20 = var0.readStringCp1252NullTerminated();
                  byte[][] var10 = new byte[var7][];
                  int var12;
                  if (var4 == 3) {
                     for(int var11 = 0; var11 < var7; ++var11) {
                        var12 = var0.readInt();
                        var10[var11] = new byte[var12];
                        var0.method3923(var10[var11], 0, var12);
                     }
                  }

                  var2.operations[var3] = var4;
                  Class[] var21 = new Class[var7];

                  for(var12 = 0; var12 < var7; ++var12) {
                     var21[var12] = Formatting.method1026(var8[var12]);
                  }

                  Class var22 = Formatting.method1026(var20);
                  if (Formatting.method1026(var5).getClassLoader() == null) {
                     throw new SecurityException();
                  }

                  Method[] var13 = Formatting.method1026(var5).getDeclaredMethods();
                  Method[] var14 = var13;

                  for(int var15 = 0; var15 < var14.length; ++var15) {
                     Method var16 = var14[var15];
                     if (var16.getName().equals(var6)) {
                        Class[] var17 = var16.getParameterTypes();
                        if (var21.length == var17.length) {
                           boolean var18 = true;

                           for(int var19 = 0; var19 < var21.length; ++var19) {
                              if (var21[var19] != var17[var19]) {
                                 var18 = false;
                                 break;
                              }
                           }

                           if (var18 && var22 == var16.getReturnType()) {
                              var2.methods[var3] = var16;
                           }
                        }
                     }
                  }

                  var2.arguments[var3] = var10;
               }
            } else {
               var5 = var0.readStringCp1252NullTerminated();
               var6 = var0.readStringCp1252NullTerminated();
               var7 = 0;
               if (var4 == 1) {
                  var7 = var0.readInt();
               }

               var2.operations[var3] = var4;
               var2.intReplaceValues[var3] = var7;
               if (Formatting.method1026(var5).getClassLoader() == null) {
                  throw new SecurityException();
               }

               var2.fields[var3] = Formatting.method1026(var5).getDeclaredField(var6);
            }
         } catch (ClassNotFoundException var24) {
            var2.creationErrors[var3] = -1;
         } catch (SecurityException var25) {
            var2.creationErrors[var3] = -2;
         } catch (NullPointerException var26) {
            var2.creationErrors[var3] = -3;
         } catch (Exception var27) {
            var2.creationErrors[var3] = -4;
         } catch (Throwable var28) {
            var2.creationErrors[var3] = -5;
         }
      }

      class321.field3914.addFirst(var2);
   }

   static final void method1318(Widget var0, int var1) {
      if (var0.field2631 == null) {
         throw new RuntimeException();
      } else {
         if (var0.field2727 == null) {
            var0.field2727 = new int[var0.field2631.length];
         }

         var0.field2727[var1] = Integer.MAX_VALUE;
      }
   }

   static final void method1314() {
      int var0 = WorldMapSection2.field129 * 128 + 64;
      int var1 = class165.field1790 * 128 + 64;
      int var2 = MilliClock.method2923(var0, var1, class31.field363) - UrlRequest.field1615;
      if (class178.field1983 < var0) {
         class178.field1983 = (var0 - class178.field1983) * WorldMapManager.field46 / 1000 + class178.field1983 + ServerPacket.field2084;
         if (class178.field1983 > var0) {
            class178.field1983 = var0;
         }
      }

      if (class178.field1983 > var0) {
         class178.field1983 -= WorldMapManager.field46 * (class178.field1983 - var0) / 1000 + ServerPacket.field2084;
         if (class178.field1983 < var0) {
            class178.field1983 = var0;
         }
      }

      if (Buffer.field2445 < var2) {
         Buffer.field2445 = (var2 - Buffer.field2445) * WorldMapManager.field46 / 1000 + Buffer.field2445 + ServerPacket.field2084;
         if (Buffer.field2445 > var2) {
            Buffer.field2445 = var2;
         }
      }

      if (Buffer.field2445 > var2) {
         Buffer.field2445 -= WorldMapManager.field46 * (Buffer.field2445 - var2) / 1000 + ServerPacket.field2084;
         if (Buffer.field2445 < var2) {
            Buffer.field2445 = var2;
         }
      }

      if (Tiles.field219 < var1) {
         Tiles.field219 = (var1 - Tiles.field219) * WorldMapManager.field46 / 1000 + Tiles.field219 + ServerPacket.field2084;
         if (Tiles.field219 > var1) {
            Tiles.field219 = var1;
         }
      }

      if (Tiles.field219 > var1) {
         Tiles.field219 -= WorldMapManager.field46 * (Tiles.field219 - var1) / 1000 + ServerPacket.field2084;
         if (Tiles.field219 < var1) {
            Tiles.field219 = var1;
         }
      }

      var0 = ClientPreferences.field406 * 128 + 64;
      var1 = UserComparator8.field1680 * 128 + 64;
      var2 = MilliClock.method2923(var0, var1, class31.field363) - class103.field1124;
      int var3 = var0 - class178.field1983;
      int var4 = var2 - Buffer.field2445;
      int var5 = var1 - Tiles.field219;
      int var6 = (int)Math.sqrt((double)(var5 * var5 + var3 * var3));
      int var7 = (int)(Math.atan2((double)var4, (double)var6) * 325.949D) & 2047;
      int var8 = (int)(Math.atan2((double)var3, (double)var5) * -325.949D) & 2047;
      if (var7 < 128) {
         var7 = 128;
      }

      if (var7 > 383) {
         var7 = 383;
      }

      if (ScriptEvent.field547 < var7) {
         ScriptEvent.field547 = (var7 - ScriptEvent.field547) * class252.field3263 / 1000 + ScriptEvent.field547 + World.field362;
         if (ScriptEvent.field547 > var7) {
            ScriptEvent.field547 = var7;
         }
      }

      if (ScriptEvent.field547 > var7) {
         ScriptEvent.field547 -= class252.field3263 * (ScriptEvent.field547 - var7) / 1000 + World.field362;
         if (ScriptEvent.field547 < var7) {
            ScriptEvent.field547 = var7;
         }
      }

      int var9 = var8 - WorldMapSectionType.field1062;
      if (var9 > 1024) {
         var9 -= 2048;
      }

      if (var9 < -1024) {
         var9 += 2048;
      }

      if (var9 > 0) {
         WorldMapSectionType.field1062 = var9 * class252.field3263 / 1000 + WorldMapSectionType.field1062 + World.field362;
         WorldMapSectionType.field1062 &= 2047;
      }

      if (var9 < 0) {
         WorldMapSectionType.field1062 -= -var9 * class252.field3263 / 1000 + World.field362;
         WorldMapSectionType.field1062 &= 2047;
      }

      int var10 = var8 - WorldMapSectionType.field1062;
      if (var10 > 1024) {
         var10 -= 2048;
      }

      if (var10 < -1024) {
         var10 += 2048;
      }

      if (var10 < 0 && var9 > 0 || var10 > 0 && var9 < 0) {
         WorldMapSectionType.field1062 = var8;
      }

   }

   static boolean method1315() {
      return (Client.field2119 & 1) != 0;
   }

   static void method1317() {
      if (Client.field2161 == 1) {
         Client.field2169 = true;
      }

   }
}
