import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public final class KeyHandler implements KeyListener, FocusListener {
   public static short[] field16;
   public static int[] field12 = new int[128];
   public static int[] field8 = new int[128];
   static int[] field23 = new int[]{-1, -1, -1, -1, -1, -1, -1, -1, 85, 80, 84, -1, 91, -1, -1, -1, 81, 82, 86, -1, -1, -1, -1, -1, -1, -1, -1, 13, -1, -1, -1, -1, 83, 104, 105, 103, 102, 96, 98, 97, 99, -1, -1, -1, -1, -1, -1, -1, 25, 16, 17, 18, 19, 20, 21, 22, 23, 24, -1, -1, -1, -1, -1, -1, -1, 48, 68, 66, 50, 34, 51, 52, 53, 39, 54, 55, 56, 70, 69, 40, 41, 32, 35, 49, 36, 38, 67, 33, 65, 37, 64, -1, -1, -1, -1, -1, 228, 231, 227, 233, 224, 219, 225, 230, 226, 232, 89, 87, -1, 88, 229, 90, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, -1, -1, -1, 101, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 100, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
   public static KeyHandler field17 = new KeyHandler();
   public static int field21 = 0;
   static char[] field15 = new char[128];
   public static int field5 = 0;
   public static int field14 = 0;
   static int[] field0 = new int[128];
   public static int field20 = 0;
   public static int field19 = 0;
   public static int field18 = 0;
   public static volatile int field22 = 0;
   public static boolean[] field11 = new boolean[112];

   public final synchronized void keyPressed(KeyEvent var1) {
      if (field17 != null) {
         int var2 = var1.getKeyCode();
         if (var2 >= 0 && var2 < field23.length) {
            var2 = field23[var2];
            if ((var2 & 128) != 0) {
               var2 = -1;
            }
         } else {
            var2 = -1;
         }

         if (field14 >= 0 && var2 >= 0) {
            field12[field14] = var2;
            field14 = field14 + 1 & 127;
            if (field14 == field5) {
               field14 = -1;
            }
         }

         int var3;
         if (var2 >= 0) {
            var3 = field20 + 1 & 127;
            if (var3 != field19) {
               field0[field20] = var2;
               field15[field20] = 0;
               field20 = var3;
            }
         }

         var3 = var1.getModifiers();
         if ((var3 & 10) != 0 || var2 == 85 || var2 == 10) {
            var1.consume();
         }
      }

   }

   public final synchronized void keyReleased(KeyEvent var1) {
      if (field17 != null) {
         int var2 = var1.getKeyCode();
         if (var2 >= 0 && var2 < field23.length) {
            var2 = field23[var2] & -129;
         } else {
            var2 = -1;
         }

         if (field14 >= 0 && var2 >= 0) {
            field12[field14] = ~var2;
            field14 = field14 + 1 & 127;
            if (field5 == field14) {
               field14 = -1;
            }
         }
      }

      var1.consume();
   }

   public final void keyTyped(KeyEvent var1) {
      if (field17 != null) {
         char var2 = var1.getKeyChar();
         if (var2 != 0 && var2 != '\uffff') {
            boolean var3;
            if (var2 > 0 && var2 < '\u0080' || var2 >= ' ' && var2 <= 'ÿ') {
               var3 = true;
            } else {
               label60: {
                  if (var2 != 0) {
                     char[] var7 = class301.field3761;

                     for(int var5 = 0; var5 < var7.length; ++var5) {
                        char var6 = var7[var5];
                        if (var6 == var2) {
                           var3 = true;
                           break label60;
                        }
                     }
                  }

                  var3 = false;
               }
            }

            if (var3) {
               int var4 = field20 + 1 & 127;
               if (var4 != field19) {
                  field0[field20] = -1;
                  field15[field20] = var2;
                  field20 = var4;
               }
            }
         }
      }

      var1.consume();
   }

   public final synchronized void focusLost(FocusEvent var1) {
      if (field17 != null) {
         field14 = -1;
      }

   }

   public final void focusGained(FocusEvent var1) {
   }

   static final void method26(Actor var0) {
      if (var0.field285 != 0) {
         if (var0.targetIndex != -1) {
            Object var1 = null;
            if (var0.targetIndex < 32768) {
               var1 = Client.field2249[var0.targetIndex];
            } else if (var0.targetIndex >= 32768) {
               var1 = Client.field2141[var0.targetIndex - '耀'];
            }

            if (var1 != null) {
               int var2 = var0.x - ((Actor)var1).x;
               int var3 = var0.y - ((Actor)var1).y;
               if (var2 != 0 || var3 != 0) {
                  var0.orientation = (int)(Math.atan2((double)var2, (double)var3) * 325.949D) & 2047;
               }
            } else if (var0.false0) {
               var0.targetIndex = -1;
               var0.false0 = false;
            }
         }

         if (var0.field305 != -1 && (var0.pathLength == 0 || var0.field293 > 0)) {
            var0.orientation = var0.field305;
            var0.field305 = -1;
         }

         int var4 = var0.orientation - var0.field278 & 2047;
         if (var4 == 0 && var0.false0) {
            var0.targetIndex = -1;
            var0.false0 = false;
         }

         if (var4 != 0) {
            ++var0.field329;
            boolean var6;
            if (var4 > 1024) {
               var0.field278 -= var0.field285;
               var6 = true;
               if (var4 < var0.field285 || var4 > 2048 - var0.field285) {
                  var0.field278 = var0.orientation;
                  var6 = false;
               }

               if (var0.movementSequence == var0.idleSequence && (var0.field329 > 25 || var6)) {
                  if (var0.turnLeftSequence != -1) {
                     var0.movementSequence = var0.turnLeftSequence;
                  } else {
                     var0.movementSequence = var0.walkSequence;
                  }
               }
            } else {
               var0.field278 += var0.field285;
               var6 = true;
               if (var4 < var0.field285 || var4 > 2048 - var0.field285) {
                  var0.field278 = var0.orientation;
                  var6 = false;
               }

               if (var0.movementSequence == var0.idleSequence && (var0.field329 > 25 || var6)) {
                  if (var0.turnRightSequence != -1) {
                     var0.movementSequence = var0.turnRightSequence;
                  } else {
                     var0.movementSequence = var0.walkSequence;
                  }
               }
            }

            var0.field278 &= 2047;
         } else {
            var0.field329 = 0;
         }

      }
   }
}
