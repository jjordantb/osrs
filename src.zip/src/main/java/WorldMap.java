import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class WorldMap {
   static final FontName field3844;
   static final FontName field3843;
   static final FontName field3842;
   long field3874;
   int field3883 = -1;
   boolean field3866 = false;
   int field3876;
   int field3880 = 50;
   int field3861 = -1;
   int field3869 = -1;
   HashSet field3855 = new HashSet();
   int field3867;
   int field3868 = -1;
   boolean field3885 = true;
   HashSet field3870 = new HashSet();
   int field3895 = -1;
   HashSet field3862 = new HashSet();
   int field3871 = -1;
   int field3856 = -1;
   int field3872 = -1;
   int field3892 = 0;
   boolean field3884 = false;
   int field3864 = 3;
   int field3863 = -1;
   HashSet field3893 = new HashSet();
   HashSet field3837 = null;
   Iterator field3888;
   int field3896 = -1;
   int field3894 = -1;
   HashSet field3889 = new HashSet();
   int field3853 = -1;
   TileLocation field3890 = null;
   Sprite sprite;
   final int[] field3886 = new int[]{1008, 1009, 1010, 1011, 1012};
   public boolean field3891 = false;
   int field3858;
   List field3887;
   WorldMapIndexCacheLoader cacheLoader;
   AbstractIndexCache indexCache;
   IndexedSprite[] mapSceneSprites;
   WorldMapManager worldMapManager;
   WorldMapData field3851;
   HashMap field3879;
   int field3877;
   HashMap fonts;
   int field3849 = -1;
   Font font;
   int field3857 = -1;
   int field3865;
   float field3859;
   WorldMapData worldMapData;
   WorldMapData field3848;
   float field3839;
   int field3873 = -1;

   static {
      field3842 = FontName.field3738;
      field3843 = FontName.field3739;
      field3844 = FontName.field3740;
   }

   public void method6047(int var1, int var2, int var3) {
      if (this.worldMapData != null) {
         int[] var4 = this.worldMapData.method1493(var1, var2, var3);
         if (var4 != null) {
            this.method6133(var4[0], var4[1]);
         }

      }
   }

   public WorldMapData method6043(int var1) {
      Iterator var2 = this.field3879.values().iterator();

      WorldMapData var3;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         var3 = (WorldMapData)var2.next();
      } while(var3.method1496() != var1);

      return var3;
   }

   float method6039(int var1) {
      if (var1 == 25) {
         return 1.0F;
      } else if (var1 == 37) {
         return 1.5F;
      } else if (var1 == 50) {
         return 2.0F;
      } else if (var1 == 75) {
         return 3.0F;
      } else {
         return var1 == 100 ? 4.0F : 8.0F;
      }
   }

   public int method6049() {
      return this.worldMapData == null ? -1 : this.field3877 + this.worldMapData.method1494() * 64;
   }

   void drawLoading(int var1, int var2, int var3, int var4, int var5) {
      byte var6 = 20;
      int var7 = var3 / 2 + var1;
      int var8 = var4 / 2 + var2 - 18 - var6;
      Rasterizer2D.method6223(var1, var2, var3, var4, -16777216);
      Rasterizer2D.method6292(var7 - 152, var8, 304, 34, -65536);
      Rasterizer2D.method6223(var7 - 150, var8 + 2, var5 * 3, 30, -65536);
      this.font.drawCentered("Loading...", var7, var8 + var6, -1, -1);
   }

   boolean method6034(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (this.sprite == null) {
         return true;
      } else if (this.sprite.subWidth == var1 && this.sprite.subHeight == var2) {
         if (this.worldMapManager.field44 != this.field3858) {
            return true;
         } else if (this.field3896 != Client.field2357) {
            return true;
         } else if (var3 <= 0 && var4 <= 0) {
            return var3 + var1 < var5 || var2 + var4 < var6;
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   public boolean isCacheLoaded() {
      return this.cacheLoader.isLoaded();
   }

   public void method6055(int var1) {
      if (var1 >= 1) {
         this.field3880 = var1;
      }

   }

   public int method6063() {
      return this.worldMapData == null ? -1 : this.field3865 + this.worldMapData.method1523() * 64;
   }

   public void loadCache() {
      this.cacheLoader.load();
   }

   public int method6051() {
      return this.field3849;
   }

   public TileLocation method6050() {
      return this.worldMapData == null ? null : this.worldMapData.method1522(this.method6063(), this.method6049());
   }

   public void method6053(int var1) {
      if (var1 >= 1) {
         this.field3864 = var1;
      }

   }

   void method6065(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (UserComparator9.field1598 != null) {
         int var7 = 512 / (this.worldMapManager.field44 * 2);
         int var8 = var3 + 512;
         int var9 = var4 + 512;
         float var10 = 1.0F;
         var8 = (int)((float)var8 / var10);
         var9 = (int)((float)var9 / var10);
         int var11 = this.method6063() - var5 / 2 - var7;
         int var12 = this.method6049() - var6 / 2 - var7;
         int var13 = var1 - (var11 + var7 - this.field3894) * this.worldMapManager.field44;
         int var14 = var2 - this.worldMapManager.field44 * (var7 - (var12 - this.field3853));
         if (this.method6034(var8, var9, var13, var14, var3, var4)) {
            if (this.sprite != null && this.sprite.subWidth == var8 && this.sprite.subHeight == var9) {
               Arrays.fill(this.sprite.pixels, 0);
            } else {
               this.sprite = new Sprite(var8, var9);
            }

            this.field3894 = this.method6063() - var5 / 2 - var7;
            this.field3853 = this.method6049() - var6 / 2 - var7;
            this.field3858 = this.worldMapManager.field44;
            UserComparator9.field1598.method4949(this.field3894, this.field3853, this.sprite, (float)this.field3858 / var10);
            this.field3896 = Client.field2357;
            var13 = var1 - (var11 + var7 - this.field3894) * this.worldMapManager.field44;
            var14 = var2 - this.worldMapManager.field44 * (var7 - (var12 - this.field3853));
         }

         Rasterizer2D.method6222(var1, var2, var3, var4, 0, 128);
         if (var10 == 1.0F) {
            this.sprite.method6370(var13, var14, 192);
         } else {
            this.sprite.method6429(var13, var14, (int)(var10 * (float)var8), (int)((float)var9 * var10), 192);
         }
      }

   }

   public int method6052() {
      return this.field3861;
   }

   public void method6056() {
      this.field3880 = 50;
   }

   public void method6059(int var1) {
      this.field3837 = new HashSet();
      this.field3868 = 0;
      this.field3869 = 0;

      for(int var2 = 0; var2 < AreaDefinition.field2901; ++var2) {
         if (Clock.mark(var2) != null && Clock.mark(var2).field2887 == var1) {
            this.field3837.add(Clock.mark(var2).field2883);
         }
      }

   }

   public void method6182(int var1, int var2) {
      if (this.worldMapData != null && this.worldMapData.method1492(var1, var2)) {
         this.field3873 = var1 - this.worldMapData.method1523() * 64;
         this.field3857 = var2 - this.worldMapData.method1494() * 64;
      }
   }

   public void method6046(int var1, int var2, int var3) {
      if (this.worldMapData != null) {
         int[] var4 = this.worldMapData.method1493(var1, var2, var3);
         if (var4 != null) {
            this.method6182(var4[0], var4[1]);
         }

      }
   }

   public void method6133(int var1, int var2) {
      if (this.worldMapData != null) {
         this.method6021(var1 - this.worldMapData.method1523() * 64, var2 - this.worldMapData.method1494() * 64, true);
         this.field3873 = -1;
         this.field3857 = -1;
      }
   }

   public void method6071(int var1) {
      this.field3837 = new HashSet();
      this.field3837.add(var1);
      this.field3868 = 0;
      this.field3869 = 0;
   }

   public void method6110(boolean var1) {
      this.field3866 = var1;
   }

   public void method6020(int var1) {
      this.field3859 = this.method6039(var1);
   }

   public void drawOverview(int var1, int var2, int var3, int var4) {
      if (this.cacheLoader.isLoaded()) {
         if (!this.worldMapManager.method109()) {
            this.worldMapManager.method101(this.indexCache, this.worldMapData.archiveName(), Client.field2090);
            if (!this.worldMapManager.method109()) {
               return;
            }
         }

         this.worldMapManager.method106(var1, var2, var3, var4, this.field3837, this.field3869, this.field3880);
      }
   }

   public void method6054() {
      this.field3864 = 3;
   }

   public int method6085() {
      if (1.0D == (double)this.field3859) {
         return 25;
      } else if ((double)this.field3859 == 1.5D) {
         return 37;
      } else if (2.0D == (double)this.field3859) {
         return 50;
      } else if (3.0D == (double)this.field3859) {
         return 75;
      } else {
         return 4.0D == (double)this.field3859 ? 100 : 200;
      }
   }

   public void method6019(int var1, boolean var2) {
      if (!var2) {
         this.field3870.add(var1);
      } else {
         this.field3870.remove(var1);
      }

      this.method6067();
   }

   public void method6070(int var1, int var2, TileLocation var3, TileLocation var4) {
      ScriptEvent var5 = new ScriptEvent();
      class17 var6 = new class17(var2, var3, var4);
      var5.method1031(new Object[]{var6});
      switch(var1) {
      case 1008:
         var5.method1033(10);
         break;
      case 1009:
         var5.method1033(11);
         break;
      case 1010:
         var5.method1033(12);
         break;
      case 1011:
         var5.method1033(13);
         break;
      case 1012:
         var5.method1033(14);
      }

      IndexCacheLoader.method1096(var5);
   }

   public WorldMapIcon method6072() {
      if (this.field3888 == null) {
         return null;
      } else {
         return !this.field3888.hasNext() ? null : (WorldMapIcon)this.field3888.next();
      }
   }

   public void method6114(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (this.cacheLoader.isLoaded()) {
         int var7 = (int)Math.ceil((double)((float)var3 / this.field3839));
         int var8 = (int)Math.ceil((double)((float)var4 / this.field3839));
         List var9 = this.worldMapManager.method107(this.field3865 - var7 / 2 - 1, this.field3877 - var8 / 2 - 1, var7 / 2 + this.field3865 + 1, var8 / 2 + this.field3877 + 1, var1, var2, var3, var4, var5, var6);
         if (!var9.isEmpty()) {
            Iterator var10 = var9.iterator();

            boolean var13;
            do {
               if (!var10.hasNext()) {
                  return;
               }

               WorldMapIcon var11 = (WorldMapIcon)var10.next();
               AreaDefinition var12 = Clock.mark(var11.field252);
               var13 = false;

               for(int var14 = this.field3886.length - 1; var14 >= 0; --var14) {
                  if (var12.strings[var14] != null) {
                     Login.method1253(var12.strings[var14], var12.string1, this.field3886[var14], var11.field252, var11.field246.method4751(), var11.field244.method4751());
                     var13 = true;
                  }
               }
            } while(!var13);

         }
      }
   }

   public void method6016(int var1, boolean var2) {
      if (!var2) {
         this.field3893.add(var1);
      } else {
         this.field3893.remove(var1);
      }

      for(int var3 = 0; var3 < AreaDefinition.field2901; ++var3) {
         if (Clock.mark(var3) != null && Clock.mark(var3).field2887 == var1) {
            int var4 = Clock.mark(var3).field2883;
            if (!var2) {
               this.field3855.add(var4);
            } else {
               this.field3855.remove(var4);
            }
         }
      }

      this.method6067();
   }

   public TileLocation method6069(int var1, TileLocation var2) {
      if (!this.cacheLoader.isLoaded()) {
         return null;
      } else if (!this.worldMapManager.method109()) {
         return null;
      } else if (!this.worldMapData.method1492(var2.x, var2.y)) {
         return null;
      } else {
         HashMap var3 = this.worldMapManager.buildIcons();
         List var4 = (List)var3.get(var1);
         if (var4 != null && !var4.isEmpty()) {
            WorldMapIcon var5 = null;
            int var6 = -1;
            Iterator var7 = var4.iterator();

            while(true) {
               WorldMapIcon var8;
               int var11;
               do {
                  if (!var7.hasNext()) {
                     return var5.field244;
                  }

                  var8 = (WorldMapIcon)var7.next();
                  int var9 = var8.field244.x - var2.x;
                  int var10 = var8.field244.y - var2.y;
                  var11 = var10 * var10 + var9 * var9;
                  if (var11 == 0) {
                     return var8.field244;
                  }
               } while(var11 >= var6 && var5 != null);

               var5 = var8;
               var6 = var11;
            }
         } else {
            return null;
         }
      }
   }

   public WorldMapIcon method6202() {
      if (!this.cacheLoader.isLoaded()) {
         return null;
      } else if (!this.worldMapManager.method109()) {
         return null;
      } else {
         HashMap var1 = this.worldMapManager.buildIcons();
         this.field3887 = new LinkedList();
         Iterator var2 = var1.values().iterator();

         while(var2.hasNext()) {
            List var3 = (List)var2.next();
            this.field3887.addAll(var3);
         }

         this.field3888 = this.field3887.iterator();
         return this.method6072();
      }
   }

   public boolean method6064() {
      return !this.field3884;
   }

   public boolean method6068(int var1) {
      return !this.field3893.contains(var1);
   }

   public void method6060() {
      this.field3837 = null;
   }

   public boolean method6066(int var1) {
      return !this.field3870.contains(var1);
   }

   void method6067() {
      this.field3862.clear();
      this.field3862.addAll(this.field3870);
      this.field3862.addAll(this.field3855);
   }

   public void method6188(boolean var1) {
      this.field3884 = !var1;
   }

   public int method6032() {
      return this.worldMapData == null ? -1 : this.worldMapData.method1496();
   }

   public void method6175(int var1, int var2, boolean var3, boolean var4) {
      long var5 = Tile.method2779();
      this.method6018(var1, var2, var4, var5);
      if (!this.method6173() && (var4 || var3)) {
         if (var4) {
            this.field3872 = var1;
            this.field3856 = var2;
            this.field3883 = this.field3865;
            this.field3871 = this.field3877;
         }

         if (this.field3883 != -1) {
            int var7 = var1 - this.field3872;
            int var8 = var2 - this.field3856;
            this.method6021(this.field3883 - (int)((float)var7 / this.field3859), (int)((float)var8 / this.field3859) + this.field3871, false);
         }
      } else {
         this.method6027();
      }

      if (var4) {
         this.field3874 = var5;
         this.field3867 = var1;
         this.field3876 = var2;
      }

   }

   final void method6021(int var1, int var2, boolean var3) {
      this.field3865 = var1;
      this.field3877 = var2;
      Tile.method2779();
      if (var3) {
         this.method6027();
      }

   }

   public void method6048() {
      class165.method3138();
   }

   public void method6026(int var1) {
      WorldMapData var2 = this.method6043(var1);
      if (var2 != null) {
         this.method6029(var2);
      }

   }

   public void init(AbstractIndexCache var1, Font var2, HashMap var3, IndexedSprite[] var4) {
      this.mapSceneSprites = var4;
      this.indexCache = var1;
      this.font = var2;
      this.fonts = new HashMap();
      this.fonts.put(WorldMapLabelSize.field717, var3.get(field3842));
      this.fonts.put(WorldMapLabelSize.field718, var3.get(field3843));
      this.fonts.put(WorldMapLabelSize.field719, var3.get(field3844));
      this.cacheLoader = new WorldMapIndexCacheLoader(var1);
      int var5 = this.indexCache.getArchiveId(WorldMapCacheName.field235.name);
      int[] var6 = this.indexCache.method4975(var5);
      this.field3879 = new HashMap(var6.length);

      for(int var7 = 0; var7 < var6.length; ++var7) {
         Buffer var8 = new Buffer(this.indexCache.takeRecord(var5, var6[var7]));
         WorldMapData var9 = new WorldMapData();
         var9.read(var8, var6[var7]);
         this.field3879.put(var9.archiveName(), var9);
         if (var9.method1497()) {
            this.field3848 = var9;
         }
      }

      this.method6029(this.field3848);
      this.field3851 = null;
   }

   public void method6025(int var1, int var2, int var3, boolean var4) {
      WorldMapData var5 = this.method6024(var1, var2, var3);
      if (var5 == null) {
         if (!var4) {
            return;
         }

         var5 = this.field3848;
      }

      boolean var6 = false;
      if (var5 != this.field3851 || var4) {
         this.field3851 = var5;
         this.method6029(var5);
         var6 = true;
      }

      if (var6 || var4) {
         this.method6030(var1, var2, var3);
      }

   }

   void method6018(int var1, int var2, boolean var3, long var4) {
      if (this.worldMapData != null) {
         int var6 = (int)((float)this.field3865 + ((float)(var1 - this.field3895) - (float)this.method6051() * this.field3839 / 2.0F) / this.field3839);
         int var7 = (int)((float)this.field3877 - ((float)(var2 - this.field3863) - (float)this.method6052() * this.field3839 / 2.0F) / this.field3839);
         this.field3890 = this.worldMapData.method1522(var6 + this.worldMapData.method1523() * 64, var7 + this.worldMapData.method1494() * 64);
         if (this.field3890 != null && var3) {
            if (SecureRandomCallable.method1019() && KeyHandler.field11[82] && KeyHandler.field11[81]) {
               class21.method543(this.field3890.x, this.field3890.y, this.field3890.plane, false);
            } else {
               boolean var8 = true;
               if (this.field3885) {
                  int var9 = var1 - this.field3867;
                  int var10 = var2 - this.field3876;
                  if (var4 - this.field3874 > 500L || var9 < -25 || var9 > 25 || var10 < -25 || var10 > 25) {
                     var8 = false;
                  }
               }

               if (var8) {
                  PacketBufferNode var11 = FaceNormal.method2884(ClientPacket.field1858, Client.field2133.isaacCipher);
                  var11.packetBuffer.writeIntME(this.field3890.method4751());
                  Client.field2133.method1281(var11);
                  this.field3874 = 0L;
               }
            }
         }
      } else {
         this.field3890 = null;
      }

   }

   final void method6027() {
      this.field3856 = -1;
      this.field3872 = -1;
      this.field3871 = -1;
      this.field3883 = -1;
   }

   void method6029(WorldMapData var1) {
      if (this.worldMapData == null || var1 != this.worldMapData) {
         this.initializeWorldMapManager(var1);
         this.method6030(-1, -1, -1);
      }
   }

   void method6099() {
      if (this.method6173()) {
         int var1 = this.field3873 - this.field3865;
         int var2 = this.field3857 - this.field3877;
         if (var1 != 0) {
            var1 /= Math.min(8, Math.abs(var1));
         }

         if (var2 != 0) {
            var2 /= Math.min(8, Math.abs(var2));
         }

         this.method6021(var1 + this.field3865, var2 + this.field3877, true);
         if (this.field3873 == this.field3865 && this.field3857 == this.field3877) {
            this.field3873 = -1;
            this.field3857 = -1;
         }

      }
   }

   public void draw(int var1, int var2, int var3, int var4, int var5) {
      int[] var6 = new int[4];
      Rasterizer2D.method6286(var6);
      Rasterizer2D.method6243(var1, var2, var3 + var1, var2 + var4);
      Rasterizer2D.method6223(var1, var2, var3, var4, -16777216);
      int var7 = this.cacheLoader.percentLoaded();
      if (var7 < 100) {
         this.drawLoading(var1, var2, var3, var4, var7);
      } else {
         if (!this.worldMapManager.method109()) {
            this.worldMapManager.method101(this.indexCache, this.worldMapData.archiveName(), Client.field2090);
            if (!this.worldMapManager.method109()) {
               return;
            }
         }

         if (this.field3837 != null) {
            ++this.field3869;
            if (this.field3869 % this.field3880 == 0) {
               this.field3869 = 0;
               ++this.field3868;
            }

            if (this.field3868 >= this.field3864 && !this.field3866) {
               this.field3837 = null;
            }
         }

         int var8 = (int)Math.ceil((double)((float)var3 / this.field3839));
         int var9 = (int)Math.ceil((double)((float)var4 / this.field3839));
         this.worldMapManager.method103(this.field3865 - var8 / 2, this.field3877 - var9 / 2, var8 / 2 + this.field3865, var9 / 2 + this.field3877, var1, var2, var3 + var1, var2 + var4);
         if (!this.field3884) {
            boolean var10 = false;
            if (var5 - this.field3892 > 100) {
               this.field3892 = var5;
               var10 = true;
            }

            this.worldMapManager.method115(this.field3865 - var8 / 2, this.field3877 - var9 / 2, var8 / 2 + this.field3865, var9 / 2 + this.field3877, var1, var2, var3 + var1, var2 + var4, this.field3862, this.field3837, this.field3869, this.field3880, var10);
         }

         this.method6065(var1, var2, var3, var4, var8, var9);
         if (SecureRandomCallable.method1019() && this.field3891 && this.field3890 != null) {
            this.font.draw("Coord: " + this.field3890, Rasterizer2D.field3897 + 10, Rasterizer2D.field3902 + 20, 16776960, -1);
         }

         this.field3849 = var8;
         this.field3861 = var9;
         this.field3895 = var1;
         this.field3863 = var2;
         Rasterizer2D.method6226(var6);
      }
   }

   void method6111() {
      if (UserComparator9.field1598 != null) {
         this.field3839 = this.field3859;
      } else {
         if (this.field3839 < this.field3859) {
            this.field3839 = Math.min(this.field3859, this.field3839 / 30.0F + this.field3839);
         }

         if (this.field3839 > this.field3859) {
            this.field3839 = Math.max(this.field3859, this.field3839 - this.field3839 / 30.0F);
         }

      }
   }

   public void method6015(int var1, int var2, boolean var3, int var4, int var5, int var6, int var7) {
      if (this.cacheLoader.isLoaded()) {
         this.method6111();
         this.method6099();
         if (var3) {
            int var8 = (int)Math.ceil((double)((float)var6 / this.field3839));
            int var9 = (int)Math.ceil((double)((float)var7 / this.field3839));
            List var10 = this.worldMapManager.method107(this.field3865 - var8 / 2 - 1, this.field3877 - var9 / 2 - 1, var8 / 2 + this.field3865 + 1, var9 / 2 + this.field3877 + 1, var4, var5, var6, var7, var1, var2);
            HashSet var11 = new HashSet();

            Iterator var12;
            WorldMapIcon var13;
            ScriptEvent var14;
            class17 var15;
            for(var12 = var10.iterator(); var12.hasNext(); IndexCacheLoader.method1096(var14)) {
               var13 = (WorldMapIcon)var12.next();
               var11.add(var13);
               var14 = new ScriptEvent();
               var15 = new class17(var13.field252, var13.field246, var13.field244);
               var14.method1031(new Object[]{var15, var1, var2});
               if (this.field3889.contains(var13)) {
                  var14.method1033(17);
               } else {
                  var14.method1033(15);
               }
            }

            var12 = this.field3889.iterator();

            while(var12.hasNext()) {
               var13 = (WorldMapIcon)var12.next();
               if (!var11.contains(var13)) {
                  var14 = new ScriptEvent();
                  var15 = new class17(var13.field252, var13.field246, var13.field244);
                  var14.method1031(new Object[]{var15, var1, var2});
                  var14.method1033(16);
                  IndexCacheLoader.method1096(var14);
               }
            }

            this.field3889 = var11;
         }
      }
   }

   public int method6017() {
      return this.indexCache.tryLoadRecordByNames(this.field3848.archiveName(), WorldMapCacheName.field234.name) ? 100 : this.indexCache.archiveLoadPercentByName(this.field3848.archiveName());
   }

   void initializeWorldMapManager(WorldMapData var1) {
      this.worldMapData = var1;
      this.worldMapManager = new WorldMapManager(this.mapSceneSprites, this.fonts);
      this.cacheLoader.reset(this.worldMapData.archiveName());
   }

   public WorldMapData method6028() {
      return this.worldMapData;
   }

   void method6030(int var1, int var2, int var3) {
      if (this.worldMapData != null) {
         int[] var4 = this.worldMapData.method1493(var1, var2, var3);
         if (var4 == null) {
            var4 = this.worldMapData.method1493(this.worldMapData.method1499(), this.worldMapData.method1546(), this.worldMapData.method1508());
         }

         this.method6021(var4[0] - this.worldMapData.method1523() * 64, var4[1] - this.worldMapData.method1494() * 64, true);
         this.field3873 = -1;
         this.field3857 = -1;
         this.field3839 = this.method6039(this.worldMapData.method1501());
         this.field3859 = this.field3839;
         this.field3887 = null;
         this.field3888 = null;
         this.worldMapManager.method113();
      }
   }

   public WorldMapData method6024(int var1, int var2, int var3) {
      Iterator var4 = this.field3879.values().iterator();

      WorldMapData var5;
      do {
         if (!var4.hasNext()) {
            return null;
         }

         var5 = (WorldMapData)var4.next();
      } while(!var5.method1491(var1, var2, var3));

      return var5;
   }

   boolean method6173() {
      return this.field3873 != -1 && this.field3857 != -1;
   }

   public void method6031(WorldMapData var1, TileLocation var2, TileLocation var3, boolean var4) {
      if (var1 != null) {
         if (this.worldMapData == null || var1 != this.worldMapData) {
            this.initializeWorldMapManager(var1);
         }

         if (!var4 && this.worldMapData.method1491(var2.plane, var2.x, var2.y)) {
            this.method6030(var2.plane, var2.x, var2.y);
         } else {
            this.method6030(var3.plane, var3.x, var3.y);
         }

      }
   }
}
