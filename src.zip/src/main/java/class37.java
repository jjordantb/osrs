import java.io.IOException;
import java.net.Socket;

public final class class37 extends Node {
   int field448;
   int field447;
   int field446;
   int field458;
   int field455;
   int field459;
   int field457 = -1;
   int field454;
   int field456 = 0;
   int field449;
   int field450;
   int field453;

   public static ServerPacket[] method859() {
      return new ServerPacket[]{ServerPacket.field2056, ServerPacket.field2037, ServerPacket.field1997, ServerPacket.field2065, ServerPacket.field1999, ServerPacket.field2000, ServerPacket.field2001, ServerPacket.field2077, ServerPacket.field2003, ServerPacket.field2004, ServerPacket.field2005, ServerPacket.field2006, ServerPacket.field2007, ServerPacket.field2008, ServerPacket.field1996, ServerPacket.field2010, ServerPacket.field2011, ServerPacket.field2012, ServerPacket.field2047, ServerPacket.field2014, ServerPacket.field2002, ServerPacket.field2043, ServerPacket.field2017, ServerPacket.field2018, ServerPacket.field2019, ServerPacket.field2076, ServerPacket.field2021, ServerPacket.field2059, ServerPacket.field2023, ServerPacket.field2024, ServerPacket.field2025, ServerPacket.field2026, ServerPacket.field2027, ServerPacket.field2053, ServerPacket.field2022, ServerPacket.field2030, ServerPacket.field2031, ServerPacket.field2078, ServerPacket.field2033, ServerPacket.field2083, ServerPacket.field2035, ServerPacket.field2036, ServerPacket.field2081, ServerPacket.field2034, ServerPacket.field2039, ServerPacket.field2040, ServerPacket.field2041, ServerPacket.field2042, ServerPacket.field2073, ServerPacket.field2072, ServerPacket.field2045, ServerPacket.field2046, ServerPacket.field2068, ServerPacket.field2048, ServerPacket.field2049, ServerPacket.field2038, ServerPacket.field2051, ServerPacket.field2052, ServerPacket.field2071, ServerPacket.field2054, ServerPacket.field2055, ServerPacket.field2016, ServerPacket.field2057, ServerPacket.field2058, ServerPacket.field2050, ServerPacket.field2060, ServerPacket.field2061, ServerPacket.field2062, ServerPacket.field2063, ServerPacket.field2064, ServerPacket.field2074, ServerPacket.field2066, ServerPacket.field2067, ServerPacket.field2032, ServerPacket.field2069, ServerPacket.field2070, ServerPacket.field1998, ServerPacket.field2015, ServerPacket.field2009, ServerPacket.field2079, ServerPacket.field2075, ServerPacket.field2013, ServerPacket.field2020, ServerPacket.field2044, ServerPacket.field2082};
   }

   public static AbstractSocket method860(Socket var0, int var1, int var2) throws IOException {
      return new BufferedNetSocket(var0, var1, var2);
   }

   static int method861(int var0, Script var1, boolean var2) {
      Widget var3 = var2 ? class85.field961 : Interpreter.field477;
      if (var0 == 1800) {
         Interpreter.field467[++class31.field364 - 1] = class71.method1463(class257.method5068(var3));
         return 1;
      } else if (var0 != 1801) {
         if (var0 == 1802) {
            if (var3.dataText == null) {
               Interpreter.field462[++Interpreter.field469 - 1] = "";
            } else {
               Interpreter.field462[++Interpreter.field469 - 1] = var3.dataText;
            }

            return 1;
         } else {
            return 2;
         }
      } else {
         int var4 = Interpreter.field467[--class31.field364];
         --var4;
         if (var3.actions != null && var4 < var3.actions.length && var3.actions[var4] != null) {
            Interpreter.field462[++Interpreter.field469 - 1] = var3.actions[var4];
         } else {
            Interpreter.field462[++Interpreter.field469 - 1] = "";
         }

         return 1;
      }
   }
}
