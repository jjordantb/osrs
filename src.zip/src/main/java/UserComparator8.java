public class UserComparator8 extends AbstractUserComparator {
   static int field1680;
   public static int field1678;
   final boolean field1677;

   public UserComparator8(boolean var1) {
      this.field1677 = var1;
   }

   int method2949(Buddy var1, Buddy var2) {
      if (Client.field2134 == var1.world) {
         if (var2.world != Client.field2134) {
            return this.field1677 ? -1 : 1;
         }
      } else if (var2.world == Client.field2134) {
         return this.field1677 ? 1 : -1;
      }

      return this.method5349(var1, var2);
   }

   public int compare(Object var1, Object var2) {
      return this.method2949((Buddy)var1, (Buddy)var2);
   }

   static final void method2951(Player var0, int var1, int var2, int var3) {
      if (ObjectSound.field589 != var0) {
         if (Client.field2223 < 400) {
            String var4;
            int var7;
            if (var0.skillLevel == 0) {
               String var5 = var0.actions[0] + var0.username + var0.actions[1];
               var7 = var0.combatLevel;
               int var8 = ObjectSound.field589.combatLevel;
               int var9 = var8 - var7;
               String var6;
               if (var9 < -9) {
                  var6 = ModelData0.method2792(16711680);
               } else if (var9 < -6) {
                  var6 = ModelData0.method2792(16723968);
               } else if (var9 < -3) {
                  var6 = ModelData0.method2792(16740352);
               } else if (var9 < 0) {
                  var6 = ModelData0.method2792(16756736);
               } else if (var9 > 9) {
                  var6 = ModelData0.method2792(65280);
               } else if (var9 > 6) {
                  var6 = ModelData0.method2792(4259584);
               } else if (var9 > 3) {
                  var6 = ModelData0.method2792(8453888);
               } else if (var9 > 0) {
                  var6 = ModelData0.method2792(12648192);
               } else {
                  var6 = ModelData0.method2792(16776960);
               }

               var4 = var5 + var6 + " " + " (" + "level-" + var0.combatLevel + ")" + var0.actions[2];
            } else {
               var4 = var0.actions[0] + var0.username + var0.actions[1] + " " + " (" + "skill-" + var0.skillLevel + ")" + var0.actions[2];
            }

            int var10;
            if (Client.field2239 == 1) {
               Login.method1253("Use", Client.field2209 + " " + "->" + " " + ModelData0.method2792(16777215) + var4, 14, var1, var2, var3);
            } else if (Client.field2241) {
               if ((FontName.field3737 & 8) == 8) {
                  Login.method1253(Client.field2244, Client.field2159 + " " + "->" + " " + ModelData0.method2792(16777215) + var4, 15, var1, var2, var3);
               }
            } else {
               for(var10 = 7; var10 >= 0; --var10) {
                  if (Client.field2210[var10] != null) {
                     short var11 = 0;
                     if (Client.field2210[var10].equalsIgnoreCase("Attack")) {
                        if (AttackOption.field600 == Client.field2114) {
                           continue;
                        }

                        if (AttackOption.field605 == Client.field2114 || Client.field2114 == AttackOption.field607 && var0.combatLevel > ObjectSound.field589.combatLevel) {
                           var11 = 2000;
                        }

                        if (ObjectSound.field589.team != 0 && var0.team != 0) {
                           if (var0.team == ObjectSound.field589.team) {
                              var11 = 2000;
                           } else {
                              var11 = 0;
                           }
                        }
                     } else if (Client.field2211[var10]) {
                        var11 = 2000;
                     }

                     boolean var12 = false;
                     var7 = Client.field2185[var10] + var11;
                     Login.method1253(Client.field2210[var10], ModelData0.method2792(16777215) + var4, var7, var1, var2, var3);
                  }
               }
            }

            for(var10 = 0; var10 < Client.field2223; ++var10) {
               if (Client.field2226[var10] == 23) {
                  Client.field2229[var10] = ModelData0.method2792(16777215) + var4;
                  break;
               }
            }

         }
      }
   }
}
