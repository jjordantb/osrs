public interface MouseWheel {
   int useRotation();
}
