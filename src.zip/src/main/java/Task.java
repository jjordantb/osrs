public class Task {
   public int intArgument;
   public volatile int status = 0;
   Task next;
   int type;
   public volatile Object result;
   Object objectArgument;
}
