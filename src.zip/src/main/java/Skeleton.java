public class Skeleton extends Node {
   int[] transformTypes;
   int id;
   int[][] labels;
   int count;

   Skeleton(int var1, byte[] var2) {
      this.id = var1;
      Buffer var3 = new Buffer(var2);
      this.count = var3.readUnsignedByte();
      this.transformTypes = new int[this.count];
      this.labels = new int[this.count][];

      int var4;
      for(var4 = 0; var4 < this.count; ++var4) {
         this.transformTypes[var4] = var3.readUnsignedByte();
      }

      for(var4 = 0; var4 < this.count; ++var4) {
         this.labels[var4] = new int[var3.readUnsignedByte()];
      }

      for(var4 = 0; var4 < this.count; ++var4) {
         for(int var5 = 0; var5 < this.labels[var4].length; ++var5) {
            this.labels[var4][var5] = var3.readUnsignedByte();
         }
      }

   }

   static final void method2197(Buffer var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7;
      if (var2 >= 0 && var2 < 104 && var3 >= 0 && var3 < 104) {
         Tiles.field203[var1][var2][var3] = 0;

         while(true) {
            var7 = var0.readUnsignedByte();
            if (var7 == 0) {
               if (var1 == 0) {
                  Tiles.field217[0][var2][var3] = -class10.method353(var4 + 932731 + var2, var5 + 556238 + var3) * 8;
               } else {
                  Tiles.field217[var1][var2][var3] = Tiles.field217[var1 - 1][var2][var3] - 240;
               }
               break;
            }

            if (var7 == 1) {
               int var8 = var0.readUnsignedByte();
               if (var8 == 1) {
                  var8 = 0;
               }

               if (var1 == 0) {
                  Tiles.field217[0][var2][var3] = -var8 * 8;
               } else {
                  Tiles.field217[var1][var2][var3] = Tiles.field217[var1 - 1][var2][var3] - var8 * 8;
               }
               break;
            }

            if (var7 <= 49) {
               UserComparator9.field1597[var1][var2][var3] = var0.readByte();
               Tiles.field205[var1][var2][var3] = (byte)((var7 - 2) / 4);
               class81.field917[var1][var2][var3] = (byte)(var7 - 2 + var6 & 3);
            } else if (var7 <= 81) {
               Tiles.field203[var1][var2][var3] = (byte)(var7 - 49);
            } else {
               class93.field1031[var1][var2][var3] = (byte)(var7 - 81);
            }
         }
      } else {
         while(true) {
            var7 = var0.readUnsignedByte();
            if (var7 == 0) {
               break;
            }

            if (var7 == 1) {
               var0.readUnsignedByte();
               break;
            }

            if (var7 <= 49) {
               var0.readUnsignedByte();
            }
         }
      }

   }

   public static ClientParameter[] method2198() {
      return new ClientParameter[]{ClientParameter.field3544, ClientParameter.field3535, ClientParameter.field3551, ClientParameter.field3539, ClientParameter.field3542, ClientParameter.field3543, ClientParameter.field3541, ClientParameter.field3537, ClientParameter.field3545, ClientParameter.field3540, ClientParameter.field3534, ClientParameter.field3550, ClientParameter.field3549, ClientParameter.field3538, ClientParameter.field3548, ClientParameter.field3546, ClientParameter.field3547, ClientParameter.field3536};
   }

   public static byte[] method2199(CharSequence var0) {
      int var1 = var0.length();
      byte[] var2 = new byte[var1];

      for(int var3 = 0; var3 < var1; ++var3) {
         char var4 = var0.charAt(var3);
         if (var4 > 0 && var4 < '\u0080' || var4 >= ' ' && var4 <= 'ÿ') {
            var2[var3] = (byte)var4;
         } else if (var4 == '€') {
            var2[var3] = -128;
         } else if (var4 == '‚') {
            var2[var3] = -126;
         } else if (var4 == 'ƒ') {
            var2[var3] = -125;
         } else if (var4 == '„') {
            var2[var3] = -124;
         } else if (var4 == '…') {
            var2[var3] = -123;
         } else if (var4 == '†') {
            var2[var3] = -122;
         } else if (var4 == '‡') {
            var2[var3] = -121;
         } else if (var4 == 'ˆ') {
            var2[var3] = -120;
         } else if (var4 == '‰') {
            var2[var3] = -119;
         } else if (var4 == 'Š') {
            var2[var3] = -118;
         } else if (var4 == '‹') {
            var2[var3] = -117;
         } else if (var4 == 'Œ') {
            var2[var3] = -116;
         } else if (var4 == 'Ž') {
            var2[var3] = -114;
         } else if (var4 == '‘') {
            var2[var3] = -111;
         } else if (var4 == '’') {
            var2[var3] = -110;
         } else if (var4 == '“') {
            var2[var3] = -109;
         } else if (var4 == '”') {
            var2[var3] = -108;
         } else if (var4 == '•') {
            var2[var3] = -107;
         } else if (var4 == '–') {
            var2[var3] = -106;
         } else if (var4 == '—') {
            var2[var3] = -105;
         } else if (var4 == '˜') {
            var2[var3] = -104;
         } else if (var4 == '™') {
            var2[var3] = -103;
         } else if (var4 == 'š') {
            var2[var3] = -102;
         } else if (var4 == '›') {
            var2[var3] = -101;
         } else if (var4 == 'œ') {
            var2[var3] = -100;
         } else if (var4 == 'ž') {
            var2[var3] = -98;
         } else if (var4 == 'Ÿ') {
            var2[var3] = -97;
         } else {
            var2[var3] = 63;
         }
      }

      return var2;
   }
}
