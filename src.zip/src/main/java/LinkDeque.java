public class LinkDeque {
   Link field2567 = new Link();
   Link field2566;

   public LinkDeque() {
      this.field2567.field2576 = this.field2567;
      this.field2567.field2575 = this.field2567;
   }

   public Link method4540() {
      Link var1 = this.field2566;
      if (var1 == this.field2567) {
         this.field2566 = null;
         return null;
      } else {
         this.field2566 = var1.field2576;
         return var1;
      }
   }

   public void method4538(Link var1) {
      if (var1.field2575 != null) {
         var1.remove();
      }

      var1.field2575 = this.field2567.field2575;
      var1.field2576 = this.field2567;
      var1.field2575.field2576 = var1;
      var1.field2576.field2575 = var1;
   }

   public Link method4539() {
      Link var1 = this.field2567.field2576;
      if (var1 == this.field2567) {
         this.field2566 = null;
         return null;
      } else {
         this.field2566 = var1.field2576;
         return var1;
      }
   }
}
