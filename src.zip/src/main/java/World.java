public class World {
   static int field362;
   static int field350 = 0;
   static World[] field353;
   static UrlRequest field346;
   static int field349 = 0;
   static int[] field352 = new int[]{0, 1, 2, 3};
   static int[] field354 = new int[]{1, 1, 1, 1};
   static Widget field361;
   int population;
   int index;
   String host;
   int properties;
   int id;
   int location;
   String activity;

   boolean method649() {
      return (1 & this.properties) != 0;
   }

   boolean method651() {
      return (33554432 & this.properties) != 0;
   }

   boolean method654() {
      return (536870912 & this.properties) != 0;
   }

   boolean method699() {
      return (2 & this.properties) != 0;
   }

   boolean method696() {
      return (8 & this.properties) != 0;
   }

   boolean method652() {
      return (4 & this.properties) != 0;
   }

   public static class158[] method698() {
      return new class158[]{class158.field1741, class158.field1734, class158.field1736, class158.field1737, class158.field1738, class158.field1739, class158.field1740, class158.field1735, class158.field1747, class158.field1743};
   }

   static final void method661() {
      int var0 = Players.field951;
      int[] var1 = Players.field947;

      for(int var2 = 0; var2 < var0; ++var2) {
         Player var3 = Client.field2141[var1[var2]];
         if (var3 != null) {
            class130.method2827(var3, 1);
         }
      }

   }

   static boolean method692() {
      return (Client.field2119 & 4) != 0;
   }

   static void method700() {
      if (Client.field2205) {
         Player.method845(ObjectSound.field589, false);
      }

   }

   static final void method672(int var0, int var1, int var2, int var3) {
      if (Client.field2239 == 0 && !Client.field2241) {
         Login.method1253("Walk here", "", 23, 0, var0 - var2, var1 - var3);
      }

      long var4 = -1L;
      long var6 = -1L;
      int var8 = 0;

      while(true) {
         int var10 = ViewportMouse.field1508;
         if (var8 >= var10) {
            if (-1L != var4) {
               var8 = WorldMapLabel.method1783(var4);
               int var9 = Messages.method1125(var4);
               Player var26 = Client.field2141[Client.field2212];
               UserComparator8.method2951(var26, Client.field2212, var8, var9);
            }

            return;
         }

         long var11 = ViewportMouse.field1509[var8];
         if (var6 != var11) {
            label333: {
               var6 = var11;
               int var15 = Friend.method5940(var8);
               int var16 = Messages.method1125(ViewportMouse.field1509[var8]);
               int var17 = var16;
               int var18 = class1.method33(var8);
               int var19 = WorldMapSectionType.method1829(var8);
               if (var18 == 2 && class243.field2904.getObjectFlags(class31.field363, var15, var16, var11) >= 0) {
                  ObjectDefinition var20 = class252.method4958(var19);
                  if (var20.transforms != null) {
                     var20 = var20.transform();
                  }

                  if (var20 == null) {
                     break label333;
                  }

                  if (Client.field2239 == 1) {
                     Login.method1253("Use", Client.field2209 + " " + "->" + " " + ModelData0.method2792(65535) + var20.name, 1, var19, var15, var16);
                  } else if (Client.field2241) {
                     if ((FontName.field3737 & 4) == 4) {
                        Login.method1253(Client.field2244, Client.field2159 + " " + "->" + " " + ModelData0.method2792(65535) + var20.name, 2, var19, var15, var16);
                     }
                  } else {
                     String[] var27 = var20.actions;
                     if (var27 != null) {
                        for(int var28 = 4; var28 >= 0; --var28) {
                           if (var27[var28] != null) {
                              short var23 = 0;
                              if (var28 == 0) {
                                 var23 = 3;
                              }

                              if (var28 == 1) {
                                 var23 = 4;
                              }

                              if (var28 == 2) {
                                 var23 = 5;
                              }

                              if (var28 == 3) {
                                 var23 = 6;
                              }

                              if (var28 == 4) {
                                 var23 = 1001;
                              }

                              Login.method1253(var27[var28], ModelData0.method2792(65535) + var20.name, var23, var19, var15, var17);
                           }
                        }
                     }

                     Login.method1253("Examine", ModelData0.method2792(65535) + var20.name, 1002, var20.id, var15, var17);
                  }
               }

               int var21;
               Npc var22;
               Player var24;
               int[] var34;
               int var36;
               if (var18 == 1) {
                  Npc var31 = Client.field2249[var19];
                  if (var31 == null) {
                     break label333;
                  }

                  if (var31.definition.size == 1 && (var31.x & 127) == 64 && (var31.y & 127) == 64) {
                     for(var21 = 0; var21 < Client.field2129; ++var21) {
                        var22 = Client.field2249[Client.field2130[var21]];
                        if (var22 != null && var22 != var31 && var22.definition.size == 1 && var22.x == var31.x && var22.y == var31.y) {
                           ClientPreferences.method800(var22.definition, Client.field2130[var21], var15, var17);
                        }
                     }

                     var21 = Players.field951;
                     var34 = Players.field947;

                     for(var36 = 0; var36 < var21; ++var36) {
                        var24 = Client.field2141[var34[var36]];
                        if (var24 != null && var24.x == var31.x && var31.y == var24.y) {
                           UserComparator8.method2951(var24, var34[var36], var15, var17);
                        }
                     }
                  }

                  ClientPreferences.method800(var31.definition, var19, var15, var17);
               }

               if (var18 == 0) {
                  Player var32 = Client.field2141[var19];
                  if (var32 == null) {
                     break label333;
                  }

                  if ((var32.x & 127) == 64 && (var32.y & 127) == 64) {
                     for(var21 = 0; var21 < Client.field2129; ++var21) {
                        var22 = Client.field2249[Client.field2130[var21]];
                        if (var22 != null && var22.definition.size == 1 && var32.x == var22.x && var32.y == var22.y) {
                           ClientPreferences.method800(var22.definition, Client.field2130[var21], var15, var17);
                        }
                     }

                     var21 = Players.field951;
                     var34 = Players.field947;

                     for(var36 = 0; var36 < var21; ++var36) {
                        var24 = Client.field2141[var34[var36]];
                        if (var24 != null && var32 != var24 && var24.x == var32.x && var24.y == var32.y) {
                           UserComparator8.method2951(var24, var34[var36], var15, var17);
                        }
                     }
                  }

                  if (var19 != Client.field2212) {
                     UserComparator8.method2951(var32, var19, var15, var17);
                  } else {
                     var4 = var11;
                  }
               }

               if (var18 == 3) {
                  NodeDeque var33 = Client.field2272[class31.field363][var15][var17];
                  if (var33 != null) {
                     for(GroundItem var37 = (GroundItem)var33.first(); var37 != null; var37 = (GroundItem)var33.next()) {
                        ItemDefinition var35 = Varcs.getItemDefinition(var37.id);
                        if (Client.field2239 == 1) {
                           Login.method1253("Use", Client.field2209 + " " + "->" + " " + ModelData0.method2792(16748608) + var35.name, 16, var37.id, var15, var17);
                        } else if (Client.field2241) {
                           if ((FontName.field3737 & 1) == 1) {
                              Login.method1253(Client.field2244, Client.field2159 + " " + "->" + " " + ModelData0.method2792(16748608) + var35.name, 17, var37.id, var15, var17);
                           }
                        } else {
                           String[] var29 = var35.groundActions;

                           for(int var30 = 4; var30 >= 0; --var30) {
                              if (var29 != null && var29[var30] != null) {
                                 byte var25 = 0;
                                 if (var30 == 0) {
                                    var25 = 18;
                                 }

                                 if (var30 == 1) {
                                    var25 = 19;
                                 }

                                 if (var30 == 2) {
                                    var25 = 20;
                                 }

                                 if (var30 == 3) {
                                    var25 = 21;
                                 }

                                 if (var30 == 4) {
                                    var25 = 22;
                                 }

                                 Login.method1253(var29[var30], ModelData0.method2792(16748608) + var35.name, var25, var37.id, var15, var17);
                              } else if (var30 == 2) {
                                 Login.method1253("Take", ModelData0.method2792(16748608) + var35.name, 20, var37.id, var15, var17);
                              }
                           }

                           Login.method1253("Examine", ModelData0.method2792(16748608) + var35.name, 1004, var37.id, var15, var17);
                        }
                     }
                  }
               }
            }
         }

         ++var8;
      }
   }
}
