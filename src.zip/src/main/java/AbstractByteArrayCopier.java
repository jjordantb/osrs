import java.io.File;
import java.io.RandomAccessFile;

public abstract class AbstractByteArrayCopier {
   static boolean field2365 = false;
   static int field2366;

   abstract byte[] get();

   abstract void set(byte[] var1);

   static boolean method3742(File var0, boolean var1) {
      try {
         RandomAccessFile var2 = new RandomAccessFile(var0, "rw");
         int var3 = var2.read();
         var2.seek(0L);
         var2.write(var3);
         var2.seek(0L);
         var2.close();
         if (var1) {
            var0.delete();
         }

         return true;
      } catch (Exception var4) {
         return false;
      }
   }

   public static boolean get(int var0) {
      return var0 >= class255.field3306.field3307 && var0 <= class255.field3288.field3307;
   }
}
