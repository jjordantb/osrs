public class Timer {
   static TextureProvider field3526;
   int field3522 = 0;
   long field3520 = 0L;
   public boolean field3518 = false;
   long field3524 = -1L;
   int field3525 = 0;
   long field3517 = 0L;
   int field3521 = 0;
   long field3519 = 0L;
   long field3516 = -1L;
   int field3523 = 0;

   public void method5360() {
      this.field3518 = false;
      this.field3523 = 0;
   }

   public void method5358(int var1) {
      this.field3516 = Tile.method2779();
      this.field3522 = var1;
   }

   public void method5372() {
      this.field3524 = Tile.method2779();
   }

   public void method5356() {
      this.method5359();
   }

   public void write(Buffer var1) {
      long var2 = this.field3520;
      var2 /= 10L;
      if (var2 < 0L) {
         var2 = 0L;
      } else if (var2 > 65535L) {
         var2 = 65535L;
      }

      var1.writeShort((int)var2);
      long var4 = this.field3519;
      var4 /= 10L;
      if (var4 < 0L) {
         var4 = 0L;
      } else if (var4 > 65535L) {
         var4 = 65535L;
      }

      var1.writeShort((int)var4);
      long var6 = this.field3517;
      var6 /= 10L;
      if (var6 < 0L) {
         var6 = 0L;
      } else if (var6 > 65535L) {
         var6 = 65535L;
      }

      var1.writeShort((int)var6);
      var1.writeShort(this.field3522);
      var1.writeShort(this.field3523);
      var1.writeShort(this.field3521);
      var1.writeShort(this.field3525);
   }

   public void method5359() {
      if (this.field3516 != -1L) {
         this.field3519 = Tile.method2779() - this.field3516;
         this.field3516 = -1L;
      }

      ++this.field3521;
      this.field3518 = true;
   }

   public void method5357() {
      if (-1L != this.field3524) {
         this.field3520 = Tile.method2779() - this.field3524;
         this.field3524 = -1L;
      }

   }
}
