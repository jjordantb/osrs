public class WorldMapSection2 implements WorldMapSection {
   static int field129;
   static IndexCache field136;
   int field133;
   int field131;
   int field134;
   int field135;
   int field132;
   int field130;

   public TileLocation vmethod1861(int var1, int var2) {
      if (!this.vmethod1857(var1, var2)) {
         return null;
      } else {
         int var3 = this.field131 * 64 - this.field133 * 64 + var1;
         int var4 = this.field132 * 64 - this.field135 * 64 + var2;
         return new TileLocation(this.field134, var3, var4);
      }
   }

   public boolean vmethod1857(int var1, int var2) {
      return var1 >> 6 == this.field133 && var2 >> 6 == this.field135;
   }

   public void vmethod1855(WorldMapData var1) {
      if (var1.field881 > this.field133) {
         var1.field881 = this.field133;
      }

      if (var1.field882 < this.field133) {
         var1.field882 = this.field133;
      }

      if (var1.field877 > this.field135) {
         var1.field877 = this.field135;
      }

      if (var1.field886 < this.field135) {
         var1.field886 = this.field135;
      }

   }

   public void read(Buffer var1) {
      this.field134 = var1.readUnsignedByte();
      this.field130 = var1.readUnsignedByte();
      this.field131 = var1.method3913();
      this.field132 = var1.method3913();
      this.field133 = var1.method3913();
      this.field135 = var1.method3913();
      this.method383();
   }

   void method383() {
   }

   public int[] vmethod1858(int var1, int var2, int var3) {
      if (!this.vmethod1856(var1, var2, var3)) {
         return null;
      } else {
         int[] var4 = new int[]{this.field133 * 64 - this.field131 * 64 + var2, var3 + (this.field135 * 64 - this.field132 * 64)};
         return var4;
      }
   }

   public boolean vmethod1856(int var1, int var2, int var3) {
      if (var1 >= this.field134 && var1 < this.field134 + this.field130) {
         return var2 >> 6 == this.field131 && var3 >> 6 == this.field132;
      } else {
         return false;
      }
   }

   public static void method402(AbstractIndexCache var0, AbstractIndexCache var1, boolean var2, Font var3) {
      ItemDefinition.field3609 = var0;
      GrandExchangeOffer.field690 = var1;
      PlayerAppearance.field2560 = var2;
      class322.field3916 = ItemDefinition.field3609.method5025(10);
      UserComparator9.field1596 = var3;
   }

   public static void read(int var0, AbstractIndexCache var1, String var2, String var3, int var4, boolean var5) {
      int var6 = var1.getArchiveId(var2);
      int var7 = var1.getRecordId(var6, var3);
      class83.method1700(var0, var1, var6, var7, var4, var5);
   }

   static synchronized void method400(byte[] var0) {
      if (var0.length == 100 && ByteArrayPool.field2468 < 1000) {
         ByteArrayPool.field2467[++ByteArrayPool.field2468 - 1] = var0;
      } else if (var0.length == 5000 && ByteArrayPool.field2465 < 250) {
         ByteArrayPool.field2471[++ByteArrayPool.field2465 - 1] = var0;
      } else if (var0.length == 30000 && ByteArrayPool.field2466 < 50) {
         ByteArrayPool.field2469[++ByteArrayPool.field2466 - 1] = var0;
      } else {
         if (FriendLoginUpdate.field3772 != null) {
            for(int var1 = 0; var1 < class83.field940.length; ++var1) {
               if (var0.length == class83.field940[var1] && ByteArrayPool.field2464[var1] < FriendLoginUpdate.field3772[var1].length) {
                  FriendLoginUpdate.field3772[var1][ByteArrayPool.field2464[var1]++] = var0;
                  return;
               }
            }
         }

      }
   }

   static void method377(int var0, int var1, int var2, int var3) {
      ItemContainer var4 = (ItemContainer)ItemContainer.field267.get((long)var0);
      if (var4 == null) {
         var4 = new ItemContainer();
         ItemContainer.field267.put(var4, (long)var0);
      }

      if (var4.ids.length <= var1) {
         int[] var5 = new int[var1 + 1];
         int[] var6 = new int[var1 + 1];

         int var7;
         for(var7 = 0; var7 < var4.ids.length; ++var7) {
            var5[var7] = var4.ids[var7];
            var6[var7] = var4.quantities[var7];
         }

         for(var7 = var4.ids.length; var7 < var1; ++var7) {
            var5[var7] = -1;
            var6[var7] = 0;
         }

         var4.ids = var5;
         var4.quantities = var6;
      }

      var4.ids[var1] = var2;
      var4.quantities[var1] = var3;
   }

   static void method398(int var0) {
      Client.field2313 = 0L;
      if (var0 >= 2) {
         Client.field2118 = true;
      } else {
         Client.field2118 = false;
      }

      if (class65.method1381() == 1) {
         class178.field1984.method295(765, 503);
      } else {
         class178.field1984.method295(7680, 2160);
      }

      if (Client.field2163 >= 25) {
         Interpreter.method968();
      }

   }
}
