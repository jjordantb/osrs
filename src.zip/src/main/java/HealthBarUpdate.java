public class HealthBarUpdate extends Node {
   int health2;
   int cycle;
   int cycleOffset;
   int health;

   HealthBarUpdate(int var1, int var2, int var3, int var4) {
      this.cycle = var1;
      this.health = var2;
      this.health2 = var3;
      this.cycleOffset = var4;
   }

   void set(int var1, int var2, int var3, int var4) {
      this.cycle = var1;
      this.health = var2;
      this.health2 = var3;
      this.cycleOffset = var4;
   }

   public static final void method711(int var0, boolean var1, int var2) {
      if (var0 >= 8000 && var0 <= 48000) {
         AbstractSoundSystem.field936 = var0;
         class5.field52 = var1;
         class93.field1032 = var2;
      } else {
         throw new IllegalArgumentException();
      }
   }

   static int set(int var0, int var1) {
      OverlayDefinition var3 = (OverlayDefinition)OverlayDefinition.field3678.get((long)var0);
      OverlayDefinition var2;
      if (var3 != null) {
         var2 = var3;
      } else {
         byte[] var4 = OverlayDefinition.field3688.takeRecord(4, var0);
         var3 = new OverlayDefinition();
         if (var4 != null) {
            var3.read(new Buffer(var4), var0);
         }

         var3.init();
         OverlayDefinition.field3678.put(var3, (long)var0);
         var2 = var3;
      }

      if (var2 == null) {
         return var1;
      } else if (var2.rgb2 >= 0) {
         return var2.rgb2 | -16777216;
      } else if (var2.texture >= 0) {
         int var10 = VertexNormal.method2401(Rasterizer3D.field1451.vmethod2974(var2.texture), 96);
         return Rasterizer3D.field1448[var10] | -16777216;
      } else if (var2.rgb == 16711935) {
         return var1;
      } else {
         int var5 = var2.hue;
         int var6 = var2.saturation;
         int var7 = var2.lightness;
         if (var7 > 179) {
            var6 /= 2;
         }

         if (var7 > 192) {
            var6 /= 2;
         }

         if (var7 > 217) {
            var6 /= 2;
         }

         if (var7 > 243) {
            var6 /= 2;
         }

         int var8 = (var6 / 32 << 7) + var7 / 2 + (var5 / 4 << 10);
         int var9 = VertexNormal.method2401(var8, 96);
         return Rasterizer3D.field1448[var9] | -16777216;
      }
   }
}
