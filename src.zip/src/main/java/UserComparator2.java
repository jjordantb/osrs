import java.util.Comparator;

public class UserComparator2 implements Comparator {
   final boolean field3999;

   public UserComparator2(boolean var1) {
      this.field3999 = var1;
   }

   int method6490(User var1, User var2) {
      return this.field3999 ? var1.method5384().compareTo0(var2.method5384()) : var2.method5384().compareTo0(var1.method5384());
   }

   public int compare(Object var1, Object var2) {
      return this.method6490((User)var1, (User)var2);
   }

   public boolean equals(Object var1) {
      return super.equals(var1);
   }

   public static double[] method6489(double var0, double var2, int var4) {
      int var5 = var4 * 2 + 1;
      double[] var6 = new double[var5];
      int var7 = -var4;

      for(int var8 = 0; var7 <= var4; ++var8) {
         double var11 = HitSplatDefinition.method5141(((double)var7 - var0) / var2) / var2;
         var6[var8] = var11;
         ++var7;
      }

      return var6;
   }
}
