import java.util.Comparator;

public class UserComparator4 implements Comparator {
   static int field1729;
   final boolean field1730;

   public UserComparator4(boolean var1) {
      this.field1730 = var1;
   }

   int method2993(Buddy var1, Buddy var2) {
      return this.field1730 ? var1.int2 - var2.int2 : var2.int2 - var1.int2;
   }

   public int compare(Object var1, Object var2) {
      return this.method2993((Buddy)var1, (Buddy)var2);
   }

   public boolean equals(Object var1) {
      return super.equals(var1);
   }

   public static ParamsDefinition method2997(int var0) {
      ParamsDefinition var1 = (ParamsDefinition)ParamsDefinition.field3486.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = ParamsDefinition.field3484.takeRecord(34, var0);
         var1 = new ParamsDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         var1.init();
         ParamsDefinition.field3486.put(var1, (long)var0);
         return var1;
      }
   }
}
