public class class25 {
   static int[] field263;
   int[][] field257;
   int[][] field256;
   int field258;
   int[][] field260;
   int[][] field259;
   int field261;

   class25(int var1, int var2) {
      this.field258 = var1;
      this.field261 = var2;
      this.field256 = new int[var1][var2];
      this.field259 = new int[var1][var2];
      this.field257 = new int[var1][var2];
      this.field260 = new int[var1][var2];
   }

   void method577(int var1, int var2, int var3, UnderlayDefinition var4) {
      if (var4 != null) {
         if (var3 + var1 >= 0 && var3 + var2 >= 0) {
            if (var1 - var3 <= this.field258 && var2 - var3 <= this.field261) {
               int var5 = Math.max(0, var1 - var3);
               int var6 = Math.min(this.field258, var3 + var1);
               int var7 = Math.max(0, var2 - var3);
               int var8 = Math.min(this.field261, var3 + var2);

               for(int var9 = var5; var9 < var6; ++var9) {
                  for(int var10 = var7; var10 < var8; ++var10) {
                     this.field256[var9][var10] += var4.hue * 256 / var4.hueMultiplier;
                     this.field259[var9][var10] += var4.saturation;
                     this.field257[var9][var10] += var4.lightness;
                     ++this.field260[var9][var10];
                  }
               }

            }
         }
      }
   }

   int method575(int var1, int var2) {
      if (var1 >= 0 && var2 >= 0 && var1 < this.field258 && var2 < this.field261) {
         if (this.field257[var1][var2] == 0) {
            return 0;
         } else {
            int var3 = this.field256[var1][var2] / this.field260[var1][var2];
            int var4 = this.field259[var1][var2] / this.field260[var1][var2];
            int var5 = this.field257[var1][var2] / this.field260[var1][var2];
            return class57.method1225((double)var3 / 256.0D, (double)var4 / 256.0D, (double)var5 / 256.0D);
         }
      } else {
         return 0;
      }
   }

   static int method581(int var0) {
      Message var1 = (Message)Messages.field611.get((long)var0);
      if (var1 == null) {
         return -1;
      } else {
         return var1.previousDual == Messages.field609.sentinel ? -1 : ((Message)var1.previousDual).count;
      }
   }
}
