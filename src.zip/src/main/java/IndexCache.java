import java.util.zip.CRC32;

public class IndexCache extends AbstractIndexCache {
   static CRC32 field2869 = new CRC32();
   int field2878 = -1;
   int indexReferenceVersion;
   boolean field2873 = false;
   volatile boolean[] validArchives;
   int indexReferenceCrc;
   volatile boolean field2872 = false;
   IndexStore indexStore;
   int index;
   IndexStore referenceStore;

   public IndexCache(IndexStore var1, IndexStore var2, int var3, boolean var4, boolean var5, boolean var6) {
      super(var4, var5);
      this.indexStore = var1;
      this.referenceStore = var2;
      this.index = var3;
      this.field2873 = var6;
      int var8 = this.index;
      if (Login.field687 != null) {
         Login.field687.index = var8 * 8 + 5;
         int var9 = Login.field687.readInt();
         int var10 = Login.field687.readInt();
         this.loadIndexReference(var9, var10);
      } else {
         Interpreter.method967((IndexCache)null, 255, 255, 0, (byte)0, true);
         NetCache.field2845[var8] = this;
      }

   }

   int archiveLoadPercent(int var1) {
      if (super.archives[var1] != null) {
         return 100;
      } else {
         return this.validArchives[var1] ? 100 : RunException.method2855(this.index, var1);
      }
   }

   public boolean method4824() {
      return this.field2872;
   }

   public boolean method4833(int var1) {
      return this.validArchives[var1];
   }

   void load(IndexStore var1, int var2, byte[] var3, boolean var4) {
      int var5;
      if (var1 == this.referenceStore) {
         if (this.field2872) {
            throw new RuntimeException();
         } else if (var3 == null) {
            Interpreter.method967(this, 255, this.index, this.indexReferenceCrc, (byte)0, true);
         } else {
            field2869.reset();
            field2869.update(var3, 0, var3.length);
            var5 = (int)field2869.getValue();
            if (var5 != this.indexReferenceCrc) {
               Interpreter.method967(this, 255, this.index, this.indexReferenceCrc, (byte)0, true);
            } else {
               Buffer var9 = new Buffer(class251.method4942(var3));
               int var7 = var9.readUnsignedByte();
               if (var7 != 5 && var7 != 6) {
                  throw new RuntimeException(var7 + "," + this.index + "," + var2);
               } else {
                  int var8 = 0;
                  if (var7 >= 6) {
                     var8 = var9.readInt();
                  }

                  if (var8 != this.indexReferenceVersion) {
                     Interpreter.method967(this, 255, this.index, this.indexReferenceCrc, (byte)0, true);
                  } else {
                     this.setIndexReference(var3);
                     this.loadAllLocal();
                  }
               }
            }
         }
      } else {
         if (!var4 && var2 == this.field2878) {
            this.field2872 = true;
         }

         if (var3 != null && var3.length > 2) {
            field2869.reset();
            field2869.update(var3, 0, var3.length - 2);
            var5 = (int)field2869.getValue();
            int var6 = ((var3[var3.length - 2] & 255) << 8) + (var3[var3.length - 1] & 255);
            if (var5 == super.archiveCrcs[var2] && var6 == super.archiveVersions[var2]) {
               this.validArchives[var2] = true;
               if (var4) {
                  super.archives[var2] = class103.method2027(var3, false);
               }

            } else {
               this.validArchives[var2] = false;
               if (this.field2873 || var4) {
                  Interpreter.method967(this, this.index, var2, super.archiveCrcs[var2], (byte)2, var4);
               }

            }
         } else {
            this.validArchives[var2] = false;
            if (this.field2873 || var4) {
               Interpreter.method967(this, this.index, var2, super.archiveCrcs[var2], (byte)2, var4);
            }

         }
      }
   }

   void loadArchive(int var1) {
      if (this.indexStore != null && this.validArchives != null && this.validArchives[var1]) {
         IndexStore var2 = this.indexStore;
         byte[] var4 = null;
         NodeDeque var5 = IndexStoreActionHandler.field2946;
         synchronized(IndexStoreActionHandler.field2946) {
            for(IndexStoreAction var6 = (IndexStoreAction)IndexStoreActionHandler.field2946.last(); var6 != null; var6 = (IndexStoreAction)IndexStoreActionHandler.field2946.previous()) {
               if ((long)var1 == var6.key && var2 == var6.indexStore && var6.type == 0) {
                  var4 = var6.data;
                  break;
               }
            }
         }

         if (var4 != null) {
            this.load(var2, var1, var4, true);
         } else {
            byte[] var9 = var2.read(var1);
            this.load(var2, var1, var9, true);
         }
      } else {
         Interpreter.method967(this, this.index, var1, super.archiveCrcs[var1], (byte)2, true);
      }

   }

   void write(int var1, byte[] var2, boolean var3, boolean var4) {
      if (var3) {
         if (this.field2872) {
            throw new RuntimeException();
         }

         if (this.referenceStore != null) {
            FriendSystem.method790(this.index, var2, this.referenceStore);
         }

         this.setIndexReference(var2);
         this.loadAllLocal();
      } else {
         var2[var2.length - 2] = (byte)(super.archiveVersions[var1] >> 8);
         var2[var2.length - 1] = (byte)super.archiveVersions[var1];
         if (this.indexStore != null) {
            FriendSystem.method790(var1, var2, this.indexStore);
            this.validArchives[var1] = true;
         }

         if (var4) {
            super.archives[var1] = class103.method2027(var2, false);
         }
      }

   }

   void loadIndexReference(int var1, int var2) {
      this.indexReferenceCrc = var1;
      this.indexReferenceVersion = var2;
      if (this.referenceStore != null) {
         int var3 = this.index;
         IndexStore var4 = this.referenceStore;
         byte[] var6 = null;
         NodeDeque var7 = IndexStoreActionHandler.field2946;
         synchronized(IndexStoreActionHandler.field2946) {
            for(IndexStoreAction var8 = (IndexStoreAction)IndexStoreActionHandler.field2946.last(); var8 != null; var8 = (IndexStoreAction)IndexStoreActionHandler.field2946.previous()) {
               if ((long)var3 == var8.key && var4 == var8.indexStore && var8.type == 0) {
                  var6 = var8.data;
                  break;
               }
            }
         }

         if (var6 != null) {
            this.load(var4, var3, var6, true);
         } else {
            byte[] var11 = var4.read(var3);
            this.load(var4, var3, var11, true);
         }
      } else {
         Interpreter.method967(this, 255, this.index, this.indexReferenceCrc, (byte)0, true);
      }

   }

   public int method4825() {
      if (this.field2872) {
         return 100;
      } else if (super.archives != null) {
         return 99;
      } else {
         int var1 = RunException.method2855(255, this.index);
         if (var1 >= 100) {
            var1 = 99;
         }

         return var1;
      }
   }

   void vmethod4963(int var1) {
      int var2 = this.index;
      long var3 = (long)((var2 << 16) + var1);
      NetFileRequest var5 = (NetFileRequest)NetCache.field2836.get(var3);
      if (var5 != null) {
         NetCache.field2835.addLast(var5);
      }

   }

   void loadAllLocal() {
      this.validArchives = new boolean[super.archives.length];

      int var1;
      for(var1 = 0; var1 < this.validArchives.length; ++var1) {
         this.validArchives[var1] = false;
      }

      if (this.indexStore == null) {
         this.field2872 = true;
      } else {
         this.field2878 = -1;

         for(var1 = 0; var1 < this.validArchives.length; ++var1) {
            if (super.recordCounts[var1] > 0) {
               IndexStore var2 = this.indexStore;
               IndexStoreAction var4 = new IndexStoreAction();
               var4.type = 1;
               var4.key = (long)var1;
               var4.indexStore = var2;
               var4.indexCache = this;
               NodeDeque var5 = IndexStoreActionHandler.field2946;
               synchronized(IndexStoreActionHandler.field2946) {
                  IndexStoreActionHandler.field2946.addFirst(var4);
               }

               Object var10 = IndexStoreActionHandler.field2945;
               synchronized(IndexStoreActionHandler.field2945) {
                  if (IndexStoreActionHandler.field2947 == 0) {
                     IndexStoreActionHandler.field2949 = new Thread(new IndexStoreActionHandler());
                     IndexStoreActionHandler.field2949.setDaemon(true);
                     IndexStoreActionHandler.field2949.start();
                     IndexStoreActionHandler.field2949.setPriority(5);
                  }

                  IndexStoreActionHandler.field2947 = 600;
               }

               this.field2878 = var1;
            }
         }

         if (this.field2878 == -1) {
            this.field2872 = true;
         }

      }
   }

   public boolean method4863(int var1) {
      return this.method4975(var1) != null;
   }

   public int loadPercent() {
      int var1 = 0;
      int var2 = 0;

      int var3;
      for(var3 = 0; var3 < super.archives.length; ++var3) {
         if (super.recordCounts[var3] > 0) {
            var1 += 100;
            var2 += this.archiveLoadPercent(var3);
         }
      }

      if (var1 == 0) {
         return 100;
      } else {
         var3 = var2 * 100 / var1;
         return var3;
      }
   }

   public static VarcInt method4865(int var0) {
      VarcInt var1 = (VarcInt)VarcInt.field2812.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = VarcInt.field2813.takeRecord(19, var0);
         var1 = new VarcInt();
         if (var2 != null) {
            var1.method4768(new Buffer(var2));
         }

         VarcInt.field2812.put(var1, (long)var0);
         return var1;
      }
   }
}
