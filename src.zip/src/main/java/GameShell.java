import java.applet.Applet;
import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.ImageObserver;
import java.net.URL;

public abstract class GameShell extends Applet implements Runnable, FocusListener, WindowListener {
   static ClientPreferences field72;
   static int field87 = 500;
   static long field97 = -1L;
   static volatile boolean field94 = true;
   static long field96 = -1L;
   static boolean field67 = false;
   static int field65 = 0;
   protected static TaskHandler field63;
   protected static long[] field81 = new long[32];
   static int field75 = 1;
   protected static long[] field66 = new long[32];
   protected static Clock field70;
   static int field69 = 20;
   protected static int field71 = 0;
   static long stopTimeMs = 0L;
   static GameShell field64 = null;
   static int field74;
   static Sprite[] field98;
   Frame frame;
   MouseWheelHandler mouseWheelHandler;
   int contentHeight0;
   volatile boolean field86 = true;
   final EventQueue eventQueue;
   Clipboard clipboard;
   int field82;
   boolean field88 = false;
   volatile long canvasSetTimeMs = 0L;
   volatile boolean isCanvasInvalid = false;
   int field83;
   java.awt.Canvas canvas;
   protected int contentWidth;
   int canvasX = 0;
   boolean hasErrored = false;
   int contentWidth0;
   protected int contentHeight;
   int canvasY = 0;

   protected GameShell() {
      EventQueue var1 = null;

      try {
         var1 = Toolkit.getDefaultToolkit().getSystemEventQueue();
      } catch (Throwable var3) {
         ;
      }

      this.eventQueue = var1;
      SoundSystemProvider var2 = new SoundSystemProvider();
      ClientPreferences.field415 = var2;
   }

   protected final void method218() {
      GameObject.field1636 = null;
      UserComparator6.field1629 = null;
      UrlRequester.field1590 = null;
   }

   Container container() {
      return (Container)(this.frame != null ? this.frame : this);
   }

   protected abstract void vmethod3322();

   final void method196() {
      Bounds var1 = this.getFrameContentBounds();
      if (var1.field3828 != this.contentWidth || var1.field3829 != this.contentHeight || this.field88) {
         this.method280();
         this.field88 = false;
      }

   }

   protected void error(String var1) {
      if (!this.hasErrored) {
         this.hasErrored = true;
         System.out.println("error_game_" + var1);

         try {
            this.getAppletContext().showDocument(new URL(this.getCodeBase(), "error_game_" + var1 + ".ws"), "_self");
         } catch (Exception var3) {
            ;
         }

      }
   }

   protected final boolean hasFrame() {
      return this.frame != null;
   }

   Bounds getFrameContentBounds() {
      Container var1 = this.container();
      int var2 = Math.max(var1.getWidth(), this.contentWidth0);
      int var3 = Math.max(var1.getHeight(), this.contentHeight0);
      if (this.frame != null) {
         Insets var4 = this.frame.getInsets();
         var2 -= var4.left + var4.right;
         var3 -= var4.bottom + var4.top;
      }

      return new Bounds(var2, var3);
   }

   protected abstract void vmethod3549();

   final void method212() {
      this.field88 = true;
   }

   protected abstract void vmethod3323(boolean var1);

   protected final void method217(int var1, String var2, boolean var3) {
      try {
         Graphics var4 = this.canvas.getGraphics();
         if (UserComparator6.field1629 == null) {
            UserComparator6.field1629 = new java.awt.Font("Helvetica", 1, 13);
            UrlRequester.field1590 = this.canvas.getFontMetrics(UserComparator6.field1629);
         }

         if (var3) {
            var4.setColor(Color.black);
            var4.fillRect(0, 0, FriendSystem.field379, UserComparator8.field1678);
         }

         Color var5 = new Color(140, 17, 17);

         try {
            if (GameObject.field1636 == null) {
               GameObject.field1636 = this.canvas.createImage(304, 34);
            }

            Graphics var6 = GameObject.field1636.getGraphics();
            var6.setColor(var5);
            var6.drawRect(0, 0, 303, 33);
            var6.fillRect(2, 2, var1 * 3, 30);
            var6.setColor(Color.black);
            var6.drawRect(1, 1, 301, 31);
            var6.fillRect(var1 * 3 + 2, 2, 300 - var1 * 3, 30);
            var6.setFont(UserComparator6.field1629);
            var6.setColor(Color.white);
            var6.drawString(var2, (304 - UrlRequester.field1590.stringWidth(var2)) / 2, 22);
            var4.drawImage(GameObject.field1636, FriendSystem.field379 / 2 - 152, UserComparator8.field1678 / 2 - 18, (ImageObserver)null);
         } catch (Exception var9) {
            int var7 = FriendSystem.field379 / 2 - 152;
            int var8 = UserComparator8.field1678 / 2 - 18;
            var4.setColor(var5);
            var4.drawRect(var7, var8, 303, 33);
            var4.fillRect(var7 + 2, var8 + 2, var1 * 3, 30);
            var4.setColor(Color.black);
            var4.drawRect(var7 + 1, var8 + 1, 301, 31);
            var4.fillRect(var1 * 3 + var7 + 2, var8 + 2, 300 - var1 * 3, 30);
            var4.setFont(UserComparator6.field1629);
            var4.setColor(Color.white);
            var4.drawString(var2, var7 + (304 - UrlRequester.field1590.stringWidth(var2)) / 2, var8 + 22);
         }
      } catch (Exception var10) {
         this.canvas.repaint();
      }

   }

   protected abstract void kill0();

   protected abstract void setUp();

   final synchronized void kill() {
      if (!field67) {
         field67 = true;

         try {
            this.canvas.removeFocusListener(this);
         } catch (Exception var5) {
            ;
         }

         try {
            this.kill0();
         } catch (Exception var4) {
            ;
         }

         if (this.frame != null) {
            try {
               System.exit(0);
            } catch (Throwable var3) {
               ;
            }
         }

         if (field63 != null) {
            try {
               field63.close();
            } catch (Exception var2) {
               ;
            }
         }

         this.vmethod3549();
      }
   }

   void clearBackground() {
      int var1 = this.canvasX;
      int var2 = this.canvasY;
      int var3 = this.contentWidth - FriendSystem.field379 - var1;
      int var4 = this.contentHeight - UserComparator8.field1678 - var2;
      if (var1 > 0 || var3 > 0 || var2 > 0 || var4 > 0) {
         try {
            Container var5 = this.container();
            int var6 = 0;
            int var7 = 0;
            if (var5 == this.frame) {
               Insets var8 = this.frame.getInsets();
               var6 = var8.left;
               var7 = var8.top;
            }

            Graphics var10 = var5.getGraphics();
            var10.setColor(Color.black);
            if (var1 > 0) {
               var10.fillRect(var6, var7, var1, this.contentHeight);
            }

            if (var2 > 0) {
               var10.fillRect(var6, var7, this.contentWidth, var2);
            }

            if (var3 > 0) {
               var10.fillRect(var6 + this.contentWidth - var3, var7, var3, this.contentHeight);
            }

            if (var4 > 0) {
               var10.fillRect(var6, var7 + this.contentHeight - var4, this.contentWidth, var4);
            }
         } catch (Exception var9) {
            ;
         }
      }

   }

   protected void setUpClipboard() {
      this.clipboard = this.getToolkit().getSystemClipboard();
   }

   protected abstract void vmethod3332();

   final void method280() {
      Container var1 = this.container();
      if (var1 != null) {
         Bounds var2 = this.getFrameContentBounds();
         this.contentWidth = Math.max(var2.field3828, this.contentWidth0);
         this.contentHeight = Math.max(var2.field3829, this.contentHeight0);
         if (this.contentWidth <= 0) {
            this.contentWidth = 1;
         }

         if (this.contentHeight <= 0) {
            this.contentHeight = 1;
         }

         FriendSystem.field379 = Math.min(this.contentWidth, this.field82);
         UserComparator8.field1678 = Math.min(this.contentHeight, this.field83);
         this.canvasX = (this.contentWidth - FriendSystem.field379) / 2;
         this.canvasY = 0;
         this.canvas.setSize(FriendSystem.field379, UserComparator8.field1678);
         WorldMapManager.field45 = new RasterProvider(FriendSystem.field379, UserComparator8.field1678, this.canvas);
         if (var1 == this.frame) {
            Insets var3 = this.frame.getInsets();
            this.canvas.setLocation(this.canvasX + var3.left, var3.top + this.canvasY);
         } else {
            this.canvas.setLocation(this.canvasX, this.canvasY);
         }

         this.field86 = true;
         this.vmethod3332();
      }
   }

   protected final void method295(int var1, int var2) {
      if (this.field82 != var1 || var2 != this.field83) {
         this.method212();
      }

      this.field82 = var1;
      this.field83 = var2;
   }

   protected void clipboardSetString(String var1) {
      this.clipboard.setContents(new StringSelection(var1), (ClipboardOwner)null);
   }

   protected final void startThread(int var1, int var2, int var3) {
      try {
         if (field64 != null) {
            ++field65;
            if (field65 >= 3) {
               this.error("alreadyloaded");
               return;
            }

            this.getAppletContext().showDocument(this.getDocumentBase(), "_self");
            return;
         }

         field64 = this;
         FriendSystem.field379 = var1;
         UserComparator8.field1678 = var2;
         UserComparator1.field3824 = var3;
         RunException.field1605 = this;
         if (field63 == null) {
            field63 = new TaskHandler();
         }

         field63.newThreadTask(this, 1);
      } catch (Exception var5) {
         Projectile.setDestination((String)null, var5);
         this.error("crash");
      }

   }

   protected MouseWheel mouseWheel() {
      if (this.mouseWheelHandler == null) {
         this.mouseWheelHandler = new MouseWheelHandler();
         this.mouseWheelHandler.addTo(this.canvas);
      }

      return this.mouseWheelHandler;
   }

   void method204() {
      Container var1 = this.container();
      long var2 = Tile.method2779();
      long var4 = field66[field74];
      field66[field74] = var2;
      field74 = field74 + 1 & 31;
      if (0L != var4 && var2 > var4) {
         int var6 = (int)(var2 - var4);
         field71 = ((var6 >> 1) + 32000) / var6;
      }

      if (++field87 - 1 > 50) {
         field87 -= 50;
         this.field86 = true;
         this.canvas.setSize(FriendSystem.field379, UserComparator8.field1678);
         this.canvas.setVisible(true);
         if (var1 == this.frame) {
            Insets var7 = this.frame.getInsets();
            this.canvas.setLocation(var7.left + this.canvasX, var7.top + this.canvasY);
         } else {
            this.canvas.setLocation(this.canvasX, this.canvasY);
         }
      }

      if (this.isCanvasInvalid) {
         this.replaceCanvas();
      }

      this.method196();
      this.vmethod3323(this.field86);
      if (this.field86) {
         this.clearBackground();
      }

      this.field86 = false;
   }

   final void method190(Object var1) {
      if (this.eventQueue != null) {
         for(int var2 = 0; var2 < 50 && this.eventQueue.peekEvent() != null; ++var2) {
            class276.method5382(1L);
         }

         if (var1 != null) {
            this.eventQueue.postEvent(new ActionEvent(var1, 1001, "dummy"));
         }

      }
   }

   final synchronized void addCanvas() {
      Container var1 = this.container();
      if (this.canvas != null) {
         this.canvas.removeFocusListener(this);
         var1.remove(this.canvas);
      }

      FriendSystem.field379 = Math.max(var1.getWidth(), this.contentWidth0);
      UserComparator8.field1678 = Math.max(var1.getHeight(), this.contentHeight0);
      Insets var2;
      if (this.frame != null) {
         var2 = this.frame.getInsets();
         FriendSystem.field379 -= var2.right + var2.left;
         UserComparator8.field1678 -= var2.bottom + var2.top;
      }

      this.canvas = new Canvas(this);
      var1.setBackground(Color.BLACK);
      var1.setLayout((LayoutManager)null);
      var1.add(this.canvas);
      this.canvas.setSize(FriendSystem.field379, UserComparator8.field1678);
      this.canvas.setVisible(true);
      this.canvas.setBackground(Color.BLACK);
      if (var1 == this.frame) {
         var2 = this.frame.getInsets();
         this.canvas.setLocation(var2.left + this.canvasX, this.canvasY + var2.top);
      } else {
         this.canvas.setLocation(this.canvasX, this.canvasY);
      }

      this.canvas.addFocusListener(this);
      this.canvas.requestFocus();
      this.field86 = true;
      if (WorldMapManager.field45 != null && FriendSystem.field379 == WorldMapManager.field45.width && UserComparator8.field1678 == WorldMapManager.field45.height) {
         ((RasterProvider)WorldMapManager.field45).setComponent(this.canvas);
         WorldMapManager.field45.drawFull(0, 0);
      } else {
         WorldMapManager.field45 = new RasterProvider(FriendSystem.field379, UserComparator8.field1678, this.canvas);
      }

      this.isCanvasInvalid = false;
      this.canvasSetTimeMs = Tile.method2779();
   }

   final void replaceCanvas() {
      Messages.method1143(this.canvas);
      java.awt.Canvas var1 = this.canvas;
      var1.removeMouseListener(MouseHandler.field151);
      var1.removeMouseMotionListener(MouseHandler.field151);
      var1.removeFocusListener(MouseHandler.field151);
      MouseHandler.field162 = 0;
      if (this.mouseWheelHandler != null) {
         this.mouseWheelHandler.removeFrom(this.canvas);
      }

      this.addCanvas();
      WorldMapManager.method140(this.canvas);
      WorldMapManager.method145(this.canvas);
      if (this.mouseWheelHandler != null) {
         this.mouseWheelHandler.addTo(this.canvas);
      }

      this.method212();
   }

   void method203() {
      long var1 = Tile.method2779();
      long var3 = field81[AbstractRasterProvider.field4008];
      field81[AbstractRasterProvider.field4008] = var1;
      AbstractRasterProvider.field4008 = AbstractRasterProvider.field4008 + 1 & 31;
      if (0L != var3 && var1 > var3) {
         ;
      }

      synchronized(this) {
         class180.field1994 = field94;
      }

      this.vmethod3322();
   }

   protected final void setUpMouse() {
      WorldMapManager.method145(this.canvas);
   }

   protected final void setUpKeyboard() {
      Interpreter.method969();
      WorldMapManager.method140(this.canvas);
   }

   protected final boolean checkHost() {
      String var1 = this.getDocumentBase().getHost().toLowerCase();
      if (!var1.equals("jagex.com") && !var1.endsWith(".jagex.com")) {
         if (!var1.equals("runescape.com") && !var1.endsWith(".runescape.com")) {
            if (var1.endsWith("127.0.0.1")) {
               return true;
            } else {
               while(var1.length() > 0 && var1.charAt(var1.length() - 1) >= '0' && var1.charAt(var1.length() - 1) <= '9') {
                  var1 = var1.substring(0, var1.length() - 1);
               }

               if (var1.endsWith("192.168.1.")) {
                  return true;
               } else {
                  this.error("invalidhost");
                  return false;
               }
            }
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   public final synchronized void paint(Graphics var1) {
      if (this == field64 && !field67) {
         this.field86 = true;
         if (Tile.method2779() - this.canvasSetTimeMs > 1000L) {
            Rectangle var2 = var1.getClipBounds();
            if (var2 == null || var2.width >= FriendSystem.field379 && var2.height >= UserComparator8.field1678) {
               this.isCanvasInvalid = true;
            }
         }

      }
   }

   public final void destroy() {
      if (this == field64 && !field67) {
         stopTimeMs = Tile.method2779();
         class276.method5382(5000L);
         this.kill();
      }
   }

   public void run() {
      try {
         if (TaskHandler.field1771 != null) {
            String var1 = TaskHandler.field1771.toLowerCase();
            if (var1.indexOf("sun") != -1 || var1.indexOf("apple") != -1) {
               String var2 = TaskHandler.field1767;
               if (var2.equals("1.1") || var2.startsWith("1.1.") || var2.equals("1.2") || var2.startsWith("1.2.") || var2.equals("1.3") || var2.startsWith("1.3.") || var2.equals("1.4") || var2.startsWith("1.4.") || var2.equals("1.5") || var2.startsWith("1.5.") || var2.equals("1.6.0")) {
                  this.error("wrongjava");
                  return;
               }

               if (var2.startsWith("1.6.0_")) {
                  int var3;
                  for(var3 = 6; var3 < var2.length() && Strings.method4940(var2.charAt(var3)); ++var3) {
                     ;
                  }

                  String var4 = var2.substring(6, var3);
                  if (class219.method4549(var4) && LoginPacket.method3276(var4) < 10) {
                     this.error("wrongjava");
                     return;
                  }
               }

               field75 = 5;
            }
         }

         this.setFocusCycleRoot(true);
         this.addCanvas();
         this.setUp();
         field70 = class214.method4490();

         while(0L == stopTimeMs || Tile.method2779() < stopTimeMs) {
            class167.field1800 = field70.wait(field69, field75);

            for(int var5 = 0; var5 < class167.field1800; ++var5) {
               this.method203();
            }

            this.method204();
            this.method190(this.canvas);
         }
      } catch (Exception var6) {
         Projectile.setDestination((String)null, var6);
         this.error("crash");
      }

      this.kill();
   }

   public final void start() {
      if (this == field64 && !field67) {
         stopTimeMs = 0L;
      }
   }

   public final void focusGained(FocusEvent var1) {
      field94 = true;
      this.field86 = true;
   }

   public final void focusLost(FocusEvent var1) {
      field94 = false;
   }

   public final void windowActivated(WindowEvent var1) {
   }

   public final void windowClosed(WindowEvent var1) {
   }

   public final void windowClosing(WindowEvent var1) {
      this.destroy();
   }

   public final void windowDeiconified(WindowEvent var1) {
   }

   public final void windowIconified(WindowEvent var1) {
   }

   public final void windowOpened(WindowEvent var1) {
   }

   public abstract void init();

   public final void update(Graphics var1) {
      this.paint(var1);
   }

   public final void stop() {
      if (this == field64 && !field67) {
         stopTimeMs = Tile.method2779() + 4000L;
      }
   }

   public final void windowDeactivated(WindowEvent var1) {
   }
}
