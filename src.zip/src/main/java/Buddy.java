public class Buddy extends User {
   static AbstractIndexCache field3791;
   static int[] field3789;
   public int rank;
   public int world = -1;
   public int int2;

   public boolean method5833() {
      return this.world > 0;
   }

   void set(int var1, int var2) {
      this.world = var1;
      this.int2 = var2;
   }

   public int method5829() {
      return this.world;
   }
}
