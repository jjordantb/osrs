public class GrandExchangeEvent {
   static int field761;
   String string2;
   public final GrandExchangeOffer grandExchangeOffer;
   public final int world;
   String string1;
   public final long field754;

   GrandExchangeEvent(Buffer var1, byte var2, int var3) {
      this.string1 = var1.readStringCp1252NullTerminated();
      this.string2 = var1.readStringCp1252NullTerminated();
      this.world = var1.method3913();
      this.field754 = var1.readLong();
      int var4 = var1.readInt();
      int var5 = var1.readInt();
      this.grandExchangeOffer = new GrandExchangeOffer();
      this.grandExchangeOffer.method1273(2);
      this.grandExchangeOffer.method1255(var2);
      this.grandExchangeOffer.unitPrice = var4;
      this.grandExchangeOffer.totalQuantity = var5;
      this.grandExchangeOffer.currentQuantity = 0;
      this.grandExchangeOffer.currentPrice = 0;
      this.grandExchangeOffer.id = var3;
   }

   public String method1333() {
      return this.string1;
   }

   public String method1334() {
      return this.string2;
   }

   static void method1339() {
      Client.field2133.method1282();
      Client.field2133.packetBuffer.index = 0;
      Client.field2133.serverPacket0 = null;
      Client.field2133.field716 = null;
      Client.field2133.field705 = null;
      Client.field2133.field699 = null;
      Client.field2133.serverPacket0Length = 0;
      Client.field2133.field708 = 0;
      Client.field2105 = 0;
      Client.field2223 = 0;
      Client.field2276 = false;
      Client.field2319 = 0;
      Client.field2165 = 0;

      int var0;
      for(var0 = 0; var0 < 2048; ++var0) {
         Client.field2141[var0] = null;
      }

      ObjectSound.field589 = null;

      for(var0 = 0; var0 < Client.field2249.length; ++var0) {
         Npc var1 = Client.field2249[var0];
         if (var1 != null) {
            var1.targetIndex = -1;
            var1.false0 = false;
         }
      }

      WorldMapLabelSize.method1303();
      class69.method1443(30);

      for(var0 = 0; var0 < 100; ++var0) {
         Client.field2291[var0] = true;
      }

      Interpreter.method968();
   }

   static final void method1335() {
      class178.method3308();
      if (TotalQuantityComparator.field983 != null) {
         TotalQuantityComparator.field983.method5771();
      }

   }
}
