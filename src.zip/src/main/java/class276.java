public class class276 implements Enumerated {
   static final class276 field3528 = new class276(2, 2);
   static final class276 field3531 = new class276(0, 0);
   static final class276 field3527 = new class276(1, 1);
   final int field3529;
   public final int field3530;

   class276(int var1, int var2) {
      this.field3530 = var1;
      this.field3529 = var2;
   }

   public int ordinal() {
      return this.field3529;
   }

   public static final void method5382(long var0) {
      if (var0 > 0L) {
         if (var0 % 10L == 0L) {
            long var2 = var0 - 1L;

            try {
               Thread.sleep(var2);
            } catch (InterruptedException var8) {
               ;
            }

            try {
               Thread.sleep(1L);
            } catch (InterruptedException var7) {
               ;
            }
         } else {
            try {
               Thread.sleep(var0);
            } catch (InterruptedException var6) {
               ;
            }
         }

      }
   }
}
