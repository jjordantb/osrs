import java.security.SecureRandom;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class SecureRandomFuture {
   public static class66 field851;
   ExecutorService executor = Executors.newSingleThreadExecutor();
   Future future;

   SecureRandomFuture() {
      this.future = this.executor.submit(new SecureRandomCallable());
   }

   SecureRandom get() {
      try {
         return (SecureRandom)this.future.get();
      } catch (Exception var4) {
         SecureRandom var3 = new SecureRandom();
         var3.nextInt();
         return var3;
      }
   }

   void shutdown() {
      this.executor.shutdown();
      this.executor = null;
   }

   boolean isDone() {
      return this.future.isDone();
   }

   static void method1481() {
      int var0;
      if (Client.field2345 == 0) {
         class243.field2904 = new Scene(4, 104, 104, Tiles.field217);

         for(var0 = 0; var0 < 4; ++var0) {
            Client.field2144[var0] = new CollisionMap(104, 104);
         }

         TotalQuantityComparator.field986 = new Sprite(512, 512);
         Login.field665 = "Starting game engine...";
         Login.field664 = 5;
         Client.field2345 = 20;
      } else if (Client.field2345 == 20) {
         Login.field665 = "Prepared visibility map";
         Login.field664 = 10;
         Client.field2345 = 30;
      } else if (Client.field2345 == 30) {
         class93.field1028 = Occluder.method2988(0, false, true, true);
         Canvas.field118 = Occluder.method2988(1, false, true, true);
         Tiles.field216 = Occluder.method2988(2, true, false, true);
         class178.field1967 = Occluder.method2988(3, false, true, true);
         class71.field846 = Occluder.method2988(4, false, true, true);
         class320.field3912 = Occluder.method2988(5, true, true, true);
         ServerPacket.field1995 = Occluder.method2988(6, true, true, true);
         class85.field966 = Occluder.method2988(7, false, true, true);
         RunException.field1608 = Occluder.method2988(8, false, true, true);
         class65.field801 = Occluder.method2988(9, false, true, true);
         WorldMapLabelSize.field724 = Occluder.method2988(10, false, true, true);
         IsaacCipher.field2480 = Occluder.method2988(11, false, true, true);
         UrlRequester.field1587 = Occluder.method2988(12, false, true, true);
         GraphicsObject.field569 = Occluder.method2988(13, true, false, true);
         WorldMapSection2.field136 = Occluder.method2988(14, false, true, true);
         ObjectDefinition.field3393 = Occluder.method2988(15, false, true, true);
         AbstractSocket.field1778 = Occluder.method2988(16, true, true, true);
         UserComparator3.field1709 = Occluder.method2988(17, true, true, true);
         Login.field665 = "Connecting to update server";
         Login.field664 = 20;
         Client.field2345 = 40;
      } else if (Client.field2345 == 40) {
         byte var28 = 0;
         var0 = var28 + class93.field1028.method4825() * 4 / 100;
         var0 += Canvas.field118.method4825() * 4 / 100;
         var0 += Tiles.field216.method4825() * 2 / 100;
         var0 += class178.field1967.method4825() * 2 / 100;
         var0 += class71.field846.method4825() * 6 / 100;
         var0 += class320.field3912.method4825() * 4 / 100;
         var0 += ServerPacket.field1995.method4825() * 2 / 100;
         var0 += class85.field966.method4825() * 57 / 100;
         var0 += RunException.field1608.method4825() * 2 / 100;
         var0 += class65.field801.method4825() * 2 / 100;
         var0 += WorldMapLabelSize.field724.method4825() * 2 / 100;
         var0 += IsaacCipher.field2480.method4825() * 2 / 100;
         var0 += UrlRequester.field1587.method4825() * 2 / 100;
         var0 += GraphicsObject.field569.method4825() * 2 / 100;
         var0 += WorldMapSection2.field136.method4825() * 2 / 100;
         var0 += ObjectDefinition.field3393.method4825() * 2 / 100;
         var0 += AbstractSocket.field1778.method4825() * 2 / 100;
         var0 += UserComparator3.field1709.method4824() && UserComparator3.field1709.method5040() ? 1 : 0;
         if (var0 != 100) {
            if (var0 != 0) {
               Login.field665 = "Checking for updates - " + var0 + "%";
            }

            Login.field664 = 30;
         } else {
            class211.method4329(class93.field1028, "Animations");
            class211.method4329(Canvas.field118, "Skeletons");
            class211.method4329(class71.field846, "Sound FX");
            class211.method4329(class320.field3912, "Maps");
            class211.method4329(ServerPacket.field1995, "Music Tracks");
            class211.method4329(class85.field966, "Models");
            class211.method4329(RunException.field1608, "Sprites");
            class211.method4329(IsaacCipher.field2480, "Music Jingles");
            class211.method4329(WorldMapSection2.field136, "Music Samples");
            class211.method4329(ObjectDefinition.field3393, "Music Patches");
            class211.method4329(AbstractSocket.field1778, "World Map");
            GrandExchangeEvents.field997 = new SpriteIds();
            GrandExchangeEvents.field997.read(UserComparator3.field1709);
            Login.field665 = "Loaded update list";
            Login.field664 = 30;
            Client.field2345 = 45;
         }
      } else if (Client.field2345 == 45) {
         HealthBarUpdate.method711(22050, !Client.field2091, 2);
         class214 var34 = new class214();
         var34.method4371(9, 128);
         Client.field2325 = ObjectSound.method1092(GameShell.field63, 0, 22050);
         Client.field2325.method1688(var34);
         UrlRequester.request(ObjectDefinition.field3393, WorldMapSection2.field136, class71.field846, var34);
         class57.field642 = ObjectSound.method1092(GameShell.field63, 1, 2048);
         class10.field116 = new class76();
         class57.field642.method1688(class10.field116);
         IgnoreList.field3698 = new class116(22050, AbstractSoundSystem.field936);
         Login.field665 = "Prepared sound engine";
         Login.field664 = 35;
         Client.field2345 = 50;
         FontName.field3744 = new Fonts(RunException.field1608, GraphicsObject.field569);
      } else {
         int var1;
         if (Client.field2345 == 50) {
            FontName[] var33 = new FontName[]{FontName.field3735, FontName.field3743, FontName.field3738, FontName.field3740, FontName.field3739, FontName.field3741};
            var1 = var33.length;
            Fonts var25 = FontName.field3744;
            FontName[] var24 = new FontName[]{FontName.field3735, FontName.field3743, FontName.field3738, FontName.field3740, FontName.field3739, FontName.field3741};
            Client.field2138 = var25.createMap(var24);
            if (Client.field2138.size() < var1) {
               Login.field665 = "Loading fonts - " + Client.field2138.size() * 100 / var1 + "%";
               Login.field664 = 40;
            } else {
               WorldMapSection3.field625 = (Font) Client.field2138.get(FontName.field3741);
               TotalQuantityComparator.field982 = (Font) Client.field2138.get(FontName.field3735);
               NetSocket.field1950 = (Font) Client.field2138.get(FontName.field3743);
               Player.field444 = Client.field2354.get();
               Login.field665 = "Loaded fonts";
               Login.field664 = 40;
               Client.field2345 = 60;
            }
         } else {
            IndexCache var2;
            int var18;
            int var31;
            IndexCache var36;
            if (Client.field2345 == 60) {
               var36 = WorldMapLabelSize.field724;
               var2 = RunException.field1608;
               var18 = 0;
               if (var36.tryLoadRecordByNames("title.jpg", "")) {
                  ++var18;
               }

               if (var2.tryLoadRecordByNames("logo", "")) {
                  ++var18;
               }

               if (var2.tryLoadRecordByNames("logo_deadman_mode", "")) {
                  ++var18;
               }

               if (var2.tryLoadRecordByNames("titlebox", "")) {
                  ++var18;
               }

               if (var2.tryLoadRecordByNames("titlebutton", "")) {
                  ++var18;
               }

               if (var2.tryLoadRecordByNames("runes", "")) {
                  ++var18;
               }

               if (var2.tryLoadRecordByNames("title_mute", "")) {
                  ++var18;
               }

               if (var2.tryLoadRecordByNames("options_radio_buttons,0", "")) {
                  ++var18;
               }

               if (var2.tryLoadRecordByNames("options_radio_buttons,2", "")) {
                  ++var18;
               }

               if (var2.tryLoadRecordByNames("options_radio_buttons,4", "")) {
                  ++var18;
               }

               if (var2.tryLoadRecordByNames("options_radio_buttons,6", "")) {
                  ++var18;
               }

               var2.tryLoadRecordByNames("sl_back", "");
               var2.tryLoadRecordByNames("sl_flags", "");
               var2.tryLoadRecordByNames("sl_arrows", "");
               var2.tryLoadRecordByNames("sl_stars", "");
               var2.tryLoadRecordByNames("sl_button", "");
               var31 = class45.method1022();
               if (var18 < var31) {
                  Login.field665 = "Loading title screen - " + var18 * 100 / var31 + "%";
                  Login.field664 = 50;
               } else {
                  Login.field665 = "Loaded title screen";
                  Login.field664 = 50;
                  class69.method1443(5);
                  Client.field2345 = 70;
               }
            } else if (Client.field2345 == 70) {
               if (!Tiles.field216.method5040()) {
                  Login.field665 = "Loading config - " + Tiles.field216.loadPercent() + "%";
                  Login.field664 = 60;
               } else {
                  IndexCache var32 = Tiles.field216;
                  OverlayDefinition.field3688 = var32;
                  var36 = Tiles.field216;
                  UnderlayDefinition.field3567 = var36;
                  var2 = Tiles.field216;
                  IndexCache var3 = class85.field966;
                  KitDefinition.field3354 = var2;
                  KitDefinition.field3343 = var3;
                  KitDefinition.field3344 = KitDefinition.field3354.method5025(3);
                  AreaDefinition.method4892(Tiles.field216, class85.field966, Client.field2091);
                  class157.method3021(Tiles.field216, class85.field966);
                  GameObject.method2901(Tiles.field216);
                  WorldMapSection2.method402(Tiles.field216, class85.field966, Client.field2090, WorldMapSection3.field625);
                  MouseRecorder.method1008(Tiles.field216, class93.field1028, Canvas.field118);
                  Messages.method1145(Tiles.field216, class85.field966);
                  class177.method3291(Tiles.field216);
                  class178.method3310(Tiles.field216);
                  class219.method4546(class178.field1967, class85.field966, RunException.field1608, GraphicsObject.field569);
                  IndexCache var19 = Tiles.field216;
                  InvDefinition.field2827 = var19;
                  Varcs.setInt(Tiles.field216);
                  IndexCache var26 = Tiles.field216;
                  VarcInt.field2813 = var26;
                  ServerBuild.method4931(Tiles.field216);
                  IndexCache var27 = Tiles.field216;
                  class57.field645 = var27;
                  class17.field181 = new Varcs();
                  IndexCache var7 = Tiles.field216;
                  IndexCache var29 = RunException.field1608;
                  IndexCache var9 = GraphicsObject.field569;
                  class176.field1959 = var7;
                  HitSplatDefinition.field3375 = var29;
                  HitSplatDefinition.field3367 = var9;
                  IndexCache var30 = Tiles.field216;
                  IndexCache var11 = RunException.field1608;
                  HealthBarDefinition.field3456 = var30;
                  HealthBarDefinition.field3447 = var11;
                  IndexCache var12 = Tiles.field216;
                  IndexCache var13 = RunException.field1608;
                  AreaDefinition.field2879 = var13;
                  if (var12.method5040()) {
                     AreaDefinition.field2901 = var12.method5025(35);
                     AreaDefinition.field2880 = new AreaDefinition[AreaDefinition.field2901];

                     for(int var14 = 0; var14 < AreaDefinition.field2901; ++var14) {
                        byte[] var15 = var12.takeRecord(35, var14);
                        AreaDefinition.field2880[var14] = new AreaDefinition(var14);
                        if (var15 != null) {
                           AreaDefinition.field2880[var14].read(new Buffer(var15));
                           AreaDefinition.field2880[var14].method4869();
                        }
                     }
                  }

                  Login.field665 = "Loaded config";
                  Login.field664 = 60;
                  Client.field2345 = 80;
               }
            } else if (Client.field2345 == 80) {
               var0 = 0;
               if (class34.field402 == null) {
                  class34.field402 = UserComparator3.method2971(RunException.field1608, GrandExchangeEvents.field997.field3776, 0);
               } else {
                  ++var0;
               }

               if (WorldMapLabelSize.field723 == null) {
                  WorldMapLabelSize.field723 = UserComparator3.method2971(RunException.field1608, GrandExchangeEvents.field997.field3777, 0);
               } else {
                  ++var0;
               }

               IndexedSprite[] var17;
               if (class273.field3514 == null) {
                  var2 = RunException.field1608;
                  var18 = GrandExchangeEvents.field997.mapScenes;
                  if (!class65.method1382(var2, var18, 0)) {
                     var17 = null;
                  } else {
                     var17 = SpriteIds.method5817();
                  }

                  class273.field3514 = var17;
               } else {
                  ++var0;
               }

               boolean var4;
               byte[] var5;
               Sprite[] var6;
               Sprite var8;
               byte[] var10;
               int var20;
               int var21;
               int var22;
               Sprite[] var35;
               if (Player.field445 == null) {
                  var2 = RunException.field1608;
                  var18 = GrandExchangeEvents.field997.headIconsPk;
                  var5 = var2.takeRecord(var18, 0);
                  if (var5 == null) {
                     var4 = false;
                  } else {
                     TilePaint.method2436(var5);
                     var4 = true;
                  }

                  if (!var4) {
                     var35 = null;
                  } else {
                     var6 = new Sprite[class328.field3985];
                     var20 = 0;

                     while(true) {
                        if (var20 >= class328.field3985) {
                           class328.field3982 = null;
                           class328.field3984 = null;
                           class328.field3987 = null;
                           VarcInt.field2811 = null;
                           class328.field3986 = null;
                           class328.field3989 = null;
                           var35 = var6;
                           break;
                        }

                        var8 = var6[var20] = new Sprite();
                        var8.width = class328.field3983;
                        var8.height = class328.field3988;
                        var8.yOffset = class328.field3982[var20];
                        var8.xOffset = class328.field3984[var20];
                        var8.subWidth = class328.field3987[var20];
                        var8.subHeight = VarcInt.field2811[var20];
                        var21 = var8.subHeight * var8.subWidth;
                        var10 = class328.field3989[var20];
                        var8.pixels = new int[var21];

                        for(var22 = 0; var22 < var21; ++var22) {
                           var8.pixels[var22] = class328.field3986[var10[var22] & 255];
                        }

                        ++var20;
                     }
                  }

                  Player.field445 = var35;
               } else {
                  ++var0;
               }

               if (UrlRequester.field1586 == null) {
                  var2 = RunException.field1608;
                  var18 = GrandExchangeEvents.field997.headIconsPrayer;
                  var5 = var2.takeRecord(var18, 0);
                  if (var5 == null) {
                     var4 = false;
                  } else {
                     TilePaint.method2436(var5);
                     var4 = true;
                  }

                  if (!var4) {
                     var35 = null;
                  } else {
                     var6 = new Sprite[class328.field3985];
                     var20 = 0;

                     while(true) {
                        if (var20 >= class328.field3985) {
                           class328.field3982 = null;
                           class328.field3984 = null;
                           class328.field3987 = null;
                           VarcInt.field2811 = null;
                           class328.field3986 = null;
                           class328.field3989 = null;
                           var35 = var6;
                           break;
                        }

                        var8 = var6[var20] = new Sprite();
                        var8.width = class328.field3983;
                        var8.height = class328.field3988;
                        var8.yOffset = class328.field3982[var20];
                        var8.xOffset = class328.field3984[var20];
                        var8.subWidth = class328.field3987[var20];
                        var8.subHeight = VarcInt.field2811[var20];
                        var21 = var8.subHeight * var8.subWidth;
                        var10 = class328.field3989[var20];
                        var8.pixels = new int[var21];

                        for(var22 = 0; var22 < var21; ++var22) {
                           var8.pixels[var22] = class328.field3986[var10[var22] & 255];
                        }

                        ++var20;
                     }
                  }

                  UrlRequester.field1586 = var35;
               } else {
                  ++var0;
               }

               if (class21.field229 == null) {
                  var2 = RunException.field1608;
                  var18 = GrandExchangeEvents.field997.headIconsHint;
                  var5 = var2.takeRecord(var18, 0);
                  if (var5 == null) {
                     var4 = false;
                  } else {
                     TilePaint.method2436(var5);
                     var4 = true;
                  }

                  if (!var4) {
                     var35 = null;
                  } else {
                     var6 = new Sprite[class328.field3985];
                     var20 = 0;

                     while(true) {
                        if (var20 >= class328.field3985) {
                           class328.field3982 = null;
                           class328.field3984 = null;
                           class328.field3987 = null;
                           VarcInt.field2811 = null;
                           class328.field3986 = null;
                           class328.field3989 = null;
                           var35 = var6;
                           break;
                        }

                        var8 = var6[var20] = new Sprite();
                        var8.width = class328.field3983;
                        var8.height = class328.field3988;
                        var8.yOffset = class328.field3982[var20];
                        var8.xOffset = class328.field3984[var20];
                        var8.subWidth = class328.field3987[var20];
                        var8.subHeight = VarcInt.field2811[var20];
                        var21 = var8.subHeight * var8.subWidth;
                        var10 = class328.field3989[var20];
                        var8.pixels = new int[var21];

                        for(var22 = 0; var22 < var21; ++var22) {
                           var8.pixels[var22] = class328.field3986[var10[var22] & 255];
                        }

                        ++var20;
                     }
                  }

                  class21.field229 = var35;
               } else {
                  ++var0;
               }

               if (class192.field2438 == null) {
                  var2 = RunException.field1608;
                  var18 = GrandExchangeEvents.field997.mapMarkers;
                  var5 = var2.takeRecord(var18, 0);
                  if (var5 == null) {
                     var4 = false;
                  } else {
                     TilePaint.method2436(var5);
                     var4 = true;
                  }

                  if (!var4) {
                     var35 = null;
                  } else {
                     var6 = new Sprite[class328.field3985];
                     var20 = 0;

                     while(true) {
                        if (var20 >= class328.field3985) {
                           class328.field3982 = null;
                           class328.field3984 = null;
                           class328.field3987 = null;
                           VarcInt.field2811 = null;
                           class328.field3986 = null;
                           class328.field3989 = null;
                           var35 = var6;
                           break;
                        }

                        var8 = var6[var20] = new Sprite();
                        var8.width = class328.field3983;
                        var8.height = class328.field3988;
                        var8.yOffset = class328.field3982[var20];
                        var8.xOffset = class328.field3984[var20];
                        var8.subWidth = class328.field3987[var20];
                        var8.subHeight = VarcInt.field2811[var20];
                        var21 = var8.subHeight * var8.subWidth;
                        var10 = class328.field3989[var20];
                        var8.pixels = new int[var21];

                        for(var22 = 0; var22 < var21; ++var22) {
                           var8.pixels[var22] = class328.field3986[var10[var22] & 255];
                        }

                        ++var20;
                     }
                  }

                  class192.field2438 = var35;
               } else {
                  ++var0;
               }

               if (UserComparator5.field1593 == null) {
                  var2 = RunException.field1608;
                  var18 = GrandExchangeEvents.field997.crosses;
                  var5 = var2.takeRecord(var18, 0);
                  if (var5 == null) {
                     var4 = false;
                  } else {
                     TilePaint.method2436(var5);
                     var4 = true;
                  }

                  if (!var4) {
                     var35 = null;
                  } else {
                     var6 = new Sprite[class328.field3985];
                     var20 = 0;

                     while(true) {
                        if (var20 >= class328.field3985) {
                           class328.field3982 = null;
                           class328.field3984 = null;
                           class328.field3987 = null;
                           VarcInt.field2811 = null;
                           class328.field3986 = null;
                           class328.field3989 = null;
                           var35 = var6;
                           break;
                        }

                        var8 = var6[var20] = new Sprite();
                        var8.width = class328.field3983;
                        var8.height = class328.field3988;
                        var8.yOffset = class328.field3982[var20];
                        var8.xOffset = class328.field3984[var20];
                        var8.subWidth = class328.field3987[var20];
                        var8.subHeight = VarcInt.field2811[var20];
                        var21 = var8.subWidth * var8.subHeight;
                        var10 = class328.field3989[var20];
                        var8.pixels = new int[var21];

                        for(var22 = 0; var22 < var21; ++var22) {
                           var8.pixels[var22] = class328.field3986[var10[var22] & 255];
                        }

                        ++var20;
                     }
                  }

                  UserComparator5.field1593 = var35;
               } else {
                  ++var0;
               }

               if (GameShell.field98 == null) {
                  var2 = RunException.field1608;
                  var18 = GrandExchangeEvents.field997.mapDots;
                  var5 = var2.takeRecord(var18, 0);
                  if (var5 == null) {
                     var4 = false;
                  } else {
                     TilePaint.method2436(var5);
                     var4 = true;
                  }

                  if (!var4) {
                     var35 = null;
                  } else {
                     var6 = new Sprite[class328.field3985];
                     var20 = 0;

                     while(true) {
                        if (var20 >= class328.field3985) {
                           class328.field3982 = null;
                           class328.field3984 = null;
                           class328.field3987 = null;
                           VarcInt.field2811 = null;
                           class328.field3986 = null;
                           class328.field3989 = null;
                           var35 = var6;
                           break;
                        }

                        var8 = var6[var20] = new Sprite();
                        var8.width = class328.field3983;
                        var8.height = class328.field3988;
                        var8.yOffset = class328.field3982[var20];
                        var8.xOffset = class328.field3984[var20];
                        var8.subWidth = class328.field3987[var20];
                        var8.subHeight = VarcInt.field2811[var20];
                        var21 = var8.subHeight * var8.subWidth;
                        var10 = class328.field3989[var20];
                        var8.pixels = new int[var21];

                        for(var22 = 0; var22 < var21; ++var22) {
                           var8.pixels[var22] = class328.field3986[var10[var22] & 255];
                        }

                        ++var20;
                     }
                  }

                  GameShell.field98 = var35;
               } else {
                  ++var0;
               }

               if (class189.field2394 == null) {
                  var2 = RunException.field1608;
                  var18 = GrandExchangeEvents.field997.scrollBars;
                  var5 = var2.takeRecord(var18, 0);
                  if (var5 == null) {
                     var4 = false;
                  } else {
                     TilePaint.method2436(var5);
                     var4 = true;
                  }

                  if (!var4) {
                     var17 = null;
                  } else {
                     var17 = SpriteIds.method5817();
                  }

                  class189.field2394 = var17;
               } else {
                  ++var0;
               }

               if (class17.field183 == null) {
                  var2 = RunException.field1608;
                  var18 = GrandExchangeEvents.field997.modIcons;
                  var5 = var2.takeRecord(var18, 0);
                  if (var5 == null) {
                     var4 = false;
                  } else {
                     TilePaint.method2436(var5);
                     var4 = true;
                  }

                  if (!var4) {
                     var17 = null;
                  } else {
                     var17 = SpriteIds.method5817();
                  }

                  class17.field183 = var17;
               } else {
                  ++var0;
               }

               if (var0 < 11) {
                  Login.field665 = "Loading sprites - " + var0 * 100 / 12 + "%";
                  Login.field664 = 70;
               } else {
                  AbstractFont.field3800 = class17.field183;
                  WorldMapLabelSize.field723.normalize();
                  var1 = (int)(Math.random() * 21.0D) - 10;
                  int var23 = (int)(Math.random() * 21.0D) - 10;
                  var18 = (int)(Math.random() * 21.0D) - 10;
                  var31 = (int)(Math.random() * 41.0D) - 20;
                  class273.field3514[0].shiftColors(var31 + var1, var23 + var31, var18 + var31);
                  Login.field665 = "Loaded sprites";
                  Login.field664 = 70;
                  Client.field2345 = 90;
               }
            } else if (Client.field2345 == 90) {
               if (!class65.field801.method5040()) {
                  Login.field665 = "Loading textures - " + "0%";
                  Login.field664 = 90;
               } else {
                  Timer.field3526 = new TextureProvider(class65.field801, RunException.field1608, 20, 0.8D, Client.field2091 ? 64 : 128);
                  Rasterizer3D.method2595(Timer.field3526);
                  Rasterizer3D.method2596(0.8D);
                  Client.field2345 = 100;
               }
            } else if (Client.field2345 == 100) {
               var0 = Timer.field3526.method2403();
               if (var0 < 100) {
                  Login.field665 = "Loading textures - " + var0 + "%";
                  Login.field664 = 90;
               } else {
                  Login.field665 = "Loaded textures";
                  Login.field664 = 90;
                  Client.field2345 = 110;
               }
            } else if (Client.field2345 == 110) {
               class17.field180 = new MouseRecorder();
               GameShell.field63.newThreadTask(class17.field180, 10);
               Login.field665 = "Loaded input handler";
               Login.field664 = 92;
               Client.field2345 = 120;
            } else if (Client.field2345 == 120) {
               if (!WorldMapLabelSize.field724.tryLoadRecordByNames("huffman", "")) {
                  Login.field665 = "Loading wordpack - " + 0 + "%";
                  Login.field664 = 94;
               } else {
                  Huffman var16 = new Huffman(WorldMapLabelSize.field724.takeRecordByNames("huffman", ""));
                  VarpDefinition.method4928(var16);
                  Login.field665 = "Loaded wordpack";
                  Login.field664 = 94;
                  Client.field2345 = 130;
               }
            } else if (Client.field2345 == 130) {
               if (!class178.field1967.method5040()) {
                  Login.field665 = "Loading interfaces - " + class178.field1967.loadPercent() * 4 / 5 + "%";
                  Login.field664 = 96;
               } else if (!UrlRequester.field1587.method5040()) {
                  Login.field665 = "Loading interfaces - " + (80 + UrlRequester.field1587.loadPercent() / 6) + "%";
                  Login.field664 = 96;
               } else if (!GraphicsObject.field569.method5040()) {
                  Login.field665 = "Loading interfaces - " + (96 + GraphicsObject.field569.loadPercent() / 50) + "%";
                  Login.field664 = 96;
               } else {
                  Login.field665 = "Loaded interfaces";
                  Login.field664 = 98;
                  Client.field2345 = 140;
               }
            } else if (Client.field2345 == 140) {
               Login.field664 = 100;
               if (!AbstractSocket.field1778.tryLoadArchiveByName(WorldMapCacheName.field235.name)) {
                  Login.field665 = "Loading world map - " + AbstractSocket.field1778.archiveLoadPercentByName(WorldMapCacheName.field235.name) / 10 + "%";
               } else {
                  if (class12.field123 == null) {
                     class12.field123 = new WorldMap();
                     class12.field123.init(AbstractSocket.field1778, NetSocket.field1950, Client.field2138, class273.field3514);
                  }

                  var0 = class12.field123.method6017();
                  if (var0 < 100) {
                     Login.field665 = "Loading world map - " + (var0 * 9 / 10 + 10) + "%";
                  } else {
                     Login.field665 = "Loaded world map";
                     Client.field2345 = 150;
                  }
               }
            } else if (Client.field2345 == 150) {
               class69.method1443(10);
            }
         }
      }
   }
}
