import java.io.IOException;

public class Varps {
   public static int[] field2762;
   static int[] field2760 = new int[32];
   public static int[] field2763;

   static {
      int var0 = 2;

      for(int var1 = 0; var1 < 32; ++var1) {
         field2760[var1] = var0 - 1;
         var0 += var0;
      }

      field2763 = new int[4000];
      field2762 = new int[4000];
   }

   public static void method4668(boolean var0) {
      if (NetCache.field2833 != null) {
         try {
            Buffer var1 = new Buffer(4);
            var1.writeByte(var0 ? 2 : 3);
            var1.writeMedium(0);
            NetCache.field2833.write(var1.array, 0, 4);
         } catch (IOException var4) {
            try {
               NetCache.field2833.close();
            } catch (Exception var3) {
               ;
            }

            ++NetCache.field2848;
            NetCache.field2833 = null;
         }

      }
   }

   static final void method4667(int var0, int var1, int var2, int var3) {
      for(int var4 = 0; var4 < Client.field2296; ++var4) {
         if (Client.field2262[var4] + Client.field2206[var4] > var0 && Client.field2206[var4] < var0 + var2 && Client.field2297[var4] + Client.field2295[var4] > var1 && Client.field2295[var4] < var3 + var1) {
            Client.field2292[var4] = true;
         }
      }

   }
}
