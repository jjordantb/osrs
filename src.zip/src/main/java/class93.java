public class class93 {
   static int[] field1026;
   static int[] field1025;
   static int field1032;
   static byte[][][] field1031;
   static IndexCache field1028;
   final int field1023;
   final int field1027;
   final int field1022;

   class93(int var1, int var2, int var3) {
      this.field1027 = var1;
      this.field1022 = var2;
      this.field1023 = var3;
   }

   static String method1786(int var0) {
      return "<img=" + var0 + ">";
   }

   public static boolean method1787(long var0) {
      boolean var2 = 0L != var0;
      if (var2) {
         boolean var3 = (int)(var0 >>> 16 & 1L) == 1;
         var2 = !var3;
      }

      return var2;
   }

   static final void method1784() {
      if (Client.field2168 > 0) {
         class39.method973();
      } else {
         Client.field2347.method5357();
         class69.method1443(40);
         SecureRandomCallable.field515 = Client.field2133.getSocket();
         Client.field2133.removeSocket();
      }
   }

   static boolean method1785(int var0) {
      for(int var1 = 0; var1 < Client.field2308; ++var1) {
         if (Client.field2310[var1] == var0) {
            return true;
         }
      }

      return false;
   }
}
