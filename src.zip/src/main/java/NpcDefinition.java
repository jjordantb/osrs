import java.security.SecureRandom;

public class NpcDefinition extends DualNode {
   public static EvictingDualNodeHashTable field3570 = new EvictingDualNodeHashTable(64);
   static AbstractIndexCache field3601;
   public static EvictingDualNodeHashTable field3571 = new EvictingDualNodeHashTable(50);
   static AbstractIndexCache field3574;
   public boolean field3590 = false;
   int transformVarbit = -1;
   public int[] transforms;
   int field3594 = 0;
   public boolean field3602 = true;
   public boolean isInteractable = true;
   int field3595 = 0;
   IterableNodeHashTable params;
   public int field3603 = 32;
   public int headIconPrayer = -1;
   int transformVarp = -1;
   short[] retextureFrom;
   public int size = 1;
   public int id;
   public int walkSequence = -1;
   short[] recolorTo;
   short[] recolorFrom;
   public int idleSequence = -1;
   public int walkTurnSequence = -1;
   public String[] actions = new String[5];
   public String name = "null";
   public int turnRightSequence = -1;
   int[] field3578;
   public boolean field3576 = false;
   public int turnLeftSequence = -1;
   public int combatLevel = -1;
   short[] retextureTo;
   int heightScale = 128;
   public int walkTurnRightSequence = -1;
   int[] archives;
   public int walkTurnLeftSequence = -1;
   int widthScale = 128;
   public boolean drawMapDot = true;

   void readNext(Buffer var1, int var2) {
      int var3;
      int var4;
      if (var2 == 1) {
         var3 = var1.readUnsignedByte();
         this.archives = new int[var3];

         for(var4 = 0; var4 < var3; ++var4) {
            this.archives[var4] = var1.method3913();
         }
      } else if (var2 == 2) {
         this.name = var1.readStringCp1252NullTerminated();
      } else if (var2 == 12) {
         this.size = var1.readUnsignedByte();
      } else if (var2 == 13) {
         this.idleSequence = var1.method3913();
      } else if (var2 == 14) {
         this.walkSequence = var1.method3913();
      } else if (var2 == 15) {
         this.turnLeftSequence = var1.method3913();
      } else if (var2 == 16) {
         this.turnRightSequence = var1.method3913();
      } else if (var2 == 17) {
         this.walkSequence = var1.method3913();
         this.walkTurnSequence = var1.method3913();
         this.walkTurnLeftSequence = var1.method3913();
         this.walkTurnRightSequence = var1.method3913();
      } else if (var2 >= 30 && var2 < 35) {
         this.actions[var2 - 30] = var1.readStringCp1252NullTerminated();
         if (this.actions[var2 - 30].equalsIgnoreCase("Hidden")) {
            this.actions[var2 - 30] = null;
         }
      } else if (var2 == 40) {
         var3 = var1.readUnsignedByte();
         this.recolorFrom = new short[var3];
         this.recolorTo = new short[var3];

         for(var4 = 0; var4 < var3; ++var4) {
            this.recolorFrom[var4] = (short)var1.method3913();
            this.recolorTo[var4] = (short)var1.method3913();
         }
      } else if (var2 == 41) {
         var3 = var1.readUnsignedByte();
         this.retextureFrom = new short[var3];
         this.retextureTo = new short[var3];

         for(var4 = 0; var4 < var3; ++var4) {
            this.retextureFrom[var4] = (short)var1.method3913();
            this.retextureTo[var4] = (short)var1.method3913();
         }
      } else if (var2 == 60) {
         var3 = var1.readUnsignedByte();
         this.field3578 = new int[var3];

         for(var4 = 0; var4 < var3; ++var4) {
            this.field3578[var4] = var1.method3913();
         }
      } else if (var2 == 93) {
         this.drawMapDot = false;
      } else if (var2 == 95) {
         this.combatLevel = var1.method3913();
      } else if (var2 == 97) {
         this.widthScale = var1.method3913();
      } else if (var2 == 98) {
         this.heightScale = var1.method3913();
      } else if (var2 == 99) {
         this.field3576 = true;
      } else if (var2 == 100) {
         this.field3594 = var1.readByte();
      } else if (var2 == 101) {
         this.field3595 = var1.readByte() * 5;
      } else if (var2 == 102) {
         this.headIconPrayer = var1.method3913();
      } else if (var2 == 103) {
         this.field3603 = var1.method3913();
      } else if (var2 != 106 && var2 != 118) {
         if (var2 == 107) {
            this.isInteractable = false;
         } else if (var2 == 109) {
            this.field3602 = false;
         } else if (var2 == 111) {
            this.field3590 = true;
         } else if (var2 == 249) {
            this.params = SpriteMask.contains(var1, this.params);
         }
      } else {
         this.transformVarbit = var1.method3913();
         if (this.transformVarbit == 65535) {
            this.transformVarbit = -1;
         }

         this.transformVarp = var1.method3913();
         if (this.transformVarp == 65535) {
            this.transformVarp = -1;
         }

         var3 = -1;
         if (var2 == 118) {
            var3 = var1.method3913();
            if (var3 == 65535) {
               var3 = -1;
            }
         }

         var4 = var1.readUnsignedByte();
         this.transforms = new int[var4 + 2];

         for(int var5 = 0; var5 <= var4; ++var5) {
            this.transforms[var5] = var1.method3913();
            if (this.transforms[var5] == 65535) {
               this.transforms[var5] = -1;
            }
         }

         this.transforms[var4 + 1] = var3;
      }

   }

   public boolean method5432() {
      if (this.transforms == null) {
         return true;
      } else {
         int var1 = -1;
         if (this.transformVarbit != -1) {
            var1 = AbstractSoundSystem.method1697(this.transformVarbit);
         } else if (this.transformVarp != -1) {
            var1 = Varps.field2762[this.transformVarp];
         }

         if (var1 >= 0 && var1 < this.transforms.length) {
            return this.transforms[var1] != -1;
         } else {
            return this.transforms[this.transforms.length - 1] != -1;
         }
      }
   }

   void init() {
   }

   public final Model getModel(SequenceDefinition var1, int var2, SequenceDefinition var3, int var4) {
      if (this.transforms != null) {
         NpcDefinition var12 = this.transform();
         return var12 == null ? null : var12.getModel(var1, var2, var3, var4);
      } else {
         Model var5 = (Model)field3571.get((long)this.id);
         if (var5 == null) {
            boolean var6 = false;

            for(int var7 = 0; var7 < this.archives.length; ++var7) {
               if (!field3574.tryLoadRecord(this.archives[var7], 0)) {
                  var6 = true;
               }
            }

            if (var6) {
               return null;
            }

            ModelData[] var8 = new ModelData[this.archives.length];

            int var9;
            for(var9 = 0; var9 < this.archives.length; ++var9) {
               var8[var9] = ModelData.method2741(field3574, this.archives[var9], 0);
            }

            ModelData var11;
            if (var8.length == 1) {
               var11 = var8[0];
            } else {
               var11 = new ModelData(var8, var8.length);
            }

            if (this.recolorFrom != null) {
               for(var9 = 0; var9 < this.recolorFrom.length; ++var9) {
                  var11.recolor(this.recolorFrom[var9], this.recolorTo[var9]);
               }
            }

            if (this.retextureFrom != null) {
               for(var9 = 0; var9 < this.retextureFrom.length; ++var9) {
                  var11.retexture(this.retextureFrom[var9], this.retextureTo[var9]);
               }
            }

            var5 = var11.toModel(this.field3594 + 64, this.field3595 + 850, -30, -50, -30);
            field3571.put(var5, (long)this.id);
         }

         Model var10;
         if (var1 != null && var3 != null) {
            var10 = var1.animateSequence2(var5, var2, var3, var4);
         } else if (var1 != null) {
            var10 = var1.animateSequence(var5, var2);
         } else if (var3 != null) {
            var10 = var3.animateSequence(var5, var4);
         } else {
            var10 = var5.toSharedSequenceModel(true);
         }

         if (this.widthScale != 128 || this.heightScale != 128) {
            var10.scale(this.widthScale, this.heightScale, this.widthScale);
         }

         return var10;
      }
   }

   public int getIntParam(int var1, int var2) {
      return class130.ordinal(this.params, var1, var2);
   }

   public final NpcDefinition transform() {
      int var1 = -1;
      if (this.transformVarbit != -1) {
         var1 = AbstractSoundSystem.method1697(this.transformVarbit);
      } else if (this.transformVarp != -1) {
         var1 = Varps.field2762[this.transformVarp];
      }

      int var2;
      if (var1 >= 0 && var1 < this.transforms.length - 1) {
         var2 = this.transforms[var1];
      } else {
         var2 = this.transforms[this.transforms.length - 1];
      }

      return var2 != -1 ? NetFileRequest.method4959(var2) : null;
   }

   public final ModelData getModelData() {
      if (this.transforms != null) {
         NpcDefinition var1 = this.transform();
         return var1 == null ? null : var1.getModelData();
      } else if (this.field3578 == null) {
         return null;
      } else {
         boolean var5 = false;

         for(int var2 = 0; var2 < this.field3578.length; ++var2) {
            if (!field3574.tryLoadRecord(this.field3578[var2], 0)) {
               var5 = true;
            }
         }

         if (var5) {
            return null;
         } else {
            ModelData[] var6 = new ModelData[this.field3578.length];

            for(int var3 = 0; var3 < this.field3578.length; ++var3) {
               var6[var3] = ModelData.method2741(field3574, this.field3578[var3], 0);
            }

            ModelData var7;
            if (var6.length == 1) {
               var7 = var6[0];
            } else {
               var7 = new ModelData(var6, var6.length);
            }

            int var4;
            if (this.recolorFrom != null) {
               for(var4 = 0; var4 < this.recolorFrom.length; ++var4) {
                  var7.recolor(this.recolorFrom[var4], this.recolorTo[var4]);
               }
            }

            if (this.retextureFrom != null) {
               for(var4 = 0; var4 < this.retextureFrom.length; ++var4) {
                  var7.retexture(this.retextureFrom[var4], this.retextureTo[var4]);
               }
            }

            return var7;
         }
      }
   }

   void read(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.readNext(var1, var2);
      }
   }

   public String getStringParam(int var1, String var2) {
      return class130.method2826(this.params, var1, var2);
   }

   static SecureRandom method5437() {
      SecureRandom var0 = new SecureRandom();
      var0.nextInt();
      return var0;
   }
}
