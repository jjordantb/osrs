public class class114 {
   int[] field1286;
   int field1285;
   int[] field1284;
   int field1287;

   class114() {
      MusicSample.method1343(16);
      this.field1285 = MusicSample.method1358() != 0 ? MusicSample.method1343(4) + 1 : 1;
      if (MusicSample.method1358() != 0) {
         MusicSample.method1343(8);
      }

      MusicSample.method1343(2);
      if (this.field1285 > 1) {
         this.field1287 = MusicSample.method1343(4);
      }

      this.field1286 = new int[this.field1285];
      this.field1284 = new int[this.field1285];

      for(int var1 = 0; var1 < this.field1285; ++var1) {
         MusicSample.method1343(8);
         this.field1286[var1] = MusicSample.method1343(8);
         this.field1284[var1] = MusicSample.method1343(8);
      }

   }
}
