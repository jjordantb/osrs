public class DynamicObject extends Entity {
   SequenceDefinition sequenceDefinition;
   int x;
   int orientation;
   int id;
   int y;
   int cycleStart;
   int plane;
   int type;
   int frame;

   DynamicObject(int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean var8, Entity var9) {
      this.id = var1;
      this.type = var2;
      this.orientation = var3;
      this.plane = var4;
      this.x = var5;
      this.y = var6;
      if (var7 != -1) {
         this.sequenceDefinition = WorldMapCacheName.method547(var7);
         this.frame = 0;
         this.cycleStart = Client.field2098 - 1;
         if (this.sequenceDefinition.field3463 == 0 && var9 != null && var9 instanceof DynamicObject) {
            DynamicObject var10 = (DynamicObject)var9;
            if (this.sequenceDefinition == var10.sequenceDefinition) {
               this.frame = var10.frame;
               this.cycleStart = var10.cycleStart;
               return;
            }
         }

         if (var8 && this.sequenceDefinition.frameCount != -1) {
            this.frame = (int)(Math.random() * (double)this.sequenceDefinition.frameIds.length);
            this.cycleStart -= (int)(Math.random() * (double)this.sequenceDefinition.frameLengths[this.frame]);
         }
      }

   }

   protected final Model getModel() {
      if (this.sequenceDefinition != null) {
         int var1 = Client.field2098 - this.cycleStart;
         if (var1 > 100 && this.sequenceDefinition.frameCount > 0) {
            var1 = 100;
         }

         label53: {
            do {
               do {
                  if (var1 <= this.sequenceDefinition.frameLengths[this.frame]) {
                     break label53;
                  }

                  var1 -= this.sequenceDefinition.frameLengths[this.frame];
                  ++this.frame;
               } while(this.frame < this.sequenceDefinition.frameIds.length);

               this.frame -= this.sequenceDefinition.frameCount;
            } while(this.frame >= 0 && this.frame < this.sequenceDefinition.frameIds.length);

            this.sequenceDefinition = null;
         }

         this.cycleStart = Client.field2098 - var1;
      }

      ObjectDefinition var12 = class252.method4958(this.id);
      if (var12.transforms != null) {
         var12 = var12.transform();
      }

      if (var12 == null) {
         return null;
      } else {
         int var2;
         int var3;
         if (this.orientation != 1 && this.orientation != 3) {
            var2 = var12.sizeX;
            var3 = var12.sizeY;
         } else {
            var2 = var12.sizeY;
            var3 = var12.sizeX;
         }

         int var4 = (var2 >> 1) + this.x;
         int var5 = (var2 + 1 >> 1) + this.x;
         int var6 = (var3 >> 1) + this.y;
         int var7 = (var3 + 1 >> 1) + this.y;
         int[][] var8 = Tiles.field217[this.plane];
         int var9 = var8[var5][var7] + var8[var4][var6] + var8[var5][var6] + var8[var4][var7] >> 2;
         int var10 = (this.x << 7) + (var2 << 6);
         int var11 = (this.y << 7) + (var3 << 6);
         return var12.getModelDynamic(this.type, this.orientation, var8, var10, var9, var11, this.sequenceDefinition, this.frame);
      }
   }

   static int method1830(int var0, Script var1, boolean var2) {
      Widget var3 = var2 ? class85.field961 : Interpreter.field477;
      if (var0 == 1500) {
         Interpreter.field467[++class31.field364 - 1] = var3.x;
         return 1;
      } else if (var0 == 1501) {
         Interpreter.field467[++class31.field364 - 1] = var3.y;
         return 1;
      } else if (var0 == 1502) {
         Interpreter.field467[++class31.field364 - 1] = var3.width;
         return 1;
      } else if (var0 == 1503) {
         Interpreter.field467[++class31.field364 - 1] = var3.height;
         return 1;
      } else if (var0 == 1504) {
         Interpreter.field467[++class31.field364 - 1] = var3.isHidden ? 1 : 0;
         return 1;
      } else if (var0 == 1505) {
         Interpreter.field467[++class31.field364 - 1] = var3.parentId;
         return 1;
      } else {
         return 2;
      }
   }

   static final void method1834(Widget var0, int var1, int var2, int var3) {
      SpriteMask var4 = var0.getSpriteMask(false);
      if (var4 != null) {
         if (Client.field2319 < 3) {
            class34.field402.method6364(var1, var2, var4.width, var4.height, 25, 25, Client.field2101, 256, var4.xStarts, var4.xWidths);
         } else {
            Rasterizer2D.method6234(var1, var2, 0, var4.xStarts, var4.xWidths);
         }

      }
   }
}
