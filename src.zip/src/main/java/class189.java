import java.util.Calendar;
import java.util.TimeZone;

public class class189 {
   public static Calendar field2392;
   public static final String[][] field2393 = new String[][]{{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}, {"Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"}};
   public static final String[] field2395 = new String[]{"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
   static IndexedSprite[] field2394;

   static {
      Calendar.getInstance(TimeZone.getTimeZone("Europe/London"));
      field2392 = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
   }
}
