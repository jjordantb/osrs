public class Huffman {
   int[] field1750;
   int[] field1752;
   byte[] field1749;

   public Huffman(byte[] var1) {
      int var2 = var1.length;
      this.field1752 = new int[var2];
      this.field1749 = var1;
      int[] var3 = new int[33];
      this.field1750 = new int[8];
      int var4 = 0;

      for(int var5 = 0; var5 < var2; ++var5) {
         byte var6 = var1[var5];
         if (var6 != 0) {
            int var7 = 1 << 32 - var6;
            int var8 = var3[var6];
            this.field1752[var5] = var8;
            int var9;
            int var10;
            int var11;
            int var12;
            if ((var8 & var7) != 0) {
               var9 = var3[var6 - 1];
            } else {
               var9 = var8 | var7;

               for(var10 = var6 - 1; var10 >= 1; --var10) {
                  var11 = var3[var10];
                  if (var8 != var11) {
                     break;
                  }

                  var12 = 1 << 32 - var10;
                  if ((var11 & var12) != 0) {
                     var3[var10] = var3[var10 - 1];
                     break;
                  }

                  var3[var10] = var11 | var12;
               }
            }

            var3[var6] = var9;

            for(var10 = var6 + 1; var10 <= 32; ++var10) {
               if (var8 == var3[var10]) {
                  var3[var10] = var9;
               }
            }

            var10 = 0;

            for(var11 = 0; var11 < var6; ++var11) {
               var12 = Integer.MIN_VALUE >>> var11;
               if ((var8 & var12) != 0) {
                  if (this.field1750[var10] == 0) {
                     this.field1750[var10] = var4;
                  }

                  var10 = this.field1750[var10];
               } else {
                  ++var10;
               }

               if (var10 >= this.field1750.length) {
                  int[] var13 = new int[this.field1750.length * 2];

                  for(int var14 = 0; var14 < this.field1750.length; ++var14) {
                     var13[var14] = this.field1750[var14];
                  }

                  this.field1750 = var13;
               }

               var12 >>>= 1;
            }

            this.field1750[var10] = ~var5;
            if (var10 >= var4) {
               var4 = var10 + 1;
            }
         }
      }

   }

   public int method3038(byte[] var1, int var2, int var3, byte[] var4, int var5) {
      int var6 = 0;
      int var7 = var5 << 3;

      for(var3 += var2; var2 < var3; ++var2) {
         int var8 = var1[var2] & 255;
         int var9 = this.field1752[var8];
         byte var10 = this.field1749[var8];
         if (var10 == 0) {
            throw new RuntimeException("");
         }

         int var11 = var7 >> 3;
         int var12 = var7 & 7;
         var6 &= -var12 >> 31;
         int var13 = (var12 + var10 - 1 >> 3) + var11;
         var12 += 24;
         var4[var11] = (byte)(var6 |= var9 >>> var12);
         if (var11 < var13) {
            ++var11;
            var12 -= 8;
            var4[var11] = (byte)(var6 = var9 >>> var12);
            if (var11 < var13) {
               ++var11;
               var12 -= 8;
               var4[var11] = (byte)(var6 = var9 >>> var12);
               if (var11 < var13) {
                  ++var11;
                  var12 -= 8;
                  var4[var11] = (byte)(var6 = var9 >>> var12);
                  if (var11 < var13) {
                     ++var11;
                     var12 -= 8;
                     var4[var11] = (byte)(var6 = var9 << -var12);
                  }
               }
            }
         }

         var7 += var10;
      }

      return (var7 + 7 >> 3) - var5;
   }

   public int method3036(byte[] var1, int var2, byte[] var3, int var4, int var5) {
      if (var5 == 0) {
         return 0;
      } else {
         int var6 = 0;
         var5 += var4;
         int var7 = var2;

         while(true) {
            byte var8 = var1[var7];
            if (var8 < 0) {
               var6 = this.field1750[var6];
            } else {
               ++var6;
            }

            int var9;
            if ((var9 = this.field1750[var6]) < 0) {
               var3[var4++] = (byte)(~var9);
               if (var4 >= var5) {
                  break;
               }

               var6 = 0;
            }

            if ((var8 & 64) != 0) {
               var6 = this.field1750[var6];
            } else {
               ++var6;
            }

            if ((var9 = this.field1750[var6]) < 0) {
               var3[var4++] = (byte)(~var9);
               if (var4 >= var5) {
                  break;
               }

               var6 = 0;
            }

            if ((var8 & 32) != 0) {
               var6 = this.field1750[var6];
            } else {
               ++var6;
            }

            if ((var9 = this.field1750[var6]) < 0) {
               var3[var4++] = (byte)(~var9);
               if (var4 >= var5) {
                  break;
               }

               var6 = 0;
            }

            if ((var8 & 16) != 0) {
               var6 = this.field1750[var6];
            } else {
               ++var6;
            }

            if ((var9 = this.field1750[var6]) < 0) {
               var3[var4++] = (byte)(~var9);
               if (var4 >= var5) {
                  break;
               }

               var6 = 0;
            }

            if ((var8 & 8) != 0) {
               var6 = this.field1750[var6];
            } else {
               ++var6;
            }

            if ((var9 = this.field1750[var6]) < 0) {
               var3[var4++] = (byte)(~var9);
               if (var4 >= var5) {
                  break;
               }

               var6 = 0;
            }

            if ((var8 & 4) != 0) {
               var6 = this.field1750[var6];
            } else {
               ++var6;
            }

            if ((var9 = this.field1750[var6]) < 0) {
               var3[var4++] = (byte)(~var9);
               if (var4 >= var5) {
                  break;
               }

               var6 = 0;
            }

            if ((var8 & 2) != 0) {
               var6 = this.field1750[var6];
            } else {
               ++var6;
            }

            if ((var9 = this.field1750[var6]) < 0) {
               var3[var4++] = (byte)(~var9);
               if (var4 >= var5) {
                  break;
               }

               var6 = 0;
            }

            if ((var8 & 1) != 0) {
               var6 = this.field1750[var6];
            } else {
               ++var6;
            }

            if ((var9 = this.field1750[var6]) < 0) {
               var3[var4++] = (byte)(~var9);
               if (var4 >= var5) {
                  break;
               }

               var6 = 0;
            }

            ++var7;
         }

         return var7 + 1 - var2;
      }
   }

   static void method3037(SequenceDefinition var0, int var1, int var2, int var3) {
      if (Client.field2348 < 50 && Client.field2324 != 0) {
         if (var0.field3468 != null && var1 < var0.field3468.length) {
            int var4 = var0.field3468[var1];
            if (var4 != 0) {
               int var5 = var4 >> 8;
               int var6 = var4 >> 4 & 7;
               int var7 = var4 & 15;
               Client.field2327[Client.field2348] = var5;
               Client.field2328[Client.field2348] = var6;
               Client.field2236[Client.field2348] = 0;
               Client.field2153[Client.field2348] = null;
               int var8 = (var2 - 64) / 128;
               int var9 = (var3 - 64) / 128;
               Client.field2330[Client.field2348] = var7 + (var9 << 8) + (var8 << 16);
               ++Client.field2348;
            }
         }
      }
   }
}
