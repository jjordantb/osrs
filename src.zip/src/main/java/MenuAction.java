public class MenuAction {
   String action;
   int argument2;
   int argument1;
   int opcode;
   int argument0;
}
