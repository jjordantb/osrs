import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.DataLine.Info;

public class SoundSystem extends AbstractSoundSystem {
   int bufferSize;
   AudioFormat audioFormat;
   byte[] bytes;
   SourceDataLine sourceDataLine;

   protected void close() {
      if (this.sourceDataLine != null) {
         this.sourceDataLine.close();
         this.sourceDataLine = null;
      }

   }

   protected int remaining() {
      return this.bufferSize - (this.sourceDataLine.available() >> (class5.field52 ? 2 : 1));
   }

   protected void init() {
      this.audioFormat = new AudioFormat((float)AbstractSoundSystem.field936, 16, class5.field52 ? 2 : 1, true, false);
      this.bytes = new byte[256 << (class5.field52 ? 2 : 1)];
   }

   protected void flush() {
      this.sourceDataLine.flush();
   }

   protected void write() {
      int var1 = 256;
      if (class5.field52) {
         var1 <<= 1;
      }

      for(int var2 = 0; var2 < var1; ++var2) {
         int var3 = super.ints[var2];
         if ((var3 + 8388608 & -16777216) != 0) {
            var3 = 8388607 ^ var3 >> 31;
         }

         this.bytes[var2 * 2] = (byte)(var3 >> 8);
         this.bytes[var2 * 2 + 1] = (byte)(var3 >> 16);
      }

      this.sourceDataLine.write(this.bytes, 0, var1 << 1);
   }

   protected void open(int var1) throws LineUnavailableException {
      try {
         Info var2 = new Info(SourceDataLine.class, this.audioFormat, var1 << (class5.field52 ? 2 : 1));
         this.sourceDataLine = (SourceDataLine)AudioSystem.getLine(var2);
         this.sourceDataLine.open();
         this.sourceDataLine.start();
         this.bufferSize = var1;
      } catch (LineUnavailableException var3) {
         if (SecureRandomCallable.method1017(var1) != 1) {
            this.open(TotalQuantityComparator.method1760(var1));
         } else {
            this.sourceDataLine = null;
            throw var3;
         }
      }
   }
}
