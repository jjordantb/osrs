public class class185 {
   static final int[] field2380 = new int[2048];
   static final int[] field2381 = new int[2048];
   static int field2382;

   static {
      double var0 = 0.0030679615757712823D;

      for(int var2 = 0; var2 < 2048; ++var2) {
         field2380[var2] = (int)(65536.0D * Math.sin(var0 * (double)var2));
         field2381[var2] = (int)(65536.0D * Math.cos(var0 * (double)var2));
      }

   }

   public static InvDefinition method3793(int var0) {
      InvDefinition var1 = (InvDefinition)InvDefinition.field2824.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = InvDefinition.field2827.takeRecord(5, var0);
         var1 = new InvDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         InvDefinition.field2824.put(var1, (long)var0);
         return var1;
      }
   }
}
