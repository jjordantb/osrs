import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

public class WorldMapRegion {
   static DemotingHashTable field1112 = new DemotingHashTable(37748736, 256);
   static final TileLocation field1117 = new TileLocation();
   static DemotingHashTable field1109 = new DemotingHashTable(256, 256);
   int field1114;
   final HashMap fonts;
   int y;
   int field1115;
   LinkedList field1107;
   int x;
   class85 field1113;
   HashMap iconsMap;
   List iconsList;

   WorldMapRegion(int var1, int var2, int var3, HashMap var4) {
      this.x = var1;
      this.y = var2;
      this.field1107 = new LinkedList();
      this.iconsList = new LinkedList();
      this.iconsMap = new HashMap();
      this.field1114 = var3 | -16777216;
      this.fonts = var4;
   }

   int method1911(Sprite var1, class257 var2) {
      switch(var2.field3317) {
      case 1:
         return -var1.subHeight / 2;
      case 2:
         return 0;
      default:
         return -var1.subHeight;
      }
   }

   void method1907(int var1, int var2, HashSet var3, int var4) {
      float var5 = (float)var4 / 64.0F;
      Iterator var6 = this.iconsList.iterator();

      while(var6.hasNext()) {
         WorldMapIcon var7 = (WorldMapIcon)var6.next();
         int var8 = var7.field244.x % 64;
         int var9 = var7.field244.y % 64;
         var7.field243 = (int)(var5 * (float)var8 + (float)var1);
         var7.field250 = (int)(var5 * (float)(63 - var9) + (float)var2);
         if (!var3.contains(var7.field252)) {
            this.method2015(var7, var7.field243, var7.field250, var5);
         }
      }

   }

   void method1903(AreaDefinition var1, int var2, int var3, int var4, int var5) {
      Sprite var6 = var1.getSprite(false);
      if (var6 != null) {
         var6.method6348(var2 - var6.subWidth / 2, var3 - var6.subHeight / 2);
         if (var4 % var5 < var5 / 2) {
            Rasterizer2D.method6271(var2, var3, 15, 16776960, 128);
            Rasterizer2D.method6271(var2, var3, 7, 16777215, 256);
         }

      }
   }

   WorldMapLabel method1913(int var1) {
      AreaDefinition var2 = Clock.mark(var1);
      return this.method1928(var2);
   }

   void method1902(HashSet var1, int var2, int var3) {
      Iterator var4 = this.iconsList.iterator();

      while(var4.hasNext()) {
         WorldMapIcon var5 = (WorldMapIcon)var4.next();
         AreaDefinition var6 = Clock.mark(var5.field252);
         if (var6 != null && var1.contains(var6.method4872())) {
            this.method1903(var6, var5.field243, var5.field250, var2, var3);
         }
      }

   }

   int method1898(int var1, int var2, class69 var3, class103 var4) {
      return var3.field830[0][var1][var2] == 0 ? this.field1114 : var4.method2018(var1, var2);
   }

   void method1914(WorldMapIcon var1, AreaDefinition var2, int var3, int var4, float var5) {
      if (var1.label != null) {
         if (var1.label.size.method1307(var5)) {
            Font var6 = (Font)this.fonts.get(var1.label.size);
            var6.drawLines(var1.label.text, var3 - var1.label.width / 2, var4, var1.label.width, var1.label.height, -16777216 | var2.field2897, 0, 1, 0, var6.ascent / 2);
         }
      }
   }

   AreaDefinition method1978(int var1) {
      ObjectDefinition var2 = class252.method4958(var1);
      if (var2.transforms != null) {
         var2 = var2.transform();
         if (var2 == null) {
            return null;
         }
      }

      return var2.mapIconId != -1 ? Clock.mark(var2.mapIconId) : null;
   }

   void method1926(AreaDefinition var1, int var2, int var3) {
      Sprite var4 = var1.getSprite(false);
      if (var4 != null) {
         int var5 = this.method1910(var4, var1.field2894);
         int var6 = this.method1911(var4, var1.field2898);
         var4.method6348(var5 + var2, var3 + var6);
      }

   }

   List method1915(int var1, int var2, int var3, int var4, int var5) {
      LinkedList var6 = new LinkedList();
      if (var4 >= var1 && var5 >= var2) {
         if (var4 < var3 + var1 && var5 < var3 + var2) {
            Iterator var7 = this.iconsMap.values().iterator();

            WorldMapIcon var8;
            while(var7.hasNext()) {
               var8 = (WorldMapIcon)var7.next();
               if (var8.method554(var4, var5)) {
                  var6.add(var8);
               }
            }

            var7 = this.iconsList.iterator();

            while(var7.hasNext()) {
               var8 = (WorldMapIcon)var7.next();
               if (var8.method554(var4, var5)) {
                  var6.add(var8);
               }
            }

            return var6;
         } else {
            return var6;
         }
      } else {
         return var6;
      }
   }

   WorldMapLabel method1928(AreaDefinition var1) {
      if (var1.field2886 != null && this.fonts != null && this.fonts.get(WorldMapLabelSize.field717) != null) {
         WorldMapLabelSize var2 = WorldMapLabelSize.method1302(var1.field2888);
         if (var2 == null) {
            return null;
         } else {
            Font var3 = (Font)this.fonts.get(var2);
            if (var3 == null) {
               return null;
            } else {
               int var4 = var3.lineCount(var1.field2886, 1000000);
               String[] var5 = new String[var4];
               var3.breakLines(var1.field2886, (int[])null, var5);
               int var6 = var5.length * var3.ascent / 2;
               int var7 = 0;
               String[] var8 = var5;

               for(int var9 = 0; var9 < var8.length; ++var9) {
                  String var10 = var8[var9];
                  int var11 = var3.stringWidth(var10);
                  if (var11 > var7) {
                     var7 = var11;
                  }
               }

               return new WorldMapLabel(var1.field2886, var7, var6, var2);
            }
         }
      } else {
         return null;
      }
   }

   void method1973(int var1, int var2, int var3, int var4) {
      var3 %= 4;
      if (var3 == 0) {
         Rasterizer2D.method6230(this.field1115 * var1, this.field1115 * (63 - var2), this.field1115, var4);
      }

      if (var3 == 1) {
         Rasterizer2D.method6274(this.field1115 * var1, this.field1115 * (63 - var2), this.field1115, var4);
      }

      if (var3 == 2) {
         Rasterizer2D.method6230(this.field1115 + this.field1115 * var1 - 1, this.field1115 * (63 - var2), this.field1115, var4);
      }

      if (var3 == 3) {
         Rasterizer2D.method6274(this.field1115 * var1, this.field1115 * (63 - var2) + this.field1115 - 1, this.field1115, var4);
      }

   }

   void method1899(int var1, int var2, class69 var3, IndexedSprite[] var4) {
      for(int var5 = 0; var5 < var3.field826; ++var5) {
         class93[] var6 = var3.field834[var5][var1][var2];
         if (var6 != null && var6.length != 0) {
            class93[] var7 = var6;

            for(int var8 = 0; var8 < var7.length; ++var8) {
               class93 var9 = var7[var8];
               if (AbstractByteArrayCopier.get(var9.field1022) || class137.method2880(var9.field1022)) {
                  ObjectDefinition var10 = class252.method4958(var9.field1027);
                  if (var10.mapSceneId != -1) {
                     if (var10.mapSceneId != 46 && var10.mapSceneId != 52) {
                        var4[var10.mapSceneId].method6299(this.field1115 * var1, this.field1115 * (63 - var2), this.field1115 * 2, this.field1115 * 2);
                     } else {
                        var4[var10.mapSceneId].method6299(this.field1115 * var1, this.field1115 * (63 - var2), this.field1115 * 2 + 1, this.field1115 * 2 + 1);
                     }
                  }
               }
            }
         }
      }

   }

   List icons() {
      LinkedList var1 = new LinkedList();
      var1.addAll(this.iconsList);
      var1.addAll(this.iconsMap.values());
      return var1;
   }

   void method1980() {
      if (this.field1113 != null) {
         for(int var1 = 0; var1 < 64; ++var1) {
            for(int var2 = 0; var2 < 64; ++var2) {
               this.method1891(var1, var2, this.field1113);
            }
         }
      } else {
         Iterator var5 = this.field1107.iterator();

         while(var5.hasNext()) {
            class6 var6 = (class6)var5.next();

            for(int var3 = var6.method161() * 8; var3 < var6.method161() * 8 + 8; ++var3) {
               for(int var4 = var6.method162() * 8; var4 < var6.method162() * 8 + 8; ++var4) {
                  this.method1891(var3, var4, var6);
               }
            }
         }
      }

   }

   int method1910(Sprite var1, class276 var2) {
      switch(var2.field3530) {
      case 0:
         return 0;
      case 1:
         return -var1.subWidth / 2;
      default:
         return -var1.subWidth;
      }
   }

   void method1891(int var1, int var2, class69 var3) {
      field1117.set(0, var1, var2);

      for(int var4 = 0; var4 < var3.field826; ++var4) {
         class93[] var5 = var3.field834[var4][var1][var2];
         if (var5 != null && var5.length != 0) {
            class93[] var6 = var5;

            for(int var7 = 0; var7 < var6.length; ++var7) {
               class93 var8 = var6[var7];
               AreaDefinition var9 = this.method1978(var8.field1027);
               if (var9 != null) {
                  WorldMapIcon var10 = (WorldMapIcon)this.iconsMap.get(field1117);
                  if (var10 != null) {
                     if (var10.field252 != var9.field2883) {
                        WorldMapIcon var16 = new WorldMapIcon(var9.field2883, var10.field246, var10.field244, this.method1928(var9));
                        this.iconsMap.put(new TileLocation(field1117), var16);
                        var10 = var16;
                     }

                     int var15 = var10.field246.plane - var10.field244.plane;
                     var10.field244.plane = var4;
                     var10.field246.plane = var15 + var4;
                     return;
                  }

                  TileLocation var11 = new TileLocation(var4, this.x * 64 + var1, this.y * 64 + var2);
                  TileLocation var12 = null;
                  if (this.field1113 != null) {
                     var12 = new TileLocation(this.field1113.field828 + var4, this.field1113.field824 * 64 + var1, var2 + this.field1113.field829 * 64);
                  } else {
                     Iterator var13 = this.field1107.iterator();

                     while(var13.hasNext()) {
                        class6 var14 = (class6)var13.next();
                        if (var14.method158(var1, var2)) {
                           var12 = new TileLocation(var4 + var14.field828, var14.field824 * 64 + var1 + var14.method167() * 8, var14.field829 * 64 + var2 + var14.method160() * 8);
                           break;
                        }
                     }
                  }

                  if (var12 != null) {
                     var10 = new WorldMapIcon(var9.field2883, var12, var11, this.method1928(var9));
                     this.iconsMap.put(new TileLocation(field1117), var10);
                     return;
                  }
               }
            }
         }
      }

      this.iconsMap.remove(field1117);
   }

   void method1901(int var1, int var2, HashSet var3, int var4) {
      float var5 = (float)var4 / 64.0F;
      float var6 = var5 / 2.0F;
      Iterator var7 = this.iconsMap.entrySet().iterator();

      while(var7.hasNext()) {
         Entry var8 = (Entry)var7.next();
         TileLocation var9 = (TileLocation)var8.getKey();
         int var10 = (int)((float)var9.x * var5 + (float)var1 - var6);
         int var11 = (int)((float)(var2 + var4) - var5 * (float)var9.y - var6);
         WorldMapIcon var12 = (WorldMapIcon)var8.getValue();
         if (var12 != null) {
            var12.field243 = var10;
            var12.field250 = var11;
            AreaDefinition var13 = Clock.mark(var12.field252);
            if (!var3.contains(var13.method4872())) {
               this.method2015(var12, var10, var11, var5);
            }
         }
      }

   }

   void method1900(int var1, int var2, class69 var3) {
      for(int var4 = 0; var4 < var3.field826; ++var4) {
         class93[] var5 = var3.field834[var4][var1][var2];
         if (var5 != null && var5.length != 0) {
            class93[] var6 = var5;

            for(int var7 = 0; var7 < var6.length; ++var7) {
               class93 var8 = var6[var7];
               int var10 = var8.field1022;
               boolean var9 = var10 >= class255.field3301.field3307 && var10 <= class255.field3309.field3307 || var10 == class255.field3286.field3307;
               if (var9) {
                  ObjectDefinition var11 = class252.method4958(var8.field1027);
                  int var12 = var11.int1 != 0 ? -3407872 : -3355444;
                  if (var8.field1022 == class255.field3301.field3307) {
                     this.method1973(var1, var2, var8.field1023, var12);
                  }

                  if (var8.field1022 == class255.field3298.field3307) {
                     this.method1973(var1, var2, var8.field1023, -3355444);
                     this.method1973(var1, var2, var8.field1023 + 1, var12);
                  }

                  if (var8.field1022 == class255.field3309.field3307) {
                     if (var8.field1023 == 0) {
                        Rasterizer2D.method6274(this.field1115 * var1, this.field1115 * (63 - var2), 1, var12);
                     }

                     if (var8.field1023 == 1) {
                        Rasterizer2D.method6274(this.field1115 * var1 + this.field1115 - 1, this.field1115 * (63 - var2), 1, var12);
                     }

                     if (var8.field1023 == 2) {
                        Rasterizer2D.method6274(this.field1115 + this.field1115 * var1 - 1, this.field1115 * (63 - var2) + this.field1115 - 1, 1, var12);
                     }

                     if (var8.field1023 == 3) {
                        Rasterizer2D.method6274(this.field1115 * var1, this.field1115 * (63 - var2) + this.field1115 - 1, 1, var12);
                     }
                  }

                  if (var8.field1022 == class255.field3286.field3307) {
                     int var13 = var8.field1023 % 2;
                     int var14;
                     if (var13 == 0) {
                        for(var14 = 0; var14 < this.field1115; ++var14) {
                           Rasterizer2D.method6274(var14 + this.field1115 * var1, (64 - var2) * this.field1115 - 1 - var14, 1, var12);
                        }
                     } else {
                        for(var14 = 0; var14 < this.field1115; ++var14) {
                           Rasterizer2D.method6274(var14 + this.field1115 * var1, var14 + this.field1115 * (63 - var2), 1, var12);
                        }
                     }
                  }
               }
            }
         }
      }

   }

   int method1918(int var1, int var2) {
      if (this.field1113 != null) {
         return this.field1113.method1425(var1, var2);
      } else {
         if (!this.field1107.isEmpty()) {
            Iterator var3 = this.field1107.iterator();

            while(var3.hasNext()) {
               class6 var4 = (class6)var3.next();
               if (var4.method158(var1, var2)) {
                  return var4.method1425(var1, var2);
               }
            }
         }

         return -1;
      }
   }

   void method2015(WorldMapIcon var1, int var2, int var3, float var4) {
      AreaDefinition var5 = Clock.mark(var1.field252);
      this.method1926(var5, var2, var3);
      this.method1914(var1, var5, var2, var3, var4);
   }

   void method2011(int var1, int var2, class69 var3, class1 var4, class103 var5) {
      int var6 = var3.field830[0][var1][var2] - 1;
      int var7 = var3.field831[0][var1][var2] - 1;
      if (var6 == -1 && var7 == -1) {
         Rasterizer2D.method6223(this.field1115 * var1, this.field1115 * (63 - var2), this.field1115, this.field1115, this.field1114);
      }

      int var8 = 16711935;
      int var9;
      if (var7 != -1) {
         int var10 = this.field1114;
         OverlayDefinition var11 = class209.method4321(var7);
         if (var11 == null) {
            var9 = var10;
         } else if (var11.rgb2 >= 0) {
            var9 = var11.rgb2 | -16777216;
         } else if (var11.texture >= 0) {
            int var12 = VertexNormal.method2401(Rasterizer3D.field1451.vmethod2974(var11.texture), 96);
            var9 = Rasterizer3D.field1448[var12] | -16777216;
         } else if (var11.rgb == 16711935) {
            var9 = var10;
         } else {
            int var13 = var11.hue;
            int var14 = var11.saturation;
            int var15 = var11.lightness;
            if (var15 > 179) {
               var14 /= 2;
            }

            if (var15 > 192) {
               var14 /= 2;
            }

            if (var15 > 217) {
               var14 /= 2;
            }

            if (var15 > 243) {
               var14 /= 2;
            }

            int var16 = (var14 / 32 << 7) + var15 / 2 + (var13 / 4 << 10);
            int var17 = VertexNormal.method2401(var16, 96);
            var9 = Rasterizer3D.field1448[var17] | -16777216;
         }

         var8 = var9;
      }

      if (var7 > -1 && var3.field832[0][var1][var2] == 0) {
         Rasterizer2D.method6223(this.field1115 * var1, this.field1115 * (63 - var2), this.field1115, this.field1115, var8);
      } else {
         var9 = this.method1898(var1, var2, var3, var5);
         if (var7 == -1) {
            Rasterizer2D.method6223(this.field1115 * var1, this.field1115 * (63 - var2), this.field1115, this.field1115, var9);
         } else {
            var4.method69(this.field1115 * var1, this.field1115 * (63 - var2), var9, var8, this.field1115, this.field1115, var3.field832[0][var1][var2], var3.field833[0][var1][var2]);
         }
      }
   }

   void method1881(class85 var1, List var2) {
      this.iconsMap.clear();
      this.field1113 = var1;
      this.method1883(0, 0, 64, 64, this.field1113);
      this.method1884(var2);
   }

   void method1885(int var1, class1 var2, WorldMapRegion[] var3, IndexedSprite[] var4) {
      this.field1115 = var1;
      if (this.field1113 != null || !this.field1107.isEmpty()) {
         int var6 = this.x;
         int var7 = this.y;
         DemotingHashTable var8 = field1112;
         long var9 = (long)(var1 << 16 | var6 << 8 | var7);
         Sprite var5 = (Sprite)var8.get(var9);
         if (var5 == null) {
            class103 var12 = this.method1893(this.x, this.y, var3);
            Sprite var11 = new Sprite(this.field1115 * 64, this.field1115 * 64);
            var11.method6339();
            if (this.field1113 != null) {
               this.method1939(var2, var3, var4, var12);
            } else {
               this.method1904(var2, var4, var12);
            }

            class85.method1732(var11, this.x, this.y, this.field1115);
         }
      }
   }

   void method1890(int var1, int var2, class69 var3, class1 var4, IndexedSprite[] var5) {
      this.method1900(var1, var2, var3);
      this.method1899(var1, var2, var3, var5);
   }

   void method1904(class1 var1, IndexedSprite[] var2, class103 var3) {
      Iterator var4 = this.field1107.iterator();

      class6 var5;
      int var6;
      int var7;
      while(var4.hasNext()) {
         var5 = (class6)var4.next();

         for(var6 = var5.method161() * 8; var6 < var5.method161() * 8 + 8; ++var6) {
            for(var7 = var5.method162() * 8; var7 < var5.method162() * 8 + 8; ++var7) {
               this.method2011(var6, var7, var5, var1, var3);
               this.method1888(var6, var7, var5, var1);
            }
         }
      }

      var4 = this.field1107.iterator();

      while(var4.hasNext()) {
         var5 = (class6)var4.next();

         for(var6 = var5.method161() * 8; var6 < var5.method161() * 8 + 8; ++var6) {
            for(var7 = var5.method162() * 8; var7 < var5.method162() * 8 + 8; ++var7) {
               this.method1890(var6, var7, var5, var1, var2);
            }
         }
      }

   }

   void method1990(HashSet var1, List var2) {
      this.iconsMap.clear();
      Iterator var3 = var1.iterator();

      while(var3.hasNext()) {
         class6 var4 = (class6)var3.next();
         if (var4.method1445() == this.x && var4.method1421() == this.y) {
            this.field1107.add(var4);
            this.method1883(var4.method161() * 8, var4.method162() * 8, 8, 8, var4);
         }
      }

      this.method1884(var2);
   }

   void method1960(int var1, int var2, int var3, HashSet var4) {
      if (var4 == null) {
         var4 = new HashSet();
      }

      this.method1901(var1, var2, var4, var3);
      this.method1907(var1, var2, var4, var3);
   }

   class103 method1893(int var1, int var2, WorldMapRegion[] var3) {
      DemotingHashTable var5 = field1109;
      long var6 = (long)(0 | var1 << 8 | var2);
      class103 var4 = (class103)var5.get(var6);
      class103 var11 = var4;
      if (var4 == null) {
         var11 = this.method2013(var3);
         DemotingHashTable var10 = field1109;
         long var8 = (long)(0 | var1 << 8 | var2);
         var10.put1(var11, var8);
      }

      return var11;
   }

   void method1884(List var1) {
      Iterator var2 = var1.iterator();

      while(var2.hasNext()) {
         class73 var3 = (class73)var2.next();
         if (var3.field860.x >> 6 == this.x && var3.field860.y >> 6 == this.y) {
            WorldMapIcon var4 = new WorldMapIcon(var3.field859, var3.field860, var3.field860, this.method1913(var3.field859));
            this.iconsList.add(var4);
         }
      }

   }

   void method1897(int var1, int var2, int var3, int var4, int var5, int var6, WorldMapRegion var7, class25 var8) {
      for(int var9 = 0; var9 < var5; ++var9) {
         for(int var10 = 0; var10 < var6; ++var10) {
            int var11 = var7.method1918(var9 + var1, var10 + var2);
            if (var11 != -1) {
               UnderlayDefinition var12 = class95.method1799(var11);
               var8.method577(var3 + var9, var10 + var4, 5, var12);
            }
         }
      }

   }

   void method1883(int var1, int var2, int var3, int var4, class69 var5) {
      for(int var6 = var1; var6 < var3 + var1; ++var6) {
         label56:
         for(int var7 = var2; var7 < var2 + var4; ++var7) {
            TileLocation var8 = new TileLocation(0, var6, var7);

            for(int var9 = 0; var9 < var5.field826; ++var9) {
               class93[] var10 = var5.field834[var9][var6][var7];
               if (var10 != null && var10.length != 0) {
                  class93[] var11 = var10;

                  for(int var12 = 0; var12 < var11.length; ++var12) {
                     class93 var13 = var11[var12];
                     AreaDefinition var14 = this.method1978(var13.field1027);
                     if (var14 != null) {
                        TileLocation var15 = new TileLocation(var9, this.x * 64 + var6, this.y * 64 + var7);
                        TileLocation var16 = null;
                        if (this.field1113 != null) {
                           var16 = new TileLocation(this.field1113.field828 + var9, var6 + this.field1113.field824 * 64, var7 + this.field1113.field829 * 64);
                        } else {
                           class6 var17 = (class6)var5;
                           var16 = new TileLocation(var9 + var17.field828, var17.field824 * 64 + var6 + var17.method167() * 8, var7 + var17.field829 * 64 + var17.method160() * 8);
                        }

                        WorldMapIcon var18 = new WorldMapIcon(var14.field2883, var16, var15, this.method1928(var14));
                        this.iconsMap.put(var8, var18);
                        continue label56;
                     }
                  }
               }
            }
         }
      }

   }

   void method1880(int var1, int var2, int var3) {
      int var5 = this.x;
      int var6 = this.y;
      int var7 = this.field1115;
      DemotingHashTable var8 = field1112;
      long var9 = (long)(var7 << 16 | var5 << 8 | var6);
      Sprite var4 = (Sprite)var8.get(var9);
      if (var4 != null) {
         if (var3 == this.field1115 * 64) {
            var4.method6368(var1, var2);
         } else {
            var4.method6358(var1, var2, var3, var3);
         }

      }
   }

   class103 method2013(WorldMapRegion[] var1) {
      class25 var2 = new class25(64, 64);
      if (this.field1113 != null) {
         this.method1896(0, 0, 64, 64, this.field1113, var2);
      } else {
         Iterator var3 = this.field1107.iterator();

         while(var3.hasNext()) {
            class6 var4 = (class6)var3.next();
            this.method1896(var4.method161() * 8, var4.method162() * 8, 8, 8, var4, var2);
         }
      }

      this.method1895(var1, var2);
      class103 var5 = new class103();
      var5.method2017(var2);
      return var5;
   }

   void method1888(int var1, int var2, class69 var3, class1 var4) {
      for(int var5 = 1; var5 < var3.field826; ++var5) {
         int var6 = var3.field831[var5][var1][var2] - 1;
         if (var6 > -1) {
            int var7 = HealthBarUpdate.set(var6, this.field1114);
            if (var3.field832[var5][var1][var2] == 0) {
               Rasterizer2D.method6223(this.field1115 * var1, this.field1115 * (63 - var2), this.field1115, this.field1115, var7);
            } else {
               var4.method69(this.field1115 * var1, this.field1115 * (63 - var2), 0, var7, this.field1115, this.field1115, var3.field832[var5][var1][var2], var3.field833[var5][var1][var2]);
            }
         }
      }

   }

   void method1896(int var1, int var2, int var3, int var4, class69 var5, class25 var6) {
      for(int var7 = var1; var7 < var3 + var1; ++var7) {
         for(int var8 = var2; var8 < var2 + var4; ++var8) {
            int var9 = var5.field830[0][var7][var8] - 1;
            if (var9 != -1) {
               UnderlayDefinition var10 = class95.method1799(var9);
               var6.method577(var7, var8, 5, var10);
            }
         }
      }

   }

   void method1939(class1 var1, WorldMapRegion[] var2, IndexedSprite[] var3, class103 var4) {
      int var5;
      int var6;
      for(var5 = 0; var5 < 64; ++var5) {
         for(var6 = 0; var6 < 64; ++var6) {
            this.method2011(var5, var6, this.field1113, var1, var4);
            this.method1888(var5, var6, this.field1113, var1);
         }
      }

      for(var5 = 0; var5 < 64; ++var5) {
         for(var6 = 0; var6 < 64; ++var6) {
            this.method1890(var5, var6, this.field1113, var1, var3);
         }
      }

   }

   void method1887(HashSet var1, int var2, int var3) {
      Iterator var4 = this.iconsMap.values().iterator();

      while(var4.hasNext()) {
         WorldMapIcon var5 = (WorldMapIcon)var4.next();
         if (var1.contains(var5.field252)) {
            AreaDefinition var6 = Clock.mark(var5.field252);
            this.method1903(var6, var5.field243, var5.field250, var2, var3);
         }
      }

      this.method1902(var1, var2, var3);
   }

   void method1895(WorldMapRegion[] var1, class25 var2) {
      OctantDirection[] var3 = new OctantDirection[]{OctantDirection.field3326, OctantDirection.field3332, OctantDirection.field3322, OctantDirection.field3328, OctantDirection.field3329, OctantDirection.field3324, OctantDirection.field3323, OctantDirection.field3327};
      OctantDirection[] var5 = var3;

      for(int var6 = 0; var6 < var5.length; ++var6) {
         OctantDirection var7 = var5[var6];
         if (var1[var7.ordinal()] != null) {
            byte var8 = 0;
            byte var9 = 0;
            byte var10 = 64;
            byte var11 = 64;
            byte var12 = 0;
            byte var13 = 0;
            switch(var7.field3330) {
            case 0:
               var13 = 59;
               var11 = 5;
               var8 = 59;
               var10 = 5;
               break;
            case 1:
               var8 = 59;
               var10 = 5;
               break;
            case 2:
               var12 = 59;
               var10 = 5;
               break;
            case 3:
               var12 = 59;
               var13 = 59;
               var10 = 5;
               var11 = 5;
               break;
            case 4:
               var13 = 59;
               var11 = 5;
               break;
            case 5:
               var9 = 59;
               var11 = 5;
               break;
            case 6:
               var9 = 59;
               var11 = 5;
               var8 = 59;
               var10 = 5;
               break;
            case 7:
               var9 = 59;
               var11 = 5;
               var12 = 59;
               var10 = 5;
            }

            this.method1897(var12, var13, var8, var9, var10, var11, var1[var7.ordinal()], var2);
         }
      }

   }

   public static void method1886() {
      class205.field2492.method4488();
      class219.field2568 = 1;
      UrlRequester.field1584 = null;
   }

   static final void method1925(int var0, int var1, int var2, int var3, int var4, int var5, Scene var6, CollisionMap var7) {
      if (!Client.field2091 || (Tiles.field203[0][var1][var2] & 2) != 0 || (Tiles.field203[var0][var1][var2] & 16) == 0) {
         if (var0 < Tiles.field204) {
            Tiles.field204 = var0;
         }

         ObjectDefinition var8 = class252.method4958(var3);
         int var9;
         int var10;
         if (var4 != 1 && var4 != 3) {
            var9 = var8.sizeX;
            var10 = var8.sizeY;
         } else {
            var9 = var8.sizeY;
            var10 = var8.sizeX;
         }

         int var11;
         int var12;
         if (var9 + var1 <= 104) {
            var11 = (var9 >> 1) + var1;
            var12 = (var9 + 1 >> 1) + var1;
         } else {
            var11 = var1;
            var12 = var1 + 1;
         }

         int var13;
         int var14;
         if (var10 + var2 <= 104) {
            var13 = (var10 >> 1) + var2;
            var14 = var2 + (var10 + 1 >> 1);
         } else {
            var13 = var2;
            var14 = var2 + 1;
         }

         int[][] var15 = Tiles.field217[var0];
         int var16 = var15[var11][var13] + var15[var12][var13] + var15[var11][var14] + var15[var12][var14] >> 2;
         int var17 = (var1 << 7) + (var9 << 6);
         int var18 = (var2 << 7) + (var10 << 6);
         long var19 = WorldComparator.method1404(var1, var2, 2, var8.int1 == 0, var3);
         int var21 = var5 + (var4 << 6);
         if (var8.int3 == 1) {
            var21 += 256;
         }

         int var23;
         int var24;
         if (var8.method5156()) {
            ObjectSound var22 = new ObjectSound();
            var22.field574 = var0;
            var22.field575 = var1 * 128;
            var22.field585 = var2 * 128;
            var23 = var8.sizeX;
            var24 = var8.sizeY;
            if (var4 == 1 || var4 == 3) {
               var23 = var8.sizeY;
               var24 = var8.sizeX;
            }

            var22.field588 = (var23 + var1) * 128;
            var22.field578 = (var24 + var2) * 128;
            var22.field580 = var8.ambientSoundId;
            var22.field579 = var8.int4 * 128;
            var22.field582 = var8.int5;
            var22.field583 = var8.int6;
            var22.field584 = var8.field3436;
            if (var8.transforms != null) {
               var22.obj = var8;
               var22.method1084();
            }

            ObjectSound.field577.addFirst(var22);
            if (var22.field584 != null) {
               var22.field581 = var22.field582 + (int)(Math.random() * (double)(var22.field583 - var22.field582));
            }
         }

         Object var34;
         if (var5 == 22) {
            if (!Client.field2091 || var8.int1 != 0 || var8.interactType == 1 || var8.boolean2) {
               if (var8.animationId == -1 && var8.transforms == null) {
                  var34 = var8.method5162(22, var4, var15, var17, var16, var18);
               } else {
                  var34 = new DynamicObject(var3, 22, var4, var0, var1, var2, var8.animationId, true, (Entity)null);
               }

               var6.newFloorDecoration(var0, var1, var2, var16, (Entity)var34, var19, var21);
               if (var8.interactType == 1 && var7 != null) {
                  var7.method3184(var1, var2);
               }

            }
         } else if (var5 != 10 && var5 != 11) {
            if (var5 >= 12) {
               if (var8.animationId == -1 && var8.transforms == null) {
                  var34 = var8.method5162(var5, var4, var15, var17, var16, var18);
               } else {
                  var34 = new DynamicObject(var3, var5, var4, var0, var1, var2, var8.animationId, true, (Entity)null);
               }

               var6.method2235(var0, var1, var2, var16, 1, 1, (Entity)var34, 0, var19, var21);
               if (var5 >= 12 && var5 <= 17 && var5 != 13 && var0 > 0) {
                  class34.field404[var0][var1][var2] |= 2340;
               }

               if (var8.interactType != 0 && var7 != null) {
                  var7.method3209(var1, var2, var9, var10, var8.boolean1);
               }

            } else if (var5 == 0) {
               if (var8.animationId == -1 && var8.transforms == null) {
                  var34 = var8.method5162(0, var4, var15, var17, var16, var18);
               } else {
                  var34 = new DynamicObject(var3, 0, var4, var0, var1, var2, var8.animationId, true, (Entity)null);
               }

               var6.newBoundaryObject(var0, var1, var2, var16, (Entity)var34, (Entity)null, Tiles.field202[var4], 0, var19, var21);
               if (var4 == 0) {
                  if (var8.clipped) {
                     Tiles.field214[var0][var1][var2] = 50;
                     Tiles.field214[var0][var1][var2 + 1] = 50;
                  }

                  if (var8.modelClipped) {
                     class34.field404[var0][var1][var2] |= 585;
                  }
               } else if (var4 == 1) {
                  if (var8.clipped) {
                     Tiles.field214[var0][var1][var2 + 1] = 50;
                     Tiles.field214[var0][var1 + 1][var2 + 1] = 50;
                  }

                  if (var8.modelClipped) {
                     class34.field404[var0][var1][var2 + 1] |= 1170;
                  }
               } else if (var4 == 2) {
                  if (var8.clipped) {
                     Tiles.field214[var0][var1 + 1][var2] = 50;
                     Tiles.field214[var0][var1 + 1][var2 + 1] = 50;
                  }

                  if (var8.modelClipped) {
                     class34.field404[var0][var1 + 1][var2] |= 585;
                  }
               } else if (var4 == 3) {
                  if (var8.clipped) {
                     Tiles.field214[var0][var1][var2] = 50;
                     Tiles.field214[var0][var1 + 1][var2] = 50;
                  }

                  if (var8.modelClipped) {
                     class34.field404[var0][var1][var2] |= 1170;
                  }
               }

               if (var8.interactType != 0 && var7 != null) {
                  var7.method3183(var1, var2, var5, var4, var8.boolean1);
               }

               if (var8.int2 != 16) {
                  var6.method2241(var0, var1, var2, var8.int2);
               }

            } else if (var5 == 1) {
               if (var8.animationId == -1 && var8.transforms == null) {
                  var34 = var8.method5162(1, var4, var15, var17, var16, var18);
               } else {
                  var34 = new DynamicObject(var3, 1, var4, var0, var1, var2, var8.animationId, true, (Entity)null);
               }

               var6.newBoundaryObject(var0, var1, var2, var16, (Entity)var34, (Entity)null, Tiles.field210[var4], 0, var19, var21);
               if (var8.clipped) {
                  if (var4 == 0) {
                     Tiles.field214[var0][var1][var2 + 1] = 50;
                  } else if (var4 == 1) {
                     Tiles.field214[var0][var1 + 1][var2 + 1] = 50;
                  } else if (var4 == 2) {
                     Tiles.field214[var0][var1 + 1][var2] = 50;
                  } else if (var4 == 3) {
                     Tiles.field214[var0][var1][var2] = 50;
                  }
               }

               if (var8.interactType != 0 && var7 != null) {
                  var7.method3183(var1, var2, var5, var4, var8.boolean1);
               }

            } else {
               int var28;
               if (var5 == 2) {
                  var28 = var4 + 1 & 3;
                  Object var29;
                  Object var30;
                  if (var8.animationId == -1 && var8.transforms == null) {
                     var29 = var8.method5162(2, var4 + 4, var15, var17, var16, var18);
                     var30 = var8.method5162(2, var28, var15, var17, var16, var18);
                  } else {
                     var29 = new DynamicObject(var3, 2, var4 + 4, var0, var1, var2, var8.animationId, true, (Entity)null);
                     var30 = new DynamicObject(var3, 2, var28, var0, var1, var2, var8.animationId, true, (Entity)null);
                  }

                  var6.newBoundaryObject(var0, var1, var2, var16, (Entity)var29, (Entity)var30, Tiles.field202[var4], Tiles.field202[var28], var19, var21);
                  if (var8.modelClipped) {
                     if (var4 == 0) {
                        class34.field404[var0][var1][var2] |= 585;
                        class34.field404[var0][var1][1 + var2] |= 1170;
                     } else if (var4 == 1) {
                        class34.field404[var0][var1][var2 + 1] |= 1170;
                        class34.field404[var0][var1 + 1][var2] |= 585;
                     } else if (var4 == 2) {
                        class34.field404[var0][var1 + 1][var2] |= 585;
                        class34.field404[var0][var1][var2] |= 1170;
                     } else if (var4 == 3) {
                        class34.field404[var0][var1][var2] |= 1170;
                        class34.field404[var0][var1][var2] |= 585;
                     }
                  }

                  if (var8.interactType != 0 && var7 != null) {
                     var7.method3183(var1, var2, var5, var4, var8.boolean1);
                  }

                  if (var8.int2 != 16) {
                     var6.method2241(var0, var1, var2, var8.int2);
                  }

               } else if (var5 == 3) {
                  if (var8.animationId == -1 && var8.transforms == null) {
                     var34 = var8.method5162(3, var4, var15, var17, var16, var18);
                  } else {
                     var34 = new DynamicObject(var3, 3, var4, var0, var1, var2, var8.animationId, true, (Entity)null);
                  }

                  var6.newBoundaryObject(var0, var1, var2, var16, (Entity)var34, (Entity)null, Tiles.field210[var4], 0, var19, var21);
                  if (var8.clipped) {
                     if (var4 == 0) {
                        Tiles.field214[var0][var1][var2 + 1] = 50;
                     } else if (var4 == 1) {
                        Tiles.field214[var0][var1 + 1][var2 + 1] = 50;
                     } else if (var4 == 2) {
                        Tiles.field214[var0][var1 + 1][var2] = 50;
                     } else if (var4 == 3) {
                        Tiles.field214[var0][var1][var2] = 50;
                     }
                  }

                  if (var8.interactType != 0 && var7 != null) {
                     var7.method3183(var1, var2, var5, var4, var8.boolean1);
                  }

               } else if (var5 == 9) {
                  if (var8.animationId == -1 && var8.transforms == null) {
                     var34 = var8.method5162(var5, var4, var15, var17, var16, var18);
                  } else {
                     var34 = new DynamicObject(var3, var5, var4, var0, var1, var2, var8.animationId, true, (Entity)null);
                  }

                  var6.method2235(var0, var1, var2, var16, 1, 1, (Entity)var34, 0, var19, var21);
                  if (var8.interactType != 0 && var7 != null) {
                     var7.method3209(var1, var2, var9, var10, var8.boolean1);
                  }

                  if (var8.int2 != 16) {
                     var6.method2241(var0, var1, var2, var8.int2);
                  }

               } else if (var5 == 4) {
                  if (var8.animationId == -1 && var8.transforms == null) {
                     var34 = var8.method5162(4, var4, var15, var17, var16, var18);
                  } else {
                     var34 = new DynamicObject(var3, 4, var4, var0, var1, var2, var8.animationId, true, (Entity)null);
                  }

                  var6.newWallDecoration(var0, var1, var2, var16, (Entity)var34, (Entity)null, Tiles.field202[var4], 0, 0, 0, var19, var21);
               } else {
                  long var31;
                  Object var33;
                  if (var5 == 5) {
                     var28 = 16;
                     var31 = var6.method2251(var0, var1, var2);
                     if (var31 != 0L) {
                        var28 = class252.method4958(WidgetGroupParent.method1000(var31)).int2;
                     }

                     if (var8.animationId == -1 && var8.transforms == null) {
                        var33 = var8.method5162(4, var4, var15, var17, var16, var18);
                     } else {
                        var33 = new DynamicObject(var3, 4, var4, var0, var1, var2, var8.animationId, true, (Entity)null);
                     }

                     var6.newWallDecoration(var0, var1, var2, var16, (Entity)var33, (Entity)null, Tiles.field202[var4], 0, var28 * Tiles.field208[var4], var28 * Tiles.field212[var4], var19, var21);
                  } else if (var5 == 6) {
                     var28 = 8;
                     var31 = var6.method2251(var0, var1, var2);
                     if (var31 != 0L) {
                        var28 = class252.method4958(WidgetGroupParent.method1000(var31)).int2 / 2;
                     }

                     if (var8.animationId == -1 && var8.transforms == null) {
                        var33 = var8.method5162(4, var4 + 4, var15, var17, var16, var18);
                     } else {
                        var33 = new DynamicObject(var3, 4, var4 + 4, var0, var1, var2, var8.animationId, true, (Entity)null);
                     }

                     var6.newWallDecoration(var0, var1, var2, var16, (Entity)var33, (Entity)null, 256, var4, var28 * Tiles.field213[var4], var28 * Tiles.field218[var4], var19, var21);
                  } else if (var5 == 7) {
                     var23 = var4 + 2 & 3;
                     if (var8.animationId == -1 && var8.transforms == null) {
                        var34 = var8.method5162(4, var23 + 4, var15, var17, var16, var18);
                     } else {
                        var34 = new DynamicObject(var3, 4, var23 + 4, var0, var1, var2, var8.animationId, true, (Entity)null);
                     }

                     var6.newWallDecoration(var0, var1, var2, var16, (Entity)var34, (Entity)null, 256, var23, 0, 0, var19, var21);
                  } else if (var5 == 8) {
                     var28 = 8;
                     var31 = var6.method2251(var0, var1, var2);
                     if (0L != var31) {
                        var28 = class252.method4958(WidgetGroupParent.method1000(var31)).int2 / 2;
                     }

                     int var27 = var4 + 2 & 3;
                     Object var26;
                     if (var8.animationId == -1 && var8.transforms == null) {
                        var33 = var8.method5162(4, var4 + 4, var15, var17, var16, var18);
                        var26 = var8.method5162(4, var27 + 4, var15, var17, var16, var18);
                     } else {
                        var33 = new DynamicObject(var3, 4, var4 + 4, var0, var1, var2, var8.animationId, true, (Entity)null);
                        var26 = new DynamicObject(var3, 4, var27 + 4, var0, var1, var2, var8.animationId, true, (Entity)null);
                     }

                     var6.newWallDecoration(var0, var1, var2, var16, (Entity)var33, (Entity)var26, 256, var4, var28 * Tiles.field213[var4], var28 * Tiles.field218[var4], var19, var21);
                  }
               }
            }
         } else {
            if (var8.animationId == -1 && var8.transforms == null) {
               var34 = var8.method5162(10, var4, var15, var17, var16, var18);
            } else {
               var34 = new DynamicObject(var3, 10, var4, var0, var1, var2, var8.animationId, true, (Entity)null);
            }

            if (var34 != null && var6.method2235(var0, var1, var2, var16, var9, var10, (Entity)var34, var5 == 11 ? 256 : 0, var19, var21) && var8.clipped) {
               var23 = 15;
               if (var34 instanceof Model) {
                  var23 = ((Model)var34).method2446() / 4;
                  if (var23 > 30) {
                     var23 = 30;
                  }
               }

               for(var24 = 0; var24 <= var9; ++var24) {
                  for(int var25 = 0; var25 <= var10; ++var25) {
                     if (var23 > Tiles.field214[var0][var24 + var1][var25 + var2]) {
                        Tiles.field214[var0][var24 + var1][var25 + var2] = (byte)var23;
                     }
                  }
               }
            }

            if (var8.interactType != 0 && var7 != null) {
               var7.method3209(var1, var2, var9, var10, var8.boolean1);
            }

         }
      }
   }

   static final void method1879(Widget[] var0, int var1) {
      for(int var2 = 0; var2 < var0.length; ++var2) {
         Widget var3 = var0[var2];
         if (var3 != null) {
            if (var3.type == 0) {
               if (var3.children != null) {
                  method1879(var3.children, var1);
               }

               WidgetGroupParent var4 = (WidgetGroupParent) Client.field2247.get((long)var3.id);
               if (var4 != null) {
                  WorldMapData2.method338(var4.group, var1);
               }
            }

            ScriptEvent var5;
            if (var1 == 0 && var3.field2710 != null) {
               var5 = new ScriptEvent();
               var5.widget = var3;
               var5.args = var3.field2710;
               IndexCacheLoader.method1096(var5);
            }

            if (var1 == 1 && var3.field2702 != null) {
               if (var3.childIndex >= 0) {
                  Widget var6 = WorldMapSection3.method1148(var3.id);
                  if (var6 == null || var6.children == null || var3.childIndex >= var6.children.length || var3 != var6.children[var3.childIndex]) {
                     continue;
                  }
               }

               var5 = new ScriptEvent();
               var5.widget = var3;
               var5.args = var3.field2702;
               IndexCacheLoader.method1096(var5);
            }
         }
      }

   }
}
