public class LoginType {
   static final LoginType field3933 = new LoginType(4, 6, "", "");
   static final LoginType field3931 = new LoginType(6, 4, "", "");
   static final LoginType field3930 = new LoginType(5, 2, "", "");
   public static final LoginType field3929 = new LoginType(0, 0, "", "");
   static final LoginType field3932 = new LoginType(3, 5, "", "");
   public static final LoginType field3936;
   static final LoginType field3927 = new LoginType(2, 3, "", "");
   static final LoginType field3935 = new LoginType(8, 1, "", "");
   static final LoginType field3934 = new LoginType(7, 7, "", "");
   public final int field3928;
   final String field3937;

   static {
      field3936 = new LoginType(1, -1, "", "", true, new LoginType[]{field3929, field3935, field3930, field3931, field3927});
   }

   LoginType(int var1, int var2, String var3, String var4) {
      this.field3928 = var1;
      this.field3937 = var4;
   }

   LoginType(int var1, int var2, String var3, String var4, boolean var5, LoginType[] var6) {
      this.field3928 = var1;
      this.field3937 = var4;
   }

   public String toString() {
      return this.field3937;
   }
}
