public class class196 {
   static ServerBuild field2450;

   static final int method4198(int var0, int var1, int var2) {
      int var3 = var0 / var2;
      int var4 = var0 & var2 - 1;
      int var5 = var1 / var2;
      int var6 = var1 & var2 - 1;
      int var7 = GzipDecompressor.method3219(var3, var5);
      int var8 = GzipDecompressor.method3219(var3 + 1, var5);
      int var9 = GzipDecompressor.method3219(var3, var5 + 1);
      int var10 = GzipDecompressor.method3219(var3 + 1, var5 + 1);
      int var12 = 65536 - Rasterizer3D.field1453[var4 * 1024 / var2] >> 1;
      int var11 = ((65536 - var12) * var7 >> 16) + (var8 * var12 >> 16);
      int var14 = 65536 - Rasterizer3D.field1453[var4 * 1024 / var2] >> 1;
      int var13 = ((65536 - var14) * var9 >> 16) + (var14 * var10 >> 16);
      int var16 = 65536 - Rasterizer3D.field1453[var6 * 1024 / var2] >> 1;
      int var15 = ((65536 - var16) * var11 >> 16) + (var13 * var16 >> 16);
      return var15;
   }

   public static boolean method4189(int var0) {
      if (class130.field1567[var0]) {
         return true;
      } else if (!Widget.field2678.tryLoadArchive(var0)) {
         return false;
      } else {
         int var1 = Widget.field2678.method5025(var0);
         if (var1 == 0) {
            class130.field1567[var0] = true;
            return true;
         } else {
            if (UserComparator3.field1708[var0] == null) {
               UserComparator3.field1708[var0] = new Widget[var1];
            }

            for(int var2 = 0; var2 < var1; ++var2) {
               if (UserComparator3.field1708[var0][var2] == null) {
                  byte[] var3 = Widget.field2678.takeRecord(var0, var2);
                  if (var3 != null) {
                     UserComparator3.field1708[var0][var2] = new Widget();
                     UserComparator3.field1708[var0][var2].id = var2 + (var0 << 16);
                     if (var3[0] == -1) {
                        UserComparator3.field1708[var0][var2].decode(new Buffer(var3));
                     } else {
                        UserComparator3.field1708[var0][var2].decodeLegacy(new Buffer(var3));
                     }
                  }
               }
            }

            class130.field1567[var0] = true;
            return true;
         }
      }
   }
}
