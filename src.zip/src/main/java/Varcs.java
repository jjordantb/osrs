import java.io.EOFException;

public class Varcs {
   static int field635;
   boolean unwrittenChanges = false;
   int[] ints;
   boolean[] intsPersistence;
   String[] strings;
   boolean[] stringsPersistence;
   long lastWriteTimeMs;

   Varcs() {
      this.ints = new int[Tiles.field216.method5025(19)];
      this.strings = new String[Tiles.field216.method5025(15)];
      this.intsPersistence = new boolean[this.ints.length];

      int var1;
      for(var1 = 0; var1 < this.ints.length; ++var1) {
         VarcInt var2 = IndexCache.method4865(var1);
         this.intsPersistence[var1] = var2.persist;
      }

      this.stringsPersistence = new boolean[this.strings.length];

      for(var1 = 0; var1 < this.strings.length; ++var1) {
         VarcString var3 = WorldComparator.method1392(var1);
         this.stringsPersistence[var1] = var3.persist;
      }

      for(var1 = 0; var1 < this.ints.length; ++var1) {
         this.ints[var1] = -1;
      }

      this.read();
   }

   void clearTransient() {
      int var1;
      for(var1 = 0; var1 < this.ints.length; ++var1) {
         if (!this.intsPersistence[var1]) {
            this.ints[var1] = -1;
         }
      }

      for(var1 = 0; var1 < this.strings.length; ++var1) {
         if (!this.stringsPersistence[var1]) {
            this.strings[var1] = null;
         }
      }

   }

   void tryWrite() {
      if (this.unwrittenChanges && this.lastWriteTimeMs < Tile.method2779() - 60000L) {
         this.write();
      }

   }

   void setString(int var1, String var2) {
      this.strings[var1] = var2;
      if (this.stringsPersistence[var1]) {
         this.unwrittenChanges = true;
      }

   }

   void setInt(int var1, int var2) {
      this.ints[var1] = var2;
      if (this.intsPersistence[var1]) {
         this.unwrittenChanges = true;
      }

   }

   AccessFile getPreferencesFile(boolean var1) {
      return class99.method1837("2", Client.field2089.name, var1);
   }

   boolean hasUnwrittenChanges() {
      return this.unwrittenChanges;
   }

   void read() {
      AccessFile var1 = this.getPreferencesFile(false);

      label191: {
         try {
            byte[] var2 = new byte[(int)var1.length()];

            int var4;
            for(int var3 = 0; var3 < var2.length; var3 += var4) {
               var4 = var1.read(var2, var3, var2.length - var3);
               if (var4 == -1) {
                  throw new EOFException();
               }
            }

            Buffer var13 = new Buffer(var2);
            if (var13.array.length - var13.index < 1) {
               return;
            }

            int var14 = var13.readUnsignedByte();
            if (var14 >= 0 && var14 <= 1) {
               int var15 = var13.method3913();

               int var7;
               int var8;
               int var9;
               for(var7 = 0; var7 < var15; ++var7) {
                  var8 = var13.method3913();
                  var9 = var13.readInt();
                  if (this.intsPersistence[var8]) {
                     this.ints[var8] = var9;
                  }
               }

               var7 = var13.method3913();
               var8 = 0;

               while(true) {
                  if (var8 >= var7) {
                     break label191;
                  }

                  var9 = var13.method3913();
                  String var10 = var13.readStringCp1252NullTerminated();
                  if (this.stringsPersistence[var9]) {
                     this.strings[var9] = var10;
                  }

                  ++var8;
               }
            }
         } catch (Exception var24) {
            break label191;
         } finally {
            try {
               var1.close();
            } catch (Exception var23) {
               ;
            }

         }

         return;
      }

      this.unwrittenChanges = false;
   }

   void write() {
      AccessFile var1 = this.getPreferencesFile(true);

      try {
         int var2 = 3;
         int var3 = 0;

         int var4;
         for(var4 = 0; var4 < this.ints.length; ++var4) {
            if (this.intsPersistence[var4] && this.ints[var4] != -1) {
               var2 += 6;
               ++var3;
            }
         }

         var2 += 2;
         var4 = 0;

         for(int var5 = 0; var5 < this.strings.length; ++var5) {
            if (this.stringsPersistence[var5] && this.strings[var5] != null) {
               var2 += 2 + AbstractSoundSystem.method1696(this.strings[var5]);
               ++var4;
            }
         }

         Buffer var9 = new Buffer(var2);
         var9.writeByte(1);
         var9.writeShort(var3);

         int var6;
         for(var6 = 0; var6 < this.ints.length; ++var6) {
            if (this.intsPersistence[var6] && this.ints[var6] != -1) {
               var9.writeShort(var6);
               var9.writeInt(this.ints[var6]);
            }
         }

         var9.writeShort(var4);

         for(var6 = 0; var6 < this.strings.length; ++var6) {
            if (this.stringsPersistence[var6] && this.strings[var6] != null) {
               var9.writeShort(var6);
               var9.writeStringCp1252NullTerminated(this.strings[var6]);
            }
         }

         var1.write(var9.array, 0, var9.index);
      } catch (Exception var17) {
         ;
      } finally {
         try {
            var1.close();
         } catch (Exception var16) {
            ;
         }

      }

      this.unwrittenChanges = false;
      this.lastWriteTimeMs = Tile.method2779();
   }

   String getString(int var1) {
      return this.strings[var1];
   }

   int getInt(int var1) {
      return this.ints[var1];
   }

   public static void setInt(AbstractIndexCache var0) {
      EnumDefinition.field3492 = var0;
   }

   static int getString(char var0, int var1) {
      int var2 = var0 << 4;
      if (Character.isUpperCase(var0) || Character.isTitleCase(var0)) {
         var0 = Character.toLowerCase(var0);
         var2 = (var0 << 4) + 1;
      }

      return var2;
   }

   public static ItemDefinition getItemDefinition(int var0) {
      ItemDefinition var1 = (ItemDefinition)ItemDefinition.field3610.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = ItemDefinition.field3609.takeRecord(10, var0);
         var1 = new ItemDefinition();
         var1.id = var0;
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         var1.method5466();
         if (var1.noteTemplate != -1) {
            var1.method5469(getItemDefinition(var1.noteTemplate), getItemDefinition(var1.note));
         }

         if (var1.notedId != -1) {
            var1.method5482(getItemDefinition(var1.notedId), getItemDefinition(var1.unnotedId));
         }

         if (var1.placeholderTemplate != -1) {
            var1.method5471(getItemDefinition(var1.placeholderTemplate), getItemDefinition(var1.placeholder));
         }

         if (!PlayerAppearance.field2560 && var1.isMembersOnly) {
            var1.name = "Members object";
            var1.isTradable = false;
            var1.groundActions = null;
            var1.inventoryActions = null;
            var1.shiftClickIndex0 = -1;
            var1.int1 = 0;
            if (var1.params != null) {
               boolean var3 = false;

               for(Node var4 = var1.params.first(); var4 != null; var4 = var1.params.next()) {
                  ParamKeyDefinition var5 = class83.method1701((int)var4.key);
                  if (var5.isMembersOnly) {
                     var4.remove();
                  } else {
                     var3 = true;
                  }
               }

               if (!var3) {
                  var1.params = null;
               }
            }
         }

         ItemDefinition.field3610.put(var1, (long)var0);
         return var1;
      }
   }
}
