public class MusicPatch extends Node {
   byte[] field2786 = new byte[128];
   byte[] field2791 = new byte[128];
   short[] field2780 = new short[128];
   int field2782;
   class209[] field2785 = new class209[128];
   byte[] field2783 = new byte[128];
   class88[] field2781 = new class88[128];
   int[] field2787 = new int[128];

   MusicPatch(byte[] var1) {
      Buffer var2 = new Buffer(var1);

      int var3;
      for(var3 = 0; var2.array[var3 + var2.index] != 0; ++var3) {
         ;
      }

      byte[] var4 = new byte[var3];

      int var5;
      for(var5 = 0; var5 < var3; ++var5) {
         var4[var5] = var2.readByte();
      }

      ++var2.index;
      ++var3;
      var5 = var2.index;
      var2.index += var3;

      int var6;
      for(var6 = 0; var2.array[var6 + var2.index] != 0; ++var6) {
         ;
      }

      byte[] var7 = new byte[var6];

      int var8;
      for(var8 = 0; var8 < var6; ++var8) {
         var7[var8] = var2.readByte();
      }

      ++var2.index;
      ++var6;
      var8 = var2.index;
      var2.index += var6;

      int var9;
      for(var9 = 0; var2.array[var9 + var2.index] != 0; ++var9) {
         ;
      }

      byte[] var10 = new byte[var9];

      for(int var11 = 0; var11 < var9; ++var11) {
         var10[var11] = var2.readByte();
      }

      ++var2.index;
      ++var9;
      byte[] var38 = new byte[var9];
      int var12;
      int var14;
      if (var9 > 1) {
         var38[1] = 1;
         int var13 = 1;
         var12 = 2;

         for(var14 = 2; var14 < var9; ++var14) {
            int var15 = var2.readUnsignedByte();
            if (var15 == 0) {
               var13 = var12++;
            } else {
               if (var15 <= var13) {
                  --var15;
               }

               var13 = var15;
            }

            var38[var14] = (byte)var13;
         }
      } else {
         var12 = var9;
      }

      class209[] var39 = new class209[var12];

      class209 var40;
      for(var14 = 0; var14 < var39.length; ++var14) {
         var40 = var39[var14] = new class209();
         int var16 = var2.readUnsignedByte();
         if (var16 > 0) {
            var40.field2505 = new byte[var16 * 2];
         }

         var16 = var2.readUnsignedByte();
         if (var16 > 0) {
            var40.field2508 = new byte[var16 * 2 + 2];
            var40.field2508[1] = 64;
         }
      }

      var14 = var2.readUnsignedByte();
      byte[] var47 = var14 > 0 ? new byte[var14 * 2] : null;
      var14 = var2.readUnsignedByte();
      byte[] var41 = var14 > 0 ? new byte[var14 * 2] : null;

      int var17;
      for(var17 = 0; var2.array[var17 + var2.index] != 0; ++var17) {
         ;
      }

      byte[] var18 = new byte[var17];

      int var19;
      for(var19 = 0; var19 < var17; ++var19) {
         var18[var19] = var2.readByte();
      }

      ++var2.index;
      ++var17;
      var19 = 0;

      int var20;
      for(var20 = 0; var20 < 128; ++var20) {
         var19 += var2.readUnsignedByte();
         this.field2780[var20] = (short)var19;
      }

      var19 = 0;

      for(var20 = 0; var20 < 128; ++var20) {
         var19 += var2.readUnsignedByte();
         this.field2780[var20] = (short)(this.field2780[var20] + (var19 << 8));
      }

      var20 = 0;
      int var21 = 0;
      int var22 = 0;

      int var23;
      for(var23 = 0; var23 < 128; ++var23) {
         if (var20 == 0) {
            if (var21 < var18.length) {
               var20 = var18[var21++];
            } else {
               var20 = -1;
            }

            var22 = var2.method3929();
         }

         this.field2780[var23] = (short)(this.field2780[var23] + ((var22 - 1 & 2) << 14));
         this.field2787[var23] = var22;
         --var20;
      }

      var20 = 0;
      var21 = 0;
      var23 = 0;

      int var24;
      for(var24 = 0; var24 < 128; ++var24) {
         if (this.field2787[var24] != 0) {
            if (var20 == 0) {
               if (var21 < var4.length) {
                  var20 = var4[var21++];
               } else {
                  var20 = -1;
               }

               var23 = var2.array[var5++] - 1;
            }

            this.field2786[var24] = (byte)var23;
            --var20;
         }
      }

      var20 = 0;
      var21 = 0;
      var24 = 0;

      for(int var25 = 0; var25 < 128; ++var25) {
         if (this.field2787[var25] != 0) {
            if (var20 == 0) {
               if (var21 < var7.length) {
                  var20 = var7[var21++];
               } else {
                  var20 = -1;
               }

               var24 = var2.array[var8++] + 16 << 2;
            }

            this.field2791[var25] = (byte)var24;
            --var20;
         }
      }

      var20 = 0;
      var21 = 0;
      class209 var42 = null;

      int var26;
      for(var26 = 0; var26 < 128; ++var26) {
         if (this.field2787[var26] != 0) {
            if (var20 == 0) {
               var42 = var39[var38[var21]];
               if (var21 < var10.length) {
                  var20 = var10[var21++];
               } else {
                  var20 = -1;
               }
            }

            this.field2785[var26] = var42;
            --var20;
         }
      }

      var20 = 0;
      var21 = 0;
      var26 = 0;

      int var27;
      for(var27 = 0; var27 < 128; ++var27) {
         if (var20 == 0) {
            if (var21 < var18.length) {
               var20 = var18[var21++];
            } else {
               var20 = -1;
            }

            if (this.field2787[var27] > 0) {
               var26 = var2.readUnsignedByte() + 1;
            }
         }

         this.field2783[var27] = (byte)var26;
         --var20;
      }

      this.field2782 = var2.readUnsignedByte() + 1;

      class209 var28;
      int var29;
      for(var27 = 0; var27 < var12; ++var27) {
         var28 = var39[var27];
         if (var28.field2505 != null) {
            for(var29 = 1; var29 < var28.field2505.length; var29 += 2) {
               var28.field2505[var29] = var2.readByte();
            }
         }

         if (var28.field2508 != null) {
            for(var29 = 3; var29 < var28.field2508.length - 2; var29 += 2) {
               var28.field2508[var29] = var2.readByte();
            }
         }
      }

      if (var47 != null) {
         for(var27 = 1; var27 < var47.length; var27 += 2) {
            var47[var27] = var2.readByte();
         }
      }

      if (var41 != null) {
         for(var27 = 1; var27 < var41.length; var27 += 2) {
            var41[var27] = var2.readByte();
         }
      }

      for(var27 = 0; var27 < var12; ++var27) {
         var28 = var39[var27];
         if (var28.field2508 != null) {
            var19 = 0;

            for(var29 = 2; var29 < var28.field2508.length; var29 += 2) {
               var19 = 1 + var19 + var2.readUnsignedByte();
               var28.field2508[var29] = (byte)var19;
            }
         }
      }

      for(var27 = 0; var27 < var12; ++var27) {
         var28 = var39[var27];
         if (var28.field2505 != null) {
            var19 = 0;

            for(var29 = 2; var29 < var28.field2505.length; var29 += 2) {
               var19 = var19 + 1 + var2.readUnsignedByte();
               var28.field2505[var29] = (byte)var19;
            }
         }
      }

      byte var30;
      int var32;
      int var33;
      int var34;
      int var35;
      int var36;
      int var44;
      byte var46;
      if (var47 != null) {
         var19 = var2.readUnsignedByte();
         var47[0] = (byte)var19;

         for(var27 = 2; var27 < var47.length; var27 += 2) {
            var19 = var19 + 1 + var2.readUnsignedByte();
            var47[var27] = (byte)var19;
         }

         var46 = var47[0];
         byte var43 = var47[1];

         for(var29 = 0; var29 < var46; ++var29) {
            this.field2783[var29] = (byte)(var43 * this.field2783[var29] + 32 >> 6);
         }

         for(var29 = 2; var29 < var47.length; var29 += 2) {
            var30 = var47[var29];
            byte var31 = var47[var29 + 1];
            var32 = var43 * (var30 - var46) + (var30 - var46) / 2;

            for(var33 = var46; var33 < var30; ++var33) {
               var35 = var30 - var46;
               var36 = var32 >>> 31;
               var34 = (var32 + var36) / var35 - var36;
               this.field2783[var33] = (byte)(var34 * this.field2783[var33] + 32 >> 6);
               var32 += var31 - var43;
            }

            var46 = var30;
            var43 = var31;
         }

         for(var44 = var46; var44 < 128; ++var44) {
            this.field2783[var44] = (byte)(var43 * this.field2783[var44] + 32 >> 6);
         }

         var40 = null;
      }

      if (var41 != null) {
         var19 = var2.readUnsignedByte();
         var41[0] = (byte)var19;

         for(var27 = 2; var27 < var41.length; var27 += 2) {
            var19 = 1 + var19 + var2.readUnsignedByte();
            var41[var27] = (byte)var19;
         }

         var46 = var41[0];
         int var49 = var41[1] << 1;

         for(var29 = 0; var29 < var46; ++var29) {
            var44 = var49 + (this.field2791[var29] & 255);
            if (var44 < 0) {
               var44 = 0;
            }

            if (var44 > 128) {
               var44 = 128;
            }

            this.field2791[var29] = (byte)var44;
         }

         int var45;
         for(var29 = 2; var29 < var41.length; var29 += 2) {
            var30 = var41[var29];
            var45 = var41[var29 + 1] << 1;
            var32 = var49 * (var30 - var46) + (var30 - var46) / 2;

            for(var33 = var46; var33 < var30; ++var33) {
               var35 = var30 - var46;
               var36 = var32 >>> 31;
               var34 = (var32 + var36) / var35 - var36;
               int var37 = var34 + (this.field2791[var33] & 255);
               if (var37 < 0) {
                  var37 = 0;
               }

               if (var37 > 128) {
                  var37 = 128;
               }

               this.field2791[var33] = (byte)var37;
               var32 += var45 - var49;
            }

            var46 = var30;
            var49 = var45;
         }

         for(var44 = var46; var44 < 128; ++var44) {
            var45 = var49 + (this.field2791[var44] & 255);
            if (var45 < 0) {
               var45 = 0;
            }

            if (var45 > 128) {
               var45 = 128;
            }

            this.field2791[var44] = (byte)var45;
         }

         Object var48 = null;
      }

      for(var27 = 0; var27 < var12; ++var27) {
         var39[var27].field2506 = var2.readUnsignedByte();
      }

      for(var27 = 0; var27 < var12; ++var27) {
         var28 = var39[var27];
         if (var28.field2505 != null) {
            var28.field2512 = var2.readUnsignedByte();
         }

         if (var28.field2508 != null) {
            var28.field2511 = var2.readUnsignedByte();
         }

         if (var28.field2506 > 0) {
            var28.field2509 = var2.readUnsignedByte();
         }
      }

      for(var27 = 0; var27 < var12; ++var27) {
         var39[var27].field2507 = var2.readUnsignedByte();
      }

      for(var27 = 0; var27 < var12; ++var27) {
         var28 = var39[var27];
         if (var28.field2507 > 0) {
            var28.field2510 = var2.readUnsignedByte();
         }
      }

      for(var27 = 0; var27 < var12; ++var27) {
         var28 = var39[var27];
         if (var28.field2510 > 0) {
            var28.field2504 = var2.readUnsignedByte();
         }
      }

   }

   void method4725() {
      this.field2787 = null;
   }

   boolean method4724(class66 var1, byte[] var2, int[] var3) {
      boolean var4 = true;
      int var5 = 0;
      class88 var6 = null;

      for(int var7 = 0; var7 < 128; ++var7) {
         if (var2 == null || var2[var7] != 0) {
            int var8 = this.field2787[var7];
            if (var8 != 0) {
               if (var5 != var8) {
                  var5 = var8--;
                  if ((var8 & 1) == 0) {
                     var6 = var1.method1388(var8 >> 2, var3);
                  } else {
                     var6 = var1.method1391(var8 >> 2, var3);
                  }

                  if (var6 == null) {
                     var4 = false;
                  }
               }

               if (var6 != null) {
                  this.field2781[var7] = var6;
                  this.field2787[var7] = 0;
               }
            }
         }
      }

      return var4;
   }

   static final void method4733() {
      class6.method183("You can't add yourself to your own friend list");
   }

   static void method4734(Widget[] var0, Widget var1, boolean var2) {
      int var3 = var1.scrollWidth != 0 ? var1.scrollWidth : var1.width;
      int var4 = var1.scrollHeight != 0 ? var1.scrollHeight : var1.height;
      Clock.method3016(var0, var1.id, var3, var4, var2);
      if (var1.children != null) {
         Clock.method3016(var1.children, var1.id, var3, var4, var2);
      }

      WidgetGroupParent var5 = (WidgetGroupParent) Client.field2247.get((long)var1.id);
      if (var5 != null) {
         WorldMapManager.method102(var5.group, var3, var4, var2);
      }

      if (var1.contentType == 1337) {
         ;
      }

   }

   static final void method4735(int var0) {
      WorldComparator.method1403();
      class214.method4489();
      int var1 = UserComparator10.method2912(var0).type;
      if (var1 != 0) {
         int var2 = Varps.field2762[var0];
         if (var1 == 1) {
            if (var2 == 1) {
               Rasterizer3D.method2596(0.9D);
               ((TextureProvider)Rasterizer3D.field1451).setBrightness(0.9D);
            }

            if (var2 == 2) {
               Rasterizer3D.method2596(0.8D);
               ((TextureProvider)Rasterizer3D.field1451).setBrightness(0.8D);
            }

            if (var2 == 3) {
               Rasterizer3D.method2596(0.7D);
               ((TextureProvider)Rasterizer3D.field1451).setBrightness(0.7D);
            }

            if (var2 == 4) {
               Rasterizer3D.method2596(0.6D);
               ((TextureProvider)Rasterizer3D.field1451).setBrightness(0.6D);
            }

            ItemDefinition.field3649.clear();
         }

         if (var1 == 3) {
            short var3 = 0;
            if (var2 == 0) {
               var3 = 255;
            }

            if (var2 == 1) {
               var3 = 192;
            }

            if (var2 == 2) {
               var3 = 128;
            }

            if (var2 == 3) {
               var3 = 64;
            }

            if (var2 == 4) {
               var3 = 0;
            }

            if (var3 != Client.field2320) {
               if (Client.field2320 == 0 && Client.field2321 != -1) {
                  BufferedNetSocket.available(ServerPacket.field1995, Client.field2321, 0, var3, false);
                  Client.field2322 = false;
               } else if (var3 == 0) {
                  WorldMapRegion.method1886();
                  Client.field2322 = false;
               } else {
                  WallDecoration.method2959(var3);
               }

               Client.field2320 = var3;
            }
         }

         if (var1 == 4) {
            if (var2 == 0) {
               Client.field2331 = 127;
            }

            if (var2 == 1) {
               Client.field2331 = 96;
            }

            if (var2 == 2) {
               Client.field2331 = 64;
            }

            if (var2 == 3) {
               Client.field2331 = 32;
            }

            if (var2 == 4) {
               Client.field2331 = 0;
            }
         }

         if (var1 == 5) {
            Client.field2309 = var2;
         }

         if (var1 == 6) {
            Client.field2250 = var2;
         }

         if (var1 == 9) {
            Client.field2251 = var2;
         }

         if (var1 == 10) {
            if (var2 == 0) {
               Client.field2324 = 127;
            }

            if (var2 == 1) {
               Client.field2324 = 96;
            }

            if (var2 == 2) {
               Client.field2324 = 64;
            }

            if (var2 == 3) {
               Client.field2324 = 32;
            }

            if (var2 == 4) {
               Client.field2324 = 0;
            }
         }

         if (var1 == 17) {
            Client.field2256 = var2 & '\uffff';
         }

         if (var1 == 18) {
            Client.field2114 = (AttackOption)class10.method352(class10.method348(), var2);
            if (Client.field2114 == null) {
               Client.field2114 = AttackOption.field607;
            }
         }

         if (var1 == 19) {
            if (var2 == -1) {
               Client.field2212 = -1;
            } else {
               Client.field2212 = var2 & 2047;
            }
         }

         if (var1 == 22) {
            Client.field2115 = (AttackOption)class10.method352(class10.method348(), var2);
            if (Client.field2115 == null) {
               Client.field2115 = AttackOption.field607;
            }
         }

      }
   }
}
