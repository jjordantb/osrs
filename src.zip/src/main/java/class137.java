public class class137 implements class146 {
   static int method2881(int var0, Script var1, boolean var2) {
      int var3;
      if (var0 == 3903) {
         var3 = Interpreter.field467[--class31.field364];
         Interpreter.field467[++class31.field364 - 1] = Client.field2338[var3].type();
         return 1;
      } else if (var0 == 3904) {
         var3 = Interpreter.field467[--class31.field364];
         Interpreter.field467[++class31.field364 - 1] = Client.field2338[var3].id;
         return 1;
      } else if (var0 == 3905) {
         var3 = Interpreter.field467[--class31.field364];
         Interpreter.field467[++class31.field364 - 1] = Client.field2338[var3].unitPrice;
         return 1;
      } else if (var0 == 3906) {
         var3 = Interpreter.field467[--class31.field364];
         Interpreter.field467[++class31.field364 - 1] = Client.field2338[var3].totalQuantity;
         return 1;
      } else if (var0 == 3907) {
         var3 = Interpreter.field467[--class31.field364];
         Interpreter.field467[++class31.field364 - 1] = Client.field2338[var3].currentQuantity;
         return 1;
      } else if (var0 == 3908) {
         var3 = Interpreter.field467[--class31.field364];
         Interpreter.field467[++class31.field364 - 1] = Client.field2338[var3].currentPrice;
         return 1;
      } else {
         int var12;
         if (var0 == 3910) {
            var3 = Interpreter.field467[--class31.field364];
            var12 = Client.field2338[var3].status();
            Interpreter.field467[++class31.field364 - 1] = var12 == 0 ? 1 : 0;
            return 1;
         } else if (var0 == 3911) {
            var3 = Interpreter.field467[--class31.field364];
            var12 = Client.field2338[var3].status();
            Interpreter.field467[++class31.field364 - 1] = var12 == 2 ? 1 : 0;
            return 1;
         } else if (var0 == 3912) {
            var3 = Interpreter.field467[--class31.field364];
            var12 = Client.field2338[var3].status();
            Interpreter.field467[++class31.field364 - 1] = var12 == 5 ? 1 : 0;
            return 1;
         } else if (var0 == 3913) {
            var3 = Interpreter.field467[--class31.field364];
            var12 = Client.field2338[var3].status();
            Interpreter.field467[++class31.field364 - 1] = var12 == 1 ? 1 : 0;
            return 1;
         } else {
            boolean var13;
            if (var0 == 3914) {
               var13 = Interpreter.field467[--class31.field364] == 1;
               if (Message.field553 != null) {
                  Message.field553.sort(GrandExchangeEvents.field999, var13);
               }

               return 1;
            } else if (var0 == 3915) {
               var13 = Interpreter.field467[--class31.field364] == 1;
               if (Message.field553 != null) {
                  Message.field553.sort(GrandExchangeEvents.field992, var13);
               }

               return 1;
            } else if (var0 == 3916) {
               class31.field364 -= 2;
               var13 = Interpreter.field467[class31.field364] == 1;
               boolean var4 = Interpreter.field467[class31.field364 + 1] == 1;
               if (Message.field553 != null) {
                  Client.field2356.field270 = var4;
                  Message.field553.sort(Client.field2356, var13);
               }

               return 1;
            } else if (var0 == 3917) {
               var13 = Interpreter.field467[--class31.field364] == 1;
               if (Message.field553 != null) {
                  Message.field553.sort(GrandExchangeEvents.field993, var13);
               }

               return 1;
            } else if (var0 == 3918) {
               var13 = Interpreter.field467[--class31.field364] == 1;
               if (Message.field553 != null) {
                  Message.field553.sort(GrandExchangeEvents.field996, var13);
               }

               return 1;
            } else if (var0 == 3919) {
               Interpreter.field467[++class31.field364 - 1] = Message.field553 == null ? 0 : Message.field553.events.size();
               return 1;
            } else {
               GrandExchangeEvent var11;
               if (var0 == 3920) {
                  var3 = Interpreter.field467[--class31.field364];
                  var11 = (GrandExchangeEvent)Message.field553.events.get(var3);
                  Interpreter.field467[++class31.field364 - 1] = var11.world;
                  return 1;
               } else if (var0 == 3921) {
                  var3 = Interpreter.field467[--class31.field364];
                  var11 = (GrandExchangeEvent)Message.field553.events.get(var3);
                  Interpreter.field462[++Interpreter.field469 - 1] = var11.method1333();
                  return 1;
               } else if (var0 == 3922) {
                  var3 = Interpreter.field467[--class31.field364];
                  var11 = (GrandExchangeEvent)Message.field553.events.get(var3);
                  Interpreter.field462[++Interpreter.field469 - 1] = var11.method1334();
                  return 1;
               } else if (var0 == 3923) {
                  var3 = Interpreter.field467[--class31.field364];
                  var11 = (GrandExchangeEvent)Message.field553.events.get(var3);
                  long var5 = Tile.method2779() - TextureProvider.field1249 - var11.field754;
                  int var7 = (int)(var5 / 3600000L);
                  int var8 = (int)((var5 - (long)(var7 * 3600000)) / 60000L);
                  int var9 = (int)((var5 - (long)(var7 * 3600000) - (long)(var8 * '\uea60')) / 1000L);
                  String var10 = var7 + ":" + var8 / 10 + var8 % 10 + ":" + var9 / 10 + var9 % 10;
                  Interpreter.field462[++Interpreter.field469 - 1] = var10;
                  return 1;
               } else if (var0 == 3924) {
                  var3 = Interpreter.field467[--class31.field364];
                  var11 = (GrandExchangeEvent)Message.field553.events.get(var3);
                  Interpreter.field467[++class31.field364 - 1] = var11.grandExchangeOffer.totalQuantity;
                  return 1;
               } else if (var0 == 3925) {
                  var3 = Interpreter.field467[--class31.field364];
                  var11 = (GrandExchangeEvent)Message.field553.events.get(var3);
                  Interpreter.field467[++class31.field364 - 1] = var11.grandExchangeOffer.unitPrice;
                  return 1;
               } else if (var0 == 3926) {
                  var3 = Interpreter.field467[--class31.field364];
                  var11 = (GrandExchangeEvent)Message.field553.events.get(var3);
                  Interpreter.field467[++class31.field364 - 1] = var11.grandExchangeOffer.id;
                  return 1;
               } else {
                  return 2;
               }
            }
         }
      }
   }

   public static boolean method2880(int var0) {
      return var0 == class255.field3308.field3307;
   }

   public static PacketBufferNode method2882() {
      PacketBufferNode var0 = ClientPacket.method3232();
      var0.field1803 = null;
      var0.field1802 = 0;
      var0.packetBuffer = new PacketBuffer(5000);
      return var0;
   }

   public static int method2879(Buffer var0, String var1) {
      int var2 = var0.index;
      byte[] var3 = Skeleton.method2199(var1);
      var0.writeSmartByteShort(var3.length);
      var0.index += class303.field3768.method3038(var3, 0, var3.length, var0.array, var0.index);
      return var0.index - var2;
   }
}
