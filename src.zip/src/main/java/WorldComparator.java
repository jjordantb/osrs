import java.util.Comparator;

final class WorldComparator implements Comparator {
   public static int field810;

   int method1393(GrandExchangeEvent var1, GrandExchangeEvent var2) {
      return var1.world < var2.world ? -1 : (var2.world == var1.world ? 0 : 1);
   }

   public boolean equals(Object var1) {
      return super.equals(var1);
   }

   public int compare(Object var1, Object var2) {
      return this.method1393((GrandExchangeEvent)var1, (GrandExchangeEvent)var2);
   }

   public static long method1404(int var0, int var1, int var2, boolean var3, int var4) {
      long var5 = (long)((var0 & 127) << 0 | (var1 & 127) << 7 | (var2 & 3) << 14) | ((long)var4 & 4294967295L) << 17;
      if (var3) {
         var5 |= 65536L;
      }

      return var5;
   }

   static World method1394() {
      World.field350 = 0;
      return class65.method1378();
   }

   public static VarcString method1392(int var0) {
      VarcString var1 = (VarcString)VarcString.field2913.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = VarcString.field2914.takeRecord(15, var0);
         var1 = new VarcString();
         if (var2 != null) {
            var1.method4898(new Buffer(var2));
         }

         VarcString.field2913.put(var1, (long)var0);
         return var1;
      }
   }

   static void method1403() {
      for(WidgetGroupParent var0 = (WidgetGroupParent) Client.field2247.first(); var0 != null; var0 = (WidgetGroupParent) Client.field2247.next()) {
         int var1 = var0.group;
         if (class196.method4189(var1)) {
            boolean var2 = true;
            Widget[] var3 = UserComparator3.field1708[var1];

            int var4;
            for(var4 = 0; var4 < var3.length; ++var4) {
               if (var3[var4] != null) {
                  var2 = var3[var4].isIf3;
                  break;
               }
            }

            if (!var2) {
               var4 = (int)var0.key;
               Widget var5 = WorldMapSection3.method1148(var4);
               if (var5 != null) {
                  WorldMapSection1.method506(var5);
               }
            }
         }
      }

   }

   static void method1402(int var0) {
      ScriptFrame.field172 = new MenuAction();
      ScriptFrame.field172.argument1 = Client.field2224[var0];
      ScriptFrame.field172.argument2 = Client.field2225[var0];
      ScriptFrame.field172.opcode = Client.field2226[var0];
      ScriptFrame.field172.argument0 = Client.field2227[var0];
      ScriptFrame.field172.action = Client.field2359[var0];
   }
}
