public class NetFileRequest extends DualNode {
   static int field3267;
   byte padding;
   IndexCache indexCache;
   int crc;

   static Sprite method4960() {
      Sprite var0 = new Sprite();
      var0.width = class328.field3983;
      var0.height = class328.field3988;
      var0.yOffset = class328.field3982[0];
      var0.xOffset = class328.field3984[0];
      var0.subWidth = class328.field3987[0];
      var0.subHeight = VarcInt.field2811[0];
      int var1 = var0.subHeight * var0.subWidth;
      byte[] var2 = class328.field3989[0];
      var0.pixels = new int[var1];

      for(int var3 = 0; var3 < var1; ++var3) {
         var0.pixels[var3] = class328.field3986[var2[var3] & 255];
      }

      class328.field3982 = null;
      class328.field3984 = null;
      class328.field3987 = null;
      VarcInt.field2811 = null;
      class328.field3986 = null;
      class328.field3989 = null;
      return var0;
   }

   public static NpcDefinition method4959(int var0) {
      NpcDefinition var1 = (NpcDefinition)NpcDefinition.field3570.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = NpcDefinition.field3601.takeRecord(9, var0);
         var1 = new NpcDefinition();
         var1.id = var0;
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         var1.init();
         NpcDefinition.field3570.put(var1, (long)var0);
         return var1;
      }
   }
}
