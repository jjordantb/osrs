import java.io.IOException;

public abstract class AbstractSocket {
   static IndexCache field1778;

   public abstract int read(byte[] var1, int var2, int var3) throws IOException;

   public abstract int available() throws IOException;

   public abstract void write(byte[] var1, int var2, int var3) throws IOException;

   public abstract void close();

   public abstract int readUnsignedByte() throws IOException;

   public abstract boolean isAvailable(int var1) throws IOException;

   static int method3106(int var0, Script var1, boolean var2) {
      if (var0 == 6500) {
         Interpreter.field467[++class31.field364 - 1] = class79.method1622() ? 1 : 0;
         return 1;
      } else {
         World var3;
         if (var0 == 6501) {
            var3 = WorldComparator.method1394();
            if (var3 != null) {
               Interpreter.field467[++class31.field364 - 1] = var3.id;
               Interpreter.field467[++class31.field364 - 1] = var3.properties;
               Interpreter.field462[++Interpreter.field469 - 1] = var3.activity;
               Interpreter.field467[++class31.field364 - 1] = var3.location;
               Interpreter.field467[++class31.field364 - 1] = var3.population;
               Interpreter.field462[++Interpreter.field469 - 1] = var3.host;
            } else {
               Interpreter.field467[++class31.field364 - 1] = -1;
               Interpreter.field467[++class31.field364 - 1] = 0;
               Interpreter.field462[++Interpreter.field469 - 1] = "";
               Interpreter.field467[++class31.field364 - 1] = 0;
               Interpreter.field467[++class31.field364 - 1] = 0;
               Interpreter.field462[++Interpreter.field469 - 1] = "";
            }

            return 1;
         } else if (var0 == 6502) {
            var3 = class65.method1378();
            if (var3 != null) {
               Interpreter.field467[++class31.field364 - 1] = var3.id;
               Interpreter.field467[++class31.field364 - 1] = var3.properties;
               Interpreter.field462[++Interpreter.field469 - 1] = var3.activity;
               Interpreter.field467[++class31.field364 - 1] = var3.location;
               Interpreter.field467[++class31.field364 - 1] = var3.population;
               Interpreter.field462[++Interpreter.field469 - 1] = var3.host;
            } else {
               Interpreter.field467[++class31.field364 - 1] = -1;
               Interpreter.field467[++class31.field364 - 1] = 0;
               Interpreter.field462[++Interpreter.field469 - 1] = "";
               Interpreter.field467[++class31.field364 - 1] = 0;
               Interpreter.field467[++class31.field364 - 1] = 0;
               Interpreter.field462[++Interpreter.field469 - 1] = "";
            }

            return 1;
         } else {
            World var4;
            int var5;
            int var7;
            if (var0 == 6506) {
               var7 = Interpreter.field467[--class31.field364];
               var4 = null;

               for(var5 = 0; var5 < World.field349; ++var5) {
                  if (var7 == World.field353[var5].id) {
                     var4 = World.field353[var5];
                     break;
                  }
               }

               if (var4 != null) {
                  Interpreter.field467[++class31.field364 - 1] = var4.id;
                  Interpreter.field467[++class31.field364 - 1] = var4.properties;
                  Interpreter.field462[++Interpreter.field469 - 1] = var4.activity;
                  Interpreter.field467[++class31.field364 - 1] = var4.location;
                  Interpreter.field467[++class31.field364 - 1] = var4.population;
                  Interpreter.field462[++Interpreter.field469 - 1] = var4.host;
               } else {
                  Interpreter.field467[++class31.field364 - 1] = -1;
                  Interpreter.field467[++class31.field364 - 1] = 0;
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
                  Interpreter.field467[++class31.field364 - 1] = 0;
                  Interpreter.field467[++class31.field364 - 1] = 0;
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
               }

               return 1;
            } else if (var0 == 6507) {
               class31.field364 -= 4;
               var7 = Interpreter.field467[class31.field364];
               boolean var10 = Interpreter.field467[class31.field364 + 1] == 1;
               var5 = Interpreter.field467[class31.field364 + 2];
               boolean var6 = Interpreter.field467[class31.field364 + 3] == 1;
               ScriptEvent.method1034(var7, var10, var5, var6);
               return 1;
            } else if (var0 != 6511) {
               if (var0 == 6512) {
                  Client.field2231 = Interpreter.field467[--class31.field364] == 1;
                  return 1;
               } else {
                  int var8;
                  ParamKeyDefinition var9;
                  if (var0 == 6513) {
                     class31.field364 -= 2;
                     var7 = Interpreter.field467[class31.field364];
                     var8 = Interpreter.field467[class31.field364 + 1];
                     var9 = class83.method1701(var8);
                     if (var9.isString()) {
                        Interpreter.field462[++Interpreter.field469 - 1] = NetFileRequest.method4959(var7).getStringParam(var8, var9.keyString);
                     } else {
                        Interpreter.field467[++class31.field364 - 1] = NetFileRequest.method4959(var7).getIntParam(var8, var9.keyInt);
                     }

                     return 1;
                  } else if (var0 == 6514) {
                     class31.field364 -= 2;
                     var7 = Interpreter.field467[class31.field364];
                     var8 = Interpreter.field467[class31.field364 + 1];
                     var9 = class83.method1701(var8);
                     if (var9.isString()) {
                        Interpreter.field462[++Interpreter.field469 - 1] = class252.method4958(var7).getStringParam(var8, var9.keyString);
                     } else {
                        Interpreter.field467[++class31.field364 - 1] = class252.method4958(var7).getIntParam(var8, var9.keyInt);
                     }

                     return 1;
                  } else if (var0 == 6515) {
                     class31.field364 -= 2;
                     var7 = Interpreter.field467[class31.field364];
                     var8 = Interpreter.field467[class31.field364 + 1];
                     var9 = class83.method1701(var8);
                     if (var9.isString()) {
                        Interpreter.field462[++Interpreter.field469 - 1] = Varcs.getItemDefinition(var7).getStringParam(var8, var9.keyString);
                     } else {
                        Interpreter.field467[++class31.field364 - 1] = Varcs.getItemDefinition(var7).getIntParam(var8, var9.keyInt);
                     }

                     return 1;
                  } else if (var0 == 6516) {
                     class31.field364 -= 2;
                     var7 = Interpreter.field467[class31.field364];
                     var8 = Interpreter.field467[class31.field364 + 1];
                     var9 = class83.method1701(var8);
                     if (var9.isString()) {
                        Interpreter.field462[++Interpreter.field469 - 1] = UserComparator4.method2997(var7).getString(var8, var9.keyString);
                     } else {
                        Interpreter.field467[++class31.field364 - 1] = UserComparator4.method2997(var7).getInt(var8, var9.keyInt);
                     }

                     return 1;
                  } else if (var0 == 6518) {
                     Interpreter.field467[++class31.field364 - 1] = Client.field2213 ? 1 : 0;
                     return 1;
                  } else if (var0 == 6519) {
                     Interpreter.field467[++class31.field364 - 1] = Client.field2094 & 3;
                     return 1;
                  } else if (var0 == 6520) {
                     return 1;
                  } else if (var0 == 6521) {
                     return 1;
                  } else if (var0 == 6522) {
                     --Interpreter.field469;
                     --class31.field364;
                     return 1;
                  } else if (var0 == 6523) {
                     --Interpreter.field469;
                     --class31.field364;
                     return 1;
                  } else if (var0 == 6524) {
                     Interpreter.field467[++class31.field364 - 1] = -1;
                     return 1;
                  } else if (var0 == 6525) {
                     Interpreter.field467[++class31.field364 - 1] = 1;
                     return 1;
                  } else if (var0 == 6526) {
                     Interpreter.field467[++class31.field364 - 1] = 1;
                     return 1;
                  } else {
                     return 2;
                  }
               }
            } else {
               var7 = Interpreter.field467[--class31.field364];
               if (var7 >= 0 && var7 < World.field349) {
                  var4 = World.field353[var7];
                  Interpreter.field467[++class31.field364 - 1] = var4.id;
                  Interpreter.field467[++class31.field364 - 1] = var4.properties;
                  Interpreter.field462[++Interpreter.field469 - 1] = var4.activity;
                  Interpreter.field467[++class31.field364 - 1] = var4.location;
                  Interpreter.field467[++class31.field364 - 1] = var4.population;
                  Interpreter.field462[++Interpreter.field469 - 1] = var4.host;
               } else {
                  Interpreter.field467[++class31.field364 - 1] = -1;
                  Interpreter.field467[++class31.field364 - 1] = 0;
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
                  Interpreter.field467[++class31.field364 - 1] = 0;
                  Interpreter.field467[++class31.field364 - 1] = 0;
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
               }

               return 1;
            }
         }
      }
   }
}
