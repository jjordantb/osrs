public class VarcInt extends DualNode {
   public static int[] field2811;
   public static AbstractIndexCache field2813;
   static EvictingDualNodeHashTable field2812 = new EvictingDualNodeHashTable(64);
   public boolean persist = false;

   void method4769(Buffer var1, int var2) {
      if (var2 == 2) {
         this.persist = true;
      }

   }

   void method4768(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.method4769(var1, var2);
      }
   }

   static int method4773(int var0, Script var1, boolean var2) {
      if (var0 == 5000) {
         Interpreter.field467[++class31.field364 - 1] = Client.field2173;
         return 1;
      } else if (var0 == 5001) {
         class31.field364 -= 3;
         Client.field2173 = Interpreter.field467[class31.field364];
         OverlayDefinition.field3690 = ScriptFrame.method462(Interpreter.field467[class31.field364 + 1]);
         if (OverlayDefinition.field3690 == null) {
            OverlayDefinition.field3690 = class291.field3711;
         }

         Client.field2304 = Interpreter.field467[class31.field364 + 2];
         PacketBufferNode var18 = FaceNormal.method2884(ClientPacket.field1882, Client.field2133.isaacCipher);
         var18.packetBuffer.writeByte(Client.field2173);
         var18.packetBuffer.writeByte(OverlayDefinition.field3690.field3713);
         var18.packetBuffer.writeByte(Client.field2304);
         Client.field2133.method1281(var18);
         return 1;
      } else {
         String var3;
         int var4;
         if (var0 == 5002) {
            var3 = Interpreter.field462[--Interpreter.field469];
            class31.field364 -= 2;
            var4 = Interpreter.field467[class31.field364];
            int var5 = Interpreter.field467[class31.field364 + 1];
            PacketBufferNode var6 = FaceNormal.method2884(ClientPacket.field1874, Client.field2133.isaacCipher);
            var6.packetBuffer.writeByte(AbstractSoundSystem.method1696(var3) + 2);
            var6.packetBuffer.writeStringCp1252NullTerminated(var3);
            var6.packetBuffer.writeByte(var4 - 1);
            var6.packetBuffer.writeByte(var5);
            Client.field2133.method1281(var6);
            return 1;
         } else {
            int var10;
            if (var0 == 5003) {
               class31.field364 -= 2;
               var10 = Interpreter.field467[class31.field364];
               var4 = Interpreter.field467[class31.field364 + 1];
               Message var15 = MouseHandler.getButton(var10, var4);
               if (var15 != null) {
                  Interpreter.field467[++class31.field364 - 1] = var15.count;
                  Interpreter.field467[++class31.field364 - 1] = var15.cycle;
                  Interpreter.field462[++Interpreter.field469 - 1] = var15.sender != null ? var15.sender : "";
                  Interpreter.field462[++Interpreter.field469 - 1] = var15.prefix != null ? var15.prefix : "";
                  Interpreter.field462[++Interpreter.field469 - 1] = var15.text != null ? var15.text : "";
                  Interpreter.field467[++class31.field364 - 1] = var15.method1046() ? 1 : (var15.method1043() ? 2 : 0);
               } else {
                  Interpreter.field467[++class31.field364 - 1] = -1;
                  Interpreter.field467[++class31.field364 - 1] = 0;
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
                  Interpreter.field467[++class31.field364 - 1] = 0;
               }

               return 1;
            } else if (var0 == 5004) {
               var10 = Interpreter.field467[--class31.field364];
               Message var16 = class79.method1620(var10);
               if (var16 != null) {
                  Interpreter.field467[++class31.field364 - 1] = var16.type;
                  Interpreter.field467[++class31.field364 - 1] = var16.cycle;
                  Interpreter.field462[++Interpreter.field469 - 1] = var16.sender != null ? var16.sender : "";
                  Interpreter.field462[++Interpreter.field469 - 1] = var16.prefix != null ? var16.prefix : "";
                  Interpreter.field462[++Interpreter.field469 - 1] = var16.text != null ? var16.text : "";
                  Interpreter.field467[++class31.field364 - 1] = var16.method1046() ? 1 : (var16.method1043() ? 2 : 0);
               } else {
                  Interpreter.field467[++class31.field364 - 1] = -1;
                  Interpreter.field467[++class31.field364 - 1] = 0;
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
                  Interpreter.field467[++class31.field364 - 1] = 0;
               }

               return 1;
            } else if (var0 == 5005) {
               if (OverlayDefinition.field3690 == null) {
                  Interpreter.field467[++class31.field364 - 1] = -1;
               } else {
                  Interpreter.field467[++class31.field364 - 1] = OverlayDefinition.field3690.field3713;
               }

               return 1;
            } else if (var0 == 5008) {
               var3 = Interpreter.field462[--Interpreter.field469];
               var4 = Interpreter.field467[--class31.field364];
               String var14 = var3.toLowerCase();
               byte var17 = 0;
               if (var14.startsWith("yellow:")) {
                  var17 = 0;
                  var3 = var3.substring("yellow:".length());
               } else if (var14.startsWith("red:")) {
                  var17 = 1;
                  var3 = var3.substring("red:".length());
               } else if (var14.startsWith("green:")) {
                  var17 = 2;
                  var3 = var3.substring("green:".length());
               } else if (var14.startsWith("cyan:")) {
                  var17 = 3;
                  var3 = var3.substring("cyan:".length());
               } else if (var14.startsWith("purple:")) {
                  var17 = 4;
                  var3 = var3.substring("purple:".length());
               } else if (var14.startsWith("white:")) {
                  var17 = 5;
                  var3 = var3.substring("white:".length());
               } else if (var14.startsWith("flash1:")) {
                  var17 = 6;
                  var3 = var3.substring("flash1:".length());
               } else if (var14.startsWith("flash2:")) {
                  var17 = 7;
                  var3 = var3.substring("flash2:".length());
               } else if (var14.startsWith("flash3:")) {
                  var17 = 8;
                  var3 = var3.substring("flash3:".length());
               } else if (var14.startsWith("glow1:")) {
                  var17 = 9;
                  var3 = var3.substring("glow1:".length());
               } else if (var14.startsWith("glow2:")) {
                  var17 = 10;
                  var3 = var3.substring("glow2:".length());
               } else if (var14.startsWith("glow3:")) {
                  var17 = 11;
                  var3 = var3.substring("glow3:".length());
               } else if (Client.field2228 != 0) {
                  if (var14.startsWith("yellow:")) {
                     var17 = 0;
                     var3 = var3.substring("yellow:".length());
                  } else if (var14.startsWith("red:")) {
                     var17 = 1;
                     var3 = var3.substring("red:".length());
                  } else if (var14.startsWith("green:")) {
                     var17 = 2;
                     var3 = var3.substring("green:".length());
                  } else if (var14.startsWith("cyan:")) {
                     var17 = 3;
                     var3 = var3.substring("cyan:".length());
                  } else if (var14.startsWith("purple:")) {
                     var17 = 4;
                     var3 = var3.substring("purple:".length());
                  } else if (var14.startsWith("white:")) {
                     var17 = 5;
                     var3 = var3.substring("white:".length());
                  } else if (var14.startsWith("flash1:")) {
                     var17 = 6;
                     var3 = var3.substring("flash1:".length());
                  } else if (var14.startsWith("flash2:")) {
                     var17 = 7;
                     var3 = var3.substring("flash2:".length());
                  } else if (var14.startsWith("flash3:")) {
                     var17 = 8;
                     var3 = var3.substring("flash3:".length());
                  } else if (var14.startsWith("glow1:")) {
                     var17 = 9;
                     var3 = var3.substring("glow1:".length());
                  } else if (var14.startsWith("glow2:")) {
                     var17 = 10;
                     var3 = var3.substring("glow2:".length());
                  } else if (var14.startsWith("glow3:")) {
                     var17 = 11;
                     var3 = var3.substring("glow3:".length());
                  }
               }

               var14 = var3.toLowerCase();
               byte var7 = 0;
               if (var14.startsWith("wave:")) {
                  var7 = 1;
                  var3 = var3.substring("wave:".length());
               } else if (var14.startsWith("wave2:")) {
                  var7 = 2;
                  var3 = var3.substring("wave2:".length());
               } else if (var14.startsWith("shake:")) {
                  var7 = 3;
                  var3 = var3.substring("shake:".length());
               } else if (var14.startsWith("scroll:")) {
                  var7 = 4;
                  var3 = var3.substring("scroll:".length());
               } else if (var14.startsWith("slide:")) {
                  var7 = 5;
                  var3 = var3.substring("slide:".length());
               } else if (Client.field2228 != 0) {
                  if (var14.startsWith("wave:")) {
                     var7 = 1;
                     var3 = var3.substring("wave:".length());
                  } else if (var14.startsWith("wave2:")) {
                     var7 = 2;
                     var3 = var3.substring("wave2:".length());
                  } else if (var14.startsWith("shake:")) {
                     var7 = 3;
                     var3 = var3.substring("shake:".length());
                  } else if (var14.startsWith("scroll:")) {
                     var7 = 4;
                     var3 = var3.substring("scroll:".length());
                  } else if (var14.startsWith("slide:")) {
                     var7 = 5;
                     var3 = var3.substring("slide:".length());
                  }
               }

               PacketBufferNode var8 = FaceNormal.method2884(ClientPacket.field1859, Client.field2133.isaacCipher);
               var8.packetBuffer.writeByte(0);
               int var9 = var8.packetBuffer.index;
               var8.packetBuffer.writeByte(var4);
               var8.packetBuffer.writeByte(var17);
               var8.packetBuffer.writeByte(var7);
               class137.method2879(var8.packetBuffer, var3);
               var8.packetBuffer.method3908(var8.packetBuffer.index - var9);
               Client.field2133.method1281(var8);
               return 1;
            } else if (var0 == 5009) {
               Interpreter.field469 -= 2;
               var3 = Interpreter.field462[Interpreter.field469];
               String var12 = Interpreter.field462[Interpreter.field469 + 1];
               PacketBufferNode var11 = FaceNormal.method2884(ClientPacket.field1861, Client.field2133.isaacCipher);
               var11.packetBuffer.writeShort(0);
               int var13 = var11.packetBuffer.index;
               var11.packetBuffer.writeStringCp1252NullTerminated(var3);
               class137.method2879(var11.packetBuffer, var12);
               var11.packetBuffer.method3907(var11.packetBuffer.index - var13);
               Client.field2133.method1281(var11);
               return 1;
            } else if (var0 != 5015) {
               if (var0 == 5016) {
                  Interpreter.field467[++class31.field364 - 1] = Client.field2304;
                  return 1;
               } else if (var0 == 5017) {
                  var10 = Interpreter.field467[--class31.field364];
                  Interpreter.field467[++class31.field364 - 1] = Messages.method1147(var10);
                  return 1;
               } else if (var0 == 5018) {
                  var10 = Interpreter.field467[--class31.field364];
                  Interpreter.field467[++class31.field364 - 1] = class25.method581(var10);
                  return 1;
               } else if (var0 == 5019) {
                  var10 = Interpreter.field467[--class31.field364];
                  Interpreter.field467[++class31.field364 - 1] = ScriptEvent.method1042(var10);
                  return 1;
               } else if (var0 == 5020) {
                  var3 = Interpreter.field462[--Interpreter.field469];
                  SoundSystemProvider.method331(var3);
                  return 1;
               } else if (var0 == 5021) {
                  Client.field2305 = Interpreter.field462[--Interpreter.field469].toLowerCase().trim();
                  return 1;
               } else if (var0 == 5022) {
                  Interpreter.field462[++Interpreter.field469 - 1] = Client.field2305;
                  return 1;
               } else {
                  return 2;
               }
            } else {
               if (ObjectSound.field589 != null && ObjectSound.field589.username != null) {
                  var3 = ObjectSound.field589.username.name();
               } else {
                  var3 = "";
               }

               Interpreter.field462[++Interpreter.field469 - 1] = var3;
               return 1;
            }
         }
      }
   }
}
