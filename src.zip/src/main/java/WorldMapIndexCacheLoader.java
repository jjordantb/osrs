public class WorldMapIndexCacheLoader {
   AbstractIndexCache indexCache;
   String cacheName;
   boolean isLoaded0 = false;
   int percentLoaded0 = 0;

   WorldMapIndexCacheLoader(AbstractIndexCache var1) {
      this.indexCache = var1;
   }

   boolean isLoaded() {
      return this.isLoaded0;
   }

   void reset(String var1) {
      if (var1 != null && !var1.isEmpty()) {
         if (var1 != this.cacheName) {
            this.cacheName = var1;
            this.percentLoaded0 = 0;
            this.isLoaded0 = false;
            this.load();
         }
      }
   }

   int percentLoaded() {
      return this.percentLoaded0;
   }

   int load() {
      if (this.percentLoaded0 < 25) {
         if (!this.indexCache.tryLoadRecordByNames(WorldMapCacheName.field232.name, this.cacheName)) {
            return this.percentLoaded0;
         }

         this.percentLoaded0 = 25;
      }

      if (this.percentLoaded0 == 25) {
         if (!this.indexCache.tryLoadRecordByNames(this.cacheName, WorldMapCacheName.field234.name)) {
            return 25 + this.indexCache.archiveLoadPercentByName(this.cacheName) * 25 / 100;
         }

         this.percentLoaded0 = 50;
      }

      if (this.percentLoaded0 == 50) {
         if (this.indexCache.method4984(WorldMapCacheName.field233.name, this.cacheName) && !this.indexCache.tryLoadRecordByNames(WorldMapCacheName.field233.name, this.cacheName)) {
            return 50;
         }

         this.percentLoaded0 = 75;
      }

      if (this.percentLoaded0 == 75) {
         if (!this.indexCache.tryLoadRecordByNames(this.cacheName, WorldMapCacheName.field236.name)) {
            return 75;
         }

         this.percentLoaded0 = 100;
         this.isLoaded0 = true;
      }

      return this.percentLoaded0;
   }

   static int method6514(int var0, Script var1, boolean var2) {
      int var3;
      int var4;
      int var6;
      if (var0 == 3400) {
         class31.field364 -= 2;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         EnumDefinition var5 = Script.method1818(var3);
         if (var5.valType != 's') {
            ;
         }

         for(var6 = 0; var6 < var5.size0; ++var6) {
            if (var4 == var5.keys[var6]) {
               Interpreter.field462[++Interpreter.field469 - 1] = var5.stringVals[var6];
               var5 = null;
               break;
            }
         }

         if (var5 != null) {
            Interpreter.field462[++Interpreter.field469 - 1] = var5.defaultString;
         }

         return 1;
      } else if (var0 != 3408) {
         if (var0 == 3411) {
            var3 = Interpreter.field467[--class31.field364];
            EnumDefinition var10 = Script.method1818(var3);
            Interpreter.field467[++class31.field364 - 1] = var10.size();
            return 1;
         } else {
            return 2;
         }
      } else {
         class31.field364 -= 4;
         var3 = Interpreter.field467[class31.field364];
         var4 = Interpreter.field467[class31.field364 + 1];
         int var9 = Interpreter.field467[class31.field364 + 2];
         var6 = Interpreter.field467[class31.field364 + 3];
         EnumDefinition var7 = Script.method1818(var9);
         if (var3 == var7.keyType && var4 == var7.valType) {
            for(int var8 = 0; var8 < var7.size0; ++var8) {
               if (var6 == var7.keys[var8]) {
                  if (var4 == 115) {
                     Interpreter.field462[++Interpreter.field469 - 1] = var7.stringVals[var8];
                  } else {
                     Interpreter.field467[++class31.field364 - 1] = var7.intVals[var8];
                  }

                  var7 = null;
                  break;
               }
            }

            if (var7 != null) {
               if (var4 == 115) {
                  Interpreter.field462[++Interpreter.field469 - 1] = var7.defaultString;
               } else {
                  Interpreter.field467[++class31.field364 - 1] = var7.defaultInt;
               }
            }

            return 1;
         } else {
            if (var4 == 115) {
               Interpreter.field462[++Interpreter.field469 - 1] = "null";
            } else {
               Interpreter.field467[++class31.field364 - 1] = 0;
            }

            return 1;
         }
      }
   }
}
