public class Script extends DualNode {
   static EvictingDualNodeHashTable field1052 = new EvictingDualNodeHashTable(128);
   static int field1051;
   int intArgumentCount;
   int localIntCount;
   int[] intOperands;
   int localStringCount;
   IterableNodeHashTable[] switches;
   String[] stringOperands;
   int[] opcodes;
   int stringArgumentCount;

   IterableNodeHashTable[] method1803(int var1) {
      return new IterableNodeHashTable[var1];
   }

   static Script method1805(int var0, int var1) {
      Script var2 = (Script)field1052.get((long)(var0 << 16));
      if (var2 != null) {
         return var2;
      } else {
         String var3 = String.valueOf(var0);
         int var4 = UrlRequester.field1587.getArchiveId(var3);
         if (var4 == -1) {
            return null;
         } else {
            byte[] var5 = UrlRequester.field1587.takeRecordFlat(var4);
            if (var5 != null) {
               if (var5.length <= 1) {
                  return null;
               }

               var2 = Projectile.method1331(var5);
               if (var2 != null) {
                  field1052.put(var2, (long)(var0 << 16));
                  return var2;
               }
            }

            return null;
         }
      }
   }

   static boolean method1814(PacketBuffer var0, int var1) {
      int var2 = var0.readBits(2);
      int var3;
      int var4;
      int var7;
      int var8;
      int var9;
      int var10;
      if (var2 == 0) {
         if (var0.readBits(1) != 0) {
            method1814(var0, var1);
         }

         var3 = var0.readBits(13);
         var4 = var0.readBits(13);
         boolean var12 = var0.readBits(1) == 1;
         if (var12) {
            Players.field959[++Players.field952 - 1] = var1;
         }

         if (Client.field2141[var1] != null) {
            throw new RuntimeException();
         } else {
            Player var6 = Client.field2141[var1] = new Player();
            var6.index = var1;
            if (Players.field958[var1] != null) {
               var6.read(Players.field958[var1]);
            }

            var6.orientation = Players.field956[var1];
            var6.targetIndex = Players.field957[var1];
            var7 = Players.field955[var1];
            var8 = var7 >> 28;
            var9 = var7 >> 14 & 255;
            var10 = var7 & 255;
            var6.pathTraversed[0] = Players.field949[var1];
            var6.plane = (byte)var8;
            var6.resetPath((var9 << 13) + var3 - class21.field230, (var10 << 13) + var4 - class79.field902);
            var6.field441 = false;
            return true;
         }
      } else if (var2 == 1) {
         var3 = var0.readBits(2);
         var4 = Players.field955[var1];
         Players.field955[var1] = (var4 & 268435455) + (((var4 >> 28) + var3 & 3) << 28);
         return false;
      } else {
         int var5;
         int var11;
         if (var2 == 2) {
            var3 = var0.readBits(5);
            var4 = var3 >> 3;
            var5 = var3 & 7;
            var11 = Players.field955[var1];
            var7 = (var11 >> 28) + var4 & 3;
            var8 = var11 >> 14 & 255;
            var9 = var11 & 255;
            if (var5 == 0) {
               --var8;
               --var9;
            }

            if (var5 == 1) {
               --var9;
            }

            if (var5 == 2) {
               ++var8;
               --var9;
            }

            if (var5 == 3) {
               --var8;
            }

            if (var5 == 4) {
               ++var8;
            }

            if (var5 == 5) {
               --var8;
               ++var9;
            }

            if (var5 == 6) {
               ++var9;
            }

            if (var5 == 7) {
               ++var8;
               ++var9;
            }

            Players.field955[var1] = (var8 << 14) + var9 + (var7 << 28);
            return false;
         } else {
            var3 = var0.readBits(18);
            var4 = var3 >> 16;
            var5 = var3 >> 8 & 255;
            var11 = var3 & 255;
            var7 = Players.field955[var1];
            var8 = (var7 >> 28) + var4 & 3;
            var9 = var5 + (var7 >> 14) & 255;
            var10 = var7 + var11 & 255;
            Players.field955[var1] = (var9 << 14) + var10 + (var8 << 28);
            return false;
         }
      }
   }

   public static void method1817(int var0) {
      MouseHandler.field165 = var0;
   }

   public static EnumDefinition method1818(int var0) {
      EnumDefinition var1 = (EnumDefinition)EnumDefinition.field3487.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = EnumDefinition.field3492.takeRecord(8, var0);
         var1 = new EnumDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         EnumDefinition.field3487.put(var1, (long)var0);
         return var1;
      }
   }

   static String method1819(Widget var0) {
      if (class71.method1463(class257.method5068(var0)) == 0) {
         return null;
      } else {
         return var0.spellActionName != null && var0.spellActionName.trim().length() != 0 ? var0.spellActionName : null;
      }
   }

   static void method1815(Buffer var0, int var1) {
      byte[] var2 = var0.array;
      if (Client.field2151 == null) {
         Client.field2151 = new byte[24];
      }

      class195.method4145(var2, var1, Client.field2151, 0, 24);
      if (class178.field1985 != null) {
         try {
            class178.field1985.seek(0L);
            class178.field1985.write(var0.array, var1, 24);
         } catch (Exception var4) {
            ;
         }
      }

   }
}
