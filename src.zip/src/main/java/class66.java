public class class66 {
   NodeHashTable field805 = new NodeHashTable(256);
   AbstractIndexCache field807;
   NodeHashTable field806 = new NodeHashTable(256);
   AbstractIndexCache field804;

   public class66(AbstractIndexCache var1, AbstractIndexCache var2) {
      this.field807 = var1;
      this.field804 = var2;
   }

   public class88 method1388(int var1, int[] var2) {
      if (this.field807.method4977() == 1) {
         return this.method1384(0, var1, var2);
      } else if (this.field807.method5025(var1) == 1) {
         return this.method1384(var1, 0, var2);
      } else {
         throw new RuntimeException();
      }
   }

   class88 method1384(int var1, int var2, int[] var3) {
      int var4 = var2 ^ (var1 << 4 & '\uffff' | var1 >>> 12);
      var4 |= var1 << 16;
      long var5 = (long)var4;
      class88 var7 = (class88)this.field806.get(var5);
      if (var7 != null) {
         return var7;
      } else if (var3 != null && var3[0] <= 0) {
         return null;
      } else {
         SoundEffect var8 = SoundEffect.method1624(this.field807, var1, var2);
         if (var8 == null) {
            return null;
         } else {
            var7 = var8.method1630();
            this.field806.put(var7, var5);
            if (var3 != null) {
               var3[0] -= var7.field988.length;
            }

            return var7;
         }
      }
   }

   public class88 method1391(int var1, int[] var2) {
      if (this.field804.method4977() == 1) {
         return this.method1385(0, var1, var2);
      } else if (this.field804.method5025(var1) == 1) {
         return this.method1385(var1, 0, var2);
      } else {
         throw new RuntimeException();
      }
   }

   class88 method1385(int var1, int var2, int[] var3) {
      int var4 = var2 ^ (var1 << 4 & '\uffff' | var1 >>> 12);
      var4 |= var1 << 16;
      long var5 = (long)var4 ^ 4294967296L;
      class88 var7 = (class88)this.field806.get(var5);
      if (var7 != null) {
         return var7;
      } else if (var3 != null && var3[0] <= 0) {
         return null;
      } else {
         MusicSample var8 = (MusicSample)this.field805.get(var5);
         if (var8 == null) {
            var8 = MusicSample.method1348(this.field804, var1, var2);
            if (var8 == null) {
               return null;
            }

            this.field805.put(var8, var5);
         }

         var7 = var8.method1349(var3);
         if (var7 == null) {
            return null;
         } else {
            var8.remove();
            this.field806.put(var7, var5);
            return var7;
         }
      }
   }
}
