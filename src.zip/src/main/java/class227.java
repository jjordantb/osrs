public class class227 {
   static final byte[] field2771 = new byte[]{2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
   int field2770;
   int[] field2768;
   int[] field2766;
   Buffer field2774 = new Buffer((byte[])null);
   int[] field2769;
   long field2772;
   int[] field2767;
   int field2765;

   class227(byte[] var1) {
      this.method4671(var1);
   }

   class227() {
   }

   void method4674(long var1) {
      this.field2772 = var1;
      int var3 = this.field2767.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         this.field2768[var4] = 0;
         this.field2769[var4] = 0;
         this.field2774.index = this.field2766[var4];
         this.method4677(var4);
         this.field2767[var4] = this.field2774.index;
      }

   }

   void method4708(int var1) {
      this.field2774.index = this.field2767[var1];
   }

   int method4678(int var1) {
      int var2 = this.method4679(var1);
      return var2;
   }

   boolean method4669() {
      return this.field2774.array != null;
   }

   boolean method4683() {
      int var1 = this.field2767.length;

      for(int var2 = 0; var2 < var1; ++var2) {
         if (this.field2767[var2] >= 0) {
            return false;
         }
      }

      return true;
   }

   void method4671(byte[] var1) {
      this.field2774.array = var1;
      this.field2774.index = 10;
      int var2 = this.field2774.method3913();
      this.field2765 = this.field2774.method3913();
      this.field2770 = 500000;
      this.field2766 = new int[var2];

      int var3;
      int var5;
      for(var3 = 0; var3 < var2; this.field2774.index += var5) {
         int var4 = this.field2774.readInt();
         var5 = this.field2774.readInt();
         if (var4 == 1297379947) {
            this.field2766[var3] = this.field2774.index;
            ++var3;
         }
      }

      this.field2772 = 0L;
      this.field2767 = new int[var2];

      for(var3 = 0; var3 < var2; ++var3) {
         this.field2767[var3] = this.field2766[var3];
      }

      this.field2768 = new int[var2];
      this.field2769 = new int[var2];
   }

   int method4713() {
      int var1 = this.field2767.length;
      int var2 = -1;
      int var3 = Integer.MAX_VALUE;

      for(int var4 = 0; var4 < var1; ++var4) {
         if (this.field2767[var4] >= 0 && this.field2768[var4] < var3) {
            var2 = var4;
            var3 = this.field2768[var4];
         }
      }

      return var2;
   }

   void method4675(int var1) {
      this.field2767[var1] = this.field2774.index;
   }

   int method4679(int var1) {
      byte var2 = this.field2774.array[this.field2774.index];
      int var5;
      if (var2 < 0) {
         var5 = var2 & 255;
         this.field2769[var1] = var5;
         ++this.field2774.index;
      } else {
         var5 = this.field2769[var1];
      }

      if (var5 != 240 && var5 != 247) {
         return this.method4680(var1, var5);
      } else {
         int var3 = this.field2774.method3929();
         if (var5 == 247 && var3 > 0) {
            int var4 = this.field2774.array[this.field2774.index] & 255;
            if (var4 >= 241 && var4 <= 243 || var4 == 246 || var4 == 248 || var4 >= 250 && var4 <= 252 || var4 == 254) {
               ++this.field2774.index;
               this.field2769[var1] = var4;
               return this.method4680(var1, var4);
            }
         }

         this.field2774.index += var3;
         return 0;
      }
   }

   void method4677(int var1) {
      int var2 = this.field2774.method3929();
      this.field2768[var1] += var2;
   }

   void method4676() {
      this.field2774.index = -1;
   }

   int method4712() {
      return this.field2767.length;
   }

   void method4722() {
      this.field2774.array = null;
      this.field2766 = null;
      this.field2767 = null;
      this.field2768 = null;
      this.field2769 = null;
   }

   long method4681(int var1) {
      return this.field2772 + (long)var1 * (long)this.field2770;
   }

   int method4680(int var1, int var2) {
      int var4;
      if (var2 == 255) {
         int var7 = this.field2774.readUnsignedByte();
         var4 = this.field2774.method3929();
         if (var7 == 47) {
            this.field2774.index += var4;
            return 1;
         } else if (var7 == 81) {
            int var5 = this.field2774.readMedium();
            var4 -= 3;
            int var6 = this.field2768[var1];
            this.field2772 += (long)var6 * (long)(this.field2770 - var5);
            this.field2770 = var5;
            this.field2774.index += var4;
            return 2;
         } else {
            this.field2774.index += var4;
            return 3;
         }
      } else {
         byte var3 = field2771[var2 - 128];
         var4 = var2;
         if (var3 >= 1) {
            var4 = var2 | this.field2774.readUnsignedByte() << 8;
         }

         if (var3 >= 2) {
            var4 |= this.field2774.readUnsignedByte() << 16;
         }

         return var4;
      }
   }
}
