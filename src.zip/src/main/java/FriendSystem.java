public class FriendSystem {
   public static int field379;
   int field383 = 0;
   public final FriendsList friendsList;
   public final IgnoreList ignoreList;
   final LoginType loginType;

   FriendSystem(LoginType var1) {
      this.loginType = var1;
      this.friendsList = new FriendsList(var1);
      this.ignoreList = new IgnoreList(var1);
   }

   final boolean method727(Username var1) {
      Friend var2 = (Friend)this.friendsList.getByUsername(var1);
      return var2 != null && var2.method5833();
   }

   final void method723(String var1) {
      if (var1 != null) {
         Username var2 = new Username(var1, this.loginType);
         if (var2.hasCleanName()) {
            if (this.method724()) {
               class6.method183("Your ignore list is full. Max of 100 for free users, and 400 for members");
            } else if (ObjectSound.field589.username.equals(var2)) {
               class6.method183("You can't add yourself to your own ignore list");
            } else if (this.method766(var2)) {
               LoginPacket.method3277(var1);
            } else if (this.method739(var2, false)) {
               WorldMapData.method1561(var1);
            } else {
               PacketBufferNode var3 = FaceNormal.method2884(ClientPacket.field1926, Client.field2133.isaacCipher);
               var3.packetBuffer.writeByte(AbstractSoundSystem.method1696(var1));
               var3.packetBuffer.writeStringCp1252NullTerminated(var1);
               Client.field2133.method1281(var3);
            }
         }
      }
   }

   final void method718() {
      this.field383 = 0;
      this.friendsList.clear();
      this.ignoreList.clear();
   }

   final void method716(Buffer var1, int var2) {
      this.friendsList.read(var1, var2);
      this.field383 = 2;
      IndexStoreActionHandler.method4939();
   }

   final boolean method722() {
      return this.friendsList.isFull() || this.friendsList.size() >= 200 && Client.field2204 != 1;
   }

   boolean method714() {
      return this.field383 == 2;
   }

   final boolean method739(Username var1, boolean var2) {
      if (var1 == null) {
         return false;
      } else if (var1.equals(ObjectSound.field589.username)) {
         return true;
      } else {
         return this.friendsList.method5745(var1, var2);
      }
   }

   final void method721(String var1) {
      if (var1 != null) {
         Username var2 = new Username(var1, this.loginType);
         if (var2.hasCleanName()) {
            if (this.method722()) {
               class222.method4626();
            } else if (ObjectSound.field589.username.equals(var2)) {
               MusicPatch.method4733();
            } else if (this.method739(var2, false)) {
               WorldMapSection3.method1172(var1);
            } else if (this.method766(var2)) {
               class6.method183("Please remove " + var1 + " from your ignore list first");
            } else {
               InvDefinition.method4793(var1);
            }
         }
      }
   }

   final boolean method766(Username var1) {
      if (var1 == null) {
         return false;
      } else {
         return this.ignoreList.contains(var1);
      }
   }

   final void method786() {
      for(FriendLoginUpdate var1 = (FriendLoginUpdate)this.friendsList.friendLoginUpdates.method4539(); var1 != null; var1 = (FriendLoginUpdate)this.friendsList.friendLoginUpdates.method4540()) {
         if ((long)var1.time < Tile.method2779() / 1000L - 5L) {
            if (var1.world > 0) {
               Message.set(5, "", var1.username + " has logged in.");
            }

            if (var1.world == 0) {
               Message.set(5, "", var1.username + " has logged out.");
            }

            var1.remove();
         }
      }

   }

   final void method767() {
      this.field383 = 1;
   }

   final boolean method724() {
      return this.ignoreList.isFull() || this.ignoreList.size() >= 100 && Client.field2204 != 1;
   }

   final void removeIgnore(String var1) {
      if (var1 != null) {
         Username var2 = new Username(var1, this.loginType);
         if (var2.hasCleanName()) {
            if (this.ignoreList.removeByUsername(var2)) {
               Client.field2279 = Client.field2271;
               PacketBufferNode var3 = FaceNormal.method2884(ClientPacket.field1864, Client.field2133.isaacCipher);
               var3.packetBuffer.writeByte(AbstractSoundSystem.method1696(var1));
               var3.packetBuffer.writeStringCp1252NullTerminated(var1);
               Client.field2133.method1281(var3);
            }

            GrandExchangeEvent.method1335();
         }
      }
   }

   final void removeFriend(String var1) {
      if (var1 != null) {
         Username var2 = new Username(var1, this.loginType);
         if (var2.hasCleanName()) {
            if (this.friendsList.removeByUsername(var2)) {
               Client.field2279 = Client.field2271;
               PacketBufferNode var3 = FaceNormal.method2884(ClientPacket.field1860, Client.field2133.isaacCipher);
               var3.packetBuffer.writeByte(AbstractSoundSystem.method1696(var1));
               var3.packetBuffer.writeStringCp1252NullTerminated(var1);
               Client.field2133.method1281(var3);
            }

            IndexStoreActionHandler.method4939();
         }
      }
   }

   public static IndexedSprite method726(AbstractIndexCache var0, int var1) {
      byte[] var3 = var0.takeRecordFlat(var1);
      boolean var2;
      if (var3 == null) {
         var2 = false;
      } else {
         TilePaint.method2436(var3);
         var2 = true;
      }

      return !var2 ? null : OverlayDefinition.method5557();
   }

   static void method790(int var0, byte[] var1, IndexStore var2) {
      IndexStoreAction var3 = new IndexStoreAction();
      var3.type = 0;
      var3.key = (long)var0;
      var3.data = var1;
      var3.indexStore = var2;
      NodeDeque var4 = IndexStoreActionHandler.field2946;
      synchronized(IndexStoreActionHandler.field2946) {
         IndexStoreActionHandler.field2946.addFirst(var3);
      }

      Object var9 = IndexStoreActionHandler.field2945;
      synchronized(IndexStoreActionHandler.field2945) {
         if (IndexStoreActionHandler.field2947 == 0) {
            IndexStoreActionHandler.field2949 = new Thread(new IndexStoreActionHandler());
            IndexStoreActionHandler.field2949.setDaemon(true);
            IndexStoreActionHandler.field2949.start();
            IndexStoreActionHandler.field2949.setPriority(5);
         }

         IndexStoreActionHandler.field2947 = 600;
      }
   }

   static final void method761(Widget var0, int var1, int var2, int var3) {
      if (var0.field2686 == null) {
         throw new RuntimeException();
      } else {
         var0.field2686[var1] = var2;
         var0.field2666[var1] = var3;
      }
   }

   static void method789() {
      WorldMapRegion.field1112.clear();
      WorldMapRegion.field1109.clear();
   }

   static final void method791(Actor var0, int var1, int var2, int var3, int var4, int var5) {
      if (var0 != null && var0.isVisible()) {
         if (var0 instanceof Npc) {
            NpcDefinition var6 = ((Npc)var0).definition;
            if (var6.transforms != null) {
               var6 = var6.transform();
            }

            if (var6 == null) {
               return;
            }
         }

         int var75 = Players.field951;
         int[] var7 = Players.field947;
         byte var8 = 0;
         if (var1 < var75 && var0.playerCycle == Client.field2098 && class178.method3304((Player)var0)) {
            Player var9 = (Player)var0;
            if (var1 < var75) {
               WorldMapData2.method343(var0, var0.defaultHeight + 15);
               AbstractFont var10 = (AbstractFont) Client.field2138.get(FontName.field3735);
               byte var11 = 9;
               var10.drawCentered(var9.username.name(), var2 + Client.field2095, var3 + Client.field2346 - var11, 16777215, 0);
               var8 = 18;
            }
         }

         int var76 = -2;
         int var15;
         int var22;
         int var23;
         if (!var0.healthBars.isEmpty()) {
            WorldMapData2.method343(var0, var0.defaultHeight + 15);

            for(HealthBar var87 = (HealthBar)var0.healthBars.last(); var87 != null; var87 = (HealthBar)var0.healthBars.previous()) {
               HealthBarUpdate var77 = var87.get(Client.field2098);
               if (var77 == null) {
                  if (var87.isEmpty()) {
                     var87.remove();
                  }
               } else {
                  HealthBarDefinition var12 = var87.definition;
                  Sprite var13 = var12.getSprite2();
                  Sprite var14 = var12.getSprite1();
                  int var16 = 0;
                  if (var13 != null && var14 != null) {
                     if (var12.widthPadding * 2 < var14.subWidth) {
                        var16 = var12.widthPadding;
                     }

                     var15 = var14.subWidth - var16 * 2;
                  } else {
                     var15 = var12.width;
                  }

                  int var17 = 255;
                  boolean var18 = true;
                  int var19 = Client.field2098 - var77.cycle;
                  int var20 = var15 * var77.health2 / var12.width;
                  int var21;
                  int var92;
                  if (var77.cycleOffset > var19) {
                     var21 = var12.int4 == 0 ? 0 : var12.int4 * (var19 / var12.int4);
                     var22 = var15 * var77.health / var12.width;
                     var92 = var21 * (var20 - var22) / var77.cycleOffset + var22;
                  } else {
                     var92 = var20;
                     var21 = var77.cycleOffset + var12.int5 - var19;
                     if (var12.int3 >= 0) {
                        var17 = (var21 << 8) / (var12.int5 - var12.int3);
                     }
                  }

                  if (var77.health2 > 0 && var92 < 1) {
                     var92 = 1;
                  }

                  if (var13 != null && var14 != null) {
                     if (var92 == var15) {
                        var92 += var16 * 2;
                     } else {
                        var92 += var16;
                     }

                     var21 = var13.subHeight;
                     var76 += var21;
                     var22 = var2 + Client.field2095 - (var15 >> 1);
                     var23 = var3 + Client.field2346 - var76;
                     var22 -= var16;
                     if (var17 >= 0 && var17 < 255) {
                        var13.method6354(var22, var23, var17);
                        Rasterizer2D.method6217(var22, var23, var22 + var92, var21 + var23);
                        var14.method6354(var22, var23, var17);
                     } else {
                        var13.method6348(var22, var23);
                        Rasterizer2D.method6217(var22, var23, var22 + var92, var21 + var23);
                        var14.method6348(var22, var23);
                     }

                     Rasterizer2D.method6243(var2, var3, var2 + var4, var3 + var5);
                     var76 += 2;
                  } else {
                     var76 += 5;
                     if (Client.field2095 > -1) {
                        var21 = var2 + Client.field2095 - (var15 >> 1);
                        var22 = var3 + Client.field2346 - var76;
                        Rasterizer2D.method6223(var21, var22, var92, 5, 65280);
                        Rasterizer2D.method6223(var92 + var21, var22, var15 - var92, 5, 16711680);
                     }

                     var76 += 2;
                  }
               }
            }
         }

         if (var76 == -2) {
            var76 += 7;
         }

         var76 += var8;
         if (var1 < var75) {
            Player var88 = (Player)var0;
            if (var88.isHidden) {
               return;
            }

            if (var88.headIconPk != -1 || var88.headIconPrayer != -1) {
               WorldMapData2.method343(var0, var0.defaultHeight + 15);
               if (Client.field2095 > -1) {
                  if (var88.headIconPk != -1) {
                     var76 += 25;
                     Player.field445[var88.headIconPk].method6348(var2 + Client.field2095 - 12, var3 + Client.field2346 - var76);
                  }

                  if (var88.headIconPrayer != -1) {
                     var76 += 25;
                     UrlRequester.field1586[var88.headIconPrayer].method6348(var2 + Client.field2095 - 12, var3 + Client.field2346 - var76);
                  }
               }
            }

            if (var1 >= 0 && Client.field2106 == 10 && var7[var1] == Client.field2108) {
               WorldMapData2.method343(var0, var0.defaultHeight + 15);
               if (Client.field2095 > -1) {
                  var76 += class21.field229[1].subHeight;
                  class21.field229[1].method6348(var2 + Client.field2095 - 12, var3 + Client.field2346 - var76);
               }
            }
         } else {
            NpcDefinition var89 = ((Npc)var0).definition;
            if (var89.transforms != null) {
               var89 = var89.transform();
            }

            if (var89.headIconPrayer >= 0 && var89.headIconPrayer < UrlRequester.field1586.length) {
               WorldMapData2.method343(var0, var0.defaultHeight + 15);
               if (Client.field2095 > -1) {
                  UrlRequester.field1586[var89.headIconPrayer].method6348(var2 + Client.field2095 - 12, var3 + Client.field2346 - 30);
               }
            }

            if (Client.field2106 == 1 && Client.field2130[var1 - var75] == Client.field2107 && Client.field2098 % 20 < 10) {
               WorldMapData2.method343(var0, var0.defaultHeight + 15);
               if (Client.field2095 > -1) {
                  class21.field229[0].method6348(var2 + Client.field2095 - 12, var3 + Client.field2346 - 28);
               }
            }
         }

         if (var0.overheadText != null && (var1 >= var75 || !var0.field292 && (Client.field2173 == 4 || !var0.isAutoChatting && (Client.field2173 == 0 || Client.field2173 == 3 || Client.field2173 == 1 && ((Player)var0).method811())))) {
            WorldMapData2.method343(var0, var0.defaultHeight);
            if (Client.field2095 > -1 && Client.field2355 < Client.field2174) {
               Client.field2200[Client.field2355] = NetSocket.field1950.stringWidth(var0.overheadText) / 2;
               Client.field2181[Client.field2355] = NetSocket.field1950.ascent;
               Client.field2175[Client.field2355] = Client.field2095;
               Client.field2176[Client.field2355] = Client.field2346;
               Client.field2179[Client.field2355] = var0.overheadTextColor;
               Client.field2180[Client.field2355] = var0.overheadTextEffect;
               Client.field2261[Client.field2355] = var0.overheadTextCyclesRemaining;
               Client.field2182[Client.field2355] = var0.overheadText;
               ++Client.field2355;
            }
         }

         for(int var78 = 0; var78 < 4; ++var78) {
            int var90 = var0.hitSplatCycles[var78];
            int var79 = var0.hitSplatTypes[var78];
            HitSplatDefinition var91 = null;
            int var80 = 0;
            if (var79 >= 0) {
               if (var90 <= Client.field2098) {
                  continue;
               }

               var91 = class222.method4627(var0.hitSplatTypes[var78]);
               var80 = var91.field3356;
               if (var91 != null && var91.transforms != null) {
                  var91 = var91.transform();
                  if (var91 == null) {
                     var0.hitSplatCycles[var78] = -1;
                     continue;
                  }
               }
            } else if (var90 < 0) {
               continue;
            }

            var15 = var0.hitSplatTypes2[var78];
            HitSplatDefinition var81 = null;
            if (var15 >= 0) {
               var81 = class222.method4627(var15);
               if (var81 != null && var81.transforms != null) {
                  var81 = var81.transform();
               }
            }

            if (var90 - var80 <= Client.field2098) {
               if (var91 == null) {
                  var0.hitSplatCycles[var78] = -1;
               } else {
                  WorldMapData2.method343(var0, var0.defaultHeight / 2);
                  if (Client.field2095 > -1) {
                     if (var78 == 1) {
                        Client.field2346 -= 20;
                     }

                     if (var78 == 2) {
                        Client.field2095 -= 15;
                        Client.field2346 -= 10;
                     }

                     if (var78 == 3) {
                        Client.field2095 += 15;
                        Client.field2346 -= 10;
                     }

                     Sprite var82 = null;
                     Sprite var83 = null;
                     Sprite var84 = null;
                     Sprite var85 = null;
                     var22 = 0;
                     var23 = 0;
                     int var24 = 0;
                     int var25 = 0;
                     int var26 = 0;
                     int var27 = 0;
                     int var28 = 0;
                     int var29 = 0;
                     Sprite var30 = null;
                     Sprite var31 = null;
                     Sprite var32 = null;
                     Sprite var33 = null;
                     int var34 = 0;
                     int var35 = 0;
                     int var36 = 0;
                     int var37 = 0;
                     int var38 = 0;
                     int var39 = 0;
                     int var40 = 0;
                     int var41 = 0;
                     int var42 = 0;
                     var82 = var91.method5140();
                     int var43;
                     if (var82 != null) {
                        var22 = var82.subWidth;
                        var43 = var82.subHeight;
                        if (var43 > var42) {
                           var42 = var43;
                        }

                        var26 = var82.yOffset;
                     }

                     var83 = var91.method5110();
                     if (var83 != null) {
                        var23 = var83.subWidth;
                        var43 = var83.subHeight;
                        if (var43 > var42) {
                           var42 = var43;
                        }

                        var27 = var83.yOffset;
                     }

                     var84 = var91.method5117();
                     if (var84 != null) {
                        var24 = var84.subWidth;
                        var43 = var84.subHeight;
                        if (var43 > var42) {
                           var42 = var43;
                        }

                        var28 = var84.yOffset;
                     }

                     var85 = var91.method5115();
                     if (var85 != null) {
                        var25 = var85.subWidth;
                        var43 = var85.subHeight;
                        if (var43 > var42) {
                           var42 = var43;
                        }

                        var29 = var85.yOffset;
                     }

                     if (var81 != null) {
                        var30 = var81.method5140();
                        if (var30 != null) {
                           var34 = var30.subWidth;
                           var43 = var30.subHeight;
                           if (var43 > var42) {
                              var42 = var43;
                           }

                           var38 = var30.yOffset;
                        }

                        var31 = var81.method5110();
                        if (var31 != null) {
                           var35 = var31.subWidth;
                           var43 = var31.subHeight;
                           if (var43 > var42) {
                              var42 = var43;
                           }

                           var39 = var31.yOffset;
                        }

                        var32 = var81.method5117();
                        if (var32 != null) {
                           var36 = var32.subWidth;
                           var43 = var32.subHeight;
                           if (var43 > var42) {
                              var42 = var43;
                           }

                           var40 = var32.yOffset;
                        }

                        var33 = var81.method5115();
                        if (var33 != null) {
                           var37 = var33.subWidth;
                           var43 = var33.subHeight;
                           if (var43 > var42) {
                              var42 = var43;
                           }

                           var41 = var33.yOffset;
                        }
                     }

                     Font var86 = var91.getFont();
                     if (var86 == null) {
                        var86 = WorldMapSection3.field625;
                     }

                     Font var44;
                     if (var81 != null) {
                        var44 = var81.getFont();
                        if (var44 == null) {
                           var44 = WorldMapSection3.field625;
                        }
                     } else {
                        var44 = WorldMapSection3.field625;
                     }

                     String var45 = null;
                     String var46 = null;
                     boolean var47 = false;
                     int var48 = 0;
                     var45 = var91.getString(var0.hitSplatValues[var78]);
                     int var93 = var86.stringWidth(var45);
                     if (var81 != null) {
                        var46 = var81.getString(var0.hitSplatValues2[var78]);
                        var48 = var44.stringWidth(var46);
                     }

                     int var49 = 0;
                     int var50 = 0;
                     if (var23 > 0) {
                        if (var84 == null && var85 == null) {
                           var49 = 1;
                        } else {
                           var49 = var93 / var23 + 1;
                        }
                     }

                     if (var81 != null && var35 > 0) {
                        if (var32 == null && var33 == null) {
                           var50 = 1;
                        } else {
                           var50 = var48 / var35 + 1;
                        }
                     }

                     int var51 = 0;
                     int var52 = var51;
                     if (var22 > 0) {
                        var51 += var22;
                     }

                     var51 += 2;
                     int var53 = var51;
                     if (var24 > 0) {
                        var51 += var24;
                     }

                     int var54 = var51;
                     int var55 = var51;
                     int var56;
                     if (var23 > 0) {
                        var56 = var49 * var23;
                        var51 += var56;
                        var55 += (var56 - var93) / 2;
                     } else {
                        var51 += var93;
                     }

                     var56 = var51;
                     if (var25 > 0) {
                        var51 += var25;
                     }

                     int var57 = 0;
                     int var58 = 0;
                     int var59 = 0;
                     int var60 = 0;
                     int var61 = 0;
                     int var62;
                     if (var81 != null) {
                        var51 += 2;
                        var57 = var51;
                        if (var34 > 0) {
                           var51 += var34;
                        }

                        var51 += 2;
                        var58 = var51;
                        if (var36 > 0) {
                           var51 += var36;
                        }

                        var59 = var51;
                        var61 = var51;
                        if (var35 > 0) {
                           var62 = var50 * var35;
                           var51 += var62;
                           var61 += (var62 - var48) / 2;
                        } else {
                           var51 += var48;
                        }

                        var60 = var51;
                        if (var37 > 0) {
                           var51 += var37;
                        }
                     }

                     var62 = var0.hitSplatCycles[var78] - Client.field2098;
                     int var63 = var91.field3369 - var62 * var91.field3369 / var91.field3356;
                     int var64 = var62 * var91.field3359 / var91.field3356 + -var91.field3359;
                     int var65 = var63 + (var2 + Client.field2095 - (var51 >> 1));
                     int var66 = var64 + (var3 + Client.field2346 - 12);
                     int var67 = var66;
                     int var68 = var66 + var42;
                     int var69 = var66 + var91.field3374 + 15;
                     int var70 = var69 - var86.maxAscent;
                     int var71 = var69 + var86.maxDescent;
                     if (var70 < var66) {
                        var67 = var70;
                     }

                     if (var71 > var68) {
                        var68 = var71;
                     }

                     int var72 = 0;
                     int var73;
                     int var74;
                     if (var81 != null) {
                        var72 = var66 + var81.field3374 + 15;
                        var73 = var72 - var44.maxAscent;
                        var74 = var72 + var44.maxDescent;
                        if (var73 < var67) {
                           ;
                        }

                        if (var74 > var68) {
                           ;
                        }
                     }

                     var73 = 255;
                     if (var91.field3370 >= 0) {
                        var73 = (var62 << 8) / (var91.field3356 - var91.field3370);
                     }

                     if (var73 >= 0 && var73 < 255) {
                        if (var82 != null) {
                           var82.method6354(var52 + var65 - var26, var66, var73);
                        }

                        if (var84 != null) {
                           var84.method6354(var53 + var65 - var28, var66, var73);
                        }

                        if (var83 != null) {
                           for(var74 = 0; var74 < var49; ++var74) {
                              var83.method6354(var74 * var23 + (var65 + var54 - var27), var66, var73);
                           }
                        }

                        if (var85 != null) {
                           var85.method6354(var65 + var56 - var29, var66, var73);
                        }

                        var86.drawAlpha(var45, var65 + var55, var69, var91.field3363, 0, var73);
                        if (var81 != null) {
                           if (var30 != null) {
                              var30.method6354(var57 + var65 - var38, var66, var73);
                           }

                           if (var32 != null) {
                              var32.method6354(var58 + var65 - var40, var66, var73);
                           }

                           if (var31 != null) {
                              for(var74 = 0; var74 < var50; ++var74) {
                                 var31.method6354(var74 * var35 + (var59 + var65 - var39), var66, var73);
                              }
                           }

                           if (var33 != null) {
                              var33.method6354(var60 + var65 - var41, var66, var73);
                           }

                           var44.drawAlpha(var46, var61 + var65, var72, var81.field3363, 0, var73);
                        }
                     } else {
                        if (var82 != null) {
                           var82.method6348(var52 + var65 - var26, var66);
                        }

                        if (var84 != null) {
                           var84.method6348(var53 + var65 - var28, var66);
                        }

                        if (var83 != null) {
                           for(var74 = 0; var74 < var49; ++var74) {
                              var83.method6348(var74 * var23 + (var54 + var65 - var27), var66);
                           }
                        }

                        if (var85 != null) {
                           var85.method6348(var56 + var65 - var29, var66);
                        }

                        var86.draw(var45, var55 + var65, var69, var91.field3363 | -16777216, 0);
                        if (var81 != null) {
                           if (var30 != null) {
                              var30.method6348(var57 + var65 - var38, var66);
                           }

                           if (var32 != null) {
                              var32.method6348(var58 + var65 - var40, var66);
                           }

                           if (var31 != null) {
                              for(var74 = 0; var74 < var50; ++var74) {
                                 var31.method6348(var74 * var35 + (var65 + var59 - var39), var66);
                              }
                           }

                           if (var33 != null) {
                              var33.method6348(var65 + var60 - var41, var66);
                           }

                           var44.draw(var46, var65 + var61, var72, var81.field3363 | -16777216, 0);
                        }
                     }
                  }
               }
            }
         }

      }
   }
}
