public class VarcString extends DualNode {
   static AbstractIndexCache field2914;
   static EvictingDualNodeHashTable field2913 = new EvictingDualNodeHashTable(64);
   public boolean persist = false;

   void method4898(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.method4896(var1, var2);
      }
   }

   void method4896(Buffer var1, int var2) {
      if (var2 == 2) {
         this.persist = true;
      }

   }

   static boolean method4905(int var0) {
      return var0 == 57 || var0 == 58 || var0 == 1007 || var0 == 25 || var0 == 30;
   }
}
