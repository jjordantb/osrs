import java.math.BigInteger;

public class class39 {
   static final BigInteger field482 = new BigInteger("80782894952180643741752986186714059433953886149239752893425047584684715842049");
   static final BigInteger field487 = new BigInteger("7237300117305667488707183861728052766358166655052137727439795191253340127955075499635575104901523446809299097934591732635674173519120047404024393881551683");
   static int field491;

   static int method980(int var0, Script var1, boolean var2) {
      if (var0 == 5630) {
         Client.field2168 = 250;
         return 1;
      } else {
         return 2;
      }
   }

   public static String method982(CharSequence var0) {
      int var1 = var0.length();
      StringBuilder var2 = new StringBuilder(var1);

      for(int var3 = 0; var3 < var1; ++var3) {
         char var4 = var0.charAt(var3);
         if ((var4 < 'a' || var4 > 'z') && (var4 < 'A' || var4 > 'Z') && (var4 < '0' || var4 > '9') && var4 != '.' && var4 != '-' && var4 != '*' && var4 != '_') {
            if (var4 == ' ') {
               var2.append('+');
            } else {
               byte var5 = FaceNormal.method2883(var4);
               var2.append('%');
               int var6 = var5 >> 4 & 15;
               if (var6 >= 10) {
                  var2.append((char)(var6 + 55));
               } else {
                  var2.append((char)(var6 + 48));
               }

               var6 = var5 & 15;
               if (var6 >= 10) {
                  var2.append((char)(var6 + 55));
               } else {
                  var2.append((char)(var6 + 48));
               }
            }
         } else {
            var2.append(var4);
         }
      }

      return var2.toString();
   }

   static final void method973() {
      Client.field2133.close();
      TilePaint.method2437();
      class243.field2904.clear();

      for(int var0 = 0; var0 < 4; ++var0) {
         Client.field2144[var0].method3182();
      }

      System.gc();
      class165.method3136(2);
      Client.field2321 = -1;
      Client.field2322 = false;
      class130.method2825();
      class69.method1443(10);
   }

   static void method979(boolean var0) {
      Client.field2233 = var0;
   }

   static final int method970(Widget var0, int var1) {
      if (var0.cs1Instructions != null && var1 < var0.cs1Instructions.length) {
         try {
            int[] var2 = var0.cs1Instructions[var1];
            int var3 = 0;
            int var4 = 0;
            byte var5 = 0;

            while(true) {
               int var6 = var2[var4++];
               int var7 = 0;
               byte var8 = 0;
               if (var6 == 0) {
                  return var3;
               }

               if (var6 == 1) {
                  var7 = Client.field2218[var2[var4++]];
               }

               if (var6 == 2) {
                  var7 = Client.field2219[var2[var4++]];
               }

               if (var6 == 3) {
                  var7 = Client.field2220[var2[var4++]];
               }

               int var9;
               Widget var10;
               int var11;
               int var12;
               if (var6 == 4) {
                  var9 = var2[var4++] << 16;
                  var9 += var2[var4++];
                  var10 = WorldMapSection3.method1148(var9);
                  var11 = var2[var4++];
                  if (var11 != -1 && (!Varcs.getItemDefinition(var11).isMembersOnly || Client.field2090)) {
                     for(var12 = 0; var12 < var10.itemIds.length; ++var12) {
                        if (var11 + 1 == var10.itemIds[var12]) {
                           var7 += var10.itemQuantities[var12];
                        }
                     }
                  }
               }

               if (var6 == 5) {
                  var7 = Varps.field2762[var2[var4++]];
               }

               if (var6 == 6) {
                  var7 = Skills.field3312[Client.field2219[var2[var4++]] - 1];
               }

               if (var6 == 7) {
                  var7 = Varps.field2762[var2[var4++]] * 100 / '뜛';
               }

               if (var6 == 8) {
                  var7 = ObjectSound.field589.combatLevel;
               }

               if (var6 == 9) {
                  for(var9 = 0; var9 < 25; ++var9) {
                     if (Skills.field3310[var9]) {
                        var7 += Client.field2219[var9];
                     }
                  }
               }

               if (var6 == 10) {
                  var9 = var2[var4++] << 16;
                  var9 += var2[var4++];
                  var10 = WorldMapSection3.method1148(var9);
                  var11 = var2[var4++];
                  if (var11 != -1 && (!Varcs.getItemDefinition(var11).isMembersOnly || Client.field2090)) {
                     for(var12 = 0; var12 < var10.itemIds.length; ++var12) {
                        if (var11 + 1 == var10.itemIds[var12]) {
                           var7 = 999999999;
                           break;
                        }
                     }
                  }
               }

               if (var6 == 11) {
                  var7 = Client.field2253;
               }

               if (var6 == 12) {
                  var7 = Client.field2294;
               }

               if (var6 == 13) {
                  var9 = Varps.field2762[var2[var4++]];
                  int var13 = var2[var4++];
                  var7 = (var9 & 1 << var13) != 0 ? 1 : 0;
               }

               if (var6 == 14) {
                  var9 = var2[var4++];
                  var7 = AbstractSoundSystem.method1697(var9);
               }

               if (var6 == 15) {
                  var8 = 1;
               }

               if (var6 == 16) {
                  var8 = 2;
               }

               if (var6 == 17) {
                  var8 = 3;
               }

               if (var6 == 18) {
                  var7 = (ObjectSound.field589.x >> 7) + class21.field230;
               }

               if (var6 == 19) {
                  var7 = (ObjectSound.field589.y >> 7) + class79.field902;
               }

               if (var6 == 20) {
                  var7 = var2[var4++];
               }

               if (var8 == 0) {
                  if (var5 == 0) {
                     var3 += var7;
                  }

                  if (var5 == 1) {
                     var3 -= var7;
                  }

                  if (var5 == 2 && var7 != 0) {
                     var3 /= var7;
                  }

                  if (var5 == 3) {
                     var3 *= var7;
                  }

                  var5 = 0;
               } else {
                  var5 = var8;
               }
            }
         } catch (Exception var14) {
            return -1;
         }
      } else {
         return -2;
      }
   }
}
