public class class158 {
   public static final class158 field1740 = new class158(2);
   public static final class158 field1738 = new class158(4);
   public static final class158 field1736 = new class158(14);
   public static final class158 field1741 = new class158(7);
   public static final class158 field1743 = new class158(4);
   public static final class158 field1739 = new class158(5);
   public static final class158 field1747 = new class158(5);
   public static final class158 field1737 = new class158(6);
   public static final class158 field1734 = new class158(15);
   public static final class158 field1735 = new class158(3);

   class158(int var1) {
   }
}
