import java.awt.Component;
import java.awt.Graphics;

public final class Canvas extends java.awt.Canvas {
   static int field122;
   static IndexCache field118;
   Component component;

   Canvas(Component var1) {
      this.component = var1;
   }

   public final void update(Graphics var1) {
      this.component.update(var1);
   }

   public final void paint(Graphics var1) {
      this.component.paint(var1);
   }

   static int method363(int var0, Script var1, boolean var2) {
      Widget var3 = WorldMapSection3.method1148(Interpreter.field467[--class31.field364]);
      if (var0 == 2800) {
         Interpreter.field467[++class31.field364 - 1] = class71.method1463(class257.method5068(var3));
         return 1;
      } else if (var0 != 2801) {
         if (var0 == 2802) {
            if (var3.dataText == null) {
               Interpreter.field462[++Interpreter.field469 - 1] = "";
            } else {
               Interpreter.field462[++Interpreter.field469 - 1] = var3.dataText;
            }

            return 1;
         } else {
            return 2;
         }
      } else {
         int var4 = Interpreter.field467[--class31.field364];
         --var4;
         if (var3.actions != null && var4 < var3.actions.length && var3.actions[var4] != null) {
            Interpreter.field462[++Interpreter.field469 - 1] = var3.actions[var4];
         } else {
            Interpreter.field462[++Interpreter.field469 - 1] = "";
         }

         return 1;
      }
   }

   static final int method362(int var0, int var1) {
      if (var0 == -2) {
         return 12345678;
      } else if (var0 == -1) {
         if (var1 < 2) {
            var1 = 2;
         } else if (var1 > 126) {
            var1 = 126;
         }

         return var1;
      } else {
         var1 = (var0 & 127) * var1 / 128;
         if (var1 < 2) {
            var1 = 2;
         } else if (var1 > 126) {
            var1 = 126;
         }

         return (var0 & 'ﾀ') + var1;
      }
   }

   static final void method360() {
      PacketBufferNode var0 = FaceNormal.method2884(ClientPacket.field1856, Client.field2133.isaacCipher);
      Client.field2133.method1281(var0);

      for(WidgetGroupParent var1 = (WidgetGroupParent) Client.field2247.first(); var1 != null; var1 = (WidgetGroupParent) Client.field2247.next()) {
         if (var1.type == 0 || var1.type == 3) {
            class57.method1213(var1, true);
         }
      }

      if (Client.field2323 != null) {
         WorldMapSection1.method506(Client.field2323);
         Client.field2323 = null;
      }

   }

   static boolean method361(Widget var0) {
      return var0.isHidden;
   }
}
