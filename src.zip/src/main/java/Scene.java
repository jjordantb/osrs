public class Scene {
   public static int field1180 = -1;
   static boolean field1195 = false;
   static int[] field1224;
   static GameObject[] field1226 = new GameObject[100];
   static int field1164;
   static int field1190 = 0;
   static final int[] field1171;
   static int field1204 = 4;
   static int field1197 = 0;
   static int field1184;
   static Occluder[][] field1198;
   static NodeDeque field1209;
   static int field1191;
   static Occluder[] field1169;
   static final int[] field1212;
   static final int[] field1183;
   public static int field1200 = -1;
   static boolean field1201 = false;
   static final int[] field1214;
   static final int[] field1213;
   static int field1193;
   static int field1192;
   static final int[] field1210;
   static int field1196 = 0;
   static int field1168;
   static int field1228;
   static int field1230;
   static boolean[][] field1215;
   static int field1229;
   static int field1225;
   static int field1199;
   static final int[] field1216;
   static boolean[][][][] field1223;
   static int field1218;
   static int field1181;
   public static boolean field1172 = true;
   static int field1211;
   static int field1227;
   static int field1189;
   static int field1186;
   static int field1185;
   static int field1188;
   static int field1179 = 0;
   static int field1178 = 0;
   static int field1187;
   static int field1207;
   int[][] field1222 = new int[][]{{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}, {12, 8, 4, 0, 13, 9, 5, 1, 14, 10, 6, 2, 15, 11, 7, 3}, {15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0}, {3, 7, 11, 15, 2, 6, 10, 14, 1, 5, 9, 13, 0, 4, 8, 12}};
   int[][] field1166 = new int[][]{{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, {1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1}, {1, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1}, {0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, {1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1}, {1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0}, {1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1}, {1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1}};
   int minPlane = 0;
   int[][][] tileHeights;
   int xSize;
   int[][][] field1206;
   Tile[][][] tiles;
   GameObject[] tempGameObjects = new GameObject[5000];
   int ySize;
   int planes;
   int tempGameObjectsCount = 0;

   static {
      field1224 = new int[field1204];
      field1198 = new Occluder[field1204][500];
      field1184 = 0;
      field1169 = new Occluder[500];
      field1209 = new NodeDeque();
      field1210 = new int[]{19, 55, 38, 155, 255, 110, 137, 205, 76};
      field1171 = new int[]{160, 192, 80, 96, 0, 144, 80, 48, 160};
      field1212 = new int[]{76, 8, 137, 4, 0, 1, 38, 2, 19};
      field1213 = new int[]{0, 0, 2, 0, 0, 2, 1, 1, 0};
      field1214 = new int[]{2, 0, 0, 2, 0, 0, 0, 4, 4};
      field1183 = new int[]{0, 4, 4, 8, 0, 0, 8, 0, 0};
      field1216 = new int[]{1, 1, 0, 0, 0, 8, 0, 0, 8};
      field1223 = new boolean[8][32][51][51];
   }

   public Scene(int var1, int var2, int var3, int[][][] var4) {
      this.planes = var1;
      this.xSize = var2;
      this.ySize = var3;
      this.tiles = new Tile[var1][var2][var3];
      this.field1206 = new int[var1][var2 + 1][var3 + 1];
      this.tileHeights = var4;
      this.clear();
   }

   public void drawTileMinimap(int[] var1, int var2, int var3, int var4, int var5, int var6) {
      Tile var7 = this.tiles[var4][var5][var6];
      if (var7 != null) {
         TilePaint var8 = var7.paint;
         int var10;
         if (var8 != null) {
            int var9 = var8.rgb;
            if (var9 != 0) {
               for(var10 = 0; var10 < 4; ++var10) {
                  var1[var2] = var9;
                  var1[var2 + 1] = var9;
                  var1[var2 + 2] = var9;
                  var1[var2 + 3] = var9;
                  var2 += var3;
               }

            }
         } else {
            TileModel var18 = var7.model;
            if (var18 != null) {
               var10 = var18.shape;
               int var11 = var18.rotation;
               int var12 = var18.underlayRgb;
               int var13 = var18.overlayRgb;
               int[] var14 = this.field1166[var10];
               int[] var15 = this.field1222[var11];
               int var16 = 0;
               int var17;
               if (var12 != 0) {
                  for(var17 = 0; var17 < 4; ++var17) {
                     var1[var2] = var14[var15[var16++]] == 0 ? var12 : var13;
                     var1[var2 + 1] = var14[var15[var16++]] == 0 ? var12 : var13;
                     var1[var2 + 2] = var14[var15[var16++]] == 0 ? var12 : var13;
                     var1[var2 + 3] = var14[var15[var16++]] == 0 ? var12 : var13;
                     var2 += var3;
                  }
               } else {
                  for(var17 = 0; var17 < 4; ++var17) {
                     if (var14[var15[var16++]] != 0) {
                        var1[var2] = var13;
                     }

                     if (var14[var15[var16++]] != 0) {
                        var1[var2 + 1] = var13;
                     }

                     if (var14[var15[var16++]] != 0) {
                        var1[var2 + 2] = var13;
                     }

                     if (var14[var15[var16++]] != 0) {
                        var1[var2 + 3] = var13;
                     }

                     var2 += var3;
                  }
               }

            }
         }
      }
   }

   public int getObjectFlags(int var1, int var2, int var3, long var4) {
      Tile var6 = this.tiles[var1][var2][var3];
      if (var6 == null) {
         return -1;
      } else if (var6.boundaryObject != null && var6.boundaryObject.tag == var4) {
         return var6.boundaryObject.flags & 255;
      } else if (var6.wallDecoration != null && var6.wallDecoration.tag == var4) {
         return var6.wallDecoration.flags & 255;
      } else if (var6.floorDecoration != null && var6.floorDecoration.tag == var4) {
         return var6.floorDecoration.flags & 255;
      } else {
         for(int var7 = 0; var7 < var6.gameObjectsCount; ++var7) {
            if (var6.gameObjects[var7].tag == var4) {
               return var6.gameObjects[var7].flags & 255;
            }
         }

         return -1;
      }
   }

   public long method2251(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      return var4 != null && var4.boundaryObject != null ? var4.boundaryObject.tag : 0L;
   }

   public FloorDecoration getFloorDecoration(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      return var4 != null && var4.floorDecoration != null ? var4.floorDecoration : null;
   }

   public void removeGroundItemPile(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      if (var4 != null) {
         var4.groundItemPile = null;
      }
   }

   public long getFloorDecorationTag(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      return var4 != null && var4.floorDecoration != null ? var4.floorDecoration.tag : 0L;
   }

   void drawTile(Tile var1, boolean var2) {
      field1209.addFirst(var1);

      while(true) {
         Tile var3;
         int var4;
         int var5;
         int var6;
         int var7;
         Tile[][] var8;
         Tile var9;
         int var11;
         int var14;
         int var15;
         int var16;
         int var24;
         int var25;
         do {
            do {
               do {
                  do {
                     do {
                        do {
                           while(true) {
                              BoundaryObject var10;
                              GameObject var12;
                              int var17;
                              int var18;
                              boolean var20;
                              int var21;
                              Tile var36;
                              while(true) {
                                 do {
                                    var3 = (Tile)field1209.removeLast();
                                    if (var3 == null) {
                                       return;
                                    }
                                 } while(!var3.drawSecondary);

                                 var4 = var3.x;
                                 var5 = var3.y;
                                 var6 = var3.plane;
                                 var7 = var3.originalPlane;
                                 var8 = this.tiles[var6];
                                 if (!var3.drawPrimary) {
                                    break;
                                 }

                                 if (var2) {
                                    if (var6 > 0) {
                                       var9 = this.tiles[var6 - 1][var4][var5];
                                       if (var9 != null && var9.drawSecondary) {
                                          continue;
                                       }
                                    }

                                    if (var4 <= field1207 && var4 > field1181) {
                                       var9 = var8[var4 - 1][var5];
                                       if (var9 != null && var9.drawSecondary && (var9.drawPrimary || (var3.gameObjectsEdgeMask & 1) == 0)) {
                                          continue;
                                       }
                                    }

                                    if (var4 >= field1207 && var4 < field1218 - 1) {
                                       var9 = var8[var4 + 1][var5];
                                       if (var9 != null && var9.drawSecondary && (var9.drawPrimary || (var3.gameObjectsEdgeMask & 4) == 0)) {
                                          continue;
                                       }
                                    }

                                    if (var5 <= field1186 && var5 > field1185) {
                                       var9 = var8[var4][var5 - 1];
                                       if (var9 != null && var9.drawSecondary && (var9.drawPrimary || (var3.gameObjectsEdgeMask & 8) == 0)) {
                                          continue;
                                       }
                                    }

                                    if (var5 >= field1186 && var5 < field1227 - 1) {
                                       var9 = var8[var4][var5 + 1];
                                       if (var9 != null && var9.drawSecondary && (var9.drawPrimary || (var3.gameObjectsEdgeMask & 2) == 0)) {
                                          continue;
                                       }
                                    }
                                 } else {
                                    var2 = true;
                                 }

                                 var3.drawPrimary = false;
                                 if (var3.linkedBelowTile != null) {
                                    var9 = var3.linkedBelowTile;
                                    if (var9.paint != null) {
                                       if (!this.method2321(0, var4, var5)) {
                                          this.method2268(var9.paint, 0, field1164, field1191, field1192, field1193, var4, var5);
                                       }
                                    } else if (var9.model != null && !this.method2321(0, var4, var5)) {
                                       this.method2269(var9.model, field1164, field1191, field1192, field1193, var4, var5);
                                    }

                                    var10 = var9.boundaryObject;
                                    if (var10 != null) {
                                       var10.entity1.draw(0, field1164, field1191, field1192, field1193, var10.x - field1187, var10.tileHeight - field1188, var10.y - field1189, var10.tag);
                                    }

                                    for(var11 = 0; var11 < var9.gameObjectsCount; ++var11) {
                                       var12 = var9.gameObjects[var11];
                                       if (var12 != null) {
                                          var12.entity.draw(var12.orientation, field1164, field1191, field1192, field1193, var12.centerX - field1187, var12.height - field1188, var12.centerY - field1189, var12.tag);
                                       }
                                    }
                                 }

                                 var20 = false;
                                 if (var3.paint != null) {
                                    if (!this.method2321(var7, var4, var5)) {
                                       var20 = true;
                                       if (var3.paint.neColor != 12345678 || field1195 && var6 <= field1196) {
                                          this.method2268(var3.paint, var7, field1164, field1191, field1192, field1193, var4, var5);
                                       }
                                    }
                                 } else if (var3.model != null && !this.method2321(var7, var4, var5)) {
                                    var20 = true;
                                    this.method2269(var3.model, field1164, field1191, field1192, field1193, var4, var5);
                                 }

                                 var21 = 0;
                                 var11 = 0;
                                 BoundaryObject var31 = var3.boundaryObject;
                                 WallDecoration var13 = var3.wallDecoration;
                                 if (var31 != null || var13 != null) {
                                    if (var4 == field1207) {
                                       ++var21;
                                    } else if (field1207 < var4) {
                                       var21 += 2;
                                    }

                                    if (var5 == field1186) {
                                       var21 += 3;
                                    } else if (field1186 > var5) {
                                       var21 += 6;
                                    }

                                    var11 = field1210[var21];
                                    var3.field1536 = field1212[var21];
                                 }

                                 if (var31 != null) {
                                    if ((var31.orientationA & field1171[var21]) != 0) {
                                       if (var31.orientationA == 16) {
                                          var3.drawGameObjectEdges = 3;
                                          var3.field1534 = field1213[var21];
                                          var3.field1515 = 3 - var3.field1534;
                                       } else if (var31.orientationA == 32) {
                                          var3.drawGameObjectEdges = 6;
                                          var3.field1534 = field1214[var21];
                                          var3.field1515 = 6 - var3.field1534;
                                       } else if (var31.orientationA == 64) {
                                          var3.drawGameObjectEdges = 12;
                                          var3.field1534 = field1183[var21];
                                          var3.field1515 = 12 - var3.field1534;
                                       } else {
                                          var3.drawGameObjectEdges = 9;
                                          var3.field1534 = field1216[var21];
                                          var3.field1515 = 9 - var3.field1534;
                                       }
                                    } else {
                                       var3.drawGameObjectEdges = 0;
                                    }

                                    if ((var31.orientationA & var11) != 0 && !this.method2264(var7, var4, var5, var31.orientationA)) {
                                       var31.entity1.draw(0, field1164, field1191, field1192, field1193, var31.x - field1187, var31.tileHeight - field1188, var31.y - field1189, var31.tag);
                                    }

                                    if ((var31.orientationB & var11) != 0 && !this.method2264(var7, var4, var5, var31.orientationB)) {
                                       var31.entity2.draw(0, field1164, field1191, field1192, field1193, var31.x - field1187, var31.tileHeight - field1188, var31.y - field1189, var31.tag);
                                    }
                                 }

                                 if (var13 != null && !this.method2284(var7, var4, var5, var13.entity1.height)) {
                                    if ((var13.orientation & var11) != 0) {
                                       var13.entity1.draw(0, field1164, field1191, field1192, field1193, var13.x - field1187 + var13.xOffset, var13.tileHeight - field1188, var13.y - field1189 + var13.yOffset, var13.tag);
                                    } else if (var13.orientation == 256) {
                                       var14 = var13.x - field1187;
                                       var15 = var13.tileHeight - field1188;
                                       var16 = var13.y - field1189;
                                       var17 = var13.int7;
                                       if (var17 != 1 && var17 != 2) {
                                          var18 = var14;
                                       } else {
                                          var18 = -var14;
                                       }

                                       int var19;
                                       if (var17 != 2 && var17 != 3) {
                                          var19 = var16;
                                       } else {
                                          var19 = -var16;
                                       }

                                       if (var19 < var18) {
                                          var13.entity1.draw(0, field1164, field1191, field1192, field1193, var14 + var13.xOffset, var15, var16 + var13.yOffset, var13.tag);
                                       } else if (var13.entity2 != null) {
                                          var13.entity2.draw(0, field1164, field1191, field1192, field1193, var14, var15, var16, var13.tag);
                                       }
                                    }
                                 }

                                 if (var20) {
                                    FloorDecoration var22 = var3.floorDecoration;
                                    if (var22 != null) {
                                       var22.entity.draw(0, field1164, field1191, field1192, field1193, var22.x - field1187, var22.tileHeight - field1188, var22.y - field1189, var22.tag);
                                    }

                                    GroundItemPile var23 = var3.groundItemPile;
                                    if (var23 != null && var23.height == 0) {
                                       if (var23.second != null) {
                                          var23.second.draw(0, field1164, field1191, field1192, field1193, var23.x - field1187, var23.tileHeight - field1188, var23.y - field1189, var23.tag);
                                       }

                                       if (var23.third != null) {
                                          var23.third.draw(0, field1164, field1191, field1192, field1193, var23.x - field1187, var23.tileHeight - field1188, var23.y - field1189, var23.tag);
                                       }

                                       if (var23.first != null) {
                                          var23.first.draw(0, field1164, field1191, field1192, field1193, var23.x - field1187, var23.tileHeight - field1188, var23.y - field1189, var23.tag);
                                       }
                                    }
                                 }

                                 var14 = var3.gameObjectsEdgeMask;
                                 if (var14 != 0) {
                                    if (var4 < field1207 && (var14 & 4) != 0) {
                                       var36 = var8[var4 + 1][var5];
                                       if (var36 != null && var36.drawSecondary) {
                                          field1209.addFirst(var36);
                                       }
                                    }

                                    if (var5 < field1186 && (var14 & 2) != 0) {
                                       var36 = var8[var4][var5 + 1];
                                       if (var36 != null && var36.drawSecondary) {
                                          field1209.addFirst(var36);
                                       }
                                    }

                                    if (var4 > field1207 && (var14 & 1) != 0) {
                                       var36 = var8[var4 - 1][var5];
                                       if (var36 != null && var36.drawSecondary) {
                                          field1209.addFirst(var36);
                                       }
                                    }

                                    if (var5 > field1186 && (var14 & 8) != 0) {
                                       var36 = var8[var4][var5 - 1];
                                       if (var36 != null && var36.drawSecondary) {
                                          field1209.addFirst(var36);
                                       }
                                    }
                                 }
                                 break;
                              }

                              if (var3.drawGameObjectEdges != 0) {
                                 var20 = true;

                                 for(var21 = 0; var21 < var3.gameObjectsCount; ++var21) {
                                    if (var3.gameObjects[var21].lastDrawn != field1211 && (var3.gameObjectEdgeMasks[var21] & var3.drawGameObjectEdges) == var3.field1534) {
                                       var20 = false;
                                       break;
                                    }
                                 }

                                 if (var20) {
                                    var10 = var3.boundaryObject;
                                    if (!this.method2264(var7, var4, var5, var10.orientationA)) {
                                       var10.entity1.draw(0, field1164, field1191, field1192, field1193, var10.x - field1187, var10.tileHeight - field1188, var10.y - field1189, var10.tag);
                                    }

                                    var3.drawGameObjectEdges = 0;
                                 }
                              }

                              if (!var3.drawGameObjects) {
                                 break;
                              }

                              try {
                                 int var34 = var3.gameObjectsCount;
                                 var3.drawGameObjects = false;
                                 var21 = 0;

                                 label563:
                                 for(var11 = 0; var11 < var34; ++var11) {
                                    var12 = var3.gameObjects[var11];
                                    if (var12.lastDrawn != field1211) {
                                       for(var24 = var12.startX; var24 <= var12.endX; ++var24) {
                                          for(var14 = var12.startY; var14 <= var12.endY; ++var14) {
                                             var36 = var8[var24][var14];
                                             if (var36.drawPrimary) {
                                                var3.drawGameObjects = true;
                                                continue label563;
                                             }

                                             if (var36.drawGameObjectEdges != 0) {
                                                var16 = 0;
                                                if (var24 > var12.startX) {
                                                   ++var16;
                                                }

                                                if (var24 < var12.endX) {
                                                   var16 += 4;
                                                }

                                                if (var14 > var12.startY) {
                                                   var16 += 8;
                                                }

                                                if (var14 < var12.endY) {
                                                   var16 += 2;
                                                }

                                                if ((var16 & var36.drawGameObjectEdges) == var3.field1515) {
                                                   var3.drawGameObjects = true;
                                                   continue label563;
                                                }
                                             }
                                          }
                                       }

                                       field1226[var21++] = var12;
                                       var24 = field1207 - var12.startX;
                                       var14 = var12.endX - field1207;
                                       if (var14 > var24) {
                                          var24 = var14;
                                       }

                                       var15 = field1186 - var12.startY;
                                       var16 = var12.endY - field1186;
                                       if (var16 > var15) {
                                          var12.field1646 = var24 + var16;
                                       } else {
                                          var12.field1646 = var24 + var15;
                                       }
                                    }
                                 }

                                 while(var21 > 0) {
                                    var11 = -50;
                                    var25 = -1;

                                    for(var24 = 0; var24 < var21; ++var24) {
                                       GameObject var35 = field1226[var24];
                                       if (var35.lastDrawn != field1211) {
                                          if (var35.field1646 > var11) {
                                             var11 = var35.field1646;
                                             var25 = var24;
                                          } else if (var11 == var35.field1646) {
                                             var15 = var35.centerX - field1187;
                                             var16 = var35.centerY - field1189;
                                             var17 = field1226[var25].centerX - field1187;
                                             var18 = field1226[var25].centerY - field1189;
                                             if (var15 * var15 + var16 * var16 > var17 * var17 + var18 * var18) {
                                                var25 = var24;
                                             }
                                          }
                                       }
                                    }

                                    if (var25 == -1) {
                                       break;
                                    }

                                    GameObject var33 = field1226[var25];
                                    var33.lastDrawn = field1211;
                                    if (!this.method2276(var7, var33.startX, var33.endX, var33.startY, var33.endY, var33.entity.height)) {
                                       var33.entity.draw(var33.orientation, field1164, field1191, field1192, field1193, var33.centerX - field1187, var33.height - field1188, var33.centerY - field1189, var33.tag);
                                    }

                                    for(var14 = var33.startX; var14 <= var33.endX; ++var14) {
                                       for(var15 = var33.startY; var15 <= var33.endY; ++var15) {
                                          Tile var26 = var8[var14][var15];
                                          if (var26.drawGameObjectEdges != 0) {
                                             field1209.addFirst(var26);
                                          } else if ((var14 != var4 || var15 != var5) && var26.drawSecondary) {
                                             field1209.addFirst(var26);
                                          }
                                       }
                                    }
                                 }

                                 if (!var3.drawGameObjects) {
                                    break;
                                 }
                              } catch (Exception var28) {
                                 var3.drawGameObjects = false;
                                 break;
                              }
                           }
                        } while(!var3.drawSecondary);
                     } while(var3.drawGameObjectEdges != 0);

                     if (var4 > field1207 || var4 <= field1181) {
                        break;
                     }

                     var9 = var8[var4 - 1][var5];
                  } while(var9 != null && var9.drawSecondary);

                  if (var4 < field1207 || var4 >= field1218 - 1) {
                     break;
                  }

                  var9 = var8[var4 + 1][var5];
               } while(var9 != null && var9.drawSecondary);

               if (var5 > field1186 || var5 <= field1185) {
                  break;
               }

               var9 = var8[var4][var5 - 1];
            } while(var9 != null && var9.drawSecondary);

            if (var5 < field1186 || var5 >= field1227 - 1) {
               break;
            }

            var9 = var8[var4][var5 + 1];
         } while(var9 != null && var9.drawSecondary);

         var3.drawSecondary = false;
         --field1178;
         GroundItemPile var32 = var3.groundItemPile;
         if (var32 != null && var32.height != 0) {
            if (var32.second != null) {
               var32.second.draw(0, field1164, field1191, field1192, field1193, var32.x - field1187, var32.tileHeight - field1188 - var32.height, var32.y - field1189, var32.tag);
            }

            if (var32.third != null) {
               var32.third.draw(0, field1164, field1191, field1192, field1193, var32.x - field1187, var32.tileHeight - field1188 - var32.height, var32.y - field1189, var32.tag);
            }

            if (var32.first != null) {
               var32.first.draw(0, field1164, field1191, field1192, field1193, var32.x - field1187, var32.tileHeight - field1188 - var32.height, var32.y - field1189, var32.tag);
            }
         }

         if (var3.field1536 != 0) {
            WallDecoration var29 = var3.wallDecoration;
            if (var29 != null && !this.method2284(var7, var4, var5, var29.entity1.height)) {
               if ((var29.orientation & var3.field1536) != 0) {
                  var29.entity1.draw(0, field1164, field1191, field1192, field1193, var29.x - field1187 + var29.xOffset, var29.tileHeight - field1188, var29.y - field1189 + var29.yOffset, var29.tag);
               } else if (var29.orientation == 256) {
                  var11 = var29.x - field1187;
                  var25 = var29.tileHeight - field1188;
                  var24 = var29.y - field1189;
                  var14 = var29.int7;
                  if (var14 != 1 && var14 != 2) {
                     var15 = var11;
                  } else {
                     var15 = -var11;
                  }

                  if (var14 != 2 && var14 != 3) {
                     var16 = var24;
                  } else {
                     var16 = -var24;
                  }

                  if (var16 >= var15) {
                     var29.entity1.draw(0, field1164, field1191, field1192, field1193, var11 + var29.xOffset, var25, var24 + var29.yOffset, var29.tag);
                  } else if (var29.entity2 != null) {
                     var29.entity2.draw(0, field1164, field1191, field1192, field1193, var11, var25, var24, var29.tag);
                  }
               }
            }

            BoundaryObject var27 = var3.boundaryObject;
            if (var27 != null) {
               if ((var27.orientationB & var3.field1536) != 0 && !this.method2264(var7, var4, var5, var27.orientationB)) {
                  var27.entity2.draw(0, field1164, field1191, field1192, field1193, var27.x - field1187, var27.tileHeight - field1188, var27.y - field1189, var27.tag);
               }

               if ((var27.orientationA & var3.field1536) != 0 && !this.method2264(var7, var4, var5, var27.orientationA)) {
                  var27.entity1.draw(0, field1164, field1191, field1192, field1193, var27.x - field1187, var27.tileHeight - field1188, var27.y - field1189, var27.tag);
               }
            }
         }

         Tile var30;
         if (var6 < this.planes - 1) {
            var30 = this.tiles[var6 + 1][var4][var5];
            if (var30 != null && var30.drawSecondary) {
               field1209.addFirst(var30);
            }
         }

         if (var4 < field1207) {
            var30 = var8[var4 + 1][var5];
            if (var30 != null && var30.drawSecondary) {
               field1209.addFirst(var30);
            }
         }

         if (var5 < field1186) {
            var30 = var8[var4][var5 + 1];
            if (var30 != null && var30.drawSecondary) {
               field1209.addFirst(var30);
            }
         }

         if (var4 > field1207) {
            var30 = var8[var4 - 1][var5];
            if (var30 != null && var30.drawSecondary) {
               field1209.addFirst(var30);
            }
         }

         if (var5 > field1186) {
            var30 = var8[var4][var5 - 1];
            if (var30 != null && var30.drawSecondary) {
               field1209.addFirst(var30);
            }
         }
      }
   }

   public long method2253(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      if (var4 == null) {
         return 0L;
      } else {
         for(int var5 = 0; var5 < var4.gameObjectsCount; ++var5) {
            GameObject var6 = var4.gameObjects[var5];
            if (WorldMapCacheName.method548(var6.tag) && var2 == var6.startX && var3 == var6.startY) {
               return var6.tag;
            }
         }

         return 0L;
      }
   }

   public void method2263() {
      field1201 = true;
   }

   public void method2248(int var1, int var2, int var3, boolean var4) {
      if (!method2277() || var4) {
         field1195 = true;
         field1201 = var4;
         field1196 = var1;
         field1197 = var2;
         field1190 = var3;
         field1180 = -1;
         field1200 = -1;
      }
   }

   public BoundaryObject getBoundaryObject(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      return var4 == null ? null : var4.boundaryObject;
   }

   void method2268(TilePaint var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      int var9;
      int var10 = var9 = (var7 << 7) - field1187;
      int var11;
      int var12 = var11 = (var8 << 7) - field1189;
      int var13;
      int var14 = var13 = var10 + 128;
      int var15;
      int var16 = var15 = var12 + 128;
      int var17 = this.tileHeights[var2][var7][var8] - field1188;
      int var18 = this.tileHeights[var2][var7 + 1][var8] - field1188;
      int var19 = this.tileHeights[var2][var7 + 1][var8 + 1] - field1188;
      int var20 = this.tileHeights[var2][var7][var8 + 1] - field1188;
      int var21 = var10 * var6 + var5 * var12 >> 16;
      var12 = var12 * var6 - var5 * var10 >> 16;
      var10 = var21;
      var21 = var17 * var4 - var3 * var12 >> 16;
      var12 = var3 * var17 + var12 * var4 >> 16;
      var17 = var21;
      if (var12 >= 50) {
         var21 = var14 * var6 + var5 * var11 >> 16;
         var11 = var11 * var6 - var5 * var14 >> 16;
         var14 = var21;
         var21 = var18 * var4 - var3 * var11 >> 16;
         var11 = var3 * var18 + var11 * var4 >> 16;
         var18 = var21;
         if (var11 >= 50) {
            var21 = var13 * var6 + var5 * var16 >> 16;
            var16 = var16 * var6 - var5 * var13 >> 16;
            var13 = var21;
            var21 = var19 * var4 - var3 * var16 >> 16;
            var16 = var3 * var19 + var16 * var4 >> 16;
            var19 = var21;
            if (var16 >= 50) {
               var21 = var9 * var6 + var5 * var15 >> 16;
               var15 = var15 * var6 - var5 * var9 >> 16;
               var9 = var21;
               var21 = var20 * var4 - var3 * var15 >> 16;
               var15 = var3 * var20 + var15 * var4 >> 16;
               if (var15 >= 50) {
                  int var22 = var10 * Rasterizer3D.field1440 / var12 + Rasterizer3D.field1438;
                  int var23 = var17 * Rasterizer3D.field1440 / var12 + Rasterizer3D.field1429;
                  int var24 = var14 * Rasterizer3D.field1440 / var11 + Rasterizer3D.field1438;
                  int var25 = var18 * Rasterizer3D.field1440 / var11 + Rasterizer3D.field1429;
                  int var26 = var13 * Rasterizer3D.field1440 / var16 + Rasterizer3D.field1438;
                  int var27 = var19 * Rasterizer3D.field1440 / var16 + Rasterizer3D.field1429;
                  int var28 = var9 * Rasterizer3D.field1440 / var15 + Rasterizer3D.field1438;
                  int var29 = var21 * Rasterizer3D.field1440 / var15 + Rasterizer3D.field1429;
                  Rasterizer3D.field1431 = 0;
                  int var30;
                  if ((var26 - var28) * (var25 - var29) - (var27 - var29) * (var24 - var28) > 0) {
                     Rasterizer3D.field1452 = false;
                     if (var26 < 0 || var28 < 0 || var24 < 0 || var26 > Rasterizer3D.field1441 || var28 > Rasterizer3D.field1441 || var24 > Rasterizer3D.field1441) {
                        Rasterizer3D.field1452 = true;
                     }

                     if (field1195 && method2349(field1197, field1190, var27, var29, var25, var26, var28, var24)) {
                        field1180 = var7;
                        field1200 = var8;
                     }

                     if (var1.texture == -1) {
                        if (var1.neColor != 12345678) {
                           Rasterizer3D.method2600(var27, var29, var25, var26, var28, var24, var1.neColor, var1.nwColor, var1.seColor);
                        }
                     } else if (!field1172) {
                        if (var1.isFlat) {
                           Rasterizer3D.method2606(var27, var29, var25, var26, var28, var24, var1.neColor, var1.nwColor, var1.seColor, var10, var14, var9, var17, var18, var21, var12, var11, var15, var1.texture);
                        } else {
                           Rasterizer3D.method2606(var27, var29, var25, var26, var28, var24, var1.neColor, var1.nwColor, var1.seColor, var13, var9, var14, var19, var21, var18, var16, var15, var11, var1.texture);
                        }
                     } else {
                        var30 = Rasterizer3D.field1451.vmethod2974(var1.texture);
                        Rasterizer3D.method2600(var27, var29, var25, var26, var28, var24, method2270(var30, var1.neColor), method2270(var30, var1.nwColor), method2270(var30, var1.seColor));
                     }
                  }

                  if ((var22 - var24) * (var29 - var25) - (var23 - var25) * (var28 - var24) > 0) {
                     Rasterizer3D.field1452 = false;
                     if (var22 < 0 || var24 < 0 || var28 < 0 || var22 > Rasterizer3D.field1441 || var24 > Rasterizer3D.field1441 || var28 > Rasterizer3D.field1441) {
                        Rasterizer3D.field1452 = true;
                     }

                     if (field1195 && method2349(field1197, field1190, var23, var25, var29, var22, var24, var28)) {
                        field1180 = var7;
                        field1200 = var8;
                     }

                     if (var1.texture == -1) {
                        if (var1.swColor != 12345678) {
                           Rasterizer3D.method2600(var23, var25, var29, var22, var24, var28, var1.swColor, var1.seColor, var1.nwColor);
                        }
                     } else if (!field1172) {
                        Rasterizer3D.method2606(var23, var25, var29, var22, var24, var28, var1.swColor, var1.seColor, var1.nwColor, var10, var14, var9, var17, var18, var21, var12, var11, var15, var1.texture);
                     } else {
                        var30 = Rasterizer3D.field1451.vmethod2974(var1.texture);
                        Rasterizer3D.method2600(var23, var25, var29, var22, var24, var28, method2270(var30, var1.swColor), method2270(var30, var1.seColor), method2270(var30, var1.nwColor));
                     }
                  }

               }
            }
         }
      }
   }

   public void method2325(int var1, int var2, int var3) {
      for(int var4 = 0; var4 < this.planes; ++var4) {
         for(int var5 = 0; var5 < this.xSize; ++var5) {
            for(int var6 = 0; var6 < this.ySize; ++var6) {
               Tile var7 = this.tiles[var4][var5][var6];
               if (var7 != null) {
                  BoundaryObject var8 = var7.boundaryObject;
                  ModelData var10;
                  if (var8 != null && var8.entity1 instanceof ModelData) {
                     ModelData var9 = (ModelData)var8.entity1;
                     this.method2373(var9, var4, var5, var6, 1, 1);
                     if (var8.entity2 instanceof ModelData) {
                        var10 = (ModelData)var8.entity2;
                        this.method2373(var10, var4, var5, var6, 1, 1);
                        ModelData.method2688(var9, var10, 0, 0, 0, false);
                        var8.entity2 = var10.toModel(var10.field1490, var10.field1491, var1, var2, var3);
                     }

                     var8.entity1 = var9.toModel(var9.field1490, var9.field1491, var1, var2, var3);
                  }

                  for(int var12 = 0; var12 < var7.gameObjectsCount; ++var12) {
                     GameObject var14 = var7.gameObjects[var12];
                     if (var14 != null && var14.entity instanceof ModelData) {
                        ModelData var11 = (ModelData)var14.entity;
                        this.method2373(var11, var4, var5, var6, var14.endX - var14.startX + 1, var14.endY - var14.startY + 1);
                        var14.entity = var11.toModel(var11.field1490, var11.field1491, var1, var2, var3);
                     }
                  }

                  FloorDecoration var13 = var7.floorDecoration;
                  if (var13 != null && var13.entity instanceof ModelData) {
                     var10 = (ModelData)var13.entity;
                     this.method2257(var10, var4, var5, var6);
                     var13.entity = var10.toModel(var10.field1490, var10.field1491, var1, var2, var3);
                  }
               }
            }
         }
      }

   }

   void method2373(ModelData var1, int var2, int var3, int var4, int var5, int var6) {
      boolean var7 = true;
      int var8 = var3;
      int var9 = var3 + var5;
      int var10 = var4 - 1;
      int var11 = var4 + var6;

      for(int var12 = var2; var12 <= var2 + 1; ++var12) {
         if (var12 != this.planes) {
            for(int var13 = var8; var13 <= var9; ++var13) {
               if (var13 >= 0 && var13 < this.xSize) {
                  for(int var14 = var10; var14 <= var11; ++var14) {
                     if (var14 >= 0 && var14 < this.ySize && (!var7 || var13 >= var9 || var14 >= var11 || var14 < var4 && var3 != var13)) {
                        Tile var15 = this.tiles[var12][var13][var14];
                        if (var15 != null) {
                           int var16 = (this.tileHeights[var12][var13 + 1][var14] + this.tileHeights[var12][var13 + 1][var14 + 1] + this.tileHeights[var12][var13][var14] + this.tileHeights[var12][var13][var14 + 1]) / 4 - (this.tileHeights[var2][var3 + 1][var4] + this.tileHeights[var2][var3][var4] + this.tileHeights[var2][var3 + 1][var4 + 1] + this.tileHeights[var2][var3][var4 + 1]) / 4;
                           BoundaryObject var17 = var15.boundaryObject;
                           if (var17 != null) {
                              ModelData var18;
                              if (var17.entity1 instanceof ModelData) {
                                 var18 = (ModelData)var17.entity1;
                                 ModelData.method2688(var1, var18, (1 - var5) * 64 + (var13 - var3) * 128, var16, (var14 - var4) * 128 + (1 - var6) * 64, var7);
                              }

                              if (var17.entity2 instanceof ModelData) {
                                 var18 = (ModelData)var17.entity2;
                                 ModelData.method2688(var1, var18, (1 - var5) * 64 + (var13 - var3) * 128, var16, (var14 - var4) * 128 + (1 - var6) * 64, var7);
                              }
                           }

                           for(int var23 = 0; var23 < var15.gameObjectsCount; ++var23) {
                              GameObject var19 = var15.gameObjects[var23];
                              if (var19 != null && var19.entity instanceof ModelData) {
                                 ModelData var20 = (ModelData)var19.entity;
                                 int var21 = var19.endX - var19.startX + 1;
                                 int var22 = var19.endY - var19.startY + 1;
                                 ModelData.method2688(var1, var20, (var21 - var5) * 64 + (var19.startX - var3) * 128, var16, (var19.startY - var4) * 128 + (var22 - var6) * 64, var7);
                              }
                           }
                        }
                     }
                  }
               }
            }

            --var8;
            var7 = false;
         }
      }

   }

   void method2257(ModelData var1, int var2, int var3, int var4) {
      Tile var5;
      ModelData var6;
      if (var3 < this.xSize) {
         var5 = this.tiles[var2][var3 + 1][var4];
         if (var5 != null && var5.floorDecoration != null && var5.floorDecoration.entity instanceof ModelData) {
            var6 = (ModelData)var5.floorDecoration.entity;
            ModelData.method2688(var1, var6, 128, 0, 0, true);
         }
      }

      if (var4 < this.xSize) {
         var5 = this.tiles[var2][var3][var4 + 1];
         if (var5 != null && var5.floorDecoration != null && var5.floorDecoration.entity instanceof ModelData) {
            var6 = (ModelData)var5.floorDecoration.entity;
            ModelData.method2688(var1, var6, 0, 0, 128, true);
         }
      }

      if (var3 < this.xSize && var4 < this.ySize) {
         var5 = this.tiles[var2][var3 + 1][var4 + 1];
         if (var5 != null && var5.floorDecoration != null && var5.floorDecoration.entity instanceof ModelData) {
            var6 = (ModelData)var5.floorDecoration.entity;
            ModelData.method2688(var1, var6, 128, 0, 128, true);
         }
      }

      if (var3 < this.xSize && var4 > 0) {
         var5 = this.tiles[var2][var3 + 1][var4 - 1];
         if (var5 != null && var5.floorDecoration != null && var5.floorDecoration.entity instanceof ModelData) {
            var6 = (ModelData)var5.floorDecoration.entity;
            ModelData.method2688(var1, var6, 128, 0, -128, true);
         }
      }

   }

   void method2269(TileModel var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = var1.field1393.length;

      int var9;
      int var10;
      int var11;
      int var12;
      int var13;
      for(var9 = 0; var9 < var8; ++var9) {
         var10 = var1.field1393[var9] - field1187;
         var11 = var1.field1392[var9] - field1188;
         var12 = var1.field1385[var9] - field1189;
         var13 = var12 * var4 + var5 * var10 >> 16;
         var12 = var5 * var12 - var10 * var4 >> 16;
         var10 = var13;
         var13 = var3 * var11 - var12 * var2 >> 16;
         var12 = var11 * var2 + var3 * var12 >> 16;
         if (var12 < 50) {
            return;
         }

         if (var1.field1383 != null) {
            TileModel.field1400[var9] = var10;
            TileModel.field1401[var9] = var13;
            TileModel.field1402[var9] = var12;
         }

         TileModel.field1398[var9] = var10 * Rasterizer3D.field1440 / var12 + Rasterizer3D.field1438;
         TileModel.field1384[var9] = var13 * Rasterizer3D.field1440 / var12 + Rasterizer3D.field1429;
      }

      Rasterizer3D.field1431 = 0;
      var8 = var1.field1391.length;

      for(var9 = 0; var9 < var8; ++var9) {
         var10 = var1.field1391[var9];
         var11 = var1.field1390[var9];
         var12 = var1.field1389[var9];
         var13 = TileModel.field1398[var10];
         int var14 = TileModel.field1398[var11];
         int var15 = TileModel.field1398[var12];
         int var16 = TileModel.field1384[var10];
         int var17 = TileModel.field1384[var11];
         int var18 = TileModel.field1384[var12];
         if ((var13 - var14) * (var18 - var17) - (var16 - var17) * (var15 - var14) > 0) {
            Rasterizer3D.field1452 = false;
            if (var13 < 0 || var14 < 0 || var15 < 0 || var13 > Rasterizer3D.field1441 || var14 > Rasterizer3D.field1441 || var15 > Rasterizer3D.field1441) {
               Rasterizer3D.field1452 = true;
            }

            if (field1195 && method2349(field1197, field1190, var16, var17, var18, var13, var14, var15)) {
               field1180 = var6;
               field1200 = var7;
            }

            if (var1.field1383 != null && var1.field1383[var9] != -1) {
               if (!field1172) {
                  if (var1.isFlat) {
                     Rasterizer3D.method2606(var16, var17, var18, var13, var14, var15, var1.field1386[var9], var1.field1387[var9], var1.field1388[var9], TileModel.field1400[0], TileModel.field1400[1], TileModel.field1400[3], TileModel.field1401[0], TileModel.field1401[1], TileModel.field1401[3], TileModel.field1402[0], TileModel.field1402[1], TileModel.field1402[3], var1.field1383[var9]);
                  } else {
                     Rasterizer3D.method2606(var16, var17, var18, var13, var14, var15, var1.field1386[var9], var1.field1387[var9], var1.field1388[var9], TileModel.field1400[var10], TileModel.field1400[var11], TileModel.field1400[var12], TileModel.field1401[var10], TileModel.field1401[var11], TileModel.field1401[var12], TileModel.field1402[var10], TileModel.field1402[var11], TileModel.field1402[var12], var1.field1383[var9]);
                  }
               } else {
                  int var19 = Rasterizer3D.field1451.vmethod2974(var1.field1383[var9]);
                  Rasterizer3D.method2600(var16, var17, var18, var13, var14, var15, method2270(var19, var1.field1386[var9]), method2270(var19, var1.field1387[var9]), method2270(var19, var1.field1388[var9]));
               }
            } else if (var1.field1386[var9] != 12345678) {
               Rasterizer3D.method2600(var16, var17, var18, var13, var14, var15, var1.field1386[var9], var1.field1387[var9], var1.field1388[var9]);
            }
         }
      }

   }

   public GameObject method2249(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      if (var4 == null) {
         return null;
      } else {
         for(int var5 = 0; var5 < var4.gameObjectsCount; ++var5) {
            GameObject var6 = var4.gameObjects[var5];
            if (WorldMapCacheName.method548(var6.tag) && var2 == var6.startX && var3 == var6.startY) {
               return var6;
            }
         }

         return null;
      }
   }

   public WallDecoration getWallDecoration(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      return var4 == null ? null : var4.wallDecoration;
   }

   public void draw(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (var1 < 0) {
         var1 = 0;
      } else if (var1 >= this.xSize * 128) {
         var1 = this.xSize * 128 - 1;
      }

      if (var3 < 0) {
         var3 = 0;
      } else if (var3 >= this.ySize * 128) {
         var3 = this.ySize * 128 - 1;
      }

      if (var4 < 128) {
         var4 = 128;
      } else if (var4 > 383) {
         var4 = 383;
      }

      ++field1211;
      field1164 = Rasterizer3D.field1446[var4];
      field1191 = Rasterizer3D.field1453[var4];
      field1192 = Rasterizer3D.field1446[var5];
      field1193 = Rasterizer3D.field1453[var5];
      field1215 = field1223[(var4 - 128) / 32][var5 / 64];
      field1187 = var1;
      field1188 = var2;
      field1189 = var3;
      field1207 = var1 / 128;
      field1186 = var3 / 128;
      field1179 = var6;
      field1181 = field1207 - 25;
      if (field1181 < 0) {
         field1181 = 0;
      }

      field1185 = field1186 - 25;
      if (field1185 < 0) {
         field1185 = 0;
      }

      field1218 = field1207 + 25;
      if (field1218 > this.xSize) {
         field1218 = this.xSize;
      }

      field1227 = field1186 + 25;
      if (field1227 > this.ySize) {
         field1227 = this.ySize;
      }

      this.occlude();
      field1178 = 0;

      int var7;
      Tile[][] var8;
      int var9;
      int var10;
      for(var7 = this.minPlane; var7 < this.planes; ++var7) {
         var8 = this.tiles[var7];

         for(var9 = field1181; var9 < field1218; ++var9) {
            for(var10 = field1185; var10 < field1227; ++var10) {
               Tile var11 = var8[var9][var10];
               if (var11 != null) {
                  if (var11.minPlane > var6 || !field1215[var9 - field1207 + 25][var10 - field1186 + 25] && this.tileHeights[var7][var9][var10] - var2 < 2000) {
                     var11.drawPrimary = false;
                     var11.drawSecondary = false;
                     var11.drawGameObjectEdges = 0;
                  } else {
                     var11.drawPrimary = true;
                     var11.drawSecondary = true;
                     if (var11.gameObjectsCount > 0) {
                        var11.drawGameObjects = true;
                     } else {
                        var11.drawGameObjects = false;
                     }

                     ++field1178;
                  }
               }
            }
         }
      }

      int var12;
      int var13;
      int var14;
      Tile var15;
      int var16;
      for(var7 = this.minPlane; var7 < this.planes; ++var7) {
         var8 = this.tiles[var7];

         for(var9 = -25; var9 <= 0; ++var9) {
            var10 = var9 + field1207;
            var16 = field1207 - var9;
            if (var10 >= field1181 || var16 < field1218) {
               for(var12 = -25; var12 <= 0; ++var12) {
                  var13 = var12 + field1186;
                  var14 = field1186 - var12;
                  if (var10 >= field1181) {
                     if (var13 >= field1185) {
                        var15 = var8[var10][var13];
                        if (var15 != null && var15.drawPrimary) {
                           this.drawTile(var15, true);
                        }
                     }

                     if (var14 < field1227) {
                        var15 = var8[var10][var14];
                        if (var15 != null && var15.drawPrimary) {
                           this.drawTile(var15, true);
                        }
                     }
                  }

                  if (var16 < field1218) {
                     if (var13 >= field1185) {
                        var15 = var8[var16][var13];
                        if (var15 != null && var15.drawPrimary) {
                           this.drawTile(var15, true);
                        }
                     }

                     if (var14 < field1227) {
                        var15 = var8[var16][var14];
                        if (var15 != null && var15.drawPrimary) {
                           this.drawTile(var15, true);
                        }
                     }
                  }

                  if (field1178 == 0) {
                     field1195 = false;
                     return;
                  }
               }
            }
         }
      }

      for(var7 = this.minPlane; var7 < this.planes; ++var7) {
         var8 = this.tiles[var7];

         for(var9 = -25; var9 <= 0; ++var9) {
            var10 = var9 + field1207;
            var16 = field1207 - var9;
            if (var10 >= field1181 || var16 < field1218) {
               for(var12 = -25; var12 <= 0; ++var12) {
                  var13 = var12 + field1186;
                  var14 = field1186 - var12;
                  if (var10 >= field1181) {
                     if (var13 >= field1185) {
                        var15 = var8[var10][var13];
                        if (var15 != null && var15.drawPrimary) {
                           this.drawTile(var15, false);
                        }
                     }

                     if (var14 < field1227) {
                        var15 = var8[var10][var14];
                        if (var15 != null && var15.drawPrimary) {
                           this.drawTile(var15, false);
                        }
                     }
                  }

                  if (var16 < field1218) {
                     if (var13 >= field1185) {
                        var15 = var8[var16][var13];
                        if (var15 != null && var15.drawPrimary) {
                           this.drawTile(var15, false);
                        }
                     }

                     if (var14 < field1227) {
                        var15 = var8[var16][var14];
                        if (var15 != null && var15.drawPrimary) {
                           this.drawTile(var15, false);
                        }
                     }
                  }

                  if (field1178 == 0) {
                     field1195 = false;
                     return;
                  }
               }
            }
         }
      }

      field1195 = false;
   }

   public long method2252(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      return var4 != null && var4.wallDecoration != null ? var4.wallDecoration.tag : 0L;
   }

   boolean method2264(int var1, int var2, int var3, int var4) {
      if (!this.method2321(var1, var2, var3)) {
         return false;
      } else {
         int var5 = var2 << 7;
         int var6 = var3 << 7;
         int var7 = this.tileHeights[var1][var2][var3] - 1;
         int var8 = var7 - 120;
         int var9 = var7 - 230;
         int var10 = var7 - 238;
         if (var4 < 16) {
            if (var4 == 1) {
               if (var5 > field1187) {
                  if (!this.method2333(var5, var7, var6)) {
                     return false;
                  }

                  if (!this.method2333(var5, var7, var6 + 128)) {
                     return false;
                  }
               }

               if (var1 > 0) {
                  if (!this.method2333(var5, var8, var6)) {
                     return false;
                  }

                  if (!this.method2333(var5, var8, var6 + 128)) {
                     return false;
                  }
               }

               if (!this.method2333(var5, var9, var6)) {
                  return false;
               }

               if (!this.method2333(var5, var9, var6 + 128)) {
                  return false;
               }

               return true;
            }

            if (var4 == 2) {
               if (var6 < field1189) {
                  if (!this.method2333(var5, var7, var6 + 128)) {
                     return false;
                  }

                  if (!this.method2333(var5 + 128, var7, var6 + 128)) {
                     return false;
                  }
               }

               if (var1 > 0) {
                  if (!this.method2333(var5, var8, var6 + 128)) {
                     return false;
                  }

                  if (!this.method2333(var5 + 128, var8, var6 + 128)) {
                     return false;
                  }
               }

               if (!this.method2333(var5, var9, var6 + 128)) {
                  return false;
               }

               if (!this.method2333(var5 + 128, var9, var6 + 128)) {
                  return false;
               }

               return true;
            }

            if (var4 == 4) {
               if (var5 < field1187) {
                  if (!this.method2333(var5 + 128, var7, var6)) {
                     return false;
                  }

                  if (!this.method2333(var5 + 128, var7, var6 + 128)) {
                     return false;
                  }
               }

               if (var1 > 0) {
                  if (!this.method2333(var5 + 128, var8, var6)) {
                     return false;
                  }

                  if (!this.method2333(var5 + 128, var8, var6 + 128)) {
                     return false;
                  }
               }

               if (!this.method2333(var5 + 128, var9, var6)) {
                  return false;
               }

               if (!this.method2333(var5 + 128, var9, var6 + 128)) {
                  return false;
               }

               return true;
            }

            if (var4 == 8) {
               if (var6 > field1189) {
                  if (!this.method2333(var5, var7, var6)) {
                     return false;
                  }

                  if (!this.method2333(var5 + 128, var7, var6)) {
                     return false;
                  }
               }

               if (var1 > 0) {
                  if (!this.method2333(var5, var8, var6)) {
                     return false;
                  }

                  if (!this.method2333(var5 + 128, var8, var6)) {
                     return false;
                  }
               }

               if (!this.method2333(var5, var9, var6)) {
                  return false;
               }

               if (!this.method2333(var5 + 128, var9, var6)) {
                  return false;
               }

               return true;
            }
         }

         if (!this.method2333(var5 + 64, var10, var6 + 64)) {
            return false;
         } else if (var4 == 16) {
            return this.method2333(var5, var9, var6 + 128);
         } else if (var4 == 32) {
            return this.method2333(var5 + 128, var9, var6 + 128);
         } else if (var4 == 64) {
            return this.method2333(var5 + 128, var9, var6);
         } else if (var4 == 128) {
            return this.method2333(var5, var9, var6);
         } else {
            return true;
         }
      }
   }

   boolean method2284(int var1, int var2, int var3, int var4) {
      if (!this.method2321(var1, var2, var3)) {
         return false;
      } else {
         int var5 = var2 << 7;
         int var6 = var3 << 7;
         return this.method2333(var5 + 1, this.tileHeights[var1][var2][var3] - var4, var6 + 1) && this.method2333(var5 + 128 - 1, this.tileHeights[var1][var2 + 1][var3] - var4, var6 + 1) && this.method2333(var5 + 128 - 1, this.tileHeights[var1][var2 + 1][var3 + 1] - var4, var6 + 128 - 1) && this.method2333(var5 + 1, this.tileHeights[var1][var2][var3 + 1] - var4, var6 + 128 - 1);
      }
   }

   boolean method2276(int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7;
      int var8;
      if (var3 == var2 && var5 == var4) {
         if (!this.method2321(var1, var2, var4)) {
            return false;
         } else {
            var7 = var2 << 7;
            var8 = var4 << 7;
            return this.method2333(var7 + 1, this.tileHeights[var1][var2][var4] - var6, var8 + 1) && this.method2333(var7 + 128 - 1, this.tileHeights[var1][var2 + 1][var4] - var6, var8 + 1) && this.method2333(var7 + 128 - 1, this.tileHeights[var1][var2 + 1][var4 + 1] - var6, var8 + 128 - 1) && this.method2333(var7 + 1, this.tileHeights[var1][var2][var4 + 1] - var6, var8 + 128 - 1);
         }
      } else {
         for(var7 = var2; var7 <= var3; ++var7) {
            for(var8 = var4; var8 <= var5; ++var8) {
               if (this.field1206[var1][var7][var8] == -field1211) {
                  return false;
               }
            }
         }

         var7 = (var2 << 7) + 1;
         var8 = (var4 << 7) + 2;
         int var9 = this.tileHeights[var1][var2][var4] - var6;
         if (!this.method2333(var7, var9, var8)) {
            return false;
         } else {
            int var10 = (var3 << 7) - 1;
            if (!this.method2333(var10, var9, var8)) {
               return false;
            } else {
               int var11 = (var5 << 7) - 1;
               if (!this.method2333(var7, var9, var11)) {
                  return false;
               } else if (!this.method2333(var10, var9, var11)) {
                  return false;
               } else {
                  return true;
               }
            }
         }
      }
   }

   void occlude() {
      int var1 = field1224[field1179];
      Occluder[] var2 = field1198[field1179];
      field1184 = 0;

      for(int var3 = 0; var3 < var1; ++var3) {
         Occluder var4 = var2[var3];
         int var5;
         int var6;
         int var7;
         int var9;
         boolean var13;
         if (var4.type == 1) {
            var5 = var4.minTileX - field1207 + 25;
            if (var5 >= 0 && var5 <= 50) {
               var6 = var4.minTileY - field1186 + 25;
               if (var6 < 0) {
                  var6 = 0;
               }

               var7 = var4.maxTileY - field1186 + 25;
               if (var7 > 50) {
                  var7 = 50;
               }

               var13 = false;

               while(var6 <= var7) {
                  if (field1215[var5][var6++]) {
                     var13 = true;
                     break;
                  }
               }

               if (var13) {
                  var9 = field1187 - var4.minX;
                  if (var9 > 32) {
                     var4.field1721 = 1;
                  } else {
                     if (var9 >= -32) {
                        continue;
                     }

                     var4.field1721 = 2;
                     var9 = -var9;
                  }

                  var4.field1724 = (var4.minZ - field1189 << 8) / var9;
                  var4.field1725 = (var4.maxZ - field1189 << 8) / var9;
                  var4.field1722 = (var4.minY - field1188 << 8) / var9;
                  var4.field1727 = (var4.maxY - field1188 << 8) / var9;
                  field1169[field1184++] = var4;
               }
            }
         } else if (var4.type == 2) {
            var5 = var4.minTileY - field1186 + 25;
            if (var5 >= 0 && var5 <= 50) {
               var6 = var4.minTileX - field1207 + 25;
               if (var6 < 0) {
                  var6 = 0;
               }

               var7 = var4.maxTileX - field1207 + 25;
               if (var7 > 50) {
                  var7 = 50;
               }

               var13 = false;

               while(var6 <= var7) {
                  if (field1215[var6++][var5]) {
                     var13 = true;
                     break;
                  }
               }

               if (var13) {
                  var9 = field1189 - var4.minZ;
                  if (var9 > 32) {
                     var4.field1721 = 3;
                  } else {
                     if (var9 >= -32) {
                        continue;
                     }

                     var4.field1721 = 4;
                     var9 = -var9;
                  }

                  var4.field1711 = (var4.minX - field1187 << 8) / var9;
                  var4.field1723 = (var4.maxX - field1187 << 8) / var9;
                  var4.field1722 = (var4.minY - field1188 << 8) / var9;
                  var4.field1727 = (var4.maxY - field1188 << 8) / var9;
                  field1169[field1184++] = var4;
               }
            }
         } else if (var4.type == 4) {
            var5 = var4.minY - field1188;
            if (var5 > 128) {
               var6 = var4.minTileY - field1186 + 25;
               if (var6 < 0) {
                  var6 = 0;
               }

               var7 = var4.maxTileY - field1186 + 25;
               if (var7 > 50) {
                  var7 = 50;
               }

               if (var6 <= var7) {
                  int var8 = var4.minTileX - field1207 + 25;
                  if (var8 < 0) {
                     var8 = 0;
                  }

                  var9 = var4.maxTileX - field1207 + 25;
                  if (var9 > 50) {
                     var9 = 50;
                  }

                  boolean var10 = false;

                  label162:
                  for(int var11 = var8; var11 <= var9; ++var11) {
                     for(int var12 = var6; var12 <= var7; ++var12) {
                        if (field1215[var11][var12]) {
                           var10 = true;
                           break label162;
                        }
                     }
                  }

                  if (var10) {
                     var4.field1721 = 5;
                     var4.field1711 = (var4.minX - field1187 << 8) / var5;
                     var4.field1723 = (var4.maxX - field1187 << 8) / var5;
                     var4.field1724 = (var4.minZ - field1189 << 8) / var5;
                     var4.field1725 = (var4.maxZ - field1189 << 8) / var5;
                     field1169[field1184++] = var4;
                  }
               }
            }
         }
      }

   }

   boolean method2333(int var1, int var2, int var3) {
      for(int var4 = 0; var4 < field1184; ++var4) {
         Occluder var5 = field1169[var4];
         int var6;
         int var7;
         int var8;
         int var9;
         int var10;
         if (var5.field1721 == 1) {
            var6 = var5.minX - var1;
            if (var6 > 0) {
               var7 = (var6 * var5.field1724 >> 8) + var5.minZ;
               var8 = (var6 * var5.field1725 >> 8) + var5.maxZ;
               var9 = (var6 * var5.field1722 >> 8) + var5.minY;
               var10 = (var6 * var5.field1727 >> 8) + var5.maxY;
               if (var3 >= var7 && var3 <= var8 && var2 >= var9 && var2 <= var10) {
                  return true;
               }
            }
         } else if (var5.field1721 == 2) {
            var6 = var1 - var5.minX;
            if (var6 > 0) {
               var7 = (var6 * var5.field1724 >> 8) + var5.minZ;
               var8 = (var6 * var5.field1725 >> 8) + var5.maxZ;
               var9 = (var6 * var5.field1722 >> 8) + var5.minY;
               var10 = (var6 * var5.field1727 >> 8) + var5.maxY;
               if (var3 >= var7 && var3 <= var8 && var2 >= var9 && var2 <= var10) {
                  return true;
               }
            }
         } else if (var5.field1721 == 3) {
            var6 = var5.minZ - var3;
            if (var6 > 0) {
               var7 = (var6 * var5.field1711 >> 8) + var5.minX;
               var8 = (var6 * var5.field1723 >> 8) + var5.maxX;
               var9 = (var6 * var5.field1722 >> 8) + var5.minY;
               var10 = (var6 * var5.field1727 >> 8) + var5.maxY;
               if (var1 >= var7 && var1 <= var8 && var2 >= var9 && var2 <= var10) {
                  return true;
               }
            }
         } else if (var5.field1721 == 4) {
            var6 = var3 - var5.minZ;
            if (var6 > 0) {
               var7 = (var6 * var5.field1711 >> 8) + var5.minX;
               var8 = (var6 * var5.field1723 >> 8) + var5.maxX;
               var9 = (var6 * var5.field1722 >> 8) + var5.minY;
               var10 = (var6 * var5.field1727 >> 8) + var5.maxY;
               if (var1 >= var7 && var1 <= var8 && var2 >= var9 && var2 <= var10) {
                  return true;
               }
            }
         } else if (var5.field1721 == 5) {
            var6 = var2 - var5.minY;
            if (var6 > 0) {
               var7 = (var6 * var5.field1711 >> 8) + var5.minX;
               var8 = (var6 * var5.field1723 >> 8) + var5.maxX;
               var9 = (var6 * var5.field1724 >> 8) + var5.minZ;
               var10 = (var6 * var5.field1725 >> 8) + var5.maxZ;
               if (var1 >= var7 && var1 <= var8 && var3 >= var9 && var3 <= var10) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   boolean method2321(int var1, int var2, int var3) {
      int var4 = this.field1206[var1][var2][var3];
      if (var4 == -field1211) {
         return false;
      } else if (var4 == field1211) {
         return true;
      } else {
         int var5 = var2 << 7;
         int var6 = var3 << 7;
         if (this.method2333(var5 + 1, this.tileHeights[var1][var2][var3], var6 + 1) && this.method2333(var5 + 128 - 1, this.tileHeights[var1][var2 + 1][var3], var6 + 1) && this.method2333(var5 + 128 - 1, this.tileHeights[var1][var2 + 1][var3 + 1], var6 + 128 - 1) && this.method2333(var5 + 1, this.tileHeights[var1][var2][var3 + 1], var6 + 128 - 1)) {
            this.field1206[var1][var2][var3] = field1211;
            return true;
         } else {
            this.field1206[var1][var2][var3] = -field1211;
            return false;
         }
      }
   }

   public void clearTempGameObjects() {
      for(int var1 = 0; var1 < this.tempGameObjectsCount; ++var1) {
         GameObject var2 = this.tempGameObjects[var1];
         this.removeGameObject(var2);
         this.tempGameObjects[var1] = null;
      }

      this.tempGameObjectsCount = 0;
   }

   public void setTileMinPlane(int var1, int var2, int var3, int var4) {
      Tile var5 = this.tiles[var1][var2][var3];
      if (var5 != null) {
         this.tiles[var1][var2][var3].minPlane = var4;
      }
   }

   public void newBoundaryObject(int var1, int var2, int var3, int var4, Entity var5, Entity var6, int var7, int var8, long var9, int var11) {
      if (var5 != null || var6 != null) {
         BoundaryObject var12 = new BoundaryObject();
         var12.tag = var9;
         var12.flags = var11;
         var12.x = var2 * 128 + 64;
         var12.y = var3 * 128 + 64;
         var12.tileHeight = var4;
         var12.entity1 = var5;
         var12.entity2 = var6;
         var12.orientationA = var7;
         var12.orientationB = var8;

         for(int var13 = var1; var13 >= 0; --var13) {
            if (this.tiles[var13][var2][var3] == null) {
               this.tiles[var13][var2][var3] = new Tile(var13, var2, var3);
            }
         }

         this.tiles[var1][var2][var3].boundaryObject = var12;
      }
   }

   public void setLinkBelow(int var1, int var2) {
      Tile var3 = this.tiles[0][var1][var2];

      for(int var4 = 0; var4 < 3; ++var4) {
         Tile var5 = this.tiles[var4][var1][var2] = this.tiles[var4 + 1][var1][var2];
         if (var5 != null) {
            --var5.plane;

            for(int var6 = 0; var6 < var5.gameObjectsCount; ++var6) {
               GameObject var7 = var5.gameObjects[var6];
               if (WorldMapCacheName.method548(var7.tag) && var7.startX == var1 && var2 == var7.startY) {
                  --var7.plane;
               }
            }
         }
      }

      if (this.tiles[0][var1][var2] == null) {
         this.tiles[0][var1][var2] = new Tile(0, var1, var2);
      }

      this.tiles[0][var1][var2].linkedBelowTile = var3;
      this.tiles[3][var1][var2] = null;
   }

   boolean newGameObject(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, Entity var9, int var10, boolean var11, long var12, int var14) {
      int var16;
      for(int var15 = var2; var15 < var2 + var4; ++var15) {
         for(var16 = var3; var16 < var3 + var5; ++var16) {
            if (var15 < 0 || var16 < 0 || var15 >= this.xSize || var16 >= this.ySize) {
               return false;
            }

            Tile var17 = this.tiles[var1][var15][var16];
            if (var17 != null && var17.gameObjectsCount >= 5) {
               return false;
            }
         }
      }

      GameObject var21 = new GameObject();
      var21.tag = var12;
      var21.flags = var14;
      var21.plane = var1;
      var21.centerX = var6;
      var21.centerY = var7;
      var21.height = var8;
      var21.entity = var9;
      var21.orientation = var10;
      var21.startX = var2;
      var21.startY = var3;
      var21.endX = var2 + var4 - 1;
      var21.endY = var3 + var5 - 1;

      for(var16 = var2; var16 < var2 + var4; ++var16) {
         for(int var22 = var3; var22 < var3 + var5; ++var22) {
            int var18 = 0;
            if (var16 > var2) {
               ++var18;
            }

            if (var16 < var2 + var4 - 1) {
               var18 += 4;
            }

            if (var22 > var3) {
               var18 += 8;
            }

            if (var22 < var3 + var5 - 1) {
               var18 += 2;
            }

            for(int var19 = var1; var19 >= 0; --var19) {
               if (this.tiles[var19][var16][var22] == null) {
                  this.tiles[var19][var16][var22] = new Tile(var19, var16, var22);
               }
            }

            Tile var23 = this.tiles[var1][var16][var22];
            var23.gameObjects[var23.gameObjectsCount] = var21;
            var23.gameObjectEdgeMasks[var23.gameObjectsCount] = var18;
            var23.gameObjectsEdgeMask |= var18;
            ++var23.gameObjectsCount;
         }
      }

      if (var11) {
         this.tempGameObjects[this.tempGameObjectsCount++] = var21;
      }

      return true;
   }

   public void clear() {
      int var1;
      int var2;
      for(var1 = 0; var1 < this.planes; ++var1) {
         for(var2 = 0; var2 < this.xSize; ++var2) {
            for(int var3 = 0; var3 < this.ySize; ++var3) {
               this.tiles[var1][var2][var3] = null;
            }
         }
      }

      for(var1 = 0; var1 < field1204; ++var1) {
         for(var2 = 0; var2 < field1224[var1]; ++var2) {
            field1198[var1][var2] = null;
         }

         field1224[var1] = 0;
      }

      for(var1 = 0; var1 < this.tempGameObjectsCount; ++var1) {
         this.tempGameObjects[var1] = null;
      }

      this.tempGameObjectsCount = 0;

      for(var1 = 0; var1 < field1226.length; ++var1) {
         field1226[var1] = null;
      }

   }

   public boolean method2237(int var1, int var2, int var3, int var4, int var5, Entity var6, int var7, long var8, int var10, int var11, int var12, int var13) {
      return var6 == null ? true : this.newGameObject(var1, var10, var11, var12 - var10 + 1, var13 - var11 + 1, var2, var3, var4, var6, var7, true, var8, 0);
   }

   public void addTile(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, int var13, int var14, int var15, int var16, int var17, int var18, int var19, int var20) {
      TilePaint var21;
      int var22;
      if (var4 == 0) {
         var21 = new TilePaint(var11, var12, var13, var14, -1, var19, false);

         for(var22 = var1; var22 >= 0; --var22) {
            if (this.tiles[var22][var2][var3] == null) {
               this.tiles[var22][var2][var3] = new Tile(var22, var2, var3);
            }
         }

         this.tiles[var1][var2][var3].paint = var21;
      } else if (var4 != 1) {
         TileModel var23 = new TileModel(var4, var5, var6, var2, var3, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20);

         for(var22 = var1; var22 >= 0; --var22) {
            if (this.tiles[var22][var2][var3] == null) {
               this.tiles[var22][var2][var3] = new Tile(var22, var2, var3);
            }
         }

         this.tiles[var1][var2][var3].model = var23;
      } else {
         var21 = new TilePaint(var15, var16, var17, var18, var6, var20, var8 == var7 && var7 == var9 && var10 == var7);

         for(var22 = var1; var22 >= 0; --var22) {
            if (this.tiles[var22][var2][var3] == null) {
               this.tiles[var22][var2][var3] = new Tile(var22, var2, var3);
            }
         }

         this.tiles[var1][var2][var3].paint = var21;
      }
   }

   public void newWallDecoration(int var1, int var2, int var3, int var4, Entity var5, Entity var6, int var7, int var8, int var9, int var10, long var11, int var13) {
      if (var5 != null) {
         WallDecoration var14 = new WallDecoration();
         var14.tag = var11;
         var14.flags = var13;
         var14.x = var2 * 128 + 64;
         var14.y = var3 * 128 + 64;
         var14.tileHeight = var4;
         var14.entity1 = var5;
         var14.entity2 = var6;
         var14.orientation = var7;
         var14.int7 = var8;
         var14.xOffset = var9;
         var14.yOffset = var10;

         for(int var15 = var1; var15 >= 0; --var15) {
            if (this.tiles[var15][var2][var3] == null) {
               this.tiles[var15][var2][var3] = new Tile(var15, var2, var3);
            }
         }

         this.tiles[var1][var2][var3].wallDecoration = var14;
      }
   }

   public void method2241(int var1, int var2, int var3, int var4) {
      Tile var5 = this.tiles[var1][var2][var3];
      if (var5 != null) {
         WallDecoration var6 = var5.wallDecoration;
         if (var6 != null) {
            var6.xOffset = var4 * var6.xOffset / 16;
            var6.yOffset = var4 * var6.yOffset / 16;
         }
      }
   }

   public void newGroundItemPile(int var1, int var2, int var3, int var4, Entity var5, long var6, Entity var8, Entity var9) {
      GroundItemPile var10 = new GroundItemPile();
      var10.first = var5;
      var10.x = var2 * 128 + 64;
      var10.y = var3 * 128 + 64;
      var10.tileHeight = var4;
      var10.tag = var6;
      var10.second = var8;
      var10.third = var9;
      int var11 = 0;
      Tile var12 = this.tiles[var1][var2][var3];
      if (var12 != null) {
         for(int var13 = 0; var13 < var12.gameObjectsCount; ++var13) {
            if ((var12.gameObjects[var13].flags & 256) == 256 && var12.gameObjects[var13].entity instanceof Model) {
               Model var14 = (Model)var12.gameObjects[var13].entity;
               var14.calculateBoundsCylinder();
               if (var14.height > var11) {
                  var11 = var14.height;
               }
            }
         }
      }

      var10.height = var11;
      if (this.tiles[var1][var2][var3] == null) {
         this.tiles[var1][var2][var3] = new Tile(var1, var2, var3);
      }

      this.tiles[var1][var2][var3].groundItemPile = var10;
   }

   public void removeFloorDecoration(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      if (var4 != null) {
         var4.floorDecoration = null;
      }
   }

   public void newFloorDecoration(int var1, int var2, int var3, int var4, Entity var5, long var6, int var8) {
      if (var5 != null) {
         FloorDecoration var9 = new FloorDecoration();
         var9.entity = var5;
         var9.x = var2 * 128 + 64;
         var9.y = var3 * 128 + 64;
         var9.tileHeight = var4;
         var9.tag = var6;
         var9.flags = var8;
         if (this.tiles[var1][var2][var3] == null) {
            this.tiles[var1][var2][var3] = new Tile(var1, var2, var3);
         }

         this.tiles[var1][var2][var3].floorDecoration = var9;
      }
   }

   public void init(int var1) {
      this.minPlane = var1;

      for(int var2 = 0; var2 < this.xSize; ++var2) {
         for(int var3 = 0; var3 < this.ySize; ++var3) {
            if (this.tiles[var1][var2][var3] == null) {
               this.tiles[var1][var2][var3] = new Tile(var1, var2, var3);
            }
         }
      }

   }

   public void removeBoundaryObject(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      if (var4 != null) {
         var4.boundaryObject = null;
      }
   }

   void removeGameObject(GameObject var1) {
      for(int var2 = var1.startX; var2 <= var1.endX; ++var2) {
         for(int var3 = var1.startY; var3 <= var1.endY; ++var3) {
            Tile var4 = this.tiles[var1.plane][var2][var3];
            if (var4 != null) {
               int var5;
               for(var5 = 0; var5 < var4.gameObjectsCount; ++var5) {
                  if (var4.gameObjects[var5] == var1) {
                     --var4.gameObjectsCount;

                     for(int var6 = var5; var6 < var4.gameObjectsCount; ++var6) {
                        var4.gameObjects[var6] = var4.gameObjects[var6 + 1];
                        var4.gameObjectEdgeMasks[var6] = var4.gameObjectEdgeMasks[var6 + 1];
                     }

                     var4.gameObjects[var4.gameObjectsCount] = null;
                     break;
                  }
               }

               var4.gameObjectsEdgeMask = 0;

               for(var5 = 0; var5 < var4.gameObjectsCount; ++var5) {
                  var4.gameObjectsEdgeMask |= var4.gameObjectEdgeMasks[var5];
               }
            }
         }
      }

   }

   public void method2244(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      if (var4 != null) {
         for(int var5 = 0; var5 < var4.gameObjectsCount; ++var5) {
            GameObject var6 = var4.gameObjects[var5];
            if (WorldMapCacheName.method548(var6.tag) && var2 == var6.startX && var3 == var6.startY) {
               this.removeGameObject(var6);
               return;
            }
         }

      }
   }

   public boolean method2260(int var1, int var2, int var3, int var4, int var5, Entity var6, int var7, long var8, boolean var10) {
      if (var6 == null) {
         return true;
      } else {
         int var11 = var2 - var5;
         int var12 = var3 - var5;
         int var13 = var5 + var2;
         int var14 = var3 + var5;
         if (var10) {
            if (var7 > 640 && var7 < 1408) {
               var14 += 128;
            }

            if (var7 > 1152 && var7 < 1920) {
               var13 += 128;
            }

            if (var7 > 1664 || var7 < 384) {
               var12 -= 128;
            }

            if (var7 > 128 && var7 < 896) {
               var11 -= 128;
            }
         }

         var11 /= 128;
         var12 /= 128;
         var13 /= 128;
         var14 /= 128;
         return this.newGameObject(var1, var11, var12, var13 - var11 + 1, var14 - var12 + 1, var2, var3, var4, var6, var7, true, var8, 0);
      }
   }

   public boolean method2235(int var1, int var2, int var3, int var4, int var5, int var6, Entity var7, int var8, long var9, int var11) {
      if (var7 == null) {
         return true;
      } else {
         int var12 = var5 * 64 + var2 * 128;
         int var13 = var6 * 64 + var3 * 128;
         return this.newGameObject(var1, var2, var3, var5, var6, var12, var13, var4, var7, var8, false, var9, var11);
      }
   }

   public void removeWallDecoration(int var1, int var2, int var3) {
      Tile var4 = this.tiles[var1][var2][var3];
      if (var4 != null) {
         var4.wallDecoration = null;
      }
   }

   static boolean method2236(int var0, int var1, int var2) {
      int var3 = var0 * field1193 + var2 * field1192 >> 16;
      int var4 = var2 * field1193 - var0 * field1192 >> 16;
      int var5 = var4 * field1191 + field1164 * var1 >> 16;
      int var6 = field1191 * var1 - var4 * field1164 >> 16;
      if (var5 >= 50 && var5 <= 3500) {
         int var7 = var3 * 128 / var5 + field1225;
         int var8 = var6 * 128 / var5 + field1168;
         return var7 >= field1199 && var7 <= field1229 && var8 >= field1228 && var8 <= field1230;
      } else {
         return false;
      }
   }

   public static void method2336(int[] var0, int var1, int var2, int var3, int var4) {
      field1199 = 0;
      field1228 = 0;
      field1229 = var3;
      field1230 = var4;
      field1225 = var3 / 2;
      field1168 = var4 / 2;
      boolean[][][][] var5 = new boolean[var0.length][32][53][53];

      int var6;
      int var7;
      int var8;
      int var9;
      int var11;
      int var12;
      for(var6 = 128; var6 <= 383; var6 += 32) {
         for(var7 = 0; var7 < 2048; var7 += 64) {
            field1164 = Rasterizer3D.field1446[var6];
            field1191 = Rasterizer3D.field1453[var6];
            field1192 = Rasterizer3D.field1446[var7];
            field1193 = Rasterizer3D.field1453[var7];
            var8 = (var6 - 128) / 32;
            var9 = var7 / 64;

            for(int var10 = -26; var10 < 26; ++var10) {
               for(var11 = -26; var11 < 26; ++var11) {
                  var12 = var10 * 128;
                  int var13 = var11 * 128;
                  boolean var14 = false;

                  for(int var15 = -var1; var15 <= var2; var15 += 128) {
                     if (method2236(var12, var0[var8] + var15, var13)) {
                        var14 = true;
                        break;
                     }
                  }

                  var5[var8][var9][var10 + 1 + 25][var11 + 1 + 25] = var14;
               }
            }
         }
      }

      for(var6 = 0; var6 < 8; ++var6) {
         for(var7 = 0; var7 < 32; ++var7) {
            for(var8 = -25; var8 < 25; ++var8) {
               for(var9 = -25; var9 < 25; ++var9) {
                  boolean var16 = false;

                  label76:
                  for(var11 = -1; var11 <= 1; ++var11) {
                     for(var12 = -1; var12 <= 1; ++var12) {
                        if (var5[var6][var7][var8 + var11 + 1 + 25][var9 + var12 + 1 + 25]) {
                           var16 = true;
                           break label76;
                        }

                        if (var5[var6][(var7 + 1) % 31][var8 + var11 + 1 + 25][var9 + var12 + 1 + 25]) {
                           var16 = true;
                           break label76;
                        }

                        if (var5[var6 + 1][var7][var8 + var11 + 1 + 25][var9 + var12 + 1 + 25]) {
                           var16 = true;
                           break label76;
                        }

                        if (var5[var6 + 1][(var7 + 1) % 31][var8 + var11 + 1 + 25][var9 + var12 + 1 + 25]) {
                           var16 = true;
                           break label76;
                        }
                     }
                  }

                  field1223[var6][var7][var8 + 25][var9 + 25] = var16;
               }
            }
         }
      }

   }

   public static void method2265() {
      field1180 = -1;
      field1201 = false;
   }

   public static boolean method2277() {
      return field1201 && field1180 != -1;
   }

   static boolean method2349(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      if (var1 < var2 && var1 < var3 && var1 < var4) {
         return false;
      } else if (var1 > var2 && var1 > var3 && var1 > var4) {
         return false;
      } else if (var0 < var5 && var0 < var6 && var0 < var7) {
         return false;
      } else if (var0 > var5 && var0 > var6 && var0 > var7) {
         return false;
      } else {
         int var8 = (var1 - var2) * (var6 - var5) - (var0 - var5) * (var3 - var2);
         int var9 = (var7 - var6) * (var1 - var3) - (var0 - var6) * (var4 - var3);
         int var10 = (var5 - var7) * (var1 - var4) - (var2 - var4) * (var0 - var7);
         if (var8 == 0) {
            if (var9 != 0) {
               return var9 < 0 ? var10 <= 0 : var10 >= 0;
            } else {
               return true;
            }
         } else {
            return var8 < 0 ? var9 <= 0 && var10 <= 0 : var9 >= 0 && var10 >= 0;
         }
      }
   }

   static final int method2270(int var0, int var1) {
      var1 = (var0 & 127) * var1 >> 7;
      if (var1 < 2) {
         var1 = 2;
      } else if (var1 > 126) {
         var1 = 126;
      }

      return (var0 & 'ﾀ') + var1;
   }

   public static void method2228(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      Occluder var8 = new Occluder();
      var8.minTileX = var2 / 128;
      var8.maxTileX = var3 / 128;
      var8.minTileY = var4 / 128;
      var8.maxTileY = var5 / 128;
      var8.type = var1;
      var8.minX = var2;
      var8.maxX = var3;
      var8.minZ = var4;
      var8.maxZ = var5;
      var8.minY = var6;
      var8.maxY = var7;
      field1198[var0][field1224[var0]++] = var8;
   }
}
