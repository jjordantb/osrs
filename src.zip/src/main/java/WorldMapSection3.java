public class WorldMapSection3 implements WorldMapSection {
   static Widget[] field615;
   static Font field625;
   int field617;
   int field618;
   int field616;
   int field624;
   int field623;
   int field619;
   int field622;
   int field627;
   int field614;
   int field621;

   public TileLocation vmethod1861(int var1, int var2) {
      if (!this.vmethod1857(var1, var2)) {
         return null;
      } else {
         int var3 = this.field616 * 64 - this.field617 * 64 + var1;
         int var4 = this.field627 * 64 - this.field621 * 64 + var2;
         return new TileLocation(this.field624, var3, var4);
      }
   }

   public boolean vmethod1857(int var1, int var2) {
      return var1 >> 6 >= this.field617 && var1 >> 6 <= this.field622 && var2 >> 6 >= this.field621 && var2 >> 6 <= this.field623;
   }

   public void vmethod1855(WorldMapData var1) {
      if (var1.field881 > this.field617) {
         var1.field881 = this.field617;
      }

      if (var1.field882 < this.field622) {
         var1.field882 = this.field622;
      }

      if (var1.field877 > this.field621) {
         var1.field877 = this.field621;
      }

      if (var1.field886 < this.field623) {
         var1.field886 = this.field623;
      }

   }

   public void read(Buffer var1) {
      this.field624 = var1.readUnsignedByte();
      this.field614 = var1.readUnsignedByte();
      this.field616 = var1.method3913();
      this.field627 = var1.method3913();
      this.field618 = var1.method3913();
      this.field619 = var1.method3913();
      this.field617 = var1.method3913();
      this.field621 = var1.method3913();
      this.field622 = var1.method3913();
      this.field623 = var1.method3913();
      this.method1169();
   }

   void method1169() {
   }

   public int[] vmethod1858(int var1, int var2, int var3) {
      if (!this.vmethod1856(var1, var2, var3)) {
         return null;
      } else {
         int[] var4 = new int[]{this.field617 * 64 - this.field616 * 64 + var2, var3 + (this.field621 * 64 - this.field627 * 64)};
         return var4;
      }
   }

   public boolean vmethod1856(int var1, int var2, int var3) {
      if (var1 >= this.field624 && var1 < this.field614 + this.field624) {
         return var2 >> 6 >= this.field616 && var2 >> 6 <= this.field618 && var3 >> 6 >= this.field627 && var3 >> 6 <= this.field619;
      } else {
         return false;
      }
   }

   public static Widget method1148(int var0) {
      int var1 = var0 >> 16;
      int var2 = var0 & '\uffff';
      if (UserComparator3.field1708[var1] == null || UserComparator3.field1708[var1][var2] == null) {
         boolean var3 = class196.method4189(var1);
         if (!var3) {
            return null;
         }
      }

      return UserComparator3.field1708[var1][var2];
   }

   static int method1173(int var0, Script var1, boolean var2) {
      Widget var3;
      if (var0 >= 2000) {
         var0 -= 1000;
         var3 = method1148(Interpreter.field467[--class31.field364]);
      } else {
         var3 = var2 ? class85.field961 : Interpreter.field477;
      }

      String var4 = Interpreter.field462[--Interpreter.field469];
      int[] var5 = null;
      if (var4.length() > 0 && var4.charAt(var4.length() - 1) == 'Y') {
         int var6 = Interpreter.field467[--class31.field364];
         if (var6 > 0) {
            for(var5 = new int[var6]; var6-- > 0; var5[var6] = Interpreter.field467[--class31.field364]) {
               ;
            }
         }

         var4 = var4.substring(0, var4.length() - 1);
      }

      Object[] var8 = new Object[var4.length() + 1];

      int var7;
      for(var7 = var8.length - 1; var7 >= 1; --var7) {
         if (var4.charAt(var7 - 1) == 's') {
            var8[var7] = Interpreter.field462[--Interpreter.field469];
         } else {
            var8[var7] = new Integer(Interpreter.field467[--class31.field364]);
         }
      }

      var7 = Interpreter.field467[--class31.field364];
      if (var7 != -1) {
         var8[0] = new Integer(var7);
      } else {
         var8 = null;
      }

      if (var0 == 1400) {
         var3.onClick = var8;
      } else if (var0 == 1401) {
         var3.onHold = var8;
      } else if (var0 == 1402) {
         var3.onRelease = var8;
      } else if (var0 == 1403) {
         var3.onMouseOver = var8;
      } else if (var0 == 1404) {
         var3.onMouseLeave = var8;
      } else if (var0 == 1405) {
         var3.onDrag = var8;
      } else if (var0 == 1406) {
         var3.onTargetLeave = var8;
      } else if (var0 == 1407) {
         var3.onVarTransmit = var8;
         var3.varTransmitTriggers = var5;
      } else if (var0 == 1408) {
         var3.onTimer = var8;
      } else if (var0 == 1409) {
         var3.onOp = var8;
      } else if (var0 == 1410) {
         var3.onDragComplete = var8;
      } else if (var0 == 1411) {
         var3.onClickRepeat = var8;
      } else if (var0 == 1412) {
         var3.onMouseRepeat = var8;
      } else if (var0 == 1414) {
         var3.onInvTransmit = var8;
         var3.invTransmitTriggers = var5;
      } else if (var0 == 1415) {
         var3.onStatTransmit = var8;
         var3.statTransmitTriggers = var5;
      } else if (var0 == 1416) {
         var3.onTargetEnter = var8;
      } else if (var0 == 1417) {
         var3.onScroll = var8;
      } else if (var0 == 1418) {
         var3.field2696 = var8;
      } else if (var0 == 1419) {
         var3.field2587 = var8;
      } else if (var0 == 1420) {
         var3.field2698 = var8;
      } else if (var0 == 1421) {
         var3.field2668 = var8;
      } else if (var0 == 1422) {
         var3.field2700 = var8;
      } else if (var0 == 1423) {
         var3.field2710 = var8;
      } else if (var0 == 1424) {
         var3.field2702 = var8;
      } else if (var0 == 1425) {
         var3.field2704 = var8;
      } else if (var0 == 1426) {
         var3.field2717 = var8;
      } else {
         if (var0 != 1427) {
            return 2;
         }

         var3.field2703 = var8;
      }

      var3.hasListener = true;
      return 1;
   }

   static final void method1172(String var0) {
      class6.method183(var0 + " is already on your friend list");
   }

   static final boolean method1174(Widget var0) {
      if (var0.cs1Comparisons == null) {
         return false;
      } else {
         for(int var1 = 0; var1 < var0.cs1Comparisons.length; ++var1) {
            int var2 = class39.method970(var0, var1);
            int var3 = var0.cs1ComparisonValues[var1];
            if (var0.cs1Comparisons[var1] == 2) {
               if (var2 >= var3) {
                  return false;
               }
            } else if (var0.cs1Comparisons[var1] == 3) {
               if (var2 <= var3) {
                  return false;
               }
            } else if (var0.cs1Comparisons[var1] == 4) {
               if (var3 == var2) {
                  return false;
               }
            } else if (var3 != var2) {
               return false;
            }
         }

         return true;
      }
   }
}
