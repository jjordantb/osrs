public class class257 implements Enumerated {
   static final class257 field3321 = new class257(0, 2);
   static final class257 field3315 = new class257(2, 0);
   static final class257 field3316 = new class257(1, 1);
   final int field3319;
   public final int field3317;

   class257(int var1, int var2) {
      this.field3317 = var1;
      this.field3319 = var2;
   }

   public int ordinal() {
      return this.field3319;
   }

   public static boolean method5070(char var0) {
      return var0 >= '0' && var0 <= '9' || var0 >= 'A' && var0 <= 'Z' || var0 >= 'a' && var0 <= 'z';
   }

   static void method5062(int var0, int var1) {
      if (Client.field2320 != 0 && var0 != -1) {
         BufferedNetSocket.available(IsaacCipher.field2480, var0, 0, Client.field2320, false);
         Client.field2322 = true;
      }

   }

   static int method5068(Widget var0) {
      IntegerNode var1 = (IntegerNode) Client.field2243.get(((long)var0.id << 32) + (long)var0.childIndex);
      return var1 != null ? var1.integer : var0.clickMask;
   }
}
