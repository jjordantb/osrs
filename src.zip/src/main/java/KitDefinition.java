public class KitDefinition extends DualNode {
   public static int field3344;
   public static AbstractIndexCache field3354;
   static EvictingDualNodeHashTable field3345 = new EvictingDualNodeHashTable(64);
   public static AbstractIndexCache field3343;
   short[] recolorFrom;
   public int field3342 = -1;
   short[] retextureTo;
   int[] field3347;
   public boolean field3353 = false;
   short[] retextureFrom;
   int[] archives = new int[]{-1, -1, -1, -1, -1};
   short[] recolorTo;

   public ModelData method5088() {
      if (this.field3347 == null) {
         return null;
      } else {
         ModelData[] var1 = new ModelData[this.field3347.length];

         for(int var2 = 0; var2 < this.field3347.length; ++var2) {
            var1[var2] = ModelData.method2741(field3343, this.field3347[var2], 0);
         }

         ModelData var4;
         if (var1.length == 1) {
            var4 = var1[0];
         } else {
            var4 = new ModelData(var1, var1.length);
         }

         int var3;
         if (this.recolorFrom != null) {
            for(var3 = 0; var3 < this.recolorFrom.length; ++var3) {
               var4.recolor(this.recolorFrom[var3], this.recolorTo[var3]);
            }
         }

         if (this.retextureFrom != null) {
            for(var3 = 0; var3 < this.retextureFrom.length; ++var3) {
               var4.retexture(this.retextureFrom[var3], this.retextureTo[var3]);
            }
         }

         return var4;
      }
   }

   void readNext(Buffer var1, int var2) {
      if (var2 == 1) {
         this.field3342 = var1.readUnsignedByte();
      } else {
         int var3;
         int var4;
         if (var2 == 2) {
            var3 = var1.readUnsignedByte();
            this.field3347 = new int[var3];

            for(var4 = 0; var4 < var3; ++var4) {
               this.field3347[var4] = var1.method3913();
            }
         } else if (var2 == 3) {
            this.field3353 = true;
         } else if (var2 == 40) {
            var3 = var1.readUnsignedByte();
            this.recolorFrom = new short[var3];
            this.recolorTo = new short[var3];

            for(var4 = 0; var4 < var3; ++var4) {
               this.recolorFrom[var4] = (short)var1.method3913();
               this.recolorTo[var4] = (short)var1.method3913();
            }
         } else if (var2 == 41) {
            var3 = var1.readUnsignedByte();
            this.retextureFrom = new short[var3];
            this.retextureTo = new short[var3];

            for(var4 = 0; var4 < var3; ++var4) {
               this.retextureFrom[var4] = (short)var1.method3913();
               this.retextureTo[var4] = (short)var1.method3913();
            }
         } else if (var2 >= 60 && var2 < 70) {
            this.archives[var2 - 60] = var1.method3913();
         }
      }

   }

   public boolean method5092() {
      boolean var1 = true;

      for(int var2 = 0; var2 < 5; ++var2) {
         if (this.archives[var2] != -1 && !field3343.tryLoadRecord(this.archives[var2], 0)) {
            var1 = false;
         }
      }

      return var1;
   }

   public ModelData method5093() {
      ModelData[] var1 = new ModelData[5];
      int var2 = 0;

      for(int var3 = 0; var3 < 5; ++var3) {
         if (this.archives[var3] != -1) {
            var1[var2++] = ModelData.method2741(field3343, this.archives[var3], 0);
         }
      }

      ModelData var5 = new ModelData(var1, var2);
      int var4;
      if (this.recolorFrom != null) {
         for(var4 = 0; var4 < this.recolorFrom.length; ++var4) {
            var5.recolor(this.recolorFrom[var4], this.recolorTo[var4]);
         }
      }

      if (this.retextureFrom != null) {
         for(var4 = 0; var4 < this.retextureFrom.length; ++var4) {
            var5.retexture(this.retextureFrom[var4], this.retextureTo[var4]);
         }
      }

      return var5;
   }

   public boolean method5091() {
      if (this.field3347 == null) {
         return true;
      } else {
         boolean var1 = true;

         for(int var2 = 0; var2 < this.field3347.length; ++var2) {
            if (!field3343.tryLoadRecord(this.field3347[var2], 0)) {
               var1 = false;
            }
         }

         return var1;
      }
   }

   void read(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.readNext(var1, var2);
      }
   }

   static final void read(byte[] var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, CollisionMap[] var8) {
      int var10;
      for(int var9 = 0; var9 < 8; ++var9) {
         for(var10 = 0; var10 < 8; ++var10) {
            if (var9 + var2 > 0 && var9 + var2 < 103 && var3 + var10 > 0 && var3 + var10 < 103) {
               var8[var1].flags[var9 + var2][var3 + var10] &= -16777217;
            }
         }
      }

      Buffer var28 = new Buffer(var0);

      for(var10 = 0; var10 < 4; ++var10) {
         for(int var11 = 0; var11 < 64; ++var11) {
            for(int var12 = 0; var12 < 64; ++var12) {
               if (var10 == var4 && var11 >= var5 && var11 < var5 + 8 && var12 >= var6 && var12 < var6 + 8) {
                  int var17 = var11 & 7;
                  int var18 = var12 & 7;
                  int var19 = var7 & 3;
                  int var16;
                  if (var19 == 0) {
                     var16 = var17;
                  } else if (var19 == 1) {
                     var16 = var18;
                  } else if (var19 == 2) {
                     var16 = 7 - var17;
                  } else {
                     var16 = 7 - var18;
                  }

                  int var22 = var2 + var16;
                  int var25 = var11 & 7;
                  int var26 = var12 & 7;
                  int var27 = var7 & 3;
                  int var24;
                  if (var27 == 0) {
                     var24 = var26;
                  } else if (var27 == 1) {
                     var24 = 7 - var25;
                  } else if (var27 == 2) {
                     var24 = 7 - var26;
                  } else {
                     var24 = var25;
                  }

                  Skeleton.method2197(var28, var1, var22, var3 + var24, 0, 0, var7);
               } else {
                  Skeleton.method2197(var28, 0, -1, -1, 0, 0, 0);
               }
            }
         }
      }

   }
}
