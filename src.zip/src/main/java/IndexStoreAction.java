public class IndexStoreAction extends Node {
   IndexStore indexStore;
   int type;
   IndexCache indexCache;
   byte[] data;

   public static StudioGame[] method4777() {
      return new StudioGame[]{StudioGame.field3334, StudioGame.field3339, StudioGame.field3336, StudioGame.field3338, StudioGame.field3335, StudioGame.field3337};
   }

   public static void method4778() {
      class321.field3914 = new IterableNodeDeque();
   }

   public static String method4779(CharSequence var0) {
      int var2 = var0.length();
      char[] var3 = new char[var2];

      for(int var4 = 0; var4 < var2; ++var4) {
         var3[var4] = '*';
      }

      String var1 = new String(var3);
      return var1;
   }
}
