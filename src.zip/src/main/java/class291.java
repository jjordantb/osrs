public class class291 {
   static final class291 field3712 = new class291(2);
   static final class291 field3714 = new class291(0);
   public static final class291 field3711 = new class291(1);
   public final int field3713;

   class291(int var1) {
      this.field3713 = var1;
   }
}
