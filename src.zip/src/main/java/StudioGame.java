public class StudioGame implements Enumerated {
   static final StudioGame field3337 = new StudioGame("game5", "Game 5", 4);
   static final StudioGame field3335 = new StudioGame("game3", "Game 3", 2);
   static final StudioGame field3339 = new StudioGame("runescape", "RuneScape", 0);
   static int[] field3341;
   public static final StudioGame field3338 = new StudioGame("oldscape", "RuneScape 2007", 5);
   static final StudioGame field3336 = new StudioGame("game4", "Game 4", 3);
   static final StudioGame field3334 = new StudioGame("stellardawn", "Stellar Dawn", 1);
   public final String name;
   final int id;

   StudioGame(String var1, String var2, int var3) {
      this.name = var1;
      this.id = var3;
   }

   public int ordinal() {
      return this.id;
   }

   public static int method5078(CharSequence var0, int var1, int var2, byte[] var3, int var4) {
      int var5 = var2 - var1;

      for(int var6 = 0; var6 < var5; ++var6) {
         char var7 = var0.charAt(var6 + var1);
         if (var7 > 0 && var7 < '\u0080' || var7 >= ' ' && var7 <= 'ÿ') {
            var3[var6 + var4] = (byte)var7;
         } else if (var7 == '€') {
            var3[var6 + var4] = -128;
         } else if (var7 == '‚') {
            var3[var6 + var4] = -126;
         } else if (var7 == 'ƒ') {
            var3[var6 + var4] = -125;
         } else if (var7 == '„') {
            var3[var6 + var4] = -124;
         } else if (var7 == '…') {
            var3[var6 + var4] = -123;
         } else if (var7 == '†') {
            var3[var6 + var4] = -122;
         } else if (var7 == '‡') {
            var3[var6 + var4] = -121;
         } else if (var7 == 'ˆ') {
            var3[var6 + var4] = -120;
         } else if (var7 == '‰') {
            var3[var6 + var4] = -119;
         } else if (var7 == 'Š') {
            var3[var6 + var4] = -118;
         } else if (var7 == '‹') {
            var3[var6 + var4] = -117;
         } else if (var7 == 'Œ') {
            var3[var6 + var4] = -116;
         } else if (var7 == 'Ž') {
            var3[var6 + var4] = -114;
         } else if (var7 == '‘') {
            var3[var6 + var4] = -111;
         } else if (var7 == '’') {
            var3[var6 + var4] = -110;
         } else if (var7 == '“') {
            var3[var6 + var4] = -109;
         } else if (var7 == '”') {
            var3[var6 + var4] = -108;
         } else if (var7 == '•') {
            var3[var6 + var4] = -107;
         } else if (var7 == '–') {
            var3[var6 + var4] = -106;
         } else if (var7 == '—') {
            var3[var6 + var4] = -105;
         } else if (var7 == '˜') {
            var3[var6 + var4] = -104;
         } else if (var7 == '™') {
            var3[var6 + var4] = -103;
         } else if (var7 == 'š') {
            var3[var6 + var4] = -102;
         } else if (var7 == '›') {
            var3[var6 + var4] = -101;
         } else if (var7 == 'œ') {
            var3[var6 + var4] = -100;
         } else if (var7 == 'ž') {
            var3[var6 + var4] = -98;
         } else if (var7 == 'Ÿ') {
            var3[var6 + var4] = -97;
         } else {
            var3[var6 + var4] = 63;
         }
      }

      return var5;
   }

   public static void method5087(int[] var0, int[] var1) {
      if (var0 != null && var1 != null) {
         class83.field940 = var0;
         ByteArrayPool.field2464 = new int[var0.length];
         FriendLoginUpdate.field3772 = new byte[var0.length][][];

         for(int var2 = 0; var2 < class83.field940.length; ++var2) {
            FriendLoginUpdate.field3772[var2] = new byte[var1[var2]][];
         }

      } else {
         class83.field940 = null;
         ByteArrayPool.field2464 = null;
         FriendLoginUpdate.field3772 = null;
      }
   }

   public static boolean method5085(char var0) {
      return var0 >= 'A' && var0 <= 'Z' || var0 >= 'a' && var0 <= 'z';
   }
}
