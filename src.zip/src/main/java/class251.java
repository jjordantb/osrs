public class class251 {
   static int field3254;

   static final byte[] method4942(byte[] var0) {
      Buffer var1 = new Buffer(var0);
      int var2 = var1.readUnsignedByte();
      int var3 = var1.readInt();
      if (var3 < 0 || AbstractIndexCache.field3268 != 0 && var3 > AbstractIndexCache.field3268) {
         throw new RuntimeException();
      } else if (var2 == 0) {
         byte[] var4 = new byte[var3];
         var1.method3923(var4, 0, var3);
         return var4;
      } else {
         int var6 = var1.readInt();
         if (var6 < 0 || AbstractIndexCache.field3268 != 0 && var6 > AbstractIndexCache.field3268) {
            throw new RuntimeException();
         } else {
            byte[] var5 = new byte[var6];
            if (var2 == 1) {
               Bzip2Decompressor.method3140(var5, var6, var0, var3, 9);
            } else {
               AbstractIndexCache.field3276.decompress(var1, var5);
            }

            return var5;
         }
      }
   }

   static boolean method4941() {
      return (Client.field2119 & 8) != 0;
   }

   static final void method4943(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      class37 var9 = null;

      for(class37 var10 = (class37) Client.field2131.last(); var10 != null; var10 = (class37) Client.field2131.previous()) {
         if (var0 == var10.field458 && var10.field446 == var1 && var2 == var10.field449 && var3 == var10.field450) {
            var9 = var10;
            break;
         }
      }

      if (var9 == null) {
         var9 = new class37();
         var9.field458 = var0;
         var9.field450 = var3;
         var9.field446 = var1;
         var9.field449 = var2;
         class10.method351(var9);
         Client.field2131.addFirst(var9);
      }

      var9.field453 = var4;
      var9.field455 = var5;
      var9.field454 = var6;
      var9.field456 = var7;
      var9.field457 = var8;
   }
}
