import java.util.Comparator;

public class OwnWorldComparator implements Comparator {
   static int[] field274;
   boolean field270;

   int method607(GrandExchangeEvent var1, GrandExchangeEvent var2) {
      if (var2.world == var1.world) {
         return 0;
      } else {
         if (this.field270) {
            if (Client.field2134 == var1.world) {
               return -1;
            }

            if (var2.world == Client.field2134) {
               return 1;
            }
         }

         return var1.world < var2.world ? -1 : 1;
      }
   }

   public boolean equals(Object var1) {
      return super.equals(var1);
   }

   public int compare(Object var1, Object var2) {
      return this.method607((GrandExchangeEvent)var1, (GrandExchangeEvent)var2);
   }

   static void method617() {
      Players.field951 = 0;

      for(int var0 = 0; var0 < 2048; ++var0) {
         Players.field958[var0] = null;
         Players.field949[var0] = 1;
      }

   }

   static void method616(int var0, int var1, int var2, int var3) {
      Widget var4 = class71.method1467(var0, var1);
      if (var4 != null && var4.onTargetEnter != null) {
         ScriptEvent var5 = new ScriptEvent();
         var5.widget = var4;
         var5.args = var4.onTargetEnter;
         IndexCacheLoader.method1096(var5);
      }

      Client.field2177 = var3;
      Client.field2241 = true;
      class299.field3748 = var0;
      Client.field2242 = var1;
      FontName.field3737 = var2;
      WorldMapSection1.method506(var4);
   }
}
