public class WorldMapIcon {
   public static String field251;
   static AbstractIndexCache field249;
   int field243;
   final int field247;
   public final TileLocation field246;
   public final int field252;
   final WorldMapLabel label;
   final int field248;
   public final TileLocation field244;
   int field250;

   WorldMapIcon(int var1, TileLocation var2, TileLocation var3, WorldMapLabel var4) {
      this.field252 = var1;
      this.field246 = var2;
      this.field244 = var3;
      this.label = var4;
      AreaDefinition var5 = Clock.mark(this.field252);
      Sprite var6 = var5.getSprite(false);
      if (var6 != null) {
         this.field248 = var6.subWidth;
         this.field247 = var6.subHeight;
      } else {
         this.field248 = 0;
         this.field247 = 0;
      }

   }

   boolean method551(int var1, int var2) {
      if (this.label == null) {
         return false;
      } else if (var1 >= this.field243 - this.label.width / 2 && var1 <= this.label.width / 2 + this.field243) {
         return var2 >= this.field250 && var2 <= this.label.height + this.field250;
      } else {
         return false;
      }
   }

   boolean method554(int var1, int var2) {
      if (this.method549(var1, var2)) {
         return true;
      } else {
         return this.method551(var1, var2);
      }
   }

   boolean method549(int var1, int var2) {
      AreaDefinition var3 = Clock.mark(this.field252);
      switch(var3.field2894.field3530) {
      case 0:
         if (var1 > this.field243 - this.field248 && var1 <= this.field243) {
            break;
         }

         return false;
      case 1:
         if (var1 >= this.field243 - this.field248 / 2 && var1 <= this.field248 / 2 + this.field243) {
            break;
         }

         return false;
      case 2:
         if (var1 < this.field243 || var1 >= this.field248 + this.field243) {
            return false;
         }
      }

      switch(var3.field2898.field3317) {
      case 0:
         if (var2 >= this.field250 && var2 < this.field250 + this.field247) {
            break;
         }

         return false;
      case 1:
         if (var2 < this.field250 - this.field247 / 2 || var2 > this.field247 / 2 + this.field250) {
            return false;
         }
         break;
      case 2:
         if (var2 <= this.field250 - this.field247 || var2 > this.field250) {
            return false;
         }
      }

      return true;
   }
}
