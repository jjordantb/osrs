public class class273 {
   static IndexedSprite[] field3514;

   static void method5344(int var0, int var1, int var2, boolean var3, int var4, boolean var5) {
      if (var0 < var1) {
         int var6 = (var0 + var1) / 2;
         int var7 = var0;
         World var8 = World.field353[var6];
         World.field353[var6] = World.field353[var1];
         World.field353[var1] = var8;

         for(int var9 = var0; var9 < var1; ++var9) {
            World var11 = World.field353[var9];
            int var12 = WallDecoration.method2958(var11, var8, var2, var3);
            int var10;
            if (var12 != 0) {
               if (var3) {
                  var10 = -var12;
               } else {
                  var10 = var12;
               }
            } else if (var4 == -1) {
               var10 = 0;
            } else {
               int var13 = WallDecoration.method2958(var11, var8, var4, var5);
               if (var5) {
                  var10 = -var13;
               } else {
                  var10 = var13;
               }
            }

            if (var10 <= 0) {
               World var14 = World.field353[var9];
               World.field353[var9] = World.field353[var7];
               World.field353[var7++] = var14;
            }
         }

         World.field353[var1] = World.field353[var7];
         World.field353[var7] = var8;
         method5344(var0, var7 - 1, var2, var3, var4, var5);
         method5344(var7 + 1, var1, var2, var3, var4, var5);
      }

   }

   static final void method5343(IndexedSprite var0) {
      short var1 = 256;

      int var2;
      for(var2 = 0; var2 < OwnWorldComparator.field274.length; ++var2) {
         OwnWorldComparator.field274[var2] = 0;
      }

      int var3;
      for(var2 = 0; var2 < 5000; ++var2) {
         var3 = (int)(Math.random() * 128.0D * (double)var1);
         OwnWorldComparator.field274[var3] = (int)(Math.random() * 256.0D);
      }

      int var4;
      int var5;
      for(var2 = 0; var2 < 20; ++var2) {
         for(var3 = 1; var3 < var1 - 1; ++var3) {
            for(var4 = 1; var4 < 127; ++var4) {
               var5 = var4 + (var3 << 7);
               class25.field263[var5] = (OwnWorldComparator.field274[var5 - 128] + OwnWorldComparator.field274[var5 + 1] + OwnWorldComparator.field274[var5 + 128] + OwnWorldComparator.field274[var5 - 1]) / 4;
            }
         }

         int[] var8 = OwnWorldComparator.field274;
         OwnWorldComparator.field274 = class25.field263;
         class25.field263 = var8;
      }

      if (var0 != null) {
         var2 = 0;

         for(var3 = 0; var3 < var0.subHeight; ++var3) {
            for(var4 = 0; var4 < var0.subWidth; ++var4) {
               if (var0.pixels[var2++] != 0) {
                  var5 = var4 + var0.xOffset + 16;
                  int var6 = var3 + var0.yOffset + 16;
                  int var7 = var5 + (var6 << 7);
                  OwnWorldComparator.field274[var7] = 0;
               }
            }
         }
      }

   }
}
