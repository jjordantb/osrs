import java.util.Date;
import netscape.javascript.JSObject;

public class class285 {
   static void method5571(String var0) {
      class57.field644 = var0;

      try {
         String var1 = class178.field1984.getParameter(ClientParameter.field3546.id);
         String var2 = class178.field1984.getParameter(ClientParameter.field3549.id);
         String var3 = var1 + "settings=" + var0 + "; version=1; path=/; domain=" + var2;
         String var5;
         if (var0.length() == 0) {
            var3 = var3 + "; Expires=Thu, 01-Jan-1970 00:00:00 GMT; Max-Age=0";
         } else {
            String var4 = var3 + "; Expires=";
            long var6 = Tile.method2779() + 94608000000L;
            class189.field2392.setTime(new Date(var6));
            int var8 = class189.field2392.get(7);
            int var9 = class189.field2392.get(5);
            int var10 = class189.field2392.get(2);
            int var11 = class189.field2392.get(1);
            int var12 = class189.field2392.get(11);
            int var13 = class189.field2392.get(12);
            int var14 = class189.field2392.get(13);
            var5 = class189.field2395[var8 - 1] + ", " + var9 / 10 + var9 % 10 + "-" + class189.field2393[0][var10] + "-" + var11 + " " + var12 / 10 + var12 % 10 + ":" + var13 / 10 + var13 % 10 + ":" + var14 / 10 + var14 % 10 + " GMT";
            var3 = var4 + var5 + "; Max-Age=" + 94608000L;
         }

         Client var16 = class178.field1984;
         var5 = "document.cookie=\"" + var3 + "\"";
         JSObject.getWindow(var16).eval(var5);
      } catch (Throwable var15) {
         ;
      }

   }
}
