public class Strings {
   public static String field3007 = "Please visit the support page for assistance.";
   public static String field3046 = "Please visit the support page for assistance.";
   public static String field3041 = "";
   public static String field3216 = "Page has opened in a new window.";
   public static String field3179 = "(Please check your popup blocker.)";

   public static boolean method4940(char var0) {
      return var0 >= '0' && var0 <= '9';
   }
}
