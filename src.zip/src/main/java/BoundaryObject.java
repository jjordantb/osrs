import java.io.IOException;

public final class BoundaryObject {
   public Entity entity2;
   int orientationB;
   int y;
   int tileHeight;
   public Entity entity1;
   int flags = 0;
   int orientationA;
   int x;
   public long tag = 0L;

   public static boolean method2829() {
      long var0 = Tile.method2779();
      int var2 = (int)(var0 - NetCache.field2830);
      NetCache.field2830 = var0;
      if (var2 > 200) {
         var2 = 200;
      }

      NetCache.field2842 += var2;
      if (NetCache.field2839 == 0 && NetCache.field2834 == 0 && NetCache.field2837 == 0 && NetCache.field2832 == 0) {
         return true;
      } else if (NetCache.field2833 == null) {
         return false;
      } else {
         try {
            if (NetCache.field2842 > 30000) {
               throw new IOException();
            } else {
               NetFileRequest var3;
               Buffer var4;
               while(NetCache.field2834 < 200 && NetCache.field2832 > 0) {
                  var3 = (NetFileRequest)NetCache.field2840.first();
                  var4 = new Buffer(4);
                  var4.writeByte(1);
                  var4.writeMedium((int)var3.key);
                  NetCache.field2833.write(var4.array, 0, 4);
                  NetCache.field2831.put(var3, var3.key);
                  --NetCache.field2832;
                  ++NetCache.field2834;
               }

               while(NetCache.field2839 < 200 && NetCache.field2837 > 0) {
                  var3 = (NetFileRequest)NetCache.field2835.last();
                  var4 = new Buffer(4);
                  var4.writeByte(0);
                  var4.writeMedium((int)var3.key);
                  NetCache.field2833.write(var4.array, 0, 4);
                  var3.removeDual();
                  NetCache.field2838.put(var3, var3.key);
                  --NetCache.field2837;
                  ++NetCache.field2839;
               }

               for(int var15 = 0; var15 < 100; ++var15) {
                  int var16 = NetCache.field2833.available();
                  if (var16 < 0) {
                     throw new IOException();
                  }

                  if (var16 == 0) {
                     break;
                  }

                  NetCache.field2842 = 0;
                  byte var5 = 0;
                  if (class205.field2491 == null) {
                     var5 = 8;
                  } else if (NetCache.field2846 == 0) {
                     var5 = 1;
                  }

                  int var6;
                  int var7;
                  int var8;
                  int var10;
                  if (var5 > 0) {
                     var6 = var5 - NetCache.field2828.index;
                     if (var6 > var16) {
                        var6 = var16;
                     }

                     NetCache.field2833.read(NetCache.field2828.array, NetCache.field2828.index, var6);
                     if (NetCache.field2849 != 0) {
                        for(var7 = 0; var7 < var6; ++var7) {
                           NetCache.field2828.array[var7 + NetCache.field2828.index] ^= NetCache.field2849;
                        }
                     }

                     NetCache.field2828.index += var6;
                     if (NetCache.field2828.index < var5) {
                        break;
                     }

                     if (class205.field2491 == null) {
                        NetCache.field2828.index = 0;
                        var7 = NetCache.field2828.readUnsignedByte();
                        var8 = NetCache.field2828.method3913();
                        int var9 = NetCache.field2828.readUnsignedByte();
                        var10 = NetCache.field2828.readInt();
                        long var11 = (long)(var8 + (var7 << 16));
                        NetFileRequest var13 = (NetFileRequest)NetCache.field2831.get(var11);
                        IndexStoreActionHandler.field2950 = true;
                        if (var13 == null) {
                           var13 = (NetFileRequest)NetCache.field2838.get(var11);
                           IndexStoreActionHandler.field2950 = false;
                        }

                        if (var13 == null) {
                           throw new IOException();
                        }

                        int var14 = var9 == 0 ? 5 : 9;
                        class205.field2491 = var13;
                        NetCache.field2841 = new Buffer(var10 + var14 + class205.field2491.padding);
                        NetCache.field2841.writeByte(var9);
                        NetCache.field2841.writeInt(var10);
                        NetCache.field2846 = 8;
                        NetCache.field2828.index = 0;
                     } else if (NetCache.field2846 == 0) {
                        if (NetCache.field2828.array[0] == -1) {
                           NetCache.field2846 = 1;
                           NetCache.field2828.index = 0;
                        } else {
                           class205.field2491 = null;
                        }
                     }
                  } else {
                     var6 = NetCache.field2841.array.length - class205.field2491.padding;
                     var7 = 512 - NetCache.field2846;
                     if (var7 > var6 - NetCache.field2841.index) {
                        var7 = var6 - NetCache.field2841.index;
                     }

                     if (var7 > var16) {
                        var7 = var16;
                     }

                     NetCache.field2833.read(NetCache.field2841.array, NetCache.field2841.index, var7);
                     if (NetCache.field2849 != 0) {
                        for(var8 = 0; var8 < var7; ++var8) {
                           NetCache.field2841.array[NetCache.field2841.index + var8] ^= NetCache.field2849;
                        }
                     }

                     NetCache.field2841.index += var7;
                     NetCache.field2846 += var7;
                     if (var6 == NetCache.field2841.index) {
                        if (class205.field2491.key == 16711935L) {
                           Login.field687 = NetCache.field2841;

                           for(var8 = 0; var8 < 256; ++var8) {
                              IndexCache var17 = NetCache.field2845[var8];
                              if (var17 != null) {
                                 Login.field687.index = var8 * 8 + 5;
                                 var10 = Login.field687.readInt();
                                 int var18 = Login.field687.readInt();
                                 var17.loadIndexReference(var10, var18);
                              }
                           }
                        } else {
                           NetCache.field2844.reset();
                           NetCache.field2844.update(NetCache.field2841.array, 0, var6);
                           var8 = (int)NetCache.field2844.getValue();
                           if (var8 != class205.field2491.crc) {
                              try {
                                 NetCache.field2833.close();
                              } catch (Exception var20) {
                                 ;
                              }

                              ++NetCache.field2847;
                              NetCache.field2833 = null;
                              NetCache.field2849 = (byte)((int)(Math.random() * 255.0D + 1.0D));
                              return false;
                           }

                           NetCache.field2847 = 0;
                           NetCache.field2848 = 0;
                           class205.field2491.indexCache.write((int)(class205.field2491.key & 65535L), NetCache.field2841.array, 16711680L == (class205.field2491.key & 16711680L), IndexStoreActionHandler.field2950);
                        }

                        class205.field2491.remove();
                        if (IndexStoreActionHandler.field2950) {
                           --NetCache.field2834;
                        } else {
                           --NetCache.field2839;
                        }

                        NetCache.field2846 = 0;
                        class205.field2491 = null;
                        NetCache.field2841 = null;
                     } else {
                        if (NetCache.field2846 != 512) {
                           break;
                        }

                        NetCache.field2846 = 0;
                     }
                  }
               }

               return true;
            }
         } catch (IOException var21) {
            try {
               NetCache.field2833.close();
            } catch (Exception var19) {
               ;
            }

            ++NetCache.field2848;
            NetCache.field2833 = null;
            return false;
         }
      }
   }
}
