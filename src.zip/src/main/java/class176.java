import java.util.HashMap;

public class class176 {
   public static AbstractIndexCache field1959;
   static Widget field1961;

   static {
      new HashMap();
   }
}
