public class ScriptEvent extends Node {
   static int field547;
   Widget dragTarget;
   int mouseY;
   Widget widget;
   Object[] args;
   String targetName;
   int opIndex;
   int field544 = 76;
   int keyPressed;
   int field543;
   int mouseX;
   boolean boolean1;
   int keyTyped;

   public void method1031(Object[] var1) {
      this.args = var1;
   }

   public void method1033(int var1) {
      this.field544 = var1;
   }

   static int method1042(int var0) {
      Message var1 = (Message)Messages.field611.get((long)var0);
      if (var1 == null) {
         return -1;
      } else {
         return var1.nextDual == Messages.field609.sentinel ? -1 : ((Message)var1.nextDual).count;
      }
   }

   static void method1034(int var0, boolean var1, int var2, boolean var3) {
      if (World.field353 != null) {
         class273.method5344(0, World.field353.length - 1, var0, var1, var2, var3);
      }

   }

   static void method1039(int var0, int var1) {
      int[] var2 = new int[9];

      for(int var3 = 0; var3 < var2.length; ++var3) {
         int var4 = var3 * 32 + 15 + 128;
         int var5 = var4 * 3 + 600;
         int var7 = Rasterizer3D.field1446[var4];
         int var9 = var1 - 334;
         if (var9 < 0) {
            var9 = 0;
         } else if (var9 > 100) {
            var9 = 100;
         }

         int var10 = (Client.field2341 - Client.field2340) * var9 / 100 + Client.field2340;
         int var8 = var10 * var5 / 256;
         var2[var3] = var7 * var8 >> 16;
      }

      Scene.method2336(var2, 500, 800, var0 * 334 / var1, 334);
   }
}
