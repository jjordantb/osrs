public class class245 {
   public static void method4906() {
      ParamKeyDefinition.field3443.clear();
   }
}
