public class User implements Comparable {
   Username username;
   Username previousUsername;

   public String name() {
      return this.username == null ? "" : this.username.name();
   }

   public String previousName() {
      return this.previousUsername == null ? "" : this.previousUsername.name();
   }

   public int compareTo0(User var1) {
      return this.username.compareTo0(var1.username);
   }

   void set(Username var1, Username var2) {
      if (var1 == null) {
         throw new NullPointerException();
      } else {
         this.username = var1;
         this.previousUsername = var2;
      }
   }

   public Username method5384() {
      return this.username;
   }

   public int compareTo(Object var1) {
      return this.compareTo0((User)var1);
   }

   public static String method5400(CharSequence var0) {
      String var1 = VarpDefinition.read(TileLocation.set(var0));
      if (var1 == null) {
         var1 = "";
      }

      return var1;
   }
}
