import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.Random;

public final class GroundItemPile {
   static int field1455;
   long tag;
   Entity second;
   int y;
   int tileHeight;
   Entity third;
   Entity first;
   int x;
   int height;

   static final boolean method2667(int var0, int var1) {
      ObjectDefinition var2 = class252.method4958(var0);
      if (var1 == 11) {
         var1 = 10;
      }

      if (var1 >= 5 && var1 <= 8) {
         var1 = 4;
      }

      return var2.method5175(var1);
   }

   static final int method2666(long var0, String var2) {
      Random var3 = new Random();
      Buffer var4 = new Buffer(128);
      Buffer var5 = new Buffer(128);
      int[] var6 = new int[]{var3.nextInt(), var3.nextInt(), (int)(var0 >> 32), (int)var0};
      var4.writeByte(10);

      int var7;
      for(var7 = 0; var7 < 4; ++var7) {
         var4.writeInt(var3.nextInt());
      }

      var4.writeInt(var6[0]);
      var4.writeInt(var6[1]);
      var4.writeLong(var0);
      var4.writeLong(0L);

      for(var7 = 0; var7 < 4; ++var7) {
         var4.writeInt(var3.nextInt());
      }

      var4.encryptRsa(class39.field482, class39.field487);
      var5.writeByte(10);

      for(var7 = 0; var7 < 3; ++var7) {
         var5.writeInt(var3.nextInt());
      }

      var5.writeLong(var3.nextLong());
      var5.writeLongMedium(var3.nextLong());
      VarpDefinition.method4912(var5);
      var5.writeLong(var3.nextLong());
      var5.encryptRsa(class39.field482, class39.field487);
      var7 = AbstractSoundSystem.method1696(var2);
      if (var7 % 8 != 0) {
         var7 += 8 - var7 % 8;
      }

      Buffer var8 = new Buffer(var7);
      var8.writeStringCp1252NullTerminated(var2);
      var8.index = var7;
      var8.xteaEncryptAll(var6);
      Buffer var9 = new Buffer(var5.index + var4.index + var8.index + 5);
      var9.writeByte(2);
      var9.writeByte(var4.index);
      var9.method3905(var4.array, 0, var4.index);
      var9.writeByte(var5.index);
      var9.method3905(var5.array, 0, var5.index);
      var9.writeShort(var8.index);
      var9.method3905(var8.array, 0, var8.index);
      byte[] var11 = var9.array;
      String var10 = ChatChannel.addMessage(var11, 0, var11.length);
      String var12 = var10;

      try {
         URL var13 = new URL(WidgetGroupParent.method999("services", false) + "m=accountappeal/login.ws");
         URLConnection var14 = var13.openConnection();
         var14.setDoInput(true);
         var14.setDoOutput(true);
         var14.setConnectTimeout(5000);
         OutputStreamWriter var15 = new OutputStreamWriter(var14.getOutputStream());
         var15.write("data2=" + class39.method982(var12) + "&dest=" + class39.method982("passwordchoice.ws"));
         var15.flush();
         InputStream var16 = var14.getInputStream();
         var9 = new Buffer(new byte[1000]);

         do {
            int var17 = var16.read(var9.array, var9.index, 1000 - var9.index);
            if (var17 == -1) {
               var15.close();
               var16.close();
               String var18 = new String(var9.array);
               if (var18.startsWith("OFFLINE")) {
                  return 4;
               } else if (var18.startsWith("WRONG")) {
                  return 7;
               } else if (var18.startsWith("RELOAD")) {
                  return 3;
               } else if (var18.startsWith("Not permitted for social network accounts.")) {
                  return 6;
               } else {
                  var9.xteaDecryptAll(var6);

                  while(var9.index > 0 && var9.array[var9.index - 1] == 0) {
                     --var9.index;
                  }

                  var18 = new String(var9.array, 0, var9.index);
                  if (Player.method856(var18)) {
                     UrlRequest.isDone(var18, true, false);
                     return 2;
                  } else {
                     return 5;
                  }
               }
            }

            var9.index += var17;
         } while(var9.index < 1000);

         return 5;
      } catch (Throwable var19) {
         var19.printStackTrace();
         return 5;
      }
   }
}
