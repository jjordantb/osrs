public abstract class AbstractIntNode extends Node {
   int integer;
}
