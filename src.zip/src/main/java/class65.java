public final class class65 {
   static IndexCache field801;
   int field798;
   int field802;
   int field799;
   int field796;

   WorldMapManager this$0;

   class65(WorldMapManager var1) {
      this.this$0 = var1;
   }

   public static boolean method1382(AbstractIndexCache var0, int var1, int var2) {
      byte[] var3 = var0.takeRecord(var1, var2);
      if (var3 == null) {
         return false;
      } else {
         TilePaint.method2436(var3);
         return true;
      }
   }

   public static void method1380() {
      KitDefinition.field3345.clear();
   }

   static World method1378() {
      return World.field350 < World.field349 ? World.field353[++World.field350 - 1] : null;
   }

   static int method1381() {
      return Client.field2118 ? 2 : 1;
   }

   static final WidgetGroupParent method1379(int var0, int var1, int var2) {
      WidgetGroupParent var3 = new WidgetGroupParent();
      var3.group = var1;
      var3.type = var2;
      Client.field2247.put(var3, (long)var0);
      class162.method3079(var1);
      Widget var4 = WorldMapSection3.method1148(var0);
      WorldMapSection1.method506(var4);
      if (Client.field2323 != null) {
         WorldMapSection1.method506(Client.field2323);
         Client.field2323 = null;
      }

      for(int var5 = 0; var5 < Client.field2223; ++var5) {
         if (VarcString.method4905(Client.field2226[var5])) {
            if (var5 < Client.field2223 - 1) {
               for(int var6 = var5; var6 < Client.field2223 - 1; ++var6) {
                  Client.field2359[var6] = Client.field2359[var6 + 1];
                  Client.field2229[var6] = Client.field2229[var6 + 1];
                  Client.field2226[var6] = Client.field2226[var6 + 1];
                  Client.field2227[var6] = Client.field2227[var6 + 1];
                  Client.field2224[var6] = Client.field2224[var6 + 1];
                  Client.field2225[var6] = Client.field2225[var6 + 1];
                  Client.field2215[var6] = Client.field2215[var6 + 1];
               }
            }

            --var5;
            --Client.field2223;
         }
      }

      Formatting.method1028();
      MusicPatch.method4734(UserComparator3.field1708[var0 >> 16], var4, false);
      class83.method1702(var1);
      if (Client.field2246 != -1) {
         WorldMapData2.method338(Client.field2246, 1);
      }

      return var3;
   }
}
