public class class17 {
   static Varcs field181;
   static MouseRecorder field180;
   static IndexedSprite[] field183;
   public TileLocation field178;
   public int field176;
   public TileLocation field177;

   public class17(int var1, TileLocation var2, TileLocation var3) {
      this.field176 = var1;
      this.field177 = var2;
      this.field178 = var3;
   }

   static void method467(int var0, int var1, int var2) {
      if (Client.field2331 != 0 && var1 != 0 && Client.field2348 < 50) {
         Client.field2327[Client.field2348] = var0;
         Client.field2328[Client.field2348] = var1;
         Client.field2236[Client.field2348] = var2;
         Client.field2153[Client.field2348] = null;
         Client.field2330[Client.field2348] = 0;
         ++Client.field2348;
      }

   }

   static void method465(int var0, String var1) {
      int var2 = Players.field951;
      int[] var3 = Players.field947;
      boolean var4 = false;
      Username var5 = new Username(var1, Client.field2363);

      for(int var6 = 0; var6 < var2; ++var6) {
         Player var7 = Client.field2141[var3[var6]];
         if (var7 != null && var7 != ObjectSound.field589 && var7.username != null && var7.username.equals(var5)) {
            PacketBufferNode var8;
            if (var0 == 1) {
               var8 = FaceNormal.method2884(ClientPacket.field1937, Client.field2133.isaacCipher);
               var8.packetBuffer.writeShort(var3[var6]);
               var8.packetBuffer.method3938(0);
               Client.field2133.method1281(var8);
            } else if (var0 == 4) {
               var8 = FaceNormal.method2884(ClientPacket.field1865, Client.field2133.isaacCipher);
               var8.packetBuffer.method3948(var3[var6]);
               var8.packetBuffer.method3938(0);
               Client.field2133.method1281(var8);
            } else if (var0 == 6) {
               var8 = FaceNormal.method2884(ClientPacket.field1929, Client.field2133.isaacCipher);
               var8.packetBuffer.method4029(var3[var6]);
               var8.packetBuffer.method3939(0);
               Client.field2133.method1281(var8);
            } else if (var0 == 7) {
               var8 = FaceNormal.method2884(ClientPacket.field1911, Client.field2133.isaacCipher);
               var8.packetBuffer.method3939(0);
               var8.packetBuffer.writeShortLE(var3[var6]);
               Client.field2133.method1281(var8);
            }

            var4 = true;
            break;
         }
      }

      if (!var4) {
         Message.set(4, "", "Unable to find " + var1);
      }

   }

   static String method466(String var0, Widget var1) {
      if (var0.indexOf("%") != -1) {
         for(int var2 = 1; var2 <= 5; ++var2) {
            while(true) {
               int var3 = var0.indexOf("%" + var2);
               if (var3 == -1) {
                  break;
               }

               var0 = var0.substring(0, var3) + Buffer.method4136(class39.method970(var1, var2 - 1)) + var0.substring(var3 + 2);
            }
         }
      }

      return var0;
   }
}
