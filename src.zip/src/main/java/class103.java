public final class class103 {
   static int field1124;
   static int[] field1125;
   static String homeDirectory;
   final int[] field1123 = new int[4096];

   final void method2017(class25 var1) {
      for(int var2 = 0; var2 < 64; ++var2) {
         for(int var3 = 0; var3 < 64; ++var3) {
            this.field1123[var2 * 64 + var3] = var1.method575(var2, var3) | -16777216;
         }
      }

   }

   final int method2018(int var1, int var2) {
      return this.field1123[var1 * 64 + var2];
   }

   static int method2016(int var0, Script var1, boolean var2) {
      if (var0 == 5306) {
         Interpreter.field467[++class31.field364 - 1] = class65.method1381();
         return 1;
      } else {
         int var3;
         if (var0 == 5307) {
            var3 = Interpreter.field467[--class31.field364];
            if (var3 == 1 || var3 == 2) {
               WorldMapSection2.method398(var3);
            }

            return 1;
         } else if (var0 == 5308) {
            Interpreter.field467[++class31.field364 - 1] = GameShell.field72.windowMode;
            return 1;
         } else if (var0 != 5309) {
            return 2;
         } else {
            var3 = Interpreter.field467[--class31.field364];
            if (var3 == 1 || var3 == 2) {
               GameShell.field72.windowMode = var3;
               Player.method840();
            }

            return 1;
         }
      }
   }

   public static Object method2027(byte[] var0, boolean var1) {
      if (var0 == null) {
         return null;
      } else {
         if (var0.length > 136 && !AbstractByteArrayCopier.field2365) {
            try {
               DirectByteArrayCopier var2 = new DirectByteArrayCopier();
               var2.set(var0);
               return var2;
            } catch (Throwable var3) {
               AbstractByteArrayCopier.field2365 = true;
            }
         }

         return var0;
      }
   }

   static void method2019(int var0, int var1, int var2, int var3) {
      for(ObjectSound var4 = (ObjectSound)ObjectSound.field577.last(); var4 != null; var4 = (ObjectSound)ObjectSound.field577.previous()) {
         if (var4.field580 != -1 || var4.field584 != null) {
            int var5 = 0;
            if (var1 > var4.field588) {
               var5 += var1 - var4.field588;
            } else if (var1 < var4.field575) {
               var5 += var4.field575 - var1;
            }

            if (var2 > var4.field578) {
               var5 += var2 - var4.field578;
            } else if (var2 < var4.field585) {
               var5 += var4.field585 - var2;
            }

            if (var5 - 64 <= var4.field579 && Client.field2324 != 0 && var0 == var4.field574) {
               var5 -= 64;
               if (var5 < 0) {
                  var5 = 0;
               }

               int var6 = (var4.field579 - var5) * Client.field2324 / var4.field579;
               if (var4.field590 == null) {
                  if (var4.field580 >= 0) {
                     SoundEffect var7 = SoundEffect.method1624(class71.field846, var4.field580, 0);
                     if (var7 != null) {
                        class88 var8 = var7.method1630().method1770(IgnoreList.field3698);
                        class104 var9 = class104.method2045(var8, 100, var6);
                        var9.method2037(-1);
                        class10.field116.method1565(var9);
                        var4.field590 = var9;
                     }
                  }
               } else {
                  var4.field590.method2038(var6);
               }

               if (var4.field586 == null) {
                  if (var4.field584 != null && (var4.field581 -= var3) <= 0) {
                     int var11 = (int)(Math.random() * (double)var4.field584.length);
                     SoundEffect var12 = SoundEffect.method1624(class71.field846, var4.field584[var11], 0);
                     if (var12 != null) {
                        class88 var13 = var12.method1630().method1770(IgnoreList.field3698);
                        class104 var10 = class104.method2045(var13, 100, var6);
                        var10.method2037(0);
                        class10.field116.method1565(var10);
                        var4.field586 = var10;
                        var4.field581 = var4.field582 + (int)(Math.random() * (double)(var4.field583 - var4.field582));
                     }
                  }
               } else {
                  var4.field586.method2038(var6);
                  if (!var4.field586.hasNext()) {
                     var4.field586 = null;
                  }
               }
            } else {
               if (var4.field590 != null) {
                  class10.field116.method1564(var4.field590);
                  var4.field590 = null;
               }

               if (var4.field586 != null) {
                  class10.field116.method1564(var4.field586);
                  var4.field586 = null;
               }
            }
         }
      }

   }
}
