public class class299 {
   static int field3748;
   static char[] field3749;
   static char[] field3752 = new char[64];
   static int[] field3750;
   static char[] field3747;

   static {
      int var0;
      for(var0 = 0; var0 < 26; ++var0) {
         field3752[var0] = (char)(var0 + 65);
      }

      for(var0 = 26; var0 < 52; ++var0) {
         field3752[var0] = (char)(var0 + 97 - 26);
      }

      for(var0 = 52; var0 < 62; ++var0) {
         field3752[var0] = (char)(var0 + 48 - 52);
      }

      field3752[62] = '+';
      field3752[63] = '/';
      field3747 = new char[64];

      for(var0 = 0; var0 < 26; ++var0) {
         field3747[var0] = (char)(var0 + 65);
      }

      for(var0 = 26; var0 < 52; ++var0) {
         field3747[var0] = (char)(var0 + 97 - 26);
      }

      for(var0 = 52; var0 < 62; ++var0) {
         field3747[var0] = (char)(var0 + 48 - 52);
      }

      field3747[62] = '*';
      field3747[63] = '-';
      field3749 = new char[64];

      for(var0 = 0; var0 < 26; ++var0) {
         field3749[var0] = (char)(var0 + 65);
      }

      for(var0 = 26; var0 < 52; ++var0) {
         field3749[var0] = (char)(var0 + 97 - 26);
      }

      for(var0 = 52; var0 < 62; ++var0) {
         field3749[var0] = (char)(var0 + 48 - 52);
      }

      field3749[62] = '-';
      field3749[63] = '_';
      field3750 = new int[128];

      for(var0 = 0; var0 < field3750.length; ++var0) {
         field3750[var0] = -1;
      }

      for(var0 = 65; var0 <= 90; ++var0) {
         field3750[var0] = var0 - 65;
      }

      for(var0 = 97; var0 <= 122; ++var0) {
         field3750[var0] = var0 - 97 + 26;
      }

      for(var0 = 48; var0 <= 57; ++var0) {
         field3750[var0] = var0 - 48 + 52;
      }

      int[] var2 = field3750;
      field3750[43] = 62;
      var2[42] = 62;
      int[] var1 = field3750;
      field3750[47] = 63;
      var1[45] = 63;
   }
}
