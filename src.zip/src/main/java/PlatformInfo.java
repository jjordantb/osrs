public class PlatformInfo extends Node {
   boolean field3952;
   int field3948;
   int field3954;
   int field3962;
   String field3947;
   int field3953;
   boolean field3946;
   int field3955;
   String field3957;
   int field3961;
   String field3960;
   int field3963;
   int field3949;
   int field3951;
   int field3941;
   int field3938;
   int field3959;
   String field3958;
   int field3945;
   String field3966;
   int[] field3967 = new int[3];
   int field3968;
   int field3965;
   String field3950;
   String field3964;

   PlatformInfo(int var1, boolean var2, int var3, int var4, int var5, int var6, int var7, boolean var8, int var9, int var10, int var11, int var12, String var13, String var14, String var15, String var16, int var17, int var18, int var19, int var20, String var21, String var22, int[] var23, int var24, String var25) {
      this.field3945 = var1;
      this.field3946 = var2;
      this.field3962 = var3;
      this.field3948 = var4;
      this.field3949 = var5;
      this.field3941 = var6;
      this.field3951 = var7;
      this.field3952 = var8;
      this.field3953 = var9;
      this.field3954 = var10;
      this.field3955 = var11;
      this.field3961 = var12;
      this.field3957 = var13;
      this.field3958 = var14;
      this.field3947 = var15;
      this.field3960 = var16;
      this.field3959 = var17;
      this.field3938 = var18;
      this.field3963 = var19;
      this.field3965 = var20;
      this.field3964 = var21;
      this.field3966 = var22;
      this.field3967 = var23;
      this.field3968 = var24;
      this.field3950 = var25;
   }

   public void write(Buffer var1) {
      var1.writeByte(7);
      var1.writeByte(this.field3945);
      var1.writeByte(this.field3946 ? 1 : 0);
      var1.writeByte(this.field3962);
      var1.writeByte(this.field3948);
      var1.writeByte(this.field3949);
      var1.writeByte(this.field3941);
      var1.writeByte(this.field3951);
      var1.writeByte(this.field3952 ? 1 : 0);
      var1.writeShort(this.field3953);
      var1.writeByte(this.field3954);
      var1.writeMedium(this.field3955);
      var1.writeShort(this.field3961);
      var1.writeStringCp1252NullCircumfixed(this.field3957);
      var1.writeStringCp1252NullCircumfixed(this.field3958);
      var1.writeStringCp1252NullCircumfixed(this.field3947);
      var1.writeStringCp1252NullCircumfixed(this.field3960);
      var1.writeByte(this.field3938);
      var1.writeShort(this.field3959);
      var1.writeStringCp1252NullCircumfixed(this.field3964);
      var1.writeStringCp1252NullCircumfixed(this.field3966);
      var1.writeByte(this.field3963);
      var1.writeByte(this.field3965);

      for(int var2 = 0; var2 < this.field3967.length; ++var2) {
         var1.writeInt(this.field3967[var2]);
      }

      var1.writeInt(this.field3968);
      var1.writeStringCp1252NullCircumfixed(this.field3950);
   }

   public int size() {
      byte var1 = 38;
      String var4 = this.field3957;
      int var3 = var4.length() + 2;
      int var23 = var1 + var3;
      String var7 = this.field3958;
      int var6 = var7.length() + 2;
      var23 += var6;
      String var10 = this.field3947;
      int var9 = var10.length() + 2;
      var23 += var9;
      String var13 = this.field3960;
      int var12 = var13.length() + 2;
      var23 += var12;
      String var16 = this.field3964;
      int var15 = var16.length() + 2;
      var23 += var15;
      String var19 = this.field3966;
      int var18 = var19.length() + 2;
      var23 += var18;
      String var22 = this.field3950;
      int var21 = var22.length() + 2;
      var23 += var21;
      return var23;
   }
}
