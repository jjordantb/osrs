import java.util.HashMap;

public class Fonts {
   HashMap map;
   AbstractIndexCache field3700;
   AbstractIndexCache field3699;

   public Fonts(AbstractIndexCache var1, AbstractIndexCache var2) {
      this.field3700 = var1;
      this.field3699 = var2;
      this.map = new HashMap();
   }

   public HashMap createMap(FontName[] var1) {
      HashMap var2 = new HashMap();
      FontName[] var3 = var1;

      for(int var4 = 0; var4 < var3.length; ++var4) {
         FontName var5 = var3[var4];
         if (this.map.containsKey(var5)) {
            var2.put(var5, this.map.get(var5));
         } else {
            AbstractIndexCache var7 = this.field3700;
            AbstractIndexCache var8 = this.field3699;
            String var9 = var5.field3745;
            int var10 = var7.getArchiveId(var9);
            int var11 = var7.getRecordId(var10, "");
            Font var12;
            if (!class65.method1382(var7, var10, var11)) {
               var12 = null;
            } else {
               byte[] var14 = var8.takeRecord(var10, var11);
               Font var13;
               if (var14 == null) {
                  var13 = null;
               } else {
                  Font var15 = new Font(var14, class328.field3982, class328.field3984, class328.field3987, VarcInt.field2811, class328.field3986, class328.field3989);
                  class328.field3982 = null;
                  class328.field3984 = null;
                  class328.field3987 = null;
                  VarcInt.field2811 = null;
                  class328.field3986 = null;
                  class328.field3989 = null;
                  var13 = var15;
               }

               var12 = var13;
            }

            if (var12 != null) {
               this.map.put(var5, var12);
               var2.put(var5, var12);
            }
         }
      }

      return var2;
   }
}
