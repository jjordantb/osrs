public class class71 {
   static int field843;
   static IndexCache field846;
   static int field844;
   static int field842;

   public static Widget method1467(int var0, int var1) {
      Widget var2 = WorldMapSection3.method1148(var0);
      if (var1 == -1) {
         return var2;
      } else {
         return var2 != null && var2.children != null && var1 < var2.children.length ? var2.children[var1] : null;
      }
   }

   static char method1465(char var0) {
      if (var0 == 'Æ') {
         return 'E';
      } else if (var0 == 'æ') {
         return 'e';
      } else if (var0 == 'ß') {
         return 's';
      } else if (var0 == 'Œ') {
         return 'E';
      } else {
         return (char)(var0 == 'œ' ? 'e' : '\u0000');
      }
   }

   public static int method1463(int var0) {
      return var0 >> 11 & 63;
   }

   static Script method1464(int var0) {
      Script var1 = (Script)Script.field1052.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = UrlRequester.field1587.takeRecord(var0, 0);
         if (var2 == null) {
            return null;
         } else {
            var1 = Projectile.method1331(var2);
            Script.field1052.put(var1, (long)var0);
            return var1;
         }
      }
   }

   static void method1469(int var0, String var1, String var2, String var3) {
      ChatChannel var4 = (ChatChannel)Messages.field610.get(var0);
      if (var4 == null) {
         var4 = new ChatChannel();
         Messages.field610.put(var0, var4);
      }

      Message var5 = var4.addMessage(var0, var1, var2, var3);
      Messages.field611.put(var5, (long)var5.count);
      Messages.field609.add(var5);
      Client.field2278 = Client.field2271;
   }
}
