import java.util.Iterator;

public class IterableDualNodeQueueIterator implements Iterator {
   DualNode field2796 = null;
   IterableDualNodeQueue queue;
   DualNode field2794;

   IterableDualNodeQueueIterator(IterableDualNodeQueue var1) {
      this.queue = var1;
      this.field2794 = this.queue.sentinel.previousDual;
      this.field2796 = null;
   }

   public Object next() {
      DualNode var1 = this.field2794;
      if (var1 == this.queue.sentinel) {
         var1 = null;
         this.field2794 = null;
      } else {
         this.field2794 = var1.previousDual;
      }

      this.field2796 = var1;
      return var1;
   }

   public void remove() {
      this.field2796.removeDual();
      this.field2796 = null;
   }

   public boolean hasNext() {
      return this.queue.sentinel != this.field2794;
   }
}
