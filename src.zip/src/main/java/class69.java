import java.io.IOException;
import java.util.LinkedList;

public abstract class class69 {
   short[][][] field830;
   int field828;
   int field825;
   int field824;
   byte[][][] field833;
   int field826;
   byte[][][] field832;
   class93[][][][] field834;
   int field827;
   int field829;
   short[][][] field831;

   class69() {
      new LinkedList();
   }

   void method1422(int var1, int var2, Buffer var3) {
      int var4 = var3.readUnsignedByte();
      if (var4 != 0) {
         if ((var4 & 1) != 0) {
            this.method1442(var1, var2, var3, var4);
         } else {
            this.method1424(var1, var2, var3, var4);
         }

      }
   }

   int method1445() {
      return this.field825;
   }

   void method1442(int var1, int var2, Buffer var3, int var4) {
      boolean var5 = (var4 & 2) != 0;
      if (var5) {
         this.field831[0][var1][var2] = (short)var3.readUnsignedByte();
      }

      this.field830[0][var1][var2] = (short)var3.readUnsignedByte();
   }

   int method1421() {
      return this.field827;
   }

   int method1425(int var1, int var2) {
      if (var1 >= 0 && var2 >= 0) {
         return var1 < 64 && var2 < 64 ? this.field830[0][var1][var2] - 1 : -1;
      } else {
         return -1;
      }
   }

   void method1424(int var1, int var2, Buffer var3, int var4) {
      int var5 = ((var4 & 24) >> 3) + 1;
      boolean var6 = (var4 & 2) != 0;
      boolean var7 = (var4 & 4) != 0;
      this.field830[0][var1][var2] = (short)var3.readUnsignedByte();
      int var8;
      int var9;
      int var11;
      if (var6) {
         var8 = var3.readUnsignedByte();

         for(var9 = 0; var9 < var8; ++var9) {
            int var10 = var3.readUnsignedByte();
            if (var10 != 0) {
               this.field831[var9][var1][var2] = (short)var10;
               var11 = var3.readUnsignedByte();
               this.field832[var9][var1][var2] = (byte)(var11 >> 2);
               this.field833[var9][var1][var2] = (byte)(var11 & 3);
            }
         }
      }

      if (var7) {
         for(var8 = 0; var8 < var5; ++var8) {
            var9 = var3.readUnsignedByte();
            if (var9 != 0) {
               class93[] var14 = this.field834[var8][var1][var2] = new class93[var9];

               for(var11 = 0; var11 < var9; ++var11) {
                  int var12 = var3.method4040();
                  int var13 = var3.readUnsignedByte();
                  var14[var11] = new class93(var12, var13 >> 2, var13 & 3);
               }
            }
         }
      }

   }

   public static int method1447(int var0) {
      int var1 = 0;
      if (var0 < 0 || var0 >= 65536) {
         var0 >>>= 16;
         var1 += 16;
      }

      if (var0 >= 256) {
         var0 >>>= 8;
         var1 += 8;
      }

      if (var0 >= 16) {
         var0 >>>= 4;
         var1 += 4;
      }

      if (var0 >= 4) {
         var0 >>>= 2;
         var1 += 2;
      }

      if (var0 >= 1) {
         var0 >>>= 1;
         ++var1;
      }

      return var0 + var1;
   }

   public static void method1448(AbstractSocket var0, boolean var1) {
      if (NetCache.field2833 != null) {
         try {
            NetCache.field2833.close();
         } catch (Exception var6) {
            ;
         }

         NetCache.field2833 = null;
      }

      NetCache.field2833 = var0;
      Varps.method4668(var1);
      NetCache.field2828.index = 0;
      class205.field2491 = null;
      NetCache.field2841 = null;
      NetCache.field2846 = 0;

      while(true) {
         NetFileRequest var2 = (NetFileRequest)NetCache.field2831.first();
         if (var2 == null) {
            while(true) {
               var2 = (NetFileRequest)NetCache.field2838.first();
               if (var2 == null) {
                  if (NetCache.field2849 != 0) {
                     try {
                        Buffer var7 = new Buffer(4);
                        var7.writeByte(4);
                        var7.writeByte(NetCache.field2849);
                        var7.writeShort(0);
                        NetCache.field2833.write(var7.array, 0, 4);
                     } catch (IOException var5) {
                        try {
                           NetCache.field2833.close();
                        } catch (Exception var4) {
                           ;
                        }

                        ++NetCache.field2848;
                        NetCache.field2833 = null;
                     }
                  }

                  NetCache.field2842 = 0;
                  NetCache.field2830 = Tile.method2779();
                  return;
               }

               NetCache.field2835.addLast(var2);
               NetCache.field2836.put(var2, var2.key);
               ++NetCache.field2837;
               --NetCache.field2839;
            }
         }

         NetCache.field2840.put(var2, var2.key);
         ++NetCache.field2832;
         --NetCache.field2834;
      }
   }

   static int method1446(int var0, Script var1, boolean var2) {
      Widget var3 = WorldMapSection3.method1148(Interpreter.field467[--class31.field364]);
      if (var0 == 2600) {
         Interpreter.field467[++class31.field364 - 1] = var3.scrollX;
         return 1;
      } else if (var0 == 2601) {
         Interpreter.field467[++class31.field364 - 1] = var3.scrollY;
         return 1;
      } else if (var0 == 2602) {
         Interpreter.field462[++Interpreter.field469 - 1] = var3.text;
         return 1;
      } else if (var0 == 2603) {
         Interpreter.field467[++class31.field364 - 1] = var3.scrollWidth;
         return 1;
      } else if (var0 == 2604) {
         Interpreter.field467[++class31.field364 - 1] = var3.scrollHeight;
         return 1;
      } else if (var0 == 2605) {
         Interpreter.field467[++class31.field364 - 1] = var3.modelZoom;
         return 1;
      } else if (var0 == 2606) {
         Interpreter.field467[++class31.field364 - 1] = var3.modelAngleX;
         return 1;
      } else if (var0 == 2607) {
         Interpreter.field467[++class31.field364 - 1] = var3.modelAngleZ;
         return 1;
      } else if (var0 == 2608) {
         Interpreter.field467[++class31.field364 - 1] = var3.modelAngleY;
         return 1;
      } else if (var0 == 2609) {
         Interpreter.field467[++class31.field364 - 1] = var3.transparency;
         return 1;
      } else if (var0 == 2610) {
         Interpreter.field467[++class31.field364 - 1] = var3.field2620;
         return 1;
      } else if (var0 == 2611) {
         Interpreter.field467[++class31.field364 - 1] = var3.color;
         return 1;
      } else if (var0 == 2612) {
         Interpreter.field467[++class31.field364 - 1] = var3.color2;
         return 1;
      } else if (var0 == 2613) {
         Interpreter.field467[++class31.field364 - 1] = var3.rectangleMode.ordinal();
         return 1;
      } else if (var0 == 2614) {
         Interpreter.field467[++class31.field364 - 1] = var3.field2646 ? 1 : 0;
         return 1;
      } else {
         return 2;
      }
   }

   static void method1443(int var0) {
      if (var0 != Client.field2163) {
         if (Client.field2163 == 0) {
            class178.field1984.method218();
         }

         if (var0 == 20 || var0 == 40 || var0 == 45) {
            Client.field2120 = 0;
            Client.field2121 = 0;
            Client.field2122 = 0;
            Client.field2347.method5358(var0);
            if (var0 != 20) {
               WorldMapManager.method143(false);
            }
         }

         if (var0 != 20 && var0 != 40 && SecureRandomCallable.field515 != null) {
            SecureRandomCallable.field515.close();
            SecureRandomCallable.field515 = null;
         }

         if (Client.field2163 == 25) {
            Client.field2143 = 0;
            Client.field2139 = 0;
            Client.field2140 = 1;
            Client.field2196 = 0;
            Client.field2352 = 1;
         }

         if (var0 != 5 && var0 != 10) {
            if (var0 == 20) {
               WorldMapData.readWorldMapSection(WorldMapLabelSize.field724, RunException.field1608, true, Client.field2163 == 11 ? 4 : 0);
            } else if (var0 == 11) {
               WorldMapData.readWorldMapSection(WorldMapLabelSize.field724, RunException.field1608, false, 4);
            } else if (Login.field680) {
               Login.field655 = null;
               class294.field3719 = null;
               class57.field640 = null;
               Login.field651 = null;
               Login.field652 = null;
               VarbitDefinition.field3505 = null;
               Login.field653 = null;
               ByteArrayPool.field2470 = null;
               Frames.field1635 = null;
               AttackOption.field603 = null;
               BufferedFile.field1424 = null;
               class85.field967 = null;
               Tiles.field224 = null;
               class85.field963 = null;
               Login.field657 = null;
               MouseRecorder.field505 = null;
               BufferedNetSocket.field1783 = null;
               ObjectSound.field573 = null;
               OwnWorldComparator.field274 = null;
               class25.field263 = null;
               class93.field1025 = null;
               class93.field1026 = null;
               class165.method3136(2);
               Varps.method4668(true);
               Login.field680 = false;
            }
         } else {
            WorldMapData.readWorldMapSection(WorldMapLabelSize.field724, RunException.field1608, true, 0);
         }

         Client.field2163 = var0;
      }
   }

   static final void method1444(int var0, int var1, int var2, int var3, int var4) {
      class189.field2394[0].method6304(var0, var1);
      class189.field2394[1].method6304(var0, var3 + var1 - 16);
      Rasterizer2D.method6223(var0, var1 + 16, 16, var3 - 32, Client.field2360);
      int var5 = var3 * (var3 - 32) / var4;
      if (var5 < 8) {
         var5 = 8;
      }

      int var6 = (var3 - 32 - var5) * var2 / (var4 - var3);
      Rasterizer2D.method6223(var0, var6 + var1 + 16, 16, var5, Client.field2221);
      Rasterizer2D.method6230(var0, var6 + var1 + 16, var5, Client.field2152);
      Rasterizer2D.method6230(var0 + 1, var6 + var1 + 16, var5, Client.field2152);
      Rasterizer2D.method6274(var0, var6 + var1 + 16, 16, Client.field2152);
      Rasterizer2D.method6274(var0, var6 + var1 + 17, 16, Client.field2152);
      Rasterizer2D.method6230(var0 + 15, var6 + var1 + 16, var5, Client.field2326);
      Rasterizer2D.method6230(var0 + 14, var6 + var1 + 17, var5 - 1, Client.field2326);
      Rasterizer2D.method6274(var0, var6 + var5 + var1 + 15, 16, Client.field2326);
      Rasterizer2D.method6274(var0 + 1, var6 + var5 + var1 + 14, 15, Client.field2326);
   }

   static void method1423() {
      if (UserComparator9.field1598 != null) {
         Client.field2357 = Client.field2098;
         UserComparator9.field1598.method4948();

         for(int var0 = 0; var0 < Client.field2141.length; ++var0) {
            if (Client.field2141[var0] != null) {
               UserComparator9.field1598.method4947((Client.field2141[var0].x >> 7) + class21.field230, (Client.field2141[var0].y >> 7) + class79.field902);
            }
         }
      }

   }
}
