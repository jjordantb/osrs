import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class MouseHandler implements MouseListener, MouseMotionListener, FocusListener {
   public static int field159 = 0;
   public static volatile int field147 = -1;
   public static volatile int field165 = 0;
   public static long field153 = 0L;
   public static int field158 = 0;
   public static volatile long field157 = 0L;
   public static int field150 = 0;
   public static volatile int field152 = 0;
   public static long field146 = 0L;
   public static volatile int field162 = 0;
   public static int field145 = 0;
   public static volatile long field149 = -1L;
   public static int field154 = 0;
   public static MouseHandler field151 = new MouseHandler();
   public static int field148 = 0;
   public static volatile int field156 = 0;
   public static volatile int field144 = -1;
   public static volatile int field155 = 0;

   final int getButton(MouseEvent var1) {
      int var2 = var1.getButton();
      if (!var1.isAltDown() && var2 != 2) {
         return !var1.isMetaDown() && var2 != 3 ? 1 : 2;
      } else {
         return 4;
      }
   }

   public final synchronized void mouseMoved(MouseEvent var1) {
      if (field151 != null) {
         field165 = 0;
         field147 = var1.getX();
         field144 = var1.getY();
         field149 = var1.getWhen();
      }

   }

   public final synchronized void mousePressed(MouseEvent var1) {
      if (field151 != null) {
         field165 = 0;
         field155 = var1.getX();
         field156 = var1.getY();
         field157 = Tile.method2779();
         field152 = this.getButton(var1);
         if (field152 != 0) {
            field162 = field152;
         }
      }

      if (var1.isPopupTrigger()) {
         var1.consume();
      }

   }

   public final synchronized void mouseReleased(MouseEvent var1) {
      if (field151 != null) {
         field165 = 0;
         field162 = 0;
      }

      if (var1.isPopupTrigger()) {
         var1.consume();
      }

   }

   public final void mouseClicked(MouseEvent var1) {
      if (var1.isPopupTrigger()) {
         var1.consume();
      }

   }

   public final synchronized void mouseEntered(MouseEvent var1) {
      this.mouseMoved(var1);
   }

   public final synchronized void mouseExited(MouseEvent var1) {
      if (field151 != null) {
         field165 = 0;
         field147 = -1;
         field144 = -1;
         field149 = var1.getWhen();
      }

   }

   public final synchronized void mouseDragged(MouseEvent var1) {
      this.mouseMoved(var1);
   }

   public final synchronized void focusLost(FocusEvent var1) {
      if (field151 != null) {
         field162 = 0;
      }

   }

   public final void focusGained(FocusEvent var1) {
   }

   static Message getButton(int var0, int var1) {
      ChatChannel var2 = (ChatChannel)Messages.field610.get(var0);
      return var2.getMessage(var1);
   }

   public static void method461() {
      OverlayDefinition.field3678.clear();
   }

   public static void method459() {
      while(true) {
         NodeDeque var1 = IndexStoreActionHandler.field2946;
         IndexStoreAction var0;
         synchronized(IndexStoreActionHandler.field2946) {
            var0 = (IndexStoreAction)IndexStoreActionHandler.field2948.removeLast();
         }

         if (var0 == null) {
            return;
         }

         var0.indexCache.load(var0.indexStore, (int)var0.key, var0.data, false);
      }
   }

   static void method457(String var0, boolean var1) {
      var0 = var0.toLowerCase();
      short[] var2 = new short[16];
      int var3 = 0;

      for(int var4 = 0; var4 < class322.field3916; ++var4) {
         ItemDefinition var5 = Varcs.getItemDefinition(var4);
         if ((!var1 || var5.isTradable) && var5.noteTemplate == -1 && var5.name.toLowerCase().indexOf(var0) != -1) {
            if (var3 >= 250) {
               MilliClock.field1661 = -1;
               WorldMapData2.field106 = null;
               return;
            }

            if (var3 >= var2.length) {
               short[] var6 = new short[var2.length * 2];

               for(int var7 = 0; var7 < var3; ++var7) {
                  var6[var7] = var2[var7];
               }

               var2 = var6;
            }

            var2[var3++] = (short)var4;
         }
      }

      WorldMapData2.field106 = var2;
      class71.field843 = 0;
      MilliClock.field1661 = var3;
      String[] var8 = new String[MilliClock.field1661];

      for(int var9 = 0; var9 < MilliClock.field1661; ++var9) {
         var8[var9] = Varcs.getItemDefinition(var2[var9]).name;
      }

      short[] var10 = WorldMapData2.field106;
      GzipDecompressor.decompress(var8, var10, 0, var8.length - 1);
   }
}
