import java.net.MalformedURLException;
import java.net.URL;

public final class Player extends Actor {
   static PlatformInfo field444;
   static Sprite[] field445;
   boolean field441;
   int tileY;
   int tileX;
   int field433;
   int combatLevel;
   int tileHeight2;
   int headIconPk = -1;
   int field431;
   Username username;
   int field416;
   int animationCycleStart;
   int field422;
   int team;
   String[] actions = new String[3];
   int field426;
   int tileHeight;
   TriBool isInClanChat;
   int animationCycleEnd;
   int headIconPrayer = -1;
   PlayerAppearance appearance;
   int plane;
   boolean isUnanimated;
   TriBool isFriend;
   int field418;
   int skillLevel;
   Model model0;
   int index;
   boolean isHidden;

   Player() {
      for(int var1 = 0; var1 < 3; ++var1) {
         this.actions[var1] = "";
      }

      this.combatLevel = 0;
      this.skillLevel = 0;
      this.animationCycleStart = 0;
      this.animationCycleEnd = 0;
      this.isUnanimated = false;
      this.team = 0;
      this.isHidden = false;
      this.isFriend = TriBool.field3723;
      this.isInClanChat = TriBool.field3723;
      this.field441 = false;
   }

   boolean method814() {
      if (this.isInClanChat == TriBool.field3723) {
         this.method815();
      }

      return this.isInClanChat == TriBool.field3722;
   }

   protected final Model getModel() {
      if (this.appearance == null) {
         return null;
      } else {
         SequenceDefinition var1 = super.sequence != -1 && super.sequenceDelay == 0 ? WorldMapCacheName.method547(super.sequence) : null;
         SequenceDefinition var2 = super.movementSequence != -1 && !this.isUnanimated && (super.idleSequence != super.movementSequence || var1 == null) ? WorldMapCacheName.method547(super.movementSequence) : null;
         Model var3 = this.appearance.getModel(var1, super.sequenceFrame, var2, super.movementFrame);
         if (var3 == null) {
            return null;
         } else {
            var3.calculateBoundsCylinder();
            super.defaultHeight = var3.height;
            Model var4;
            Model[] var5;
            if (!this.isUnanimated && super.spotAnimation != -1 && super.spotAnimationFrame != -1) {
               var4 = IndexStoreActionHandler.method4937(super.spotAnimation).getModel(super.spotAnimationFrame);
               if (var4 != null) {
                  var4.offsetBy(0, -super.heightOffset, 0);
                  var5 = new Model[]{var3, var4};
                  var3 = new Model(var5, 2);
               }
            }

            if (!this.isUnanimated && this.model0 != null) {
               if (Client.field2098 >= this.animationCycleEnd) {
                  this.model0 = null;
               }

               if (Client.field2098 >= this.animationCycleStart && Client.field2098 < this.animationCycleEnd) {
                  var4 = this.model0;
                  var4.offsetBy(this.field426 - super.x, this.tileHeight2 - this.tileHeight, this.field422 - super.y);
                  if (super.orientation == 512) {
                     var4.rotateY90Ccw();
                     var4.rotateY90Ccw();
                     var4.rotateY90Ccw();
                  } else if (super.orientation == 1024) {
                     var4.rotateY90Ccw();
                     var4.rotateY90Ccw();
                  } else if (super.orientation == 1536) {
                     var4.rotateY90Ccw();
                  }

                  var5 = new Model[]{var3, var4};
                  var3 = new Model(var5, 2);
                  if (super.orientation == 512) {
                     var4.rotateY90Ccw();
                  } else if (super.orientation == 1024) {
                     var4.rotateY90Ccw();
                     var4.rotateY90Ccw();
                  } else if (super.orientation == 1536) {
                     var4.rotateY90Ccw();
                     var4.rotateY90Ccw();
                     var4.rotateY90Ccw();
                  }

                  var4.offsetBy(super.x - this.field426, this.tileHeight - this.tileHeight2, super.y - this.field422);
               }
            }

            var3.isSingleTile = true;
            return var3;
         }
      }
   }

   void method812() {
      this.isFriend = TriBool.field3723;
   }

   final void read(Buffer var1) {
      var1.index = 0;
      int var2 = var1.readUnsignedByte();
      this.headIconPk = var1.readByte();
      this.headIconPrayer = var1.readByte();
      int var3 = -1;
      this.team = 0;
      int[] var4 = new int[12];

      int var6;
      int var7;
      for(int var5 = 0; var5 < 12; ++var5) {
         var6 = var1.readUnsignedByte();
         if (var6 == 0) {
            var4[var5] = 0;
         } else {
            var7 = var1.readUnsignedByte();
            var4[var5] = var7 + (var6 << 8);
            if (var5 == 0 && var4[0] == 65535) {
               var3 = var1.method3913();
               break;
            }

            if (var4[var5] >= 512) {
               int var8 = Varcs.getItemDefinition(var4[var5] - 512).int1;
               if (var8 != 0) {
                  this.team = var8;
               }
            }
         }
      }

      int[] var9 = new int[5];

      for(var6 = 0; var6 < 5; ++var6) {
         var7 = var1.readUnsignedByte();
         if (var7 < 0 || var7 >= VarpDefinition.field2929[var6].length) {
            var7 = 0;
         }

         var9[var6] = var7;
      }

      super.idleSequence = var1.method3913();
      if (super.idleSequence == 65535) {
         super.idleSequence = -1;
      }

      super.turnLeftSequence = var1.method3913();
      if (super.turnLeftSequence == 65535) {
         super.turnLeftSequence = -1;
      }

      super.turnRightSequence = super.turnLeftSequence;
      super.walkSequence = var1.method3913();
      if (super.walkSequence == 65535) {
         super.walkSequence = -1;
      }

      super.walkTurnSequence = var1.method3913();
      if (super.walkTurnSequence == 65535) {
         super.walkTurnSequence = -1;
      }

      super.walkTurnLeftSequence = var1.method3913();
      if (super.walkTurnLeftSequence == 65535) {
         super.walkTurnLeftSequence = -1;
      }

      super.walkTurnRightSequence = var1.method3913();
      if (super.walkTurnRightSequence == 65535) {
         super.walkTurnRightSequence = -1;
      }

      super.runSequence = var1.method3913();
      if (super.runSequence == 65535) {
         super.runSequence = -1;
      }

      this.username = new Username(var1.readStringCp1252NullTerminated(), Client.field2363);
      this.method812();
      this.method824();
      if (this == ObjectSound.field589) {
         RunException.field1601 = this.username.name();
      }

      this.combatLevel = var1.readUnsignedByte();
      this.skillLevel = var1.method3913();
      this.isHidden = var1.readUnsignedByte() == 1;
      if (Client.field2088 == 0 && Client.field2255 >= 2) {
         this.isHidden = false;
      }

      if (this.appearance == null) {
         this.appearance = new PlayerAppearance();
      }

      this.appearance.method4500(var4, var9, var2 == 1, var3);
   }

   final boolean isVisible() {
      return this.appearance != null;
   }

   void method824() {
      this.isInClanChat = TriBool.field3723;
   }

   final void method818(int var1, int var2, byte var3) {
      if (super.sequence != -1 && WorldMapCacheName.method547(super.sequence).field3480 == 1) {
         super.sequence = -1;
      }

      super.field305 = -1;
      if (var1 >= 0 && var1 < 104 && var2 >= 0 && var2 < 104) {
         if (super.pathX[0] >= 0 && super.pathX[0] < 104 && super.pathY[0] >= 0 && super.pathY[0] < 104) {
            if (var3 == 2) {
               ParamsDefinition.method5298(this, var1, var2, (byte)2);
            }

            this.method833(var1, var2, var3);
         } else {
            this.resetPath(var1, var2);
         }
      } else {
         this.resetPath(var1, var2);
      }

   }

   int transformedSize() {
      return this.appearance != null && this.appearance.npcTransformId != -1 ? NetFileRequest.method4959(this.appearance.npcTransformId).size : 1;
   }

   void method815() {
      this.isInClanChat = TotalQuantityComparator.field983 != null && TotalQuantityComparator.field983.contains(this.username) ? TriBool.field3722 : TriBool.field3721;
   }

   void method813() {
      this.isFriend = ServerPacket.field2028.method727(this.username) ? TriBool.field3722 : TriBool.field3721;
   }

   boolean method811() {
      if (this.isFriend == TriBool.field3723) {
         this.method813();
      }

      return this.isFriend == TriBool.field3722;
   }

   final void method833(int var1, int var2, byte var3) {
      if (super.pathLength < 9) {
         ++super.pathLength;
      }

      for(int var4 = super.pathLength; var4 > 0; --var4) {
         super.pathX[var4] = super.pathX[var4 - 1];
         super.pathY[var4] = super.pathY[var4 - 1];
         super.pathTraversed[var4] = super.pathTraversed[var4 - 1];
      }

      super.pathX[0] = var1;
      super.pathY[0] = var2;
      super.pathTraversed[0] = var3;
   }

   void resetPath(int var1, int var2) {
      super.pathLength = 0;
      super.field297 = 0;
      super.field293 = 0;
      super.pathX[0] = var1;
      super.pathY[0] = var2;
      int var3 = this.transformedSize();
      super.x = super.pathX[0] * 128 + var3 * 64;
      super.y = var3 * 64 + super.pathY[0] * 128;
   }

   static void method840() {
      AccessFile var0 = null;

      try {
         var0 = class99.method1837("", Client.field2089.name, true);
         Buffer var1 = GameShell.field72.toBuffer();
         var0.write(var1.array, 0, var1.index);
      } catch (Exception var3) {
         ;
      }

      try {
         if (var0 != null) {
            var0.closeSync(true);
         }
      } catch (Exception var2) {
         ;
      }

   }

   static int method857(int var0, int var1) {
      ItemContainer var2 = (ItemContainer)ItemContainer.field267.get((long)var0);
      if (var2 == null) {
         return 0;
      } else if (var1 == -1) {
         return 0;
      } else {
         int var3 = 0;

         for(int var4 = 0; var4 < var2.quantities.length; ++var4) {
            if (var2.ids[var4] == var1) {
               var3 += var2.quantities[var4];
            }
         }

         return var3;
      }
   }

   static boolean method856(String var0) {
      if (var0 == null) {
         return false;
      } else {
         try {
            new URL(var0);
            return true;
         } catch (MalformedURLException var2) {
            return false;
         }
      }
   }

   static void method845(Player var0, boolean var1) {
      if (var0 != null && var0.isVisible() && !var0.isHidden) {
         var0.isUnanimated = false;
         if ((Client.field2091 && Players.field951 > 50 || Players.field951 > 200) && var1 && var0.movementSequence == var0.idleSequence) {
            var0.isUnanimated = true;
         }

         int var2 = var0.x >> 7;
         int var3 = var0.y >> 7;
         if (var2 >= 0 && var2 < 104 && var3 >= 0 && var3 < 104) {
            long var4 = WorldComparator.method1404(0, 0, 0, false, var0.index);
            if (var0.model0 != null && Client.field2098 >= var0.animationCycleStart && Client.field2098 < var0.animationCycleEnd) {
               var0.isUnanimated = false;
               var0.tileHeight = MilliClock.method2923(var0.x, var0.y, class31.field363);
               var0.playerCycle = Client.field2098;
               class243.field2904.method2237(class31.field363, var0.x, var0.y, var0.tileHeight, 60, var0, var0.field278, var4, var0.field418, var0.field416, var0.field431, var0.field433);
            } else {
               if ((var0.x & 127) == 64 && (var0.y & 127) == 64) {
                  if (Client.field2183[var2][var3] == Client.field2184) {
                     return;
                  }

                  Client.field2183[var2][var3] = Client.field2184;
               }

               var0.tileHeight = MilliClock.method2923(var0.x, var0.y, class31.field363);
               var0.playerCycle = Client.field2098;
               class243.field2904.method2260(class31.field363, var0.x, var0.y, var0.tileHeight, 60, var0, var0.field278, var4, var0.field279);
            }
         }
      }

   }
}
