public class class76 extends TaskDataNode {
   int field891 = 0;
   NodeDeque field890 = new NodeDeque();
   int field892 = -1;
   NodeDeque field889 = new NodeDeque();

   void method1589(class94 var1) {
      var1.remove();
      var1.method1789();
      Node var2 = this.field889.sentinel.previous;
      if (var2 == this.field889.sentinel) {
         this.field892 = -1;
      } else {
         this.field892 = ((class94)var2).field1035;
      }

   }

   public final synchronized void vmethod4652(int[] var1, int var2, int var3) {
      do {
         if (this.field892 < 0) {
            this.method1571(var1, var2, var3);
            return;
         }

         if (var3 + this.field891 < this.field892) {
            this.field891 += var3;
            this.method1571(var1, var2, var3);
            return;
         }

         int var4 = this.field892 - this.field891;
         this.method1571(var1, var2, var4);
         var2 += var4;
         var3 -= var4;
         this.field891 += var4;
         this.method1566();
         class94 var5 = (class94)this.field889.last();
         synchronized(var5) {
            int var7 = var5.method1790();
            if (var7 < 0) {
               var5.field1035 = 0;
               this.method1589(var5);
            } else {
               var5.field1035 = var7;
               this.method1563(var5.previous, var5);
            }
         }
      } while(var3 != 0);

   }

   void method1566() {
      if (this.field891 > 0) {
         for(class94 var1 = (class94)this.field889.last(); var1 != null; var1 = (class94)this.field889.previous()) {
            var1.field1035 -= this.field891;
         }

         this.field892 -= this.field891;
         this.field891 = 0;
      }

   }

   public final synchronized void method1565(TaskDataNode var1) {
      this.field890.addLast(var1);
   }

   protected TaskDataNode vmethod4628() {
      return (TaskDataNode)this.field890.last();
   }

   void method1571(int[] var1, int var2, int var3) {
      for(TaskDataNode var4 = (TaskDataNode)this.field890.last(); var4 != null; var4 = (TaskDataNode)this.field890.previous()) {
         var4.method2799(var1, var2, var3);
      }

   }

   protected int vmethod4641() {
      return 0;
   }

   protected TaskDataNode vmethod4630() {
      return (TaskDataNode)this.field890.previous();
   }

   void method1563(Node var1, class94 var2) {
      while(this.field889.sentinel != var1 && ((class94)var1).field1035 <= var2.field1035) {
         var1 = var1.previous;
      }

      NodeDeque.method3886(var2, var1);
      this.field892 = ((class94)this.field889.sentinel.previous).field1035;
   }

   public final synchronized void method1564(TaskDataNode var1) {
      var1.remove();
   }

   void method1591(int var1) {
      for(TaskDataNode var2 = (TaskDataNode)this.field890.last(); var2 != null; var2 = (TaskDataNode)this.field890.previous()) {
         var2.vmethod4633(var1);
      }

   }

   public final synchronized void vmethod4633(int var1) {
      do {
         if (this.field892 < 0) {
            this.method1591(var1);
            return;
         }

         if (this.field891 + var1 < this.field892) {
            this.field891 += var1;
            this.method1591(var1);
            return;
         }

         int var2 = this.field892 - this.field891;
         this.method1591(var2);
         var1 -= var2;
         this.field891 += var2;
         this.method1566();
         class94 var3 = (class94)this.field889.last();
         synchronized(var3) {
            int var5 = var3.method1790();
            if (var5 < 0) {
               var3.field1035 = 0;
               this.method1589(var3);
            } else {
               var3.field1035 = var5;
               this.method1563(var3.previous, var3);
            }
         }
      } while(var1 != 0);

   }
}
