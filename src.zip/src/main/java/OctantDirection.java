import java.net.URL;

public class OctantDirection implements Enumerated {
   public static final OctantDirection field3328 = new OctantDirection(2, 6);
   public static final OctantDirection field3326 = new OctantDirection(4, 4);
   public static final OctantDirection field3324 = new OctantDirection(1, 2);
   public static final OctantDirection field3332 = new OctantDirection(5, 0);
   public static final OctantDirection field3329 = new OctantDirection(3, 5);
   public static final OctantDirection field3322 = new OctantDirection(0, 3);
   public static final OctantDirection field3323 = new OctantDirection(6, 1);
   public static final OctantDirection field3327 = new OctantDirection(7, 7);
   final int field3331;
   public final int field3330;

   OctantDirection(int var1, int var2) {
      this.field3330 = var1;
      this.field3331 = var2;
   }

   public int ordinal() {
      return this.field3331;
   }

   static boolean ordinal(String var0, int var1, String var2) {
      if (var1 == 0) {
         try {
            if (!class12.field125.startsWith("win")) {
               throw new Exception();
            } else if (!var0.startsWith("http://") && !var0.startsWith("https://")) {
               throw new Exception();
            } else {
               String var10 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789?&=,.%+-_#:/*";

               for(int var4 = 0; var4 < var0.length(); ++var4) {
                  if (var10.indexOf(var0.charAt(var4)) == -1) {
                     throw new Exception();
                  }
               }

               Runtime.getRuntime().exec("cmd /c start \"j\" \"" + var0 + "\"");
               return true;
            }
         } catch (Throwable var5) {
            return false;
         }
      } else if (var1 == 1) {
         try {
            Object var3 = class3.method94(class12.field124, var2, new Object[]{(new URL(class12.field124.getCodeBase(), var0)).toString()});
            return var3 != null;
         } catch (Throwable var6) {
            return false;
         }
      } else if (var1 == 2) {
         try {
            class12.field124.getAppletContext().showDocument(new URL(class12.field124.getCodeBase(), var0), "_blank");
            return true;
         } catch (Exception var7) {
            return false;
         }
      } else if (var1 == 3) {
         try {
            class3.method91(class12.field124, "loggedout");
         } catch (Throwable var9) {
            ;
         }

         try {
            class12.field124.getAppletContext().showDocument(new URL(class12.field124.getCodeBase(), var0), "_top");
            return true;
         } catch (Exception var8) {
            return false;
         }
      } else {
         throw new IllegalArgumentException();
      }
   }
}
