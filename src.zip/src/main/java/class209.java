import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.OptionalDataException;
import java.io.StreamCorruptedException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class class209 {
   int field2510;
   int field2511;
   int field2506;
   byte[] field2505;
   int field2509;
   int field2504;
   int field2512;
   byte[] field2508;
   int field2507;

   public static void method4322(PacketBuffer var0) {
      ReflectionCheck var1 = (ReflectionCheck)class321.field3914.last();
      if (var1 != null) {
         int var2 = var0.index;
         var0.writeInt(var1.id);

         for(int var3 = 0; var3 < var1.size; ++var3) {
            if (var1.creationErrors[var3] != 0) {
               var0.writeByte(var1.creationErrors[var3]);
            } else {
               try {
                  int var4 = var1.operations[var3];
                  Field var5;
                  int var6;
                  if (var4 == 0) {
                     var5 = var1.fields[var3];
                     var6 = var5.getInt((Object)null);
                     var0.writeByte(0);
                     var0.writeInt(var6);
                  } else if (var4 == 1) {
                     var5 = var1.fields[var3];
                     var5.setInt((Object)null, var1.intReplaceValues[var3]);
                     var0.writeByte(0);
                  } else if (var4 == 2) {
                     var5 = var1.fields[var3];
                     var6 = var5.getModifiers();
                     var0.writeByte(0);
                     var0.writeInt(var6);
                  }

                  Method var25;
                  if (var4 != 3) {
                     if (var4 == 4) {
                        var25 = var1.methods[var3];
                        var6 = var25.getModifiers();
                        var0.writeByte(0);
                        var0.writeInt(var6);
                     }
                  } else {
                     var25 = var1.methods[var3];
                     byte[][] var10 = var1.arguments[var3];
                     Object[] var7 = new Object[var10.length];

                     for(int var8 = 0; var8 < var10.length; ++var8) {
                        ObjectInputStream var9 = new ObjectInputStream(new ByteArrayInputStream(var10[var8]));
                        var7[var8] = var9.readObject();
                     }

                     Object var11 = var25.invoke((Object)null, var7);
                     if (var11 == null) {
                        var0.writeByte(0);
                     } else if (var11 instanceof Number) {
                        var0.writeByte(1);
                        var0.writeLong(((Number)var11).longValue());
                     } else if (var11 instanceof String) {
                        var0.writeByte(2);
                        var0.writeStringCp1252NullTerminated((String)var11);
                     } else {
                        var0.writeByte(4);
                     }
                  }
               } catch (ClassNotFoundException var13) {
                  var0.writeByte(-10);
               } catch (InvalidClassException var14) {
                  var0.writeByte(-11);
               } catch (StreamCorruptedException var15) {
                  var0.writeByte(-12);
               } catch (OptionalDataException var16) {
                  var0.writeByte(-13);
               } catch (IllegalAccessException var17) {
                  var0.writeByte(-14);
               } catch (IllegalArgumentException var18) {
                  var0.writeByte(-15);
               } catch (InvocationTargetException var19) {
                  var0.writeByte(-16);
               } catch (SecurityException var20) {
                  var0.writeByte(-17);
               } catch (IOException var21) {
                  var0.writeByte(-18);
               } catch (NullPointerException var22) {
                  var0.writeByte(-19);
               } catch (Exception var23) {
                  var0.writeByte(-20);
               } catch (Throwable var24) {
                  var0.writeByte(-21);
               }
            }
         }

         var0.method3892(var2);
         var1.remove();
      }
   }

   public static OverlayDefinition method4321(int var0) {
      OverlayDefinition var1 = (OverlayDefinition)OverlayDefinition.field3678.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = OverlayDefinition.field3688.takeRecord(4, var0);
         var1 = new OverlayDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2), var0);
         }

         var1.init();
         OverlayDefinition.field3678.put(var1, (long)var0);
         return var1;
      }
   }

   static final void method4320(Widget var0, int var1, int var2) {
      if (Client.field2319 == 0 || Client.field2319 == 3) {
         if (!Client.field2276 && (MouseHandler.field158 == 1 || !WorldMapSection0.field1101 && MouseHandler.field158 == 4)) {
            SpriteMask var3 = var0.getSpriteMask(true);
            if (var3 == null) {
               return;
            }

            int var4 = MouseHandler.field159 - var1;
            int var5 = MouseHandler.field148 - var2;
            if (var3.contains(var4, var5)) {
               var4 -= var3.width / 2;
               var5 -= var3.height / 2;
               int var6 = Client.field2101 & 2047;
               int var7 = Rasterizer3D.field1446[var6];
               int var8 = Rasterizer3D.field1453[var6];
               int var9 = var4 * var8 + var5 * var7 >> 11;
               int var10 = var5 * var8 - var7 * var4 >> 11;
               int var11 = var9 + ObjectSound.field589.x >> 7;
               int var12 = ObjectSound.field589.y - var10 >> 7;
               PacketBufferNode var13 = FaceNormal.method2884(ClientPacket.field1867, Client.field2133.isaacCipher);
               var13.packetBuffer.writeByte(18);
               var13.packetBuffer.method4029(var12 + class79.field902);
               var13.packetBuffer.method4029(var11 + class21.field230);
               var13.packetBuffer.method3937(KeyHandler.field11[82] ? (KeyHandler.field11[81] ? 2 : 1) : 0);
               var13.packetBuffer.writeByte(var4);
               var13.packetBuffer.writeByte(var5);
               var13.packetBuffer.writeShort(Client.field2101);
               var13.packetBuffer.writeByte(57);
               var13.packetBuffer.writeByte(0);
               var13.packetBuffer.writeByte(0);
               var13.packetBuffer.writeByte(89);
               var13.packetBuffer.writeShort(ObjectSound.field589.x);
               var13.packetBuffer.writeShort(ObjectSound.field589.y);
               var13.packetBuffer.writeByte(63);
               Client.field2133.method1281(var13);
               Client.field2165 = var11;
               Client.field2318 = var12;
            }
         }

      }
   }
}
