public class AbstractSoundSystem {
   public static int field936;
   int field938 = 0;
   TaskDataNode[] field935 = new TaskDataNode[8];
   TaskDataNode[] field925 = new TaskDataNode[8];
   int field926;
   int field924;
   long timeMs = Tile.method2779();
   protected int[] ints;
   long field928 = 0L;
   boolean field933 = true;
   int field930 = 0;
   int field927;
   long field934 = 0L;
   int field923 = 32;
   TaskDataNode field922;
   int field931 = 0;
   int field929 = 0;

   final void method1643(int[] var1, int var2) {
      int var3 = var2;
      if (class5.field52) {
         var3 = var2 << 1;
      }

      class195.method4153(var1, 0, var3);
      this.field938 -= var2;
      if (this.field922 != null && this.field938 <= 0) {
         this.field938 += field936 >> 4;
         MouseRecorder.method1007(this.field922);
         this.method1644(this.field922, this.field922.vmethod2806());
         int var4 = 0;
         int var5 = 255;

         int var6;
         TaskDataNode var10;
         label104:
         for(var6 = 7; var5 != 0; --var6) {
            int var7;
            int var8;
            if (var6 < 0) {
               var7 = var6 & 3;
               var8 = -(var6 >> 2);
            } else {
               var7 = var6;
               var8 = 0;
            }

            for(int var9 = var5 >>> var7 & 286331153; var9 != 0; var9 >>>= 4) {
               if ((var9 & 1) != 0) {
                  var5 &= ~(1 << var7);
                  var10 = null;
                  TaskDataNode var11 = this.field925[var7];

                  label98:
                  while(true) {
                     while(true) {
                        if (var11 == null) {
                           break label98;
                        }

                        AbstractIntNode var12 = var11.field1557;
                        if (var12 != null && var12.integer > var8) {
                           var5 |= 1 << var7;
                           var10 = var11;
                           var11 = var11.field1559;
                        } else {
                           var11.field1560 = true;
                           int var13 = var11.vmethod4641();
                           var4 += var13;
                           if (var12 != null) {
                              var12.integer += var13;
                           }

                           if (var4 >= this.field923) {
                              break label104;
                           }

                           TaskDataNode var14 = var11.vmethod4628();
                           if (var14 != null) {
                              for(int var15 = var11.field1558; var14 != null; var14 = var11.vmethod4630()) {
                                 this.method1644(var14, var15 * var14.vmethod2806() >> 8);
                              }
                           }

                           TaskDataNode var18 = var11.field1559;
                           var11.field1559 = null;
                           if (var10 == null) {
                              this.field925[var7] = var18;
                           } else {
                              var10.field1559 = var18;
                           }

                           if (var18 == null) {
                              this.field935[var7] = var10;
                           }

                           var11 = var18;
                        }
                     }
                  }
               }

               var7 += 4;
               ++var8;
            }
         }

         for(var6 = 0; var6 < 8; ++var6) {
            TaskDataNode var16 = this.field925[var6];
            TaskDataNode[] var17 = this.field925;
            this.field935[var6] = null;

            for(var17[var6] = null; var16 != null; var16 = var10) {
               var10 = var16.field1559;
               var16.field1559 = null;
            }
         }
      }

      if (this.field938 < 0) {
         this.field938 = 0;
      }

      if (this.field922 != null) {
         this.field922.vmethod4652(var1, 0, var2);
      }

      this.timeMs = Tile.method2779();
   }

   public final void method1639() {
      this.field933 = true;
   }

   public final synchronized void method1638() {
      if (this.ints != null) {
         long var1 = Tile.method2779();

         try {
            if (0L != this.field928) {
               if (var1 < this.field928) {
                  return;
               }

               this.open(this.field924);
               this.field928 = 0L;
               this.field933 = true;
            }

            int var3 = this.remaining();
            if (this.field931 - var3 > this.field929) {
               this.field929 = this.field931 - var3;
            }

            int var4 = this.field926 + this.field927;
            if (var4 + 256 > 16384) {
               var4 = 16128;
            }

            if (var4 + 256 > this.field924) {
               this.field924 += 1024;
               if (this.field924 > 16384) {
                  this.field924 = 16384;
               }

               this.close();
               this.open(this.field924);
               var3 = 0;
               this.field933 = true;
               if (var4 + 256 > this.field924) {
                  var4 = this.field924 - 256;
                  this.field927 = var4 - this.field926;
               }
            }

            while(var3 < var4) {
               this.method1643(this.ints, 256);
               this.write();
               var3 += 256;
            }

            if (var1 > this.field934) {
               if (!this.field933) {
                  if (this.field929 == 0 && this.field930 == 0) {
                     this.close();
                     this.field928 = var1 + 2000L;
                     return;
                  }

                  this.field927 = Math.min(this.field930, this.field929);
                  this.field930 = this.field929;
               } else {
                  this.field933 = false;
               }

               this.field929 = 0;
               this.field934 = 2000L + var1;
            }

            this.field931 = var3;
         } catch (Exception var7) {
            this.close();
            this.field928 = var1 + 2000L;
         }

         try {
            if (var1 > 500000L + this.timeMs) {
               var1 = this.timeMs;
            }

            while(var1 > this.timeMs + 5000L) {
               this.method1642(256);
               this.timeMs += (long)(256000 / field936);
            }
         } catch (Exception var6) {
            this.timeMs = var1;
         }

      }
   }

   final void method1642(int var1) {
      this.field938 -= var1;
      if (this.field938 < 0) {
         this.field938 = 0;
      }

      if (this.field922 != null) {
         this.field922.vmethod4633(var1);
      }

   }

   public final synchronized void shutdown() {
      if (Skills.field3314 != null) {
         boolean var1 = true;

         for(int var2 = 0; var2 < 2; ++var2) {
            if (this == Skills.field3314.soundSystems[var2]) {
               Skills.field3314.soundSystems[var2] = null;
            }

            if (Skills.field3314.soundSystems[var2] != null) {
               var1 = false;
            }
         }

         if (var1) {
            Login.field661.shutdownNow();
            Login.field661 = null;
            Skills.field3314 = null;
         }
      }

      this.close();
      this.ints = null;
   }

   final void method1644(TaskDataNode var1, int var2) {
      int var3 = var2 >> 5;
      TaskDataNode var4 = this.field935[var3];
      if (var4 == null) {
         this.field925[var3] = var1;
      } else {
         var4.field1559 = var1;
      }

      this.field935[var3] = var1;
      var1.field1558 = var2;
   }

   public final synchronized void method1688(TaskDataNode var1) {
      this.field922 = var1;
   }

   public final synchronized void tryFlush() {
      this.field933 = true;

      try {
         this.flush();
      } catch (Exception var2) {
         this.close();
         this.field928 = Tile.method2779() + 2000L;
      }

   }

   protected void close() {
   }

   protected int remaining() throws Exception {
      return this.field924;
   }

   protected void vmethod1645() throws Exception {
   }

   protected void flush() throws Exception {
   }

   protected void write() throws Exception {
   }

   protected void open(int var1) throws Exception {
   }

   public static int method1697(int var0) {
      VarbitDefinition var1 = class45.method1021(var0);
      int var2 = var1.varp;
      int var3 = var1.lowBit;
      int var4 = var1.highBit;
      int var5 = Varps.field2760[var4 - var3];
      return Varps.field2762[var2] >> var3 & var5;
   }

   public static int method1696(String var0) {
      return var0.length() + 1;
   }

   static final void method1659(Widget[] var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      Rasterizer2D.method6243(var2, var3, var4, var5);
      Rasterizer3D.method2615();

      for(int var9 = 0; var9 < var0.length; ++var9) {
         Widget var10 = var0[var9];
         if (var10 != null && (var10.parentId == var1 || var1 == -1412584499 && var10 == Client.field2259)) {
            int var11;
            if (var8 == -1) {
               Client.field2206[Client.field2296] = var10.x + var6;
               Client.field2295[Client.field2296] = var7 + var10.y;
               Client.field2262[Client.field2296] = var10.width;
               Client.field2297[Client.field2296] = var10.height;
               var11 = ++Client.field2296 - 1;
            } else {
               var11 = var8;
            }

            var10.rootIndex = var11;
            var10.cycle = Client.field2098;
            if (!var10.isIf3 || !Canvas.method361(var10)) {
               if (var10.contentType > 0) {
                  WorldMapSection1.method504(var10);
               }

               int var12 = var10.x + var6;
               int var13 = var7 + var10.y;
               int var14 = var10.transparency;
               int var15;
               int var16;
               if (var10 == Client.field2259) {
                  if (var1 != -1412584499 && !var10.isScrollBar) {
                     WorldMapSection3.field615 = var0;
                     GrandExchangeEvents.field1001 = var6;
                     BufferedNetSocket.field1786 = var7;
                     continue;
                  }

                  if (Client.field2270 && Client.field2264) {
                     var15 = MouseHandler.field154;
                     var16 = MouseHandler.field145 * -976212263;
                     var15 -= Client.field2349;
                     var16 -= Client.field2281;
                     if (var15 < Client.field2156) {
                        var15 = Client.field2156;
                     }

                     if (var15 + var10.width > Client.field2156 + Client.field2260.width) {
                        var15 = Client.field2156 + Client.field2260.width - var10.width;
                     }

                     if (var16 < Client.field2266) {
                        var16 = Client.field2266;
                     }

                     if (var16 + var10.height > Client.field2266 + Client.field2260.height) {
                        var16 = Client.field2266 + Client.field2260.height - var10.height;
                     }

                     var12 = var15;
                     var13 = var16;
                  }

                  if (!var10.isScrollBar) {
                     var14 = 128;
                  }
               }

               int var17;
               int var18;
               int var19;
               int var20;
               int var21;
               int var22;
               if (var10.type == 2) {
                  var15 = var2;
                  var16 = var3;
                  var17 = var4;
                  var18 = var5;
               } else if (var10.type == 9) {
                  var19 = var12;
                  var20 = var13;
                  var21 = var12 + var10.width;
                  var22 = var13 + var10.height;
                  if (var21 < var12) {
                     var19 = var21;
                     var21 = var12;
                  }

                  if (var22 < var13) {
                     var20 = var22;
                     var22 = var13;
                  }

                  ++var21;
                  ++var22;
                  var15 = var19 > var2 ? var19 : var2;
                  var16 = var20 > var3 ? var20 : var3;
                  var17 = var21 < var4 ? var21 : var4;
                  var18 = var22 < var5 ? var22 : var5;
               } else {
                  var19 = var12 + var10.width;
                  var20 = var13 + var10.height;
                  var15 = var12 > var2 ? var12 : var2;
                  var16 = var13 > var3 ? var13 : var3;
                  var17 = var19 < var4 ? var19 : var4;
                  var18 = var20 < var5 ? var20 : var5;
               }

               if (!var10.isIf3 || var15 < var17 && var16 < var18) {
                  if (var10.contentType != 0) {
                     if (var10.contentType == 1336) {
                        if (Client.field2329) {
                           var13 += 15;
                           TotalQuantityComparator.field982.drawRightAligned("Fps:" + GameShell.field71, var12 + var10.width, var13, 16776960, -1);
                           var13 += 15;
                           Runtime var42 = Runtime.getRuntime();
                           var20 = (int)((var42.totalMemory() - var42.freeMemory()) / 1024L);
                           var21 = 16776960;
                           if (var20 > 327680 && !Client.field2091) {
                              var21 = 16711680;
                           }

                           TotalQuantityComparator.field982.drawRightAligned("Mem:" + var20 + "k", var12 + var10.width, var13, var21, -1);
                           var13 += 15;
                        }
                        continue;
                     }

                     if (var10.contentType == 1337) {
                        Client.field2235 = var12;
                        Client.field2303 = var13;
                        class6.method164(var12, var13, var10.width, var10.height);
                        Client.field2291[var10.rootIndex] = true;
                        Rasterizer2D.method6243(var2, var3, var4, var5);
                        continue;
                     }

                     if (var10.contentType == 1338) {
                        ChatChannel.method1115(var10, var12, var13, var11);
                        Rasterizer2D.method6243(var2, var3, var4, var5);
                        continue;
                     }

                     if (var10.contentType == 1339) {
                        DynamicObject.method1834(var10, var12, var13, var11);
                        Rasterizer2D.method6243(var2, var3, var4, var5);
                        continue;
                     }

                     if (var10.contentType == 1400) {
                        class12.field123.draw(var12, var13, var10.width, var10.height, Client.field2098);
                     }

                     if (var10.contentType == 1401) {
                        class12.field123.drawOverview(var12, var13, var10.width, var10.height);
                     }
                  }

                  if (var10.type == 0) {
                     if (!var10.isIf3 && Canvas.method361(var10) && var10 != BufferedSource.field1671) {
                        continue;
                     }

                     if (!var10.isIf3) {
                        if (var10.scrollY > var10.scrollHeight - var10.height) {
                           var10.scrollY = var10.scrollHeight - var10.height;
                        }

                        if (var10.scrollY < 0) {
                           var10.scrollY = 0;
                        }
                     }

                     method1659(var0, var10.id, var15, var16, var17, var18, var12 - var10.scrollX, var13 - var10.scrollY, var11);
                     if (var10.children != null) {
                        method1659(var10.children, var10.id, var15, var16, var17, var18, var12 - var10.scrollX, var13 - var10.scrollY, var11);
                     }

                     WidgetGroupParent var30 = (WidgetGroupParent) Client.field2247.get((long)var10.id);
                     if (var30 != null) {
                        class12.method376(var30.group, var15, var16, var17, var18, var12, var13, var11);
                     }

                     Rasterizer2D.method6243(var2, var3, var4, var5);
                     Rasterizer3D.method2615();
                  }

                  if (Client.field2118 || Client.field2149[var11] || Client.field2298 > 1) {
                     if (var10.type == 0 && !var10.isIf3 && var10.scrollHeight > var10.height) {
                        class69.method1444(var12 + var10.width, var13, var10.scrollY, var10.height, var10.scrollHeight);
                     }

                     if (var10.type != 1) {
                        int var23;
                        int var24;
                        int var25;
                        int var26;
                        if (var10.type == 2) {
                           var19 = 0;

                           for(var20 = 0; var20 < var10.rawHeight; ++var20) {
                              for(var21 = 0; var21 < var10.rawWidth; ++var21) {
                                 var22 = var21 * (var10.paddingX + 32) + var12;
                                 var23 = var13 + var20 * (var10.paddingY + 32);
                                 if (var19 < 20) {
                                    var22 += var10.inventoryXOffsets[var19];
                                    var23 += var10.inventoryYOffsets[var19];
                                 }

                                 if (var10.itemIds[var19] <= 0) {
                                    if (var10.inventorySprites != null && var19 < 20) {
                                       Sprite var46 = var10.getInventorySprite(var19);
                                       if (var46 != null) {
                                          var46.method6348(var22, var23);
                                       } else if (Widget.field2586) {
                                          WorldMapSection1.method506(var10);
                                       }
                                    }
                                 } else {
                                    boolean var37 = false;
                                    boolean var38 = false;
                                    var26 = var10.itemIds[var19] - 1;
                                    if (var22 + 32 > var2 && var22 < var4 && var23 + 32 > var3 && var23 < var5 || var10 == World.field361 && var19 == Client.field2194) {
                                       Sprite var27;
                                       if (Client.field2239 == 1 && var19 == WorldMapLabel.field1014 && var10.id == ChatChannel.field598) {
                                          var27 = WorldMapCacheName.method546(var26, var10.itemQuantities[var19], 2, 0, 2, false);
                                       } else {
                                          var27 = WorldMapCacheName.method546(var26, var10.itemQuantities[var19], 1, 3153952, 2, false);
                                       }

                                       if (var27 != null) {
                                          if (var10 == World.field361 && var19 == Client.field2194) {
                                             var24 = MouseHandler.field154 - Client.field2195;
                                             var25 = MouseHandler.field145 * -976212263 - Client.field2288;
                                             if (var24 < 5 && var24 > -5) {
                                                var24 = 0;
                                             }

                                             if (var25 < 5 && var25 > -5) {
                                                var25 = 0;
                                             }

                                             if (Client.field2199 < 5) {
                                                var24 = 0;
                                                var25 = 0;
                                             }

                                             var27.method6354(var22 + var24, var25 + var23, 128);
                                             if (var1 != -1) {
                                                Widget var28 = var0[var1 & '\uffff'];
                                                int var29;
                                                if (var25 + var23 < Rasterizer2D.field3902 && var28.scrollY > 0) {
                                                   var29 = (Rasterizer2D.field3902 - var23 - var25) * Client.field2148 / 3;
                                                   if (var29 > Client.field2148 * 10) {
                                                      var29 = Client.field2148 * 10;
                                                   }

                                                   if (var29 > var28.scrollY) {
                                                      var29 = var28.scrollY;
                                                   }

                                                   var28.scrollY -= var29;
                                                   Client.field2288 += var29;
                                                   WorldMapSection1.method506(var28);
                                                }

                                                if (var25 + var23 + 32 > Rasterizer2D.field3901 && var28.scrollY < var28.scrollHeight - var28.height) {
                                                   var29 = (var23 + var25 + 32 - Rasterizer2D.field3901) * Client.field2148 / 3;
                                                   if (var29 > Client.field2148 * 10) {
                                                      var29 = Client.field2148 * 10;
                                                   }

                                                   if (var29 > var28.scrollHeight - var28.height - var28.scrollY) {
                                                      var29 = var28.scrollHeight - var28.height - var28.scrollY;
                                                   }

                                                   var28.scrollY += var29;
                                                   Client.field2288 -= var29;
                                                   WorldMapSection1.method506(var28);
                                                }
                                             }
                                          } else if (var10 == class176.field1961 && var19 == Client.field2193) {
                                             var27.method6354(var22, var23, 128);
                                          } else {
                                             var27.method6348(var22, var23);
                                          }
                                       } else {
                                          WorldMapSection1.method506(var10);
                                       }
                                    }
                                 }

                                 ++var19;
                              }
                           }
                        } else if (var10.type == 3) {
                           if (WorldMapSection3.method1174(var10)) {
                              var19 = var10.color2;
                              if (var10 == BufferedSource.field1671 && var10.mouseOverColor2 != 0) {
                                 var19 = var10.mouseOverColor2;
                              }
                           } else {
                              var19 = var10.color;
                              if (var10 == BufferedSource.field1671 && var10.mouseOverColor != 0) {
                                 var19 = var10.mouseOverColor;
                              }
                           }

                           if (var10.fill) {
                              switch(var10.rectangleMode.id) {
                              case 1:
                                 Rasterizer2D.method6228(var12, var13, var10.width, var10.height, var10.color, var10.color2);
                                 break;
                              case 2:
                                 Rasterizer2D.method6215(var12, var13, var10.width, var10.height, var10.color, var10.color2, 255 - (var10.transparency & 255), 255 - (var10.field2620 & 255));
                                 break;
                              default:
                                 if (var14 == 0) {
                                    Rasterizer2D.method6223(var12, var13, var10.width, var10.height, var19);
                                 } else {
                                    Rasterizer2D.method6222(var12, var13, var10.width, var10.height, var19, 256 - (var14 & 255));
                                 }
                              }
                           } else if (var14 == 0) {
                              Rasterizer2D.method6292(var12, var13, var10.width, var10.height, var19);
                           } else {
                              Rasterizer2D.method6227(var12, var13, var10.width, var10.height, var19, 256 - (var14 & 255));
                           }
                        } else {
                           Font var39;
                           if (var10.type == 4) {
                              var39 = var10.getFont();
                              if (var39 == null) {
                                 if (Widget.field2586) {
                                    WorldMapSection1.method506(var10);
                                 }
                              } else {
                                 String var44 = var10.text;
                                 if (WorldMapSection3.method1174(var10)) {
                                    var20 = var10.color2;
                                    if (var10 == BufferedSource.field1671 && var10.mouseOverColor2 != 0) {
                                       var20 = var10.mouseOverColor2;
                                    }

                                    if (var10.text2.length() > 0) {
                                       var44 = var10.text2;
                                    }
                                 } else {
                                    var20 = var10.color;
                                    if (var10 == BufferedSource.field1671 && var10.mouseOverColor != 0) {
                                       var20 = var10.mouseOverColor;
                                    }
                                 }

                                 if (var10.isIf3 && var10.itemId != -1) {
                                    ItemDefinition var47 = Varcs.getItemDefinition(var10.itemId);
                                    var44 = var47.name;
                                    if (var44 == null) {
                                       var44 = "null";
                                    }

                                    if ((var47.isStackable == 1 || var10.itemQuantity != 1) && var10.itemQuantity != -1) {
                                       var44 = ModelData0.method2792(16748608) + var44 + "</col>" + " " + 'x' + class81.method1634(var10.itemQuantity);
                                    }
                                 }

                                 if (var10 == Client.field2323) {
                                    var44 = "Please wait...";
                                    var20 = var10.color;
                                 }

                                 if (!var10.isIf3) {
                                    var44 = class17.method466(var44, var10);
                                 }

                                 var39.drawLines(var44, var12, var13, var10.width, var10.height, var20, var10.textShadowed ? 0 : -1, var10.textXAlignment, var10.textYAlignment, var10.textLineHeight);
                              }
                           } else if (var10.type == 5) {
                              Sprite var40;
                              if (!var10.isIf3) {
                                 var40 = var10.getSprite(WorldMapSection3.method1174(var10));
                                 if (var40 != null) {
                                    var40.method6348(var12, var13);
                                 } else if (Widget.field2586) {
                                    WorldMapSection1.method506(var10);
                                 }
                              } else {
                                 if (var10.itemId != -1) {
                                    var40 = WorldMapCacheName.method546(var10.itemId, var10.itemQuantity, var10.outline, var10.spriteShadow, var10.field2718, false);
                                 } else {
                                    var40 = var10.getSprite(false);
                                 }

                                 if (var40 == null) {
                                    if (Widget.field2586) {
                                       WorldMapSection1.method506(var10);
                                    }
                                 } else {
                                    var20 = var40.width;
                                    var21 = var40.height;
                                    if (!var10.spriteTiling) {
                                       var22 = var10.width * 4096 / var20;
                                       if (var10.spriteAngle != 0) {
                                          var40.method6366(var10.width / 2 + var12, var10.height / 2 + var13, var10.spriteAngle, var22);
                                       } else if (var14 != 0) {
                                          var40.method6356(var12, var13, var10.width, var10.height, 256 - (var14 & 255));
                                       } else if (var20 == var10.width && var21 == var10.height) {
                                          var40.method6348(var12, var13);
                                       } else {
                                          var40.method6350(var12, var13, var10.width, var10.height);
                                       }
                                    } else {
                                       Rasterizer2D.method6217(var12, var13, var12 + var10.width, var13 + var10.height);
                                       var22 = (var20 - 1 + var10.width) / var20;
                                       var23 = (var21 - 1 + var10.height) / var21;

                                       for(var24 = 0; var24 < var22; ++var24) {
                                          for(var25 = 0; var25 < var23; ++var25) {
                                             if (var10.spriteAngle != 0) {
                                                var40.method6366(var20 / 2 + var12 + var24 * var20, var21 / 2 + var13 + var21 * var25, var10.spriteAngle, 4096);
                                             } else if (var14 != 0) {
                                                var40.method6354(var12 + var20 * var24, var13 + var25 * var21, 256 - (var14 & 255));
                                             } else {
                                                var40.method6348(var12 + var20 * var24, var13 + var21 * var25);
                                             }
                                          }
                                       }

                                       Rasterizer2D.method6243(var2, var3, var4, var5);
                                    }
                                 }
                              }
                           } else {
                              ItemDefinition var32;
                              if (var10.type == 6) {
                                 boolean var36 = WorldMapSection3.method1174(var10);
                                 if (var36) {
                                    var20 = var10.sequenceId2;
                                 } else {
                                    var20 = var10.sequenceId;
                                 }

                                 Model var41 = null;
                                 var22 = 0;
                                 if (var10.itemId != -1) {
                                    var32 = Varcs.getItemDefinition(var10.itemId);
                                    if (var32 != null) {
                                       var32 = var32.method5517(var10.itemQuantity);
                                       var41 = var32.getModel(1);
                                       if (var41 != null) {
                                          var41.calculateBoundsCylinder();
                                          var22 = var41.height / 2;
                                       } else {
                                          WorldMapSection1.method506(var10);
                                       }
                                    }
                                 } else if (var10.modelType == 5) {
                                    if (var10.modelId == 0) {
                                       var41 = Client.field2351.getModel((SequenceDefinition)null, -1, (SequenceDefinition)null, -1);
                                    } else {
                                       var41 = ObjectSound.field589.getModel();
                                    }
                                 } else if (var20 == -1) {
                                    var41 = var10.getModel((SequenceDefinition)null, -1, var36, ObjectSound.field589.appearance);
                                    if (var41 == null && Widget.field2586) {
                                       WorldMapSection1.method506(var10);
                                    }
                                 } else {
                                    SequenceDefinition var45 = WorldMapCacheName.method547(var20);
                                    var41 = var10.getModel(var45, var10.modelFrame, var36, ObjectSound.field589.appearance);
                                    if (var41 == null && Widget.field2586) {
                                       WorldMapSection1.method506(var10);
                                    }
                                 }

                                 Rasterizer3D.method2601(var10.width / 2 + var12, var10.height / 2 + var13);
                                 var23 = Rasterizer3D.field1446[var10.modelAngleX] * var10.modelZoom >> 16;
                                 var24 = Rasterizer3D.field1453[var10.modelAngleX] * var10.modelZoom >> 16;
                                 if (var41 != null) {
                                    if (!var10.isIf3) {
                                       var41.method2496(0, var10.modelAngleY, 0, var10.modelAngleX, 0, var23, var24);
                                    } else {
                                       var41.calculateBoundsCylinder();
                                       if (var10.modelOrthog) {
                                          var41.method2458(0, var10.modelAngleY, var10.modelAngleZ, var10.modelAngleX, var10.modelOffsetX, var22 + var23 + var10.modelOffsetY, var24 + var10.modelOffsetY, var10.modelZoom);
                                       } else {
                                          var41.method2496(0, var10.modelAngleY, var10.modelAngleZ, var10.modelAngleX, var10.modelOffsetX, var23 + var22 + var10.modelOffsetY, var24 + var10.modelOffsetY);
                                       }
                                    }
                                 }

                                 Rasterizer3D.method2629();
                              } else {
                                 if (var10.type == 7) {
                                    var39 = var10.getFont();
                                    if (var39 == null) {
                                       if (Widget.field2586) {
                                          WorldMapSection1.method506(var10);
                                       }
                                       continue;
                                    }

                                    var20 = 0;

                                    for(var21 = 0; var21 < var10.rawHeight; ++var21) {
                                       for(var22 = 0; var22 < var10.rawWidth; ++var22) {
                                          if (var10.itemIds[var20] > 0) {
                                             var32 = Varcs.getItemDefinition(var10.itemIds[var20] - 1);
                                             String var34;
                                             if (var32.isStackable != 1 && var10.itemQuantities[var20] == 1) {
                                                var34 = ModelData0.method2792(16748608) + var32.name + "</col>";
                                             } else {
                                                var34 = ModelData0.method2792(16748608) + var32.name + "</col>" + " " + 'x' + class81.method1634(var10.itemQuantities[var20]);
                                             }

                                             var25 = var12 + var22 * (var10.paddingX + 115);
                                             var26 = var21 * (var10.paddingY + 12) + var13;
                                             if (var10.textXAlignment == 0) {
                                                var39.draw(var34, var25, var26, var10.color, var10.textShadowed ? 0 : -1);
                                             } else if (var10.textXAlignment == 1) {
                                                var39.drawCentered(var34, var10.width / 2 + var25, var26, var10.color, var10.textShadowed ? 0 : -1);
                                             } else {
                                                var39.drawRightAligned(var34, var25 + var10.width - 1, var26, var10.color, var10.textShadowed ? 0 : -1);
                                             }
                                          }

                                          ++var20;
                                       }
                                    }
                                 }

                                 if (var10.type == 8 && var10 == Tiles.field206 && Client.field2238 == Client.field2237) {
                                    var19 = 0;
                                    var20 = 0;
                                    Font var31 = TotalQuantityComparator.field982;
                                    String var33 = var10.text;

                                    String var43;
                                    for(var33 = class17.method466(var33, var10); var33.length() > 0; var20 = var20 + var31.ascent + 1) {
                                       var24 = var33.indexOf("<br>");
                                       if (var24 != -1) {
                                          var43 = var33.substring(0, var24);
                                          var33 = var33.substring(var24 + 4);
                                       } else {
                                          var43 = var33;
                                          var33 = "";
                                       }

                                       var25 = var31.stringWidth(var43);
                                       if (var25 > var19) {
                                          var19 = var25;
                                       }
                                    }

                                    var19 += 6;
                                    var20 += 7;
                                    var24 = var12 + var10.width - 5 - var19;
                                    var25 = var13 + var10.height + 5;
                                    if (var24 < var12 + 5) {
                                       var24 = var12 + 5;
                                    }

                                    if (var19 + var24 > var4) {
                                       var24 = var4 - var19;
                                    }

                                    if (var25 + var20 > var5) {
                                       var25 = var5 - var20;
                                    }

                                    Rasterizer2D.method6223(var24, var25, var19, var20, 16777120);
                                    Rasterizer2D.method6292(var24, var25, var19, var20, 0);
                                    var33 = var10.text;
                                    var26 = var25 + var31.ascent + 2;

                                    for(var33 = class17.method466(var33, var10); var33.length() > 0; var26 = var26 + var31.ascent + 1) {
                                       int var35 = var33.indexOf("<br>");
                                       if (var35 != -1) {
                                          var43 = var33.substring(0, var35);
                                          var33 = var33.substring(var35 + 4);
                                       } else {
                                          var43 = var33;
                                          var33 = "";
                                       }

                                       var31.draw(var43, var24 + 3, var26, 0, -1);
                                    }
                                 }

                                 if (var10.type == 9) {
                                    if (var10.field2622) {
                                       var19 = var12;
                                       var20 = var13 + var10.height;
                                       var21 = var12 + var10.width;
                                       var22 = var13;
                                    } else {
                                       var19 = var12;
                                       var20 = var13;
                                       var21 = var12 + var10.width;
                                       var22 = var13 + var10.height;
                                    }

                                    if (var10.lineWid == 1) {
                                       Rasterizer2D.method6231(var19, var20, var21, var22, var10.color);
                                    } else {
                                       ClientPacket.method3234(var19, var20, var21, var22, var10.color, var10.lineWid);
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

   }
}
