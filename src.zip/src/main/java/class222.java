public class class222 extends Node {
   class104 field2748;
   int field2737;
   int field2750;
   int field2742;
   class88 field2732;
   int field2747;
   int field2752;
   int field2746;
   int field2739;
   int field2731;
   int field2735;
   int field2741;
   int field2753;
   int field2740;
   class209 field2733;
   MusicPatch field2738;
   int field2743;
   int field2745;
   int field2736;
   int field2744;
   int field2734;

   void method4624() {
      this.field2738 = null;
      this.field2732 = null;
      this.field2733 = null;
      this.field2748 = null;
   }

   public static HitSplatDefinition method4627(int var0) {
      HitSplatDefinition var1 = (HitSplatDefinition)HitSplatDefinition.field3357.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = class176.field1959.takeRecord(32, var0);
         var1 = new HitSplatDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         HitSplatDefinition.field3357.put(var1, (long)var0);
         return var1;
      }
   }

   static final void method4626() {
      class6.method183("Your friend list is full. Max of 200 for free users, and 400 for members");
   }
}
