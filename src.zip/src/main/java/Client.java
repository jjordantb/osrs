import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

public final class Client extends GameShell implements Usernamed {

   static int field2246;
   static Widget field2259;
   static int field2296;
   static int field2290;
   static long field2313;
   static boolean field2322;
   static boolean[] field2291;
   static boolean[] field2149;
   static boolean[] field2292;
   static boolean field2267;
   static boolean field2264;
   static int field2271;
   static boolean field2118;
   static int field2279;
   public static int field2357;
   static AbstractSoundSystem field2325;
   static int field2349;
   static int field2281;
   static int field2156;
   static NodeHashTable field2243;
   static Widget field2260;
   static Widget field2258;
   static int[] field2206;
   static NodeHashTable field2247;
   static int[] field2262;
   static int field2266;
   static int field2298;
   static int[] field2297;
   static int field2255;
   static int[] field2295;
   static final class31 field2113;
   static NodeDeque field2285;
   static int field2268;
   static int field2269;
   static int field2253;
   static int field2294;
   static int field2128;
   static int field2321;
   static int[] field2361;
   static int[] field2343;
   static boolean field2270;
   static int field2331;
   static String field2244;
   static int[] field2274;
   static String field2159;
   static int field2275;
   static int field2348;
   static int[] field2327;
   static int[] field2328;
   static int field2165;
   static int[] field2236;
   static int field2318;
   static SoundEffect[] field2153;
   static int field2317;
   static int[] field2330;
   static PlayerAppearance field2351;
   static int field2324;
   static int field2353;
   static int field2284;
   static Widget field2254;
   static int field2320;
   static int field2273;
   static int field2319;
   static ArrayList field2358;
   static int field2208;
   static boolean field2332;
   static int field2104;
   static int field2282;
   static long field2311;
   static Widget field2323;
   static short field2092;
   static int field2263;
   static short field2339;
   static short field2344;
   static PlatformInfoProvider field2354;
   static short field2197;
   static short field2127;
   static int[] field2314;
   static int field2350;
   static short field2342;
   static int field2087;
   static int[] field2315;
   static Sprite[] field2316;
   static int[] field2096;
   static int field2207;
   static int field2100;
   static int field2308;
   static int field2136;
   static int field2304;
   static int field2173;
   static short field2341;
   static short field2340;
   static int field2242;
   static boolean[] field2333;
   static boolean field2306;
   static int[] field2310;
   static int[] field2289;
   static int field2280;
   static NodeDeque field2286;
   static int field2177;
   static NodeDeque field2287;
   static int[] field2335;
   static int[] field2217;
   static GrandExchangeOffer[] field2338;
   static int field2277;
   static int[] field2334;
   static int[] field2336;
   static int field2301;
   static int field2250;
   static int[] field2337;
   static int field2251;
   static int field2248;
   static int field2085;
   static int field2256;
   static long[] field2283;
   static int field2307;
   static int field2278;
   static String field2305;
   static OwnWorldComparator field2356;
   static int[] field2302;
   static boolean field2299 = true;
   static int field2094 = -1;
   static int field2163 = 0;
   static int field2228 = 0;
   static boolean field2213 = false;
   static int field2088 = 0;
   static int field2093;
   static StudioGame field2089;
   public static boolean field2090 = false;
   public static int field2134 = 1;
   static LoginType field2363;
   static boolean field2091 = false;
   static int field2103 = 0;
   static int field2178 = -1;
   static int field2098 = 0;
   static boolean field2097 = true;
   static int field2086 = -1;
   static int field2106 = 0;
   static int field2112 = 0;
   static int field2110 = 0;
   static boolean field2329 = false;
   static long field2257 = -1L;
   static boolean field2362 = true;
   static int field2105 = 0;
   static int field2109 = 0;
   static int field2108 = 0;
   static int field2107 = 0;
   static int field2111 = 0;
   static int field2198 = 0;
   static long field2099 = 1L;
   static CollisionMap[] field2144;
   static AttackOption field2114;
   static int field2345;
   static int field2117;
   static int field2125;
   static AttackOption field2115;
   static byte[] field2151;
   static int field2230;
   static boolean field2189;
   static int[] field2130;
   static int field2120;
   static class130 field2124;
   static Npc[] field2249;
   static int field2129;
   static int field2222;
   static int field2203;
   static SecureRandomFuture field2126;
   static int field2121;
   static int field2122;
   static boolean field2135;
   static int[] field2132;
   public static final PacketWriter field2133;
   static int field2168;
   static int field2352;
   static int field2140;
   static int field2143;
   static int field2139;
   static Timer field2347;
   static boolean field2265;
   static int field2196;
   static HashMap field2138;
   static final int[] field2147;
   static int field2148;
   static int field2221;
   static boolean field2145;
   static int[][][] field2146;
   static int field2360;
   static int field2152;
   static int field2101;
   static int field2161;
   static int field2150;
   static boolean field2137;
   static int field2155;
   static int field2245;
   static int field2300;
   static int field2157;
   static int field2160;
   static int field2158;
   static int field2164;
   static int field2312;
   static int field2162;
   static int field2326;
   static int field2187;
   static int[] field2200;
   static int field2184;
   static String[] field2182;
   static boolean field2169;
   static int[] field2176;
   static int field2170;
   static int[] field2261;
   static int field2346;
   static int[] field2175;
   static int field2188;
   static int field2355;
   static int field2095;
   static int[] field2181;
   static int field2172;
   static int[] field2180;
   static boolean field2171;
   static int field2166;
   static int[][] field2183;
   static String field2209;
   static int[] field2179;
   static int field2167;
   static int field2102;
   static int field2174;
   static boolean field2191;
   static int field2195;
   static int field2190;
   static int field2288;
   static int field2192;
   static int field2194;
   static int field2193;
   static boolean field2201;
   static boolean field2205;
   static Player[] field2141;
   static boolean field2116;
   static int field2204;
   static int field2202;
   static int field2199;
   static int field2240;
   static int field2252;
   static int field2123;
   static int field2119;
   static NodeDeque field2131;
   static String[] field2210;
   static int[] field2186;
   static boolean field2276;
   static final int[] field2185;
   static NodeDeque[][][] field2272;
   static int[] field2142;
   static int[] field2220;
   static int[] field2219;
   static int field2212;
   static int field2223;
   static int field2309;
   static int field2293;
   static NodeDeque field2216;
   static int[] field2218;
   static boolean[] field2211;
   static NodeDeque field2154;
   static int[] field2225;
   static int[] field2227;
   static int field2303;
   static int field2239;
   static int field2237;
   static boolean field2231;
   static boolean field2233;
   static boolean[] field2215;
   static String[] field2359;
   static String[] field2229;
   static int field2238;
   static boolean field2234;
   static boolean field2241;
   static int field2235;
   static int[] field2224;
   static int[] field2226;
   static boolean field2232;

   static {
      field2114 = AttackOption.field600;
      field2115 = AttackOption.field600;
      field2345 = 0;
      field2117 = 0;
      field2125 = 0;
      field2230 = 0;
      field2120 = 0;
      field2121 = 0;
      field2122 = 0;
      field2203 = 0;
      field2124 = class130.field1561;
      field2189 = false;
      field2126 = new SecureRandomFuture();
      field2151 = null;
      field2249 = new Npc['耀'];
      field2129 = 0;
      field2130 = new int['耀'];
      field2222 = 0;
      field2132 = new int[250];
      field2133 = new PacketWriter();
      field2168 = 0;
      field2135 = false;
      field2265 = true;
      field2347 = new Timer();
      field2138 = new HashMap();
      field2139 = 0;
      field2140 = 1;
      field2196 = 0;
      field2352 = 1;
      field2143 = 0;
      field2144 = new CollisionMap[4];
      field2145 = false;
      field2146 = new int[4][13][13];
      field2147 = new int[]{0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3};
      field2148 = 0;
      field2360 = 2301979;
      field2221 = 5063219;
      field2326 = 3353893;
      field2152 = 7759444;
      field2137 = false;
      field2245 = 0;
      field2155 = 128;
      field2101 = 0;
      field2157 = 0;
      field2158 = 0;
      field2312 = 0;
      field2160 = 0;
      field2161 = 0;
      field2162 = 50;
      field2150 = 0;
      field2164 = 0;
      field2300 = 0;
      field2166 = 12;
      field2167 = 6;
      field2102 = 0;
      field2169 = false;
      field2170 = 0;
      field2171 = false;
      field2172 = 0;
      field2355 = 0;
      field2174 = 50;
      field2175 = new int[field2174];
      field2176 = new int[field2174];
      field2181 = new int[field2174];
      field2200 = new int[field2174];
      field2179 = new int[field2174];
      field2180 = new int[field2174];
      field2261 = new int[field2174];
      field2182 = new String[field2174];
      field2183 = new int[104][104];
      field2184 = 0;
      field2095 = -1;
      field2346 = -1;
      field2187 = 0;
      field2188 = 0;
      field2252 = 0;
      field2202 = 0;
      field2191 = true;
      field2192 = 0;
      field2193 = 0;
      field2194 = 0;
      field2195 = 0;
      field2288 = 0;
      field2240 = 0;
      field2116 = false;
      field2199 = 0;
      field2123 = 0;
      field2201 = true;
      field2141 = new Player[2048];
      field2190 = -1;
      field2204 = 0;
      field2205 = true;
      field2119 = 0;
      field2293 = 0;
      field2186 = new int[1000];
      field2185 = new int[]{44, 45, 46, 47, 48, 49, 50, 51};
      field2210 = new String[8];
      field2211 = new boolean[8];
      field2142 = new int[]{768, 1024, 1280, 512, 1536, 256, 0, 1792};
      field2212 = -1;
      field2272 = new NodeDeque[4][104][104];
      field2131 = new NodeDeque();
      field2216 = new NodeDeque();
      field2154 = new NodeDeque();
      field2218 = new int[25];
      field2219 = new int[25];
      field2220 = new int[25];
      field2309 = 0;
      field2276 = false;
      field2223 = 0;
      field2224 = new int[500];
      field2225 = new int[500];
      field2226 = new int[500];
      field2227 = new int[500];
      field2359 = new String[500];
      field2229 = new String[500];
      field2215 = new boolean[500];
      field2231 = false;
      field2232 = false;
      field2233 = false;
      field2234 = true;
      field2235 = -1;
      field2303 = -1;
      field2237 = 0;
      field2238 = 50;
      field2239 = 0;
      field2209 = null;
      field2241 = false;
      field2242 = -1;
      field2177 = -1;
      field2244 = null;
      field2159 = null;
      field2246 = -1;
      field2247 = new NodeHashTable(8);
      field2248 = 0;
      field2085 = -1;
      field2250 = 0;
      field2251 = 0;
      field2323 = null;
      field2253 = 0;
      field2294 = 0;
      field2255 = 0;
      field2256 = -1;
      field2306 = false;
      field2258 = null;
      field2259 = null;
      field2260 = null;
      field2349 = 0;
      field2281 = 0;
      field2254 = null;
      field2264 = false;
      field2156 = -1;
      field2266 = -1;
      field2267 = false;
      field2268 = -1;
      field2269 = -1;
      field2270 = false;
      field2271 = 1;
      field2096 = new int[32];
      field2273 = 0;
      field2274 = new int[32];
      field2275 = 0;
      field2217 = new int[32];
      field2277 = 0;
      field2278 = 0;
      field2279 = 0;
      field2280 = 0;
      field2301 = 0;
      field2282 = 0;
      field2128 = 0;
      field2284 = 0;
      field2285 = new NodeDeque();
      field2286 = new NodeDeque();
      field2287 = new NodeDeque();
      field2243 = new NodeHashTable(512);
      field2296 = 0;
      field2290 = -2;
      field2291 = new boolean[100];
      field2292 = new boolean[100];
      field2149 = new boolean[100];
      field2206 = new int[100];
      field2295 = new int[100];
      field2262 = new int[100];
      field2297 = new int[100];
      field2298 = 0;
      field2313 = 0L;
      field2118 = true;
      field2302 = new int[]{16776960, 16711680, 65280, 65535, 16711935, 16777215};
      field2173 = 0;
      field2304 = 0;
      field2305 = "";
      field2283 = new long[100];
      field2307 = 0;
      field2308 = 0;
      field2289 = new int[128];
      field2310 = new int[128];
      field2311 = -1L;
      field2104 = -1;
      field2263 = 0;
      field2314 = new int[1000];
      field2315 = new int[1000];
      field2316 = new Sprite[1000];
      field2165 = 0;
      field2318 = 0;
      field2319 = 0;
      field2320 = 255;
      field2321 = -1;
      field2322 = false;
      field2331 = 127;
      field2324 = 127;
      field2348 = 0;
      field2327 = new int[50];
      field2328 = new int[50];
      field2236 = new int[50];
      field2330 = new int[50];
      field2153 = new SoundEffect[50];
      field2332 = false;
      field2333 = new boolean[5];
      field2334 = new int[5];
      field2335 = new int[5];
      field2336 = new int[5];
      field2337 = new int[5];
      field2092 = 256;
      field2339 = 205;
      field2340 = 256;
      field2341 = 320;
      field2342 = 1;
      field2127 = 32767;
      field2344 = 1;
      field2197 = 32767;
      field2100 = 0;
      field2136 = 0;
      field2087 = 0;
      field2207 = 0;
      field2350 = 0;
      field2351 = new PlayerAppearance();
      field2317 = -1;
      field2353 = -1;
      field2354 = new DesktopPlatformInfoProvider();
      field2338 = new GrandExchangeOffer[8];
      field2356 = new OwnWorldComparator();
      field2357 = -1;
      field2358 = new ArrayList(10);
      field2208 = 0;
      field2113 = new class31();
      field2361 = new int[50];
      field2343 = new int[50];
   }

   protected final void vmethod3322() {
      ++field2098;
      this.method3325();
      MouseHandler.method459();

      int var1;
      try {
         if (class219.field2568 == 1) {
            var1 = class205.field2492.method4370();
            if (var1 > 0 && class205.field2492.method4459()) {
               var1 -= WorldComparator.field810;
               if (var1 < 0) {
                  var1 = 0;
               }

               class205.field2492.method4393(var1);
            } else {
               class205.field2492.method4488();
               class205.field2492.method4443();
               if (UrlRequester.field1584 != null) {
                  class219.field2568 = 2;
               } else {
                  class219.field2568 = 0;
               }

               GrandExchangeOffer.field697 = null;
               SecureRandomFuture.field851 = null;
            }
         }
      } catch (Exception var64) {
         var64.printStackTrace();
         class205.field2492.method4488();
         class219.field2568 = 0;
         GrandExchangeOffer.field697 = null;
         SecureRandomFuture.field851 = null;
         UrlRequester.field1584 = null;
      }

      class162.method3077();
      KeyHandler var47 = KeyHandler.field17;
      int var2;
      synchronized(KeyHandler.field17) {
         ++KeyHandler.field22;
         KeyHandler.field19 = KeyHandler.field21;
         KeyHandler.field18 = 0;
         if (KeyHandler.field14 >= 0) {
            while(KeyHandler.field5 != KeyHandler.field14) {
               var2 = KeyHandler.field12[KeyHandler.field5];
               KeyHandler.field5 = KeyHandler.field5 + 1 & 127;
               if (var2 < 0) {
                  KeyHandler.field11[~var2] = false;
               } else {
                  if (!KeyHandler.field11[var2] && KeyHandler.field18 < KeyHandler.field8.length - 1) {
                     KeyHandler.field8[++KeyHandler.field18 - 1] = var2;
                  }

                  KeyHandler.field11[var2] = true;
               }
            }
         } else {
            for(var2 = 0; var2 < 112; ++var2) {
               KeyHandler.field11[var2] = false;
            }

            KeyHandler.field14 = KeyHandler.field5;
         }

         if (KeyHandler.field18 > 0) {
            KeyHandler.field22 = 0;
         }

         KeyHandler.field21 = KeyHandler.field20;
      }

      MouseHandler var75 = MouseHandler.field151;
      synchronized(MouseHandler.field151) {
         MouseHandler.field150 = MouseHandler.field162;
         MouseHandler.field154 = MouseHandler.field147;
         MouseHandler.field145 = MouseHandler.field144 * -1727565463;
         MouseHandler.field153 = MouseHandler.field149;
         MouseHandler.field158 = MouseHandler.field152;
         MouseHandler.field159 = MouseHandler.field155;
         MouseHandler.field148 = MouseHandler.field156;
         MouseHandler.field146 = MouseHandler.field157;
         MouseHandler.field152 = 0;
      }

      if (IndexStore.field1835 != null) {
         var1 = IndexStore.field1835.useRotation();
         field2284 = var1;
      }

      if (field2163 == 0) {
         SecureRandomFuture.method1481();
         GameShell.field70.mark();

         for(var1 = 0; var1 < 32; ++var1) {
            GameShell.field66[var1] = 0L;
         }

         for(var1 = 0; var1 < 32; ++var1) {
            GameShell.field81[var1] = 0L;
         }

         class167.field1800 = 0;
      } else if (field2163 == 5) {
         ClientPreferences.method804(this);
         SecureRandomFuture.method1481();
         GameShell.field70.mark();

         for(var1 = 0; var1 < 32; ++var1) {
            GameShell.field66[var1] = 0L;
         }

         for(var1 = 0; var1 < 32; ++var1) {
            GameShell.field81[var1] = 0L;
         }

         class167.field1800 = 0;
      } else if (field2163 != 10 && field2163 != 11) {
         if (field2163 == 20) {
            ClientPreferences.method804(this);
            this.method3328();
         } else if (field2163 == 25) {
            Npc.method997(false);
            field2139 = 0;
            boolean var67 = true;

            for(var2 = 0; var2 < IsaacCipher.field2482.length; ++var2) {
               if (class219.field2571[var2] != -1 && IsaacCipher.field2482[var2] == null) {
                  IsaacCipher.field2482[var2] = class320.field3912.takeRecord(class219.field2571[var2], 0);
                  if (IsaacCipher.field2482[var2] == null) {
                     var67 = false;
                     ++field2139;
                  }
               }

               if (WorldMapCacheName.field239[var2] != -1 && BufferedFile.field1421[var2] == null) {
                  BufferedFile.field1421[var2] = class320.field3912.takeRecordEncrypted(WorldMapCacheName.field239[var2], 0, IndexStoreActionHandler.field2951[var2]);
                  if (BufferedFile.field1421[var2] == null) {
                     var67 = false;
                     ++field2139;
                  }
               }
            }

            if (!var67) {
               field2143 = 1;
            } else {
               field2196 = 0;
               var67 = true;

               int var5;
               int var48;
               for(var2 = 0; var2 < IsaacCipher.field2482.length; ++var2) {
                  byte[] var3 = BufferedFile.field1421[var2];
                  if (var3 != null) {
                     var48 = (WorldMapSection1.field201[var2] >> 8) * 64 - class21.field230;
                     var5 = (WorldMapSection1.field201[var2] & 255) * 64 - class79.field902;
                     if (field2145) {
                        var48 = 10;
                        var5 = 10;
                     }

                     var67 &= class205.method4286(var3, var48, var5);
                  }
               }

               if (!var67) {
                  field2143 = 2;
               } else {
                  if (field2143 != 0) {
                     MouseRecorder.method1009("Loading - please wait." + "<br>" + " (" + 100 + "%" + ")", true);
                  }

                  class162.method3077();
                  class243.field2904.clear();

                  for(var2 = 0; var2 < 4; ++var2) {
                     field2144[var2].method3182();
                  }

                  int var49;
                  for(var2 = 0; var2 < 4; ++var2) {
                     for(var49 = 0; var49 < 104; ++var49) {
                        for(var48 = 0; var48 < 104; ++var48) {
                           Tiles.field203[var2][var49][var48] = 0;
                        }
                     }
                  }

                  class162.method3077();
                  Tiles.field204 = 99;
                  class93.field1031 = new byte[4][104][104];
                  UserComparator9.field1597 = new byte[4][104][104];
                  Tiles.field205 = new byte[4][104][104];
                  class81.field917 = new byte[4][104][104];
                  class34.field404 = new int[4][105][105];
                  Tiles.field214 = new byte[4][105][105];
                  Tiles.field207 = new int[105][105];
                  StudioGame.field3341 = new int[104];
                  Tiles.field221 = new int[104];
                  Buffer.field2444 = new int[104];
                  FontName.field3736 = new int[104];
                  Buddy.field3789 = new int[104];
                  var2 = IsaacCipher.field2482.length;
                  class130.method2825();
                  Npc.method997(true);
                  int var7;
                  int var8;
                  int var10;
                  int var11;
                  int var12;
                  int var13;
                  int var14;
                  int var15;
                  int var16;
                  int var17;
                  int var18;
                  int var19;
                  int var20;
                  int var21;
                  int var22;
                  int var51;
                  if (!field2145) {
                     var49 = 0;

                     label1352:
                     while(true) {
                        byte[] var6;
                        if (var49 >= var2) {
                           for(var49 = 0; var49 < var2; ++var49) {
                              var48 = (WorldMapSection1.field201[var49] >> 8) * 64 - class21.field230;
                              var5 = (WorldMapSection1.field201[var49] & 255) * 64 - class79.field902;
                              var6 = IsaacCipher.field2482[var49];
                              if (var6 == null && IndexStore.field1834 < 800) {
                                 class162.method3077();
                                 class165.method3135(var48, var5, 64, 64);
                              }
                           }

                           Npc.method997(true);
                           var49 = 0;

                           while(true) {
                              if (var49 >= var2) {
                                 break label1352;
                              }

                              byte[] var4 = BufferedFile.field1421[var49];
                              if (var4 != null) {
                                 var5 = (WorldMapSection1.field201[var49] >> 8) * 64 - class21.field230;
                                 var51 = (WorldMapSection1.field201[var49] & 255) * 64 - class79.field902;
                                 class162.method3077();
                                 Scene var52 = class243.field2904;
                                 CollisionMap[] var53 = field2144;
                                 Buffer var71 = new Buffer(var4);
                                 var10 = -1;

                                 while(true) {
                                    var11 = var71.method3926();
                                    if (var11 == 0) {
                                       break;
                                    }

                                    var10 += var11;
                                    var12 = 0;

                                    while(true) {
                                       var13 = var71.method3925();
                                       if (var13 == 0) {
                                          break;
                                       }

                                       var12 += var13 - 1;
                                       var14 = var12 & 63;
                                       var15 = var12 >> 6 & 63;
                                       var16 = var12 >> 12;
                                       var17 = var71.readUnsignedByte();
                                       var18 = var17 >> 2;
                                       var19 = var17 & 3;
                                       var20 = var15 + var5;
                                       var21 = var51 + var14;
                                       if (var20 > 0 && var21 > 0 && var20 < 103 && var21 < 103) {
                                          var22 = var16;
                                          if ((Tiles.field203[1][var20][var21] & 2) == 2) {
                                             var22 = var16 - 1;
                                          }

                                          CollisionMap var23 = null;
                                          if (var22 >= 0) {
                                             var23 = var53[var22];
                                          }

                                          WorldMapRegion.method1925(var16, var20, var21, var10, var19, var18, var52, var23);
                                       }
                                    }
                                 }
                              }

                              ++var49;
                           }
                        }

                        var48 = (WorldMapSection1.field201[var49] >> 8) * 64 - class21.field230;
                        var5 = (WorldMapSection1.field201[var49] & 255) * 64 - class79.field902;
                        var6 = IsaacCipher.field2482[var49];
                        if (var6 != null) {
                           class162.method3077();
                           var7 = VertexNormal.field1238 * 8 - 48;
                           var8 = IndexStore.field1834 * 8 - 48;
                           CollisionMap[] var9 = field2144;
                           var10 = 0;

                           label1349:
                           while(true) {
                              if (var10 >= 4) {
                                 Buffer var50 = new Buffer(var6);
                                 var11 = 0;

                                 while(true) {
                                    if (var11 >= 4) {
                                       break label1349;
                                    }

                                    for(var12 = 0; var12 < 64; ++var12) {
                                       for(var13 = 0; var13 < 64; ++var13) {
                                          Skeleton.method2197(var50, var11, var48 + var12, var5 + var13, var7, var8, 0);
                                       }
                                    }

                                    ++var11;
                                 }
                              }

                              for(var11 = 0; var11 < 64; ++var11) {
                                 for(var12 = 0; var12 < 64; ++var12) {
                                    if (var11 + var48 > 0 && var11 + var48 < 103 && var5 + var12 > 0 && var12 + var5 < 103) {
                                       var9[var10].flags[var11 + var48][var12 + var5] &= -16777217;
                                    }
                                 }
                              }

                              ++var10;
                           }
                        }

                        ++var49;
                     }
                  }

                  int var54;
                  if (field2145) {
                     var49 = 0;

                     label1285:
                     while(true) {
                        if (var49 >= 4) {
                           for(var49 = 0; var49 < 13; ++var49) {
                              for(var48 = 0; var48 < 13; ++var48) {
                                 var5 = field2146[0][var49][var48];
                                 if (var5 == -1) {
                                    class165.method3135(var49 * 8, var48 * 8, 8, 8);
                                 }
                              }
                           }

                           Npc.method997(true);
                           var49 = 0;

                           while(true) {
                              if (var49 >= 4) {
                                 break label1285;
                              }

                              class162.method3077();

                              for(var48 = 0; var48 < 13; ++var48) {
                                 for(var5 = 0; var5 < 13; ++var5) {
                                    var51 = field2146[var49][var48][var5];
                                    if (var51 != -1) {
                                       var7 = var51 >> 24 & 3;
                                       var8 = var51 >> 1 & 3;
                                       var54 = var51 >> 14 & 1023;
                                       var10 = var51 >> 3 & 2047;
                                       var11 = (var54 / 8 << 8) + var10 / 8;

                                       for(var12 = 0; var12 < WorldMapSection1.field201.length; ++var12) {
                                          if (WorldMapSection1.field201[var12] == var11 && BufferedFile.field1421[var12] != null) {
                                             InvDefinition.method4794(BufferedFile.field1421[var12], var49, var48 * 8, var5 * 8, var7, (var54 & 7) * 8, (var10 & 7) * 8, var8, class243.field2904, field2144);
                                             break;
                                          }
                                       }
                                    }
                                 }
                              }

                              ++var49;
                           }
                        }

                        class162.method3077();

                        for(var48 = 0; var48 < 13; ++var48) {
                           for(var5 = 0; var5 < 13; ++var5) {
                              boolean var76 = false;
                              var7 = field2146[var49][var48][var5];
                              if (var7 != -1) {
                                 var8 = var7 >> 24 & 3;
                                 var54 = var7 >> 1 & 3;
                                 var10 = var7 >> 14 & 1023;
                                 var11 = var7 >> 3 & 2047;
                                 var12 = (var10 / 8 << 8) + var11 / 8;

                                 for(var13 = 0; var13 < WorldMapSection1.field201.length; ++var13) {
                                    if (WorldMapSection1.field201[var13] == var12 && IsaacCipher.field2482[var13] != null) {
                                       KitDefinition.read(IsaacCipher.field2482[var13], var49, var48 * 8, var5 * 8, var8, (var10 & 7) * 8, (var11 & 7) * 8, var54, field2144);
                                       var76 = true;
                                       break;
                                    }
                                 }
                              }

                              if (!var76) {
                                 var8 = var49;
                                 var54 = var48 * 8;
                                 var10 = var5 * 8;

                                 for(var11 = 0; var11 < 8; ++var11) {
                                    for(var12 = 0; var12 < 8; ++var12) {
                                       Tiles.field217[var8][var54 + var11][var12 + var10] = 0;
                                    }
                                 }

                                 if (var54 > 0) {
                                    for(var11 = 1; var11 < 8; ++var11) {
                                       Tiles.field217[var8][var54][var11 + var10] = Tiles.field217[var8][var54 - 1][var11 + var10];
                                    }
                                 }

                                 if (var10 > 0) {
                                    for(var11 = 1; var11 < 8; ++var11) {
                                       Tiles.field217[var8][var54 + var11][var10] = Tiles.field217[var8][var11 + var54][var10 - 1];
                                    }
                                 }

                                 if (var54 > 0 && Tiles.field217[var8][var54 - 1][var10] != 0) {
                                    Tiles.field217[var8][var54][var10] = Tiles.field217[var8][var54 - 1][var10];
                                 } else if (var10 > 0 && Tiles.field217[var8][var54][var10 - 1] != 0) {
                                    Tiles.field217[var8][var54][var10] = Tiles.field217[var8][var54][var10 - 1];
                                 } else if (var54 > 0 && var10 > 0 && Tiles.field217[var8][var54 - 1][var10 - 1] != 0) {
                                    Tiles.field217[var8][var54][var10] = Tiles.field217[var8][var54 - 1][var10 - 1];
                                 }
                              }
                           }
                        }

                        ++var49;
                     }
                  }

                  Npc.method997(true);
                  class162.method3077();
                  Scene var65 = class243.field2904;
                  CollisionMap[] var66 = field2144;

                  for(var5 = 0; var5 < 4; ++var5) {
                     for(var51 = 0; var51 < 104; ++var51) {
                        for(var7 = 0; var7 < 104; ++var7) {
                           if ((Tiles.field203[var5][var51][var7] & 1) == 1) {
                              var8 = var5;
                              if ((Tiles.field203[1][var51][var7] & 2) == 2) {
                                 var8 = var5 - 1;
                              }

                              if (var8 >= 0) {
                                 var66[var8].method3185(var51, var7);
                              }
                           }
                        }
                     }
                  }

                  Tiles.field215 += (int)(Math.random() * 5.0D) - 2;
                  if (Tiles.field215 < -8) {
                     Tiles.field215 = -8;
                  }

                  if (Tiles.field215 > 8) {
                     Tiles.field215 = 8;
                  }

                  Tiles.field209 += (int)(Math.random() * 5.0D) - 2;
                  if (Tiles.field209 < -16) {
                     Tiles.field209 = -16;
                  }

                  if (Tiles.field209 > 16) {
                     Tiles.field209 = 16;
                  }

                  for(var5 = 0; var5 < 4; ++var5) {
                     byte[][] var68 = Tiles.field214[var5];
                     var12 = (int)Math.sqrt(5100.0D);
                     var13 = var12 * 768 >> 8;

                     int var55;
                     for(var14 = 1; var14 < 103; ++var14) {
                        for(var15 = 1; var15 < 103; ++var15) {
                           var16 = Tiles.field217[var5][var15 + 1][var14] - Tiles.field217[var5][var15 - 1][var14];
                           var17 = Tiles.field217[var5][var15][var14 + 1] - Tiles.field217[var5][var15][var14 - 1];
                           var18 = (int)Math.sqrt((double)(var17 * var17 + var16 * var16 + 65536));
                           var19 = (var16 << 8) / var18;
                           var20 = 65536 / var18;
                           var21 = (var17 << 8) / var18;
                           var22 = (var19 * -50 + var21 * -50 + var20 * -10) / var13 + 96;
                           var55 = (var68[var15 - 1][var14] >> 2) + (var68[var15][var14 - 1] >> 2) + (var68[var15 + 1][var14] >> 3) + (var68[var15][var14 + 1] >> 3) + (var68[var15][var14] >> 1);
                           Tiles.field207[var15][var14] = var22 - var55;
                        }
                     }

                     for(var14 = 0; var14 < 104; ++var14) {
                        StudioGame.field3341[var14] = 0;
                        Tiles.field221[var14] = 0;
                        Buffer.field2444[var14] = 0;
                        FontName.field3736[var14] = 0;
                        Buddy.field3789[var14] = 0;
                     }

                     for(var14 = -5; var14 < 109; ++var14) {
                        for(var15 = 0; var15 < 104; ++var15) {
                           var16 = var14 + 5;
                           if (var16 >= 0 && var16 < 104) {
                              var17 = class93.field1031[var5][var16][var15] & 255;
                              if (var17 > 0) {
                                 UnderlayDefinition var56 = class95.method1799(var17 - 1);
                                 StudioGame.field3341[var15] += var56.hue;
                                 Tiles.field221[var15] += var56.saturation;
                                 Buffer.field2444[var15] += var56.lightness;
                                 FontName.field3736[var15] += var56.hueMultiplier;
                                 ++Buddy.field3789[var15];
                              }
                           }

                           var17 = var14 - 5;
                           if (var17 >= 0 && var17 < 104) {
                              var18 = class93.field1031[var5][var17][var15] & 255;
                              if (var18 > 0) {
                                 UnderlayDefinition var57 = class95.method1799(var18 - 1);
                                 StudioGame.field3341[var15] -= var57.hue;
                                 Tiles.field221[var15] -= var57.saturation;
                                 Buffer.field2444[var15] -= var57.lightness;
                                 FontName.field3736[var15] -= var57.hueMultiplier;
                                 --Buddy.field3789[var15];
                              }
                           }
                        }

                        if (var14 >= 1 && var14 < 103) {
                           var15 = 0;
                           var16 = 0;
                           var17 = 0;
                           var18 = 0;
                           var19 = 0;

                           for(var20 = -5; var20 < 109; ++var20) {
                              var21 = var20 + 5;
                              if (var21 >= 0 && var21 < 104) {
                                 var15 += StudioGame.field3341[var21];
                                 var16 += Tiles.field221[var21];
                                 var17 += Buffer.field2444[var21];
                                 var18 += FontName.field3736[var21];
                                 var19 += Buddy.field3789[var21];
                              }

                              var22 = var20 - 5;
                              if (var22 >= 0 && var22 < 104) {
                                 var15 -= StudioGame.field3341[var22];
                                 var16 -= Tiles.field221[var22];
                                 var17 -= Buffer.field2444[var22];
                                 var18 -= FontName.field3736[var22];
                                 var19 -= Buddy.field3789[var22];
                              }

                              if (var20 >= 1 && var20 < 103 && (!field2091 || (Tiles.field203[0][var14][var20] & 2) != 0 || (Tiles.field203[var5][var14][var20] & 16) == 0)) {
                                 if (var5 < Tiles.field204) {
                                    Tiles.field204 = var5;
                                 }

                                 var55 = class93.field1031[var5][var14][var20] & 255;
                                 int var24 = UserComparator9.field1597[var5][var14][var20] & 255;
                                 if (var55 > 0 || var24 > 0) {
                                    int var25 = Tiles.field217[var5][var14][var20];
                                    int var26 = Tiles.field217[var5][var14 + 1][var20];
                                    int var27 = Tiles.field217[var5][var14 + 1][var20 + 1];
                                    int var28 = Tiles.field217[var5][var14][var20 + 1];
                                    int var29 = Tiles.field207[var14][var20];
                                    int var30 = Tiles.field207[var14 + 1][var20];
                                    int var31 = Tiles.field207[var14 + 1][var20 + 1];
                                    int var32 = Tiles.field207[var14][var20 + 1];
                                    int var33 = -1;
                                    int var34 = -1;
                                    int var35;
                                    int var36;
                                    int var37;
                                    if (var55 > 0) {
                                       var35 = var15 * 256 / var18;
                                       var36 = var16 / var19;
                                       var37 = var17 / var19;
                                       var33 = HitSplatDefinition.method5112(var35, var36, var37);
                                       var35 = var35 + Tiles.field215 & 255;
                                       var37 += Tiles.field209;
                                       if (var37 < 0) {
                                          var37 = 0;
                                       } else if (var37 > 255) {
                                          var37 = 255;
                                       }

                                       var34 = HitSplatDefinition.method5112(var35, var36, var37);
                                    }

                                    OverlayDefinition var38;
                                    if (var5 > 0) {
                                       boolean var73 = true;
                                       if (var55 == 0 && Tiles.field205[var5][var14][var20] != 0) {
                                          var73 = false;
                                       }

                                       if (var24 > 0) {
                                          var37 = var24 - 1;
                                          var38 = (OverlayDefinition)OverlayDefinition.field3678.get((long)var37);
                                          OverlayDefinition var58;
                                          if (var38 != null) {
                                             var58 = var38;
                                          } else {
                                             byte[] var39 = OverlayDefinition.field3688.takeRecord(4, var37);
                                             var38 = new OverlayDefinition();
                                             if (var39 != null) {
                                                var38.read(new Buffer(var39), var37);
                                             }

                                             var38.init();
                                             OverlayDefinition.field3678.put(var38, (long)var37);
                                             var58 = var38;
                                          }

                                          if (!var58.field3679) {
                                             var73 = false;
                                          }
                                       }

                                       if (var73 && var26 == var25 && var25 == var27 && var28 == var25) {
                                          class34.field404[var5][var14][var20] |= 2340;
                                       }
                                    }

                                    var35 = 0;
                                    if (var34 != -1) {
                                       var35 = Rasterizer3D.field1448[Skills.method5061(var34, 96)];
                                    }

                                    if (var24 == 0) {
                                       var65.addTile(var5, var14, var20, 0, 0, -1, var25, var26, var27, var28, Skills.method5061(var33, var29), Skills.method5061(var33, var30), Skills.method5061(var33, var31), Skills.method5061(var33, var32), 0, 0, 0, 0, var35, 0);
                                    } else {
                                       var36 = Tiles.field205[var5][var14][var20] + 1;
                                       byte var74 = class81.field917[var5][var14][var20];
                                       int var59 = var24 - 1;
                                       OverlayDefinition var40 = (OverlayDefinition)OverlayDefinition.field3678.get((long)var59);
                                       if (var40 != null) {
                                          var38 = var40;
                                       } else {
                                          byte[] var41 = OverlayDefinition.field3688.takeRecord(4, var59);
                                          var40 = new OverlayDefinition();
                                          if (var41 != null) {
                                             var40.read(new Buffer(var41), var59);
                                          }

                                          var40.init();
                                          OverlayDefinition.field3678.put(var40, (long)var59);
                                          var38 = var40;
                                       }

                                       int var60 = var38.texture;
                                       int var42;
                                       int var43;
                                       int var44;
                                       int var45;
                                       if (var60 >= 0) {
                                          var43 = Rasterizer3D.field1451.vmethod2974(var60);
                                          var42 = -1;
                                       } else if (var38.rgb == 16711935) {
                                          var42 = -2;
                                          var60 = -1;
                                          var43 = -2;
                                       } else {
                                          var42 = HitSplatDefinition.method5112(var38.hue, var38.saturation, var38.lightness);
                                          var44 = var38.hue + Tiles.field215 & 255;
                                          var45 = var38.lightness + Tiles.field209;
                                          if (var45 < 0) {
                                             var45 = 0;
                                          } else if (var45 > 255) {
                                             var45 = 255;
                                          }

                                          var43 = HitSplatDefinition.method5112(var44, var38.saturation, var45);
                                       }

                                       var44 = 0;
                                       if (var43 != -2) {
                                          var44 = Rasterizer3D.field1448[Canvas.method362(var43, 96)];
                                       }

                                       if (var38.rgb2 != -1) {
                                          var45 = var38.hue2 + Tiles.field215 & 255;
                                          int var46 = var38.lightness2 + Tiles.field209;
                                          if (var46 < 0) {
                                             var46 = 0;
                                          } else if (var46 > 255) {
                                             var46 = 255;
                                          }

                                          var43 = HitSplatDefinition.method5112(var45, var38.saturation2, var46);
                                          var44 = Rasterizer3D.field1448[Canvas.method362(var43, 96)];
                                       }

                                       var65.addTile(var5, var14, var20, var36, var74, var60, var25, var26, var27, var28, Skills.method5061(var33, var29), Skills.method5061(var33, var30), Skills.method5061(var33, var31), Skills.method5061(var33, var32), Canvas.method362(var42, var29), Canvas.method362(var42, var30), Canvas.method362(var42, var31), Canvas.method362(var42, var32), var35, var44);
                                    }
                                 }
                              }
                           }
                        }
                     }

                     for(var14 = 1; var14 < 103; ++var14) {
                        for(var15 = 1; var15 < 103; ++var15) {
                           if ((Tiles.field203[var5][var15][var14] & 8) != 0) {
                              var20 = 0;
                           } else if (var5 > 0 && (Tiles.field203[1][var15][var14] & 2) != 0) {
                              var20 = var5 - 1;
                           } else {
                              var20 = var5;
                           }

                           var65.setTileMinPlane(var5, var15, var14, var20);
                        }
                     }

                     class93.field1031[var5] = null;
                     UserComparator9.field1597[var5] = null;
                     Tiles.field205[var5] = null;
                     class81.field917[var5] = null;
                     Tiles.field214[var5] = null;
                  }

                  var65.method2325(-50, -10, -50);

                  for(var5 = 0; var5 < 104; ++var5) {
                     for(var51 = 0; var51 < 104; ++var51) {
                        if ((Tiles.field203[1][var5][var51] & 2) == 2) {
                           var65.setLinkBelow(var5, var51);
                        }
                     }
                  }

                  var5 = 1;
                  var51 = 2;
                  var7 = 4;

                  for(var8 = 0; var8 < 4; ++var8) {
                     if (var8 > 0) {
                        var5 <<= 3;
                        var51 <<= 3;
                        var7 <<= 3;
                     }

                     for(var54 = 0; var54 <= var8; ++var54) {
                        for(var10 = 0; var10 <= 104; ++var10) {
                           for(var11 = 0; var11 <= 104; ++var11) {
                              short var72;
                              if ((class34.field404[var54][var11][var10] & var5) != 0) {
                                 var12 = var10;
                                 var13 = var10;
                                 var14 = var54;

                                 for(var15 = var54; var12 > 0 && (class34.field404[var54][var11][var12 - 1] & var5) != 0; --var12) {
                                    ;
                                 }

                                 while(var13 < 104 && (class34.field404[var54][var11][var13 + 1] & var5) != 0) {
                                    ++var13;
                                 }

                                 label936:
                                 while(var14 > 0) {
                                    for(var16 = var12; var16 <= var13; ++var16) {
                                       if ((class34.field404[var14 - 1][var11][var16] & var5) == 0) {
                                          break label936;
                                       }
                                    }

                                    --var14;
                                 }

                                 label925:
                                 while(var15 < var8) {
                                    for(var16 = var12; var16 <= var13; ++var16) {
                                       if ((class34.field404[var15 + 1][var11][var16] & var5) == 0) {
                                          break label925;
                                       }
                                    }

                                    ++var15;
                                 }

                                 var16 = (var13 - var12 + 1) * (var15 + 1 - var14);
                                 if (var16 >= 8) {
                                    var72 = 240;
                                    var18 = Tiles.field217[var15][var11][var12] - var72;
                                    var19 = Tiles.field217[var14][var11][var12];
                                    Scene.method2228(var8, 1, var11 * 128, var11 * 128, var12 * 128, var13 * 128 + 128, var18, var19);

                                    for(var20 = var14; var20 <= var15; ++var20) {
                                       for(var21 = var12; var21 <= var13; ++var21) {
                                          class34.field404[var20][var11][var21] &= ~var5;
                                       }
                                    }
                                 }
                              }

                              if ((class34.field404[var54][var11][var10] & var51) != 0) {
                                 var12 = var11;
                                 var13 = var11;
                                 var14 = var54;

                                 for(var15 = var54; var12 > 0 && (class34.field404[var54][var12 - 1][var10] & var51) != 0; --var12) {
                                    ;
                                 }

                                 while(var13 < 104 && (class34.field404[var54][var13 + 1][var10] & var51) != 0) {
                                    ++var13;
                                 }

                                 label989:
                                 while(var14 > 0) {
                                    for(var16 = var12; var16 <= var13; ++var16) {
                                       if ((class34.field404[var14 - 1][var16][var10] & var51) == 0) {
                                          break label989;
                                       }
                                    }

                                    --var14;
                                 }

                                 label978:
                                 while(var15 < var8) {
                                    for(var16 = var12; var16 <= var13; ++var16) {
                                       if ((class34.field404[var15 + 1][var16][var10] & var51) == 0) {
                                          break label978;
                                       }
                                    }

                                    ++var15;
                                 }

                                 var16 = (var13 - var12 + 1) * (var15 + 1 - var14);
                                 if (var16 >= 8) {
                                    var72 = 240;
                                    var18 = Tiles.field217[var15][var12][var10] - var72;
                                    var19 = Tiles.field217[var14][var12][var10];
                                    Scene.method2228(var8, 2, var12 * 128, var13 * 128 + 128, var10 * 128, var10 * 128, var18, var19);

                                    for(var20 = var14; var20 <= var15; ++var20) {
                                       for(var21 = var12; var21 <= var13; ++var21) {
                                          class34.field404[var20][var21][var10] &= ~var51;
                                       }
                                    }
                                 }
                              }

                              if ((class34.field404[var54][var11][var10] & var7) != 0) {
                                 var12 = var11;
                                 var13 = var11;
                                 var14 = var10;

                                 for(var15 = var10; var14 > 0 && (class34.field404[var54][var11][var14 - 1] & var7) != 0; --var14) {
                                    ;
                                 }

                                 while(var15 < 104 && (class34.field404[var54][var11][var15 + 1] & var7) != 0) {
                                    ++var15;
                                 }

                                 label1042:
                                 while(var12 > 0) {
                                    for(var16 = var14; var16 <= var15; ++var16) {
                                       if ((class34.field404[var54][var12 - 1][var16] & var7) == 0) {
                                          break label1042;
                                       }
                                    }

                                    --var12;
                                 }

                                 label1031:
                                 while(var13 < 104) {
                                    for(var16 = var14; var16 <= var15; ++var16) {
                                       if ((class34.field404[var54][var13 + 1][var16] & var7) == 0) {
                                          break label1031;
                                       }
                                    }

                                    ++var13;
                                 }

                                 if ((var13 - var12 + 1) * (var15 - var14 + 1) >= 4) {
                                    var16 = Tiles.field217[var54][var12][var14];
                                    Scene.method2228(var8, 4, var12 * 128, var13 * 128 + 128, var14 * 128, var15 * 128 + 128, var16, var16);

                                    for(var17 = var12; var17 <= var13; ++var17) {
                                       for(var18 = var14; var18 <= var15; ++var18) {
                                          class34.field404[var54][var17][var18] &= ~var7;
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }

                  Npc.method997(true);
                  var5 = Tiles.field204;
                  if (var5 > class31.field363) {
                     var5 = class31.field363;
                  }

                  if (var5 < class31.field363 - 1) {
                     var5 = class31.field363 - 1;
                  }

                  if (field2091) {
                     class243.field2904.init(Tiles.field204);
                  } else {
                     class243.field2904.init(0);
                  }

                  for(var51 = 0; var51 < 104; ++var51) {
                     for(var7 = 0; var7 < 104; ++var7) {
                        class240.method4819(var51, var7);
                     }
                  }

                  class162.method3077();

                  for(class37 var69 = (class37)field2131.last(); var69 != null; var69 = (class37)field2131.previous()) {
                     if (var69.field457 == -1) {
                        var69.field456 = 0;
                        class10.method351(var69);
                     } else {
                        var69.remove();
                     }
                  }

                  ObjectDefinition.field3394.clear();
                  PacketBufferNode var70;
                  if (class178.field1984.hasFrame()) {
                     var70 = FaceNormal.method2884(ClientPacket.field1863, field2133.isaacCipher);
                     var70.packetBuffer.writeInt(1057001181);
                     field2133.method1281(var70);
                  }

                  if (!field2145) {
                     var51 = (VertexNormal.field1238 - 6) / 8;
                     var7 = (VertexNormal.field1238 + 6) / 8;
                     var8 = (IndexStore.field1834 - 6) / 8;
                     var54 = (IndexStore.field1834 + 6) / 8;

                     for(var10 = var51 - 1; var10 <= var7 + 1; ++var10) {
                        for(var11 = var8 - 1; var11 <= var54 + 1; ++var11) {
                           if (var10 < var51 || var10 > var7 || var11 < var8 || var11 > var54) {
                              class320.field3912.method4964("m" + var10 + "_" + var11);
                              class320.field3912.method4964("l" + var10 + "_" + var11);
                           }
                        }
                     }
                  }

                  class69.method1443(30);
                  class162.method3077();
                  class93.field1031 = null;
                  UserComparator9.field1597 = null;
                  Tiles.field205 = null;
                  class81.field917 = null;
                  class34.field404 = null;
                  Tiles.field214 = null;
                  Tiles.field207 = null;
                  StudioGame.field3341 = null;
                  Tiles.field221 = null;
                  Buffer.field2444 = null;
                  FontName.field3736 = null;
                  Buddy.field3789 = null;
                  var70 = FaceNormal.method2884(ClientPacket.field1912, field2133.isaacCipher);
                  field2133.method1281(var70);
                  GameShell.field70.mark();

                  for(var7 = 0; var7 < 32; ++var7) {
                     GameShell.field66[var7] = 0L;
                  }

                  for(var7 = 0; var7 < 32; ++var7) {
                     GameShell.field81[var7] = 0L;
                  }

                  class167.field1800 = 0;
               }
            }
         }
      } else {
         ClientPreferences.method804(this);
      }

      if (field2163 == 30) {
         this.method3329();
      } else if (field2163 == 40 || field2163 == 45) {
         this.method3328();
      }

   }

   protected final void vmethod3549() {
   }

   protected final void vmethod3323(boolean var1) {
      boolean var2 = class165.method3137();
      if (var2 && field2322 && field2325 != null) {
         field2325.tryFlush();
      }

      if ((field2163 == 10 || field2163 == 20 || field2163 == 30) && 0L != field2313 && Tile.method2779() > field2313) {
         WorldMapSection2.method398(class65.method1381());
      }

      int var3;
      if (var1) {
         for(var3 = 0; var3 < 100; ++var3) {
            field2291[var3] = true;
         }
      }

      if (field2163 == 0) {
         this.method217(Login.field664, Login.field665, var1);
      } else if (field2163 == 5) {
         GameObject.method2900(NetSocket.field1950, WorldMapSection3.field625, TotalQuantityComparator.field982, var1);
      } else if (field2163 != 10 && field2163 != 11) {
         if (field2163 == 20) {
            GameObject.method2900(NetSocket.field1950, WorldMapSection3.field625, TotalQuantityComparator.field982, var1);
         } else if (field2163 == 25) {
            if (field2143 == 1) {
               if (field2139 > field2140) {
                  field2140 = field2139;
               }

               var3 = (field2140 * 50 - field2139 * 50) / field2140;
               MouseRecorder.method1009("Loading - please wait." + "<br>" + " (" + var3 + "%" + ")", false);
            } else if (field2143 == 2) {
               if (field2196 > field2352) {
                  field2352 = field2196;
               }

               var3 = (field2352 * 50 - field2196 * 50) / field2352 + 50;
               MouseRecorder.method1009("Loading - please wait." + "<br>" + " (" + var3 + "%" + ")", false);
            } else {
               MouseRecorder.method1009("Loading - please wait.", false);
            }
         } else if (field2163 == 30) {
            this.method3517();
         } else if (field2163 == 40) {
            MouseRecorder.method1009("Connection lost" + "<br>" + "Please wait - attempting to reestablish", false);
         } else if (field2163 == 45) {
            MouseRecorder.method1009("Please wait...", false);
         }
      } else {
         GameObject.method2900(NetSocket.field1950, WorldMapSection3.field625, TotalQuantityComparator.field982, var1);
      }

      if (field2163 == 30 && field2298 == 0 && !var1 && !field2118) {
         for(var3 = 0; var3 < field2296; ++var3) {
            if (field2292[var3]) {
               WorldMapManager.field45.draw(field2206[var3], field2295[var3], field2262[var3], field2297[var3]);
               field2292[var3] = false;
            }
         }
      } else if (field2163 > 0) {
         WorldMapManager.field45.drawFull(0, 0);

         for(var3 = 0; var3 < field2296; ++var3) {
            field2292[var3] = false;
         }
      }

   }

   protected final void kill0() {
      if (class17.field181.hasUnwrittenChanges()) {
         class17.field181.write();
      }

      if (class17.field180 != null) {
         class17.field180.isRunning = false;
      }

      class17.field180 = null;
      field2133.close();
      class240.method4820();
      if (MouseHandler.field151 != null) {
         MouseHandler var1 = MouseHandler.field151;
         synchronized(MouseHandler.field151) {
            MouseHandler.field151 = null;
         }
      }

      IndexStore.field1835 = null;
      if (field2325 != null) {
         field2325.shutdown();
      }

      if (class57.field642 != null) {
         class57.field642.shutdown();
      }

      if (NetCache.field2833 != null) {
         NetCache.field2833.close();
      }

      Object var7 = IndexStoreActionHandler.field2945;
      synchronized(IndexStoreActionHandler.field2945) {
         if (IndexStoreActionHandler.field2947 != 0) {
            IndexStoreActionHandler.field2947 = 1;

            try {
               IndexStoreActionHandler.field2945.wait();
            } catch (InterruptedException var4) {
               ;
            }
         }
      }

      if (WorldMapSection1.field186 != null) {
         WorldMapSection1.field186.close();
         WorldMapSection1.field186 = null;
      }

      AccessFile.closeAll();
   }

   protected final void setUp() {
      StudioGame.method5087(new int[]{20, 260, 10000}, new int[]{1000, 100, 500});
      UserComparator4.field1729 = field2088 == 0 ? 'ꩊ' : field2134 + '鱀';
      GrandExchangeEvent.field761 = field2088 == 0 ? 443 : field2134 + '썐';
      UserComparator5.field1595 = UserComparator4.field1729;
      KeyHandler.field16 = class217.field2562;
      VarpDefinition.field2929 = class217.field2561;
      PlayerAppearance.field2554 = class217.field2563;
      PlayerAppearance.field2550 = class217.field2564;
      WorldMapSection1.field186 = new UrlRequester();
      this.setUpKeyboard();
      this.setUpMouse();
      IndexStore.field1835 = this.mouseWheel();
      class34.field391 = new IndexStore(255, class178.field1975, class178.field1976, 500000);
      AccessFile var2 = null;
      ClientPreferences var3 = new ClientPreferences();

      try {
         var2 = class99.method1837("", field2089.name, false);
         byte[] var4 = new byte[(int)var2.length()];

         int var6;
         for(int var5 = 0; var5 < var4.length; var5 += var6) {
            var6 = var2.read(var4, var5, var4.length - var5);
            if (var6 == -1) {
               throw new IOException();
            }
         }

         var3 = new ClientPreferences(new Buffer(var4));
      } catch (Exception var8) {
         ;
      }

      try {
         if (var2 != null) {
            var2.close();
         }
      } catch (Exception var7) {
         ;
      }

      GameShell.field72 = var3;
      this.setUpClipboard();
      String var9 = WorldMapLabel.field1016;
      class12.field124 = this;
      if (var9 != null) {
         class12.field125 = var9;
      }

      if (field2088 != 0) {
         field2329 = true;
      }

      WorldMapSection2.method398(GameShell.field72.windowMode);
      ServerPacket.field2028 = new FriendSystem(field2363);
   }

   protected final void vmethod3332() {
      field2313 = Tile.method2779() + 500L;
      this.method3443();
      if (field2246 != -1) {
         this.method3337(true);
      }

   }

   void method3327(int var1) {
      class73.field857 = null;
      BufferedFile.field1423 = null;
      field2117 = 0;
      if (UserComparator5.field1595 == UserComparator4.field1729) {
         UserComparator5.field1595 = GrandExchangeEvent.field761;
      } else {
         UserComparator5.field1595 = UserComparator4.field1729;
      }

      ++field2230;
      if (field2230 >= 2 && (var1 == 7 || var1 == 9)) {
         if (field2163 <= 5) {
            this.error("js5connect_full");
            field2163 = 1000;
         } else {
            field2125 = 3000;
         }
      } else if (field2230 >= 2 && var1 == 6) {
         this.error("js5connect_outofdate");
         field2163 = 1000;
      } else if (field2230 >= 4) {
         if (field2163 <= 5) {
            this.error("js5connect");
            field2163 = 1000;
         } else {
            field2125 = 3000;
         }
      }

   }

   void method3325() {
      if (field2163 != 1000) {
         boolean var1 = BoundaryObject.method2829();
         if (!var1) {
            this.method3326();
         }

      }
   }

   void method3326() {
      if (NetCache.field2847 >= 4) {
         this.error("js5crc");
         field2163 = 1000;
      } else {
         if (NetCache.field2848 >= 4) {
            if (field2163 <= 5) {
               this.error("js5io");
               field2163 = 1000;
               return;
            }

            field2125 = 3000;
            NetCache.field2848 = 3;
         }

         if (--field2125 + 1 <= 0) {
            try {
               if (field2117 == 0) {
                  class73.field857 = GameShell.field63.newSocketTask(class85.field965, UserComparator5.field1595);
                  ++field2117;
               }

               if (field2117 == 1) {
                  if (class73.field857.status == 2) {
                     this.method3327(-1);
                     return;
                  }

                  if (class73.field857.status == 1) {
                     ++field2117;
                  }
               }

               if (field2117 == 2) {
                  if (field2265) {
                     BufferedFile.field1423 = class37.method860((Socket)class73.field857.result, 40000, 5000);
                  } else {
                     BufferedFile.field1423 = new NetSocket((Socket)class73.field857.result, GameShell.field63, 5000);
                  }

                  Buffer var1 = new Buffer(5);
                  var1.writeByte(15);
                  var1.writeInt(177);
                  BufferedFile.field1423.write(var1.array, 0, 5);
                  ++field2117;
                  class10.field114 = Tile.method2779();
               }

               if (field2117 == 3) {
                  if (BufferedFile.field1423.available() > 0 || !field2265 && field2163 <= 5) {
                     int var2 = BufferedFile.field1423.readUnsignedByte();
                     if (var2 != 0) {
                        this.method3327(var2);
                        return;
                     }

                     ++field2117;
                  } else if (Tile.method2779() - class10.field114 > 30000L) {
                     this.method3327(-2);
                     return;
                  }
               }

               if (field2117 == 4) {
                  class69.method1448(BufferedFile.field1423, field2163 > 20);
                  class73.field857 = null;
                  BufferedFile.field1423 = null;
                  field2117 = 0;
                  field2230 = 0;
               }
            } catch (IOException var3) {
               this.method3327(-3);
            }

         }
      }
   }

   final void method3328() {
      Object var1 = field2133.getSocket();
      PacketBuffer var2 = field2133.packetBuffer;

      try {
         if (field2120 == 0) {
            if (WorldMapLabelSize.field725 == null && (field2126.isDone() || field2121 > 250)) {
               WorldMapLabelSize.field725 = field2126.get();
               field2126.shutdown();
               field2126 = null;
            }

            if (WorldMapLabelSize.field725 != null) {
               if (var1 != null) {
                  ((AbstractSocket)var1).close();
                  var1 = null;
               }

               UrlRequest.field1613 = null;
               field2135 = false;
               field2121 = 0;
               field2120 = 1;
            }
         }

         if (field2120 == 1) {
            if (UrlRequest.field1613 == null) {
               UrlRequest.field1613 = GameShell.field63.newSocketTask(class85.field965, UserComparator5.field1595);
            }

            if (UrlRequest.field1613.status == 2) {
               throw new IOException();
            }

            if (UrlRequest.field1613.status == 1) {
               if (field2265) {
                  Socket var4 = (Socket)UrlRequest.field1613.result;
                  BufferedNetSocket var3 = new BufferedNetSocket(var4, 40000, 5000);
                  var1 = var3;
               } else {
                  var1 = new NetSocket((Socket)UrlRequest.field1613.result, GameShell.field63, 5000);
               }

               field2133.setSocket((AbstractSocket)var1);
               UrlRequest.field1613 = null;
               field2120 = 2;
            }
         }

         if (field2120 == 2) {
            field2133.method1282();
            PacketBufferNode var21 = class137.method2882();
            var21.packetBuffer.writeByte(LoginPacket.field1956.id);
            field2133.method1281(var21);
            field2133.method1275();
            var2.index = 0;
            field2120 = 3;
         }

         boolean var12;
         int var13;
         if (field2120 == 3) {
            if (field2325 != null) {
               field2325.method1639();
            }

            if (class57.field642 != null) {
               class57.field642.method1639();
            }

            var12 = true;
            if (field2265 && !((AbstractSocket)var1).isAvailable(1)) {
               var12 = false;
            }

            if (var12) {
               var13 = ((AbstractSocket)var1).readUnsignedByte();
               if (field2325 != null) {
                  field2325.method1639();
               }

               if (class57.field642 != null) {
                  class57.field642.method1639();
               }

               if (var13 != 0) {
                  BufferedFile.method2589(var13);
                  return;
               }

               var2.index = 0;
               field2120 = 4;
            }
         }

         int var33;
         if (field2120 == 4) {
            if (var2.index < 8) {
               var33 = ((AbstractSocket)var1).available();
               if (var33 > 8 - var2.index) {
                  var33 = 8 - var2.index;
               }

               if (var33 > 0) {
                  ((AbstractSocket)var1).read(var2.array, var2.index, var33);
                  var2.index += var33;
               }
            }

            if (var2.index == 8) {
               var2.index = 0;
               GrandExchangeEvents.field995 = var2.readLong();
               field2120 = 5;
            }
         }

         int var7;
         int var9;
         int var14;
         if (field2120 == 5) {
            field2133.packetBuffer.index = 0;
            field2133.method1282();
            PacketBuffer var22 = new PacketBuffer(500);
            int[] var24 = new int[]{WorldMapLabelSize.field725.nextInt(), WorldMapLabelSize.field725.nextInt(), WorldMapLabelSize.field725.nextInt(), WorldMapLabelSize.field725.nextInt()};
            var22.index = 0;
            var22.writeByte(1);
            var22.writeInt(var24[0]);
            var22.writeInt(var24[1]);
            var22.writeInt(var24[2]);
            var22.writeInt(var24[3]);
            var22.writeLong(GrandExchangeEvents.field995);
            int var10;
            if (field2163 == 40) {
               var22.writeInt(Messages.field613[0]);
               var22.writeInt(Messages.field613[1]);
               var22.writeInt(Messages.field613[2]);
               var22.writeInt(Messages.field613[3]);
            } else {
               var22.writeByte(field2124.ordinal());
               switch(field2124.field1565) {
               case 0:
               case 3:
                  var22.writeMedium(class31.field368);
                  ++var22.index;
                  break;
               case 1:
                  var22.index += 4;
                  break;
               case 2:
                  LinkedHashMap var6 = GameShell.field72.parameters;
                  String var8 = Login.field686;
                  var9 = var8.length();
                  var10 = 0;

                  for(int var11 = 0; var11 < var9; ++var11) {
                     var10 = (var10 << 5) - var10 + var8.charAt(var11);
                  }

                  var22.writeInt(((Integer)var6.get(var10)).intValue());
               }

               var22.writeByte(class329.field3995.ordinal());
               var22.writeStringCp1252NullTerminated(Login.field675);
            }

            var22.encryptRsa(class45.field524, class45.field520);
            Messages.field613 = var24;
            PacketBufferNode var5 = class137.method2882();
            var5.packetBuffer.index = 0;
            if (field2163 == 40) {
               var5.packetBuffer.writeByte(LoginPacket.field1955.id);
            } else {
               var5.packetBuffer.writeByte(LoginPacket.field1954.id);
            }

            var5.packetBuffer.writeShort(0);
            var14 = var5.packetBuffer.index;
            var5.packetBuffer.writeInt(177);
            var5.packetBuffer.writeInt(1);
            var5.packetBuffer.writeByte(field2094);
            var5.packetBuffer.method3905(var22.array, 0, var22.index);
            var7 = var5.packetBuffer.index;
            var5.packetBuffer.writeStringCp1252NullTerminated(Login.field686);
            var5.packetBuffer.writeByte((field2118 ? 1 : 0) << 1 | (field2091 ? 1 : 0));
            var5.packetBuffer.writeShort(FriendSystem.field379);
            var5.packetBuffer.writeShort(UserComparator8.field1678);
            VarpDefinition.method4912(var5.packetBuffer);
            var5.packetBuffer.writeStringCp1252NullTerminated(class57.field644);
            var5.packetBuffer.writeInt(field2093);
            Buffer var31 = new Buffer(Player.field444.size());
            Player.field444.write(var31);
            var5.packetBuffer.method3905(var31.array, 0, var31.array.length);
            var5.packetBuffer.writeByte(field2094);
            var5.packetBuffer.writeInt(0);
            var5.packetBuffer.writeInt(class93.field1028.hash);
            var5.packetBuffer.writeInt(Canvas.field118.hash);
            var5.packetBuffer.writeInt(Tiles.field216.hash);
            var5.packetBuffer.writeInt(class178.field1967.hash);
            var5.packetBuffer.writeInt(class71.field846.hash);
            var5.packetBuffer.writeInt(class320.field3912.hash);
            var5.packetBuffer.writeInt(ServerPacket.field1995.hash);
            var5.packetBuffer.writeInt(class85.field966.hash);
            var5.packetBuffer.writeInt(RunException.field1608.hash);
            var5.packetBuffer.writeInt(class65.field801.hash);
            var5.packetBuffer.writeInt(WorldMapLabelSize.field724.hash);
            var5.packetBuffer.writeInt(IsaacCipher.field2480.hash);
            var5.packetBuffer.writeInt(UrlRequester.field1587.hash);
            var5.packetBuffer.writeInt(GraphicsObject.field569.hash);
            var5.packetBuffer.writeInt(WorldMapSection2.field136.hash);
            var5.packetBuffer.writeInt(ObjectDefinition.field3393.hash);
            var5.packetBuffer.writeInt(AbstractSocket.field1778.hash);
            var5.packetBuffer.writeInt(UserComparator3.field1709.hash);
            var5.packetBuffer.xteaEncrypt(var24, var7, var5.packetBuffer.index);
            var5.packetBuffer.method3907(var5.packetBuffer.index - var14);
            field2133.method1281(var5);
            field2133.method1275();
            field2133.isaacCipher = new IsaacCipher(var24);
            int[] var15 = new int[4];

            for(var10 = 0; var10 < 4; ++var10) {
               var15[var10] = var24[var10] + 50;
            }

            var2.newIsaacCipher(var15);
            field2120 = 6;
         }

         if (field2120 == 6 && ((AbstractSocket)var1).available() > 0) {
            var33 = ((AbstractSocket)var1).readUnsignedByte();
            if (var33 == 21 && field2163 == 20) {
               field2120 = 9;
            } else if (var33 == 2) {
               field2120 = 11;
            } else if (var33 == 15 && field2163 == 40) {
               field2133.serverPacket0Length = -1;
               field2120 = 16;
            } else if (var33 == 64) {
               field2120 = 7;
            } else if (var33 == 23 && field2122 < 1) {
               ++field2122;
               field2120 = 0;
            } else {
               if (var33 != 29) {
                  BufferedFile.method2589(var33);
                  return;
               }

               field2120 = 14;
            }
         }

         if (field2120 == 7 && ((AbstractSocket)var1).available() > 0) {
            AbstractByteArrayCopier.field2366 = ((AbstractSocket)var1).readUnsignedByte();
            field2120 = 8;
         }

         if (field2120 == 8 && ((AbstractSocket)var1).available() >= AbstractByteArrayCopier.field2366) {
            ((AbstractSocket)var1).read(var2.array, 0, AbstractByteArrayCopier.field2366);
            var2.index = 0;
            field2120 = 6;
         }

         if (field2120 == 9 && ((AbstractSocket)var1).available() > 0) {
            field2203 = (((AbstractSocket)var1).readUnsignedByte() + 3) * 60;
            field2120 = 10;
         }

         if (field2120 == 10) {
            field2121 = 0;
            ByteArrayPool.method4250("You have only just left another world.", "Your profile will be transferred in:", field2203 / 60 + " seconds.");
            if (--field2203 <= 0) {
               field2120 = 0;
            }

         } else {
            if (field2120 == 11 && ((AbstractSocket)var1).available() >= 1) {
               ItemDefinition.field3646 = ((AbstractSocket)var1).readUnsignedByte();
               field2120 = 12;
            }

            boolean var34;
            if (field2120 == 12 && ((AbstractSocket)var1).available() >= ItemDefinition.field3646) {
               var12 = ((AbstractSocket)var1).readUnsignedByte() == 1;
               ((AbstractSocket)var1).read(var2.array, 0, 4);
               var2.index = 0;
               var34 = false;
               if (var12) {
                  var13 = var2.readByteIsaac() << 24;
                  var13 |= var2.readByteIsaac() << 16;
                  var13 |= var2.readByteIsaac() << 8;
                  var13 |= var2.readByteIsaac();
                  String var30 = Login.field686;
                  var7 = var30.length();
                  int var16 = 0;
                  var9 = 0;

                  while(true) {
                     if (var9 >= var7) {
                        if (GameShell.field72.parameters.size() >= 10 && !GameShell.field72.parameters.containsKey(var16)) {
                           Iterator var32 = GameShell.field72.parameters.entrySet().iterator();
                           var32.next();
                           var32.remove();
                        }

                        GameShell.field72.parameters.put(var16, var13);
                        break;
                     }

                     var16 = (var16 << 5) - var16 + var30.charAt(var9);
                     ++var9;
                  }
               }

               if (field2189) {
                  GameShell.field72.rememberedUsername = Login.field686;
               } else {
                  GameShell.field72.rememberedUsername = null;
               }

               Player.method840();
               field2255 = ((AbstractSocket)var1).readUnsignedByte();
               field2306 = ((AbstractSocket)var1).readUnsignedByte() == 1;
               field2190 = ((AbstractSocket)var1).readUnsignedByte();
               field2190 <<= 8;
               field2190 += ((AbstractSocket)var1).readUnsignedByte();
               field2204 = ((AbstractSocket)var1).readUnsignedByte();
               ((AbstractSocket)var1).read(var2.array, 0, 1);
               var2.index = 0;
               ServerPacket[] var28 = class37.method859();
               var14 = var2.readSmartByteShortIsaac();
               if (var14 < 0 || var14 >= var28.length) {
                  throw new IOException(var14 + " " + var2.index);
               }

               field2133.serverPacket0 = var28[var14];
               field2133.serverPacket0Length = field2133.serverPacket0.length;
               ((AbstractSocket)var1).read(var2.array, 0, 2);
               var2.index = 0;
               field2133.serverPacket0Length = var2.method3913();

               try {
                  class3.method91(class178.field1984, "zap");
               } catch (Throwable var19) {
                  ;
               }

               field2120 = 13;
            }

            if (field2120 != 13) {
               if (field2120 == 14 && ((AbstractSocket)var1).available() >= 2) {
                  var2.index = 0;
                  ((AbstractSocket)var1).read(var2.array, 0, 2);
                  var2.index = 0;
                  GrandExchangeEvents.field994 = var2.method3913();
                  field2120 = 15;
               }

               if (field2120 == 15 && ((AbstractSocket)var1).available() >= GrandExchangeEvents.field994) {
                  var2.index = 0;
                  ((AbstractSocket)var1).read(var2.array, 0, GrandExchangeEvents.field994);
                  var2.index = 0;
                  String var25 = var2.readStringCp1252NullTerminated();
                  String var27 = var2.readStringCp1252NullTerminated();
                  String var29 = var2.readStringCp1252NullTerminated();
                  ByteArrayPool.method4250(var25, var27, var29);
                  class69.method1443(10);
               }

               if (field2120 == 16) {
                  if (field2133.serverPacket0Length == -1) {
                     if (((AbstractSocket)var1).available() < 2) {
                        return;
                     }

                     ((AbstractSocket)var1).read(var2.array, 0, 2);
                     var2.index = 0;
                     field2133.serverPacket0Length = var2.method3913();
                  }

                  if (((AbstractSocket)var1).available() >= field2133.serverPacket0Length) {
                     ((AbstractSocket)var1).read(var2.array, 0, field2133.serverPacket0Length);
                     var2.index = 0;
                     var33 = field2133.serverPacket0Length;
                     field2347.method5356();
                     GrandExchangeEvent.method1339();
                     SpotAnimationDefinition.method5548(var2);
                     if (var33 != var2.index) {
                        throw new RuntimeException();
                     }
                  }
               } else {
                  ++field2121;
                  if (field2121 > 2000) {
                     if (field2122 < 1) {
                        if (UserComparator4.field1729 == UserComparator5.field1595) {
                           UserComparator5.field1595 = GrandExchangeEvent.field761;
                        } else {
                           UserComparator5.field1595 = UserComparator4.field1729;
                        }

                        ++field2122;
                        field2120 = 0;
                     } else {
                        BufferedFile.method2589(-3);
                     }
                  }
               }
            } else {
               if (((AbstractSocket)var1).available() >= field2133.serverPacket0Length) {
                  var2.index = 0;
                  ((AbstractSocket)var1).read(var2.array, 0, field2133.serverPacket0Length);
                  field2347.method5359();
                  field2099 = 1L;
                  class17.field180.index = 0;
                  class180.field1994 = true;
                  field2362 = true;
                  field2311 = -1L;
                  IndexStoreAction.method4778();
                  field2133.method1282();
                  field2133.packetBuffer.index = 0;
                  field2133.serverPacket0 = null;
                  field2133.field716 = null;
                  field2133.field705 = null;
                  field2133.field699 = null;
                  field2133.serverPacket0Length = 0;
                  field2133.field708 = 0;
                  field2105 = 0;
                  field2168 = 0;
                  field2106 = 0;
                  field2223 = 0;
                  field2276 = false;
                  Script.method1817(0);
                  Messages.field610.clear();
                  Messages.field611.clear();
                  Messages.field609.clear();
                  Messages.field608 = 0;
                  field2239 = 0;
                  field2241 = false;
                  field2348 = 0;
                  field2101 = 0;
                  field2161 = 0;
                  UserComparator9.field1598 = null;
                  field2319 = 0;
                  field2104 = -1;
                  field2165 = 0;
                  field2318 = 0;
                  field2114 = AttackOption.field600;
                  field2115 = AttackOption.field600;
                  field2129 = 0;
                  OwnWorldComparator.method617();

                  for(var33 = 0; var33 < 2048; ++var33) {
                     field2141[var33] = null;
                  }

                  for(var33 = 0; var33 < 32768; ++var33) {
                     field2249[var33] = null;
                  }

                  field2212 = -1;
                  field2216.clear();
                  field2154.clear();

                  int var17;
                  for(var33 = 0; var33 < 4; ++var33) {
                     for(var13 = 0; var13 < 104; ++var13) {
                        for(var17 = 0; var17 < 104; ++var17) {
                           field2272[var33][var13][var17] = null;
                        }
                     }
                  }

                  field2131 = new NodeDeque();
                  ServerPacket.field2028.method718();

                  for(var33 = 0; var33 < VarpDefinition.field2925; ++var33) {
                     VarpDefinition var26 = UserComparator10.method2912(var33);
                     if (var26 != null) {
                        Varps.field2763[var33] = 0;
                        Varps.field2762[var33] = 0;
                     }
                  }

                  class17.field181.clearTransient();
                  field2256 = -1;
                  if (field2246 != -1) {
                     var33 = field2246;
                     if (var33 != -1 && class130.field1567[var33]) {
                        Widget.field2678.method4979(var33);
                        if (UserComparator3.field1708[var33] != null) {
                           var34 = true;

                           for(var17 = 0; var17 < UserComparator3.field1708[var33].length; ++var17) {
                              if (UserComparator3.field1708[var33][var17] != null) {
                                 if (UserComparator3.field1708[var33][var17].type != 2) {
                                    UserComparator3.field1708[var33][var17] = null;
                                 } else {
                                    var34 = false;
                                 }
                              }
                           }

                           if (var34) {
                              UserComparator3.field1708[var33] = null;
                           }

                           class130.field1567[var33] = false;
                        }
                     }
                  }

                  for(WidgetGroupParent var23 = (WidgetGroupParent)field2247.first(); var23 != null; var23 = (WidgetGroupParent)field2247.next()) {
                     class57.method1213(var23, true);
                  }

                  field2246 = -1;
                  field2247 = new NodeHashTable(8);
                  field2323 = null;
                  field2223 = 0;
                  field2276 = false;
                  field2351.method4500((int[])null, new int[]{0, 0, 0, 0, 0}, false, -1);

                  for(var33 = 0; var33 < 8; ++var33) {
                     field2210[var33] = null;
                     field2211[var33] = false;
                  }

                  WorldMapLabelSize.method1303();
                  field2097 = true;

                  for(var33 = 0; var33 < 100; ++var33) {
                     field2291[var33] = true;
                  }

                  Interpreter.method968();
                  TotalQuantityComparator.field983 = null;

                  for(var33 = 0; var33 < 8; ++var33) {
                     field2338[var33] = new GrandExchangeOffer();
                  }

                  Message.field553 = null;
                  SpotAnimationDefinition.method5548(var2);
                  VertexNormal.field1238 = -1;
                  class79.method1621(false, var2);
                  field2133.serverPacket0 = null;
               }

            }
         }
      } catch (IOException var20) {
         if (field2122 < 1) {
            if (UserComparator5.field1595 == UserComparator4.field1729) {
               UserComparator5.field1595 = GrandExchangeEvent.field761;
            } else {
               UserComparator5.field1595 = UserComparator4.field1729;
            }

            ++field2122;
            field2120 = 0;
         } else {
            BufferedFile.method2589(-2);
         }
      }
   }

   final void method3329() {
      if (field2105 > 1) {
         --field2105;
      }

      if (field2168 > 0) {
         --field2168;
      }

      if (field2135) {
         field2135 = false;
         class93.method1784();
      } else {
         if (!field2276) {
            WorldMapSection0.method1872();
         }

         int var1;
         for(var1 = 0; var1 < 100 && this.method3333(field2133); ++var1) {
            ;
         }

         if (field2163 == 30) {
            int var2;
            PacketBufferNode var14;
            while(ClientPreferences.last()) {
               var14 = FaceNormal.method2884(ClientPacket.field1927, field2133.isaacCipher);
               var14.packetBuffer.writeByte(0);
               var2 = var14.packetBuffer.index;
               class209.method4322(var14.packetBuffer);
               var14.packetBuffer.method3908(var14.packetBuffer.index - var2);
               field2133.method1281(var14);
            }

            if (field2347.field3518) {
               var14 = FaceNormal.method2884(ClientPacket.field1886, field2133.isaacCipher);
               var14.packetBuffer.writeByte(0);
               var2 = var14.packetBuffer.index;
               field2347.write(var14.packetBuffer);
               var14.packetBuffer.method3908(var14.packetBuffer.index - var2);
               field2133.method1281(var14);
               field2347.method5360();
            }

            Object var32 = class17.field180.lock;
            int var3;
            int var4;
            int var5;
            int var6;
            int var7;
            int var8;
            int var9;
            int var10;
            int var11;
            int var12;
            synchronized(class17.field180.lock) {
               if (!field2299) {
                  class17.field180.index = 0;
               } else if (MouseHandler.field158 != 0 || class17.field180.index >= 40) {
                  PacketBufferNode var15 = null;
                  var3 = 0;
                  var4 = 0;
                  var5 = 0;
                  var6 = 0;

                  for(var7 = 0; var7 < class17.field180.index && (var15 == null || var15.packetBuffer.index - var3 < 246); ++var7) {
                     var4 = var7;
                     var8 = class17.field180.ys[var7];
                     if (var8 < -1) {
                        var8 = -1;
                     } else if (var8 > 65534) {
                        var8 = 65534;
                     }

                     var9 = class17.field180.xs[var7];
                     if (var9 < -1) {
                        var9 = -1;
                     } else if (var9 > 65534) {
                        var9 = 65534;
                     }

                     if (var9 != field2178 || var8 != field2086) {
                        if (var15 == null) {
                           var15 = FaceNormal.method2884(ClientPacket.field1901, field2133.isaacCipher);
                           var15.packetBuffer.writeByte(0);
                           var3 = var15.packetBuffer.index;
                           var15.packetBuffer.index += 2;
                           var5 = 0;
                           var6 = 0;
                        }

                        if (-1L != field2257) {
                           var10 = var9 - field2178;
                           var11 = var8 - field2086;
                           var12 = (int)((class17.field180.millis[var7] - field2257) / 20L);
                           var5 = (int)((long)var5 + (class17.field180.millis[var7] - field2257) % 20L);
                        } else {
                           var10 = var9;
                           var11 = var8;
                           var12 = Integer.MAX_VALUE;
                        }

                        field2178 = var9;
                        field2086 = var8;
                        if (var12 < 8 && var10 >= -32 && var10 <= 31 && var11 >= -32 && var11 <= 31) {
                           var10 += 32;
                           var11 += 32;
                           var15.packetBuffer.writeShort((var12 << 12) + var11 + (var10 << 6));
                        } else if (var12 < 32 && var10 >= -128 && var10 <= 127 && var11 >= -128 && var11 <= 127) {
                           var10 += 128;
                           var11 += 128;
                           var15.packetBuffer.writeByte(var12 + 128);
                           var15.packetBuffer.writeShort(var11 + (var10 << 8));
                        } else if (var12 < 32) {
                           var15.packetBuffer.writeByte(var12 + 192);
                           if (var9 != -1 && var8 != -1) {
                              var15.packetBuffer.writeInt(var9 | var8 << 16);
                           } else {
                              var15.packetBuffer.writeInt(Integer.MIN_VALUE);
                           }
                        } else {
                           var15.packetBuffer.writeShort((var12 & 8191) + '\ue000');
                           if (var9 != -1 && var8 != -1) {
                              var15.packetBuffer.writeInt(var9 | var8 << 16);
                           } else {
                              var15.packetBuffer.writeInt(Integer.MIN_VALUE);
                           }
                        }

                        ++var6;
                        field2257 = class17.field180.millis[var7];
                     }
                  }

                  if (var15 != null) {
                     var15.packetBuffer.method3908(var15.packetBuffer.index - var3);
                     var7 = var15.packetBuffer.index;
                     var15.packetBuffer.index = var3;
                     var15.packetBuffer.writeByte(var5 / var6);
                     var15.packetBuffer.writeByte(var5 % var6);
                     var15.packetBuffer.index = var7;
                     field2133.method1281(var15);
                  }

                  if (var4 >= class17.field180.index) {
                     class17.field180.index = 0;
                  } else {
                     class17.field180.index -= var4;
                     System.arraycopy(class17.field180.xs, var4, class17.field180.xs, 0, class17.field180.index);
                     System.arraycopy(class17.field180.ys, var4, class17.field180.ys, 0, class17.field180.index);
                     System.arraycopy(class17.field180.millis, var4, class17.field180.millis, 0, class17.field180.index);
                  }
               }
            }

            if (MouseHandler.field158 == 1 || !WorldMapSection0.field1101 && MouseHandler.field158 == 4 || MouseHandler.field158 == 2) {
               long var16 = (MouseHandler.field146 - field2099 * -1L) / 50L;
               if (var16 > 4095L) {
                  var16 = 4095L;
               }

               field2099 = MouseHandler.field146 * -1L;
               var3 = MouseHandler.field148;
               if (var3 < 0) {
                  var3 = 0;
               } else if (var3 > UserComparator8.field1678) {
                  var3 = UserComparator8.field1678;
               }

               var4 = MouseHandler.field159;
               if (var4 < 0) {
                  var4 = 0;
               } else if (var4 > FriendSystem.field379) {
                  var4 = FriendSystem.field379;
               }

               var5 = (int)var16;
               PacketBufferNode var18 = FaceNormal.method2884(ClientPacket.field1932, field2133.isaacCipher);
               var18.packetBuffer.writeShort((MouseHandler.field158 == 2 ? 1 : 0) + (var5 << 1));
               var18.packetBuffer.writeShort(var4);
               var18.packetBuffer.writeShort(var3);
               field2133.method1281(var18);
            }

            if (KeyHandler.field18 > 0) {
               var14 = FaceNormal.method2884(ClientPacket.field1903, field2133.isaacCipher);
               var14.packetBuffer.writeShort(0);
               var2 = var14.packetBuffer.index;
               long var19 = Tile.method2779();

               for(var5 = 0; var5 < KeyHandler.field18; ++var5) {
                  long var21 = var19 - field2311;
                  if (var21 > 16777215L) {
                     var21 = 16777215L;
                  }

                  field2311 = var19;
                  var14.packetBuffer.method3938(KeyHandler.field8[var5]);
                  var14.packetBuffer.writeMedium((int)var21);
               }

               var14.packetBuffer.method3907(var14.packetBuffer.index - var2);
               field2133.method1281(var14);
            }

            if (field2170 > 0) {
               --field2170;
            }

            if (KeyHandler.field11[96] || KeyHandler.field11[97] || KeyHandler.field11[98] || KeyHandler.field11[99]) {
               field2171 = true;
            }

            if (field2171 && field2170 <= 0) {
               field2170 = 20;
               field2171 = false;
               var14 = FaceNormal.method2884(ClientPacket.field1898, field2133.isaacCipher);
               var14.packetBuffer.method3948(field2155);
               var14.packetBuffer.writeShortLE(field2101);
               field2133.method1281(var14);
            }

            if (class180.field1994 && !field2362) {
               field2362 = true;
               var14 = FaceNormal.method2884(ClientPacket.field1870, field2133.isaacCipher);
               var14.packetBuffer.writeByte(1);
               field2133.method1281(var14);
            }

            if (!class180.field1994 && field2362) {
               field2362 = false;
               var14 = FaceNormal.method2884(ClientPacket.field1870, field2133.isaacCipher);
               var14.packetBuffer.writeByte(0);
               field2133.method1281(var14);
            }

            if (class12.field123 != null) {
               class12.field123.method6048();
            }

            if (WorldMapLabel.field1015) {
               if (TotalQuantityComparator.field983 != null) {
                  TotalQuantityComparator.field983.sort();
               }

               for(var1 = 0; var1 < Players.field951; ++var1) {
                  Player var35 = field2141[Players.field947[var1]];
                  var35.method824();
               }

               WorldMapLabel.field1015 = false;
            }

            class73.method1483();
            if (field2163 == 30) {
               class83.method1698();

               for(var1 = 0; var1 < field2348; ++var1) {
                  --field2236[var1];
                  if (field2236[var1] >= -10) {
                     Object var36 = field2153[var1];
                     if (var36 == null) {
                        Object var10000 = null;
                        var36 = SoundEffect.method1624(class71.field846, field2327[var1], 0);
                        if (var36 == null) {
                           continue;
                        }

                        field2236[var1] += ((SoundEffect)var36).method1623();
                        field2153[var1] = (SoundEffect) var36;
                     }

                     if (field2236[var1] < 0) {
                        if (field2330[var1] != 0) {
                           var4 = (field2330[var1] & 255) * 128;
                           var5 = field2330[var1] >> 16 & 255;
                           var6 = var5 * 128 + 64 - ObjectSound.field589.x;
                           if (var6 < 0) {
                              var6 = -var6;
                           }

                           var7 = field2330[var1] >> 8 & 255;
                           var8 = var7 * 128 + 64 - ObjectSound.field589.y;
                           if (var8 < 0) {
                              var8 = -var8;
                           }

                           var9 = var8 + var6 - 128;
                           if (var9 > var4) {
                              field2236[var1] = -100;
                              continue;
                           }

                           if (var9 < 0) {
                              var9 = 0;
                           }

                           var3 = (var4 - var9) * field2324 / var4;
                        } else {
                           var3 = field2331;
                        }

                        if (var3 > 0) {
                           class88 var23 = ((SoundEffect)var36).method1630().method1770(IgnoreList.field3698);
                           class104 var24 = class104.method2045(var23, 100, var3);
                           var24.method2037(field2328[var1] - 1);
                           class10.field116.method1565(var24);
                        }

                        field2236[var1] = -100;
                     }
                  } else {
                     --field2348;

                     for(var2 = var1; var2 < field2348; ++var2) {
                        field2327[var2] = field2327[var2 + 1];
                        field2153[var2] = field2153[var2 + 1];
                        field2328[var2] = field2328[var2 + 1];
                        field2236[var2] = field2236[var2 + 1];
                        field2330[var2] = field2330[var2 + 1];
                     }

                     --var1;
                  }
               }

               if (field2322 && !class85.method1735()) {
                  if (field2320 != 0 && field2321 != -1) {
                     BufferedNetSocket.available(ServerPacket.field1995, field2321, 0, field2320, false);
                  }

                  field2322 = false;
               }

               ++field2133.field708;
               if (field2133.field708 > 750) {
                  class93.method1784();
               } else {
                  World.method661();
                  Projectile.method1332();
                  int[] var33 = Players.field947;

                  for(var2 = 0; var2 < Players.field951; ++var2) {
                     Player var25 = field2141[var33[var2]];
                     if (var25 != null && var25.overheadTextCyclesRemaining > 0) {
                        --var25.overheadTextCyclesRemaining;
                        if (var25.overheadTextCyclesRemaining == 0) {
                           var25.overheadText = null;
                        }
                     }
                  }

                  for(var2 = 0; var2 < field2129; ++var2) {
                     var3 = field2130[var2];
                     Npc var39 = field2249[var3];
                     if (var39 != null && var39.overheadTextCyclesRemaining > 0) {
                        --var39.overheadTextCyclesRemaining;
                        if (var39.overheadTextCyclesRemaining == 0) {
                           var39.overheadText = null;
                        }
                     }
                  }

                  ++field2148;
                  if (field2202 != 0) {
                     field2252 += 20;
                     if (field2252 >= 400) {
                        field2202 = 0;
                     }
                  }

                  if (class176.field1961 != null) {
                     ++field2192;
                     if (field2192 >= 15) {
                        WorldMapSection1.method506(class176.field1961);
                        class176.field1961 = null;
                     }
                  }

                  Widget var34 = BufferedSource.field1671;
                  Widget var37 = Tiles.field206;
                  BufferedSource.field1671 = null;
                  Tiles.field206 = null;
                  field2254 = null;
                  field2267 = false;
                  field2264 = false;
                  field2308 = 0;

                  while(ClanMate.method5342() && field2308 < 128) {
                     if (field2255 >= 2 && KeyHandler.field11[82] && Message.field561 == 66) {
                        String var40 = "";

                        Message var38;
                        for(Iterator var41 = Messages.field611.iterator(); var41.hasNext(); var40 = var40 + var38.sender + ':' + var38.text + '\n') {
                           var38 = (Message)var41.next();
                        }

                        class178.field1984.clipboardSetString(var40);
                     } else if (field2161 != 1 || FaceNormal.field1622 <= 0) {
                        field2310[field2308] = Message.field561;
                        field2289[field2308] = FaceNormal.field1622;
                        ++field2308;
                     }
                  }

                  if (SecureRandomCallable.method1019() && KeyHandler.field11[82] && KeyHandler.field11[81] && field2284 != 0) {
                     var3 = ObjectSound.field589.plane - field2284;
                     if (var3 < 0) {
                        var3 = 0;
                     } else if (var3 > 3) {
                        var3 = 3;
                     }

                     if (var3 != ObjectSound.field589.plane) {
                        class21.method543(ObjectSound.field589.pathX[0] + class21.field230, ObjectSound.field589.pathY[0] + class79.field902, var3, false);
                     }

                     field2284 = 0;
                  }

                  if (field2246 != -1) {
                     class57.method1228(field2246, 0, 0, FriendSystem.field379, UserComparator8.field1678, 0, 0);
                  }

                  ++field2271;

                  while(true) {
                     Widget var42;
                     Widget var43;
                     ScriptEvent var44;
                     do {
                        var44 = (ScriptEvent)field2286.removeLast();
                        if (var44 == null) {
                           while(true) {
                              do {
                                 var44 = (ScriptEvent)field2287.removeLast();
                                 if (var44 == null) {
                                    while(true) {
                                       do {
                                          var44 = (ScriptEvent)field2285.removeLast();
                                          if (var44 == null) {
                                             this.method3418();
                                             class177.method3290();
                                             if (field2259 != null) {
                                                this.method3434();
                                             }

                                             PacketBufferNode var45;
                                             if (World.field361 != null) {
                                                WorldMapSection1.method506(World.field361);
                                                ++field2199;
                                                if (MouseHandler.field150 == 0) {
                                                   if (field2116) {
                                                      if (World.field361 == class73.field855 && field2240 != field2194) {
                                                         Widget var46 = World.field361;
                                                         byte var29 = 0;
                                                         if (field2251 == 1 && var46.contentType == 206) {
                                                            var29 = 1;
                                                         }

                                                         if (var46.itemIds[field2240] <= 0) {
                                                            var29 = 0;
                                                         }

                                                         if (ServerPacket.method3317(class257.method5068(var46))) {
                                                            var5 = field2194;
                                                            var6 = field2240;
                                                            var46.itemIds[var6] = var46.itemIds[var5];
                                                            var46.itemQuantities[var6] = var46.itemQuantities[var5];
                                                            var46.itemIds[var5] = -1;
                                                            var46.itemQuantities[var5] = 0;
                                                         } else if (var29 == 1) {
                                                            var5 = field2194;
                                                            var6 = field2240;

                                                            while(var5 != var6) {
                                                               if (var5 > var6) {
                                                                  var46.swapItems(var5 - 1, var5);
                                                                  --var5;
                                                               } else if (var5 < var6) {
                                                                  var46.swapItems(var5 + 1, var5);
                                                                  ++var5;
                                                               }
                                                            }
                                                         } else {
                                                            var46.swapItems(field2240, field2194);
                                                         }

                                                         var45 = FaceNormal.method2884(ClientPacket.field1916, field2133.isaacCipher);
                                                         var45.packetBuffer.writeShort(field2240);
                                                         var45.packetBuffer.writeShortLE(field2194);
                                                         var45.packetBuffer.writeInt(World.field361.id);
                                                         var45.packetBuffer.method3938(var29);
                                                         field2133.method1281(var45);
                                                      }
                                                   } else if (this.method3335()) {
                                                      this.method3704(field2195, field2288);
                                                   } else if (field2223 > 0) {
                                                      class12.method374(field2195, field2288);
                                                   }

                                                   field2192 = 10;
                                                   MouseHandler.field158 = 0;
                                                   World.field361 = null;
                                                } else if (field2199 >= 5 && (MouseHandler.field154 > field2195 + 5 || MouseHandler.field154 < field2195 - 5 || MouseHandler.field145 * -976212263 > field2288 + 5 || MouseHandler.field145 * -976212263 < field2288 - 5)) {
                                                   field2116 = true;
                                                }
                                             }

                                             if (Scene.method2277()) {
                                                var3 = Scene.field1180;
                                                var4 = Scene.field1200;
                                                var45 = FaceNormal.method2884(ClientPacket.field1851, field2133.isaacCipher);
                                                var45.packetBuffer.writeByte(5);
                                                var45.packetBuffer.method4029(var4 + class79.field902);
                                                var45.packetBuffer.method4029(var3 + class21.field230);
                                                var45.packetBuffer.method3937(KeyHandler.field11[82] ? (KeyHandler.field11[81] ? 2 : 1) : 0);
                                                field2133.method1281(var45);
                                                Scene.method2265();
                                                field2187 = MouseHandler.field159;
                                                field2188 = MouseHandler.field148;
                                                field2202 = 1;
                                                field2252 = 0;
                                                field2165 = var3;
                                                field2318 = var4;
                                             }

                                             if (var34 != BufferedSource.field1671) {
                                                if (var34 != null) {
                                                   WorldMapSection1.method506(var34);
                                                }

                                                if (BufferedSource.field1671 != null) {
                                                   WorldMapSection1.method506(BufferedSource.field1671);
                                                }
                                             }

                                             if (var37 != Tiles.field206 && field2238 == field2237) {
                                                if (var37 != null) {
                                                   WorldMapSection1.method506(var37);
                                                }

                                                if (Tiles.field206 != null) {
                                                   WorldMapSection1.method506(Tiles.field206);
                                                }
                                             }

                                             if (Tiles.field206 != null) {
                                                if (field2237 < field2238) {
                                                   ++field2237;
                                                   if (field2238 == field2237) {
                                                      WorldMapSection1.method506(Tiles.field206);
                                                   }
                                                }
                                             } else if (field2237 > 0) {
                                                --field2237;
                                             }

                                             if (field2161 == 0) {
                                                var3 = ObjectSound.field589.x;
                                                var4 = ObjectSound.field589.y;
                                                if (class71.field842 - var3 < -500 || class71.field842 - var3 > 500 || class71.field844 - var4 < -500 || class71.field844 - var4 > 500) {
                                                   class71.field842 = var3;
                                                   class71.field844 = var4;
                                                }

                                                if (var3 != class71.field842) {
                                                   class71.field842 += (var3 - class71.field842) / 16;
                                                }

                                                if (var4 != class71.field844) {
                                                   class71.field844 += (var4 - class71.field844) / 16;
                                                }

                                                var5 = class71.field842 >> 7;
                                                var6 = class71.field844 >> 7;
                                                var7 = MilliClock.method2923(class71.field842, class71.field844, class31.field363);
                                                var8 = 0;
                                                if (var5 > 3 && var6 > 3 && var5 < 100 && var6 < 100) {
                                                   for(var9 = var5 - 4; var9 <= var5 + 4; ++var9) {
                                                      for(var10 = var6 - 4; var10 <= var6 + 4; ++var10) {
                                                         var11 = class31.field363;
                                                         if (var11 < 3 && (Tiles.field203[1][var9][var10] & 2) == 2) {
                                                            ++var11;
                                                         }

                                                         var12 = var7 - Tiles.field217[var11][var9][var10];
                                                         if (var12 > var8) {
                                                            var8 = var12;
                                                         }
                                                      }
                                                   }
                                                }

                                                var9 = var8 * 192;
                                                if (var9 > 98048) {
                                                   var9 = 98048;
                                                }

                                                if (var9 < 32768) {
                                                   var9 = 32768;
                                                }

                                                if (var9 > field2172) {
                                                   field2172 += (var9 - field2172) / 24;
                                                } else if (var9 < field2172) {
                                                   field2172 += (var9 - field2172) / 80;
                                                }

                                                ViewportMouse.field1512 = MilliClock.method2923(ObjectSound.field589.x, ObjectSound.field589.y, class31.field363) - field2162;
                                             } else if (field2161 == 1) {
                                                if (field2169 && ObjectSound.field589 != null) {
                                                   var3 = ObjectSound.field589.pathX[0];
                                                   var4 = ObjectSound.field589.pathY[0];
                                                   if (var3 >= 0 && var4 >= 0 && var3 < 104 && var4 < 104) {
                                                      class71.field842 = ObjectSound.field589.x;
                                                      var5 = MilliClock.method2923(ObjectSound.field589.x, ObjectSound.field589.y, class31.field363) - field2162;
                                                      if (var5 < ViewportMouse.field1512) {
                                                         ViewportMouse.field1512 = var5;
                                                      }

                                                      class71.field844 = ObjectSound.field589.y;
                                                      field2169 = false;
                                                   }
                                                }

                                                short var30 = -1;
                                                if (KeyHandler.field11[33]) {
                                                   var30 = 0;
                                                } else if (KeyHandler.field11[49]) {
                                                   var30 = 1024;
                                                }

                                                if (KeyHandler.field11[48]) {
                                                   if (var30 == 0) {
                                                      var30 = 1792;
                                                   } else if (var30 == 1024) {
                                                      var30 = 1280;
                                                   } else {
                                                      var30 = 1536;
                                                   }
                                                } else if (KeyHandler.field11[50]) {
                                                   if (var30 == 0) {
                                                      var30 = 256;
                                                   } else if (var30 == 1024) {
                                                      var30 = 768;
                                                   } else {
                                                      var30 = 512;
                                                   }
                                                }

                                                byte var31 = 0;
                                                if (KeyHandler.field11[35]) {
                                                   var31 = -1;
                                                } else if (KeyHandler.field11[51]) {
                                                   var31 = 1;
                                                }

                                                var5 = 0;
                                                if (var30 >= 0 || var31 != 0) {
                                                   var5 = KeyHandler.field11[81] ? field2167 : field2166;
                                                   var5 *= 16;
                                                   field2164 = var30;
                                                   field2300 = var31;
                                                }

                                                if (field2150 < var5) {
                                                   field2150 += var5 / 8;
                                                   if (field2150 > var5) {
                                                      field2150 = var5;
                                                   }
                                                } else if (field2150 > var5) {
                                                   field2150 = field2150 * 9 / 10;
                                                }

                                                if (field2150 > 0) {
                                                   var6 = field2150 / 16;
                                                   if (field2164 >= 0) {
                                                      var3 = field2164 - WorldMapSectionType.field1062 & 2047;
                                                      var7 = Rasterizer3D.field1446[var3];
                                                      var8 = Rasterizer3D.field1453[var3];
                                                      class71.field842 += var6 * var7 / 65536;
                                                      class71.field844 += var6 * var8 / 65536;
                                                   }

                                                   if (field2300 != 0) {
                                                      ViewportMouse.field1512 += var6 * field2300;
                                                      if (ViewportMouse.field1512 > 0) {
                                                         ViewportMouse.field1512 = 0;
                                                      }
                                                   }
                                                } else {
                                                   field2164 = -1;
                                                   field2300 = -1;
                                                }

                                                if (KeyHandler.field11[13]) {
                                                   field2133.method1281(FaceNormal.method2884(ClientPacket.field1914, field2133.isaacCipher));
                                                   field2161 = 0;
                                                }
                                             }

                                             if (MouseHandler.field150 == 4 && WorldMapSection0.field1101) {
                                                var3 = MouseHandler.field145 * -976212263 - field2160 * -976212263;
                                                field2158 = var3 * 2;
                                                field2160 = (var3 != -1 && var3 != 1 ? (MouseHandler.field145 * -976212263 + field2160 * -976212263) / 2 : MouseHandler.field145 * -976212263) * -1727565463;
                                                var4 = field2312 - MouseHandler.field154;
                                                field2157 = var4 * 2;
                                                field2312 = var4 != -1 && var4 != 1 ? (field2312 + MouseHandler.field154) / 2 : MouseHandler.field154;
                                             } else {
                                                if (KeyHandler.field11[96]) {
                                                   field2157 += (-24 - field2157) / 2;
                                                } else if (KeyHandler.field11[97]) {
                                                   field2157 += (24 - field2157) / 2;
                                                } else {
                                                   field2157 /= 2;
                                                }

                                                if (KeyHandler.field11[98]) {
                                                   field2158 += (12 - field2158) / 2;
                                                } else if (KeyHandler.field11[99]) {
                                                   field2158 += (-12 - field2158) / 2;
                                                } else {
                                                   field2158 /= 2;
                                                }

                                                field2160 = MouseHandler.field145;
                                                field2312 = MouseHandler.field154;
                                             }

                                             field2101 = field2157 / 2 + field2101 & 2047;
                                             field2155 += field2158 / 2;
                                             if (field2155 < 128) {
                                                field2155 = 128;
                                             }

                                             if (field2155 > 383) {
                                                field2155 = 383;
                                             }

                                             if (field2332) {
                                                WorldMapLabelSize.method1314();
                                             }

                                             for(var3 = 0; var3 < 5; ++var3) {
                                                ++field2337[var3];
                                             }

                                             class17.field181.tryWrite();
                                             var3 = ++MouseHandler.field165 - 1;
                                             var5 = KeyHandler.field22;
                                             PacketBufferNode var26;
                                             if (var3 > 15000 && var5 > 15000) {
                                                field2168 = 250;
                                                Script.method1817(14500);
                                                var26 = FaceNormal.method2884(ClientPacket.field1885, field2133.isaacCipher);
                                                field2133.method1281(var26);
                                             }

                                             ServerPacket.field2028.method786();
                                             ++field2133.field709;
                                             if (field2133.field709 > 50) {
                                                var26 = FaceNormal.method2884(ClientPacket.field1853, field2133.isaacCipher);
                                                field2133.method1281(var26);
                                             }

                                             try {
                                                field2133.method1275();
                                             } catch (IOException var27) {
                                                class93.method1784();
                                             }

                                             return;
                                          }

                                          var42 = var44.widget;
                                          if (var42.childIndex < 0) {
                                             break;
                                          }

                                          var43 = WorldMapSection3.method1148(var42.parentId);
                                       } while(var43 == null || var43.children == null || var42.childIndex >= var43.children.length || var42 != var43.children[var42.childIndex]);

                                       IndexCacheLoader.method1096(var44);
                                    }
                                 }

                                 var42 = var44.widget;
                                 if (var42.childIndex < 0) {
                                    break;
                                 }

                                 var43 = WorldMapSection3.method1148(var42.parentId);
                              } while(var43 == null || var43.children == null || var42.childIndex >= var43.children.length || var42 != var43.children[var42.childIndex]);

                              IndexCacheLoader.method1096(var44);
                           }
                        }

                        var42 = var44.widget;
                        if (var42.childIndex < 0) {
                           break;
                        }

                        var43 = WorldMapSection3.method1148(var42.parentId);
                     } while(var43 == null || var43.children == null || var42.childIndex >= var43.children.length || var42 != var43.children[var42.childIndex]);

                     IndexCacheLoader.method1096(var44);
                  }
               }
            }
         }
      }
   }

   public final void init() {
      try {
         if (this.checkHost()) {
            ClientParameter[] var1 = Skeleton.method2198();

            for(int var2 = 0; var2 < var1.length; ++var2) {
               ClientParameter var3 = var1[var2];
               String var4 = this.getParameter(var3.id);
               if (var4 != null) {
                  switch(Integer.parseInt(var3.id)) {
                  case 1:
                     field2265 = Integer.parseInt(var4) != 0;
                  case 2:
                  case 11:
                  case 13:
                  case 16:
                  default:
                     break;
                  case 3:
                     if (var4.equalsIgnoreCase("true")) {
                        field2090 = true;
                     } else {
                        field2090 = false;
                     }
                     break;
                  case 4:
                     if (field2094 == -1) {
                        field2094 = Integer.parseInt(var4);
                     }
                     break;
                  case 5:
                     field2103 = Integer.parseInt(var4);
                     break;
                  case 6:
                     field2228 = Integer.parseInt(var4);
                     break;
                  case 7:
                     class196.field2450 = Formatting.method1027(Integer.parseInt(var4));
                     break;
                  case 8:
                     if (var4.equalsIgnoreCase("true")) {
                        ;
                     }
                     break;
                  case 9:
                     class57.field644 = var4;
                     break;
                  case 10:
                     field2089 = (StudioGame)class10.method352(IndexStoreAction.method4777(), Integer.parseInt(var4));
                     if (StudioGame.field3338 == field2089) {
                        field2363 = LoginType.field3929;
                     } else {
                        field2363 = LoginType.field3936;
                     }
                     break;
                  case 12:
                     field2134 = Integer.parseInt(var4);
                     break;
                  case 14:
                     field2093 = Integer.parseInt(var4);
                     break;
                  case 15:
                     field2088 = Integer.parseInt(var4);
                     break;
                  case 17:
                     AccessFile.field1367 = var4;
                  }
               }
            }

            ClientPacket.method3231();
            class85.field965 = this.getCodeBase().getHost();
            String var7 = class196.field2450.name;
            byte var8 = 0;

            try {
               class34.method794("oldschool", var7, var8, 18);
            } catch (Exception var5) {
               Projectile.setDestination(null, var5);
            }

            class178.field1984 = this;
            class83.field943 = field2094;
            this.startThread(765, 503, 177);
         }
      } catch (RuntimeException var6) {
         throw BufferedFile.seek(var6, "Client.init(" + ')');
      }
   }

   final void method3517() {
      int var1;
      if (field2246 != -1) {
         var1 = field2246;
         if (class196.method4189(var1)) {
            IndexCacheLoader.method1097(UserComparator3.field1708[var1], -1);
         }
      }

      for(var1 = 0; var1 < field2296; ++var1) {
         if (field2291[var1]) {
            field2292[var1] = true;
         }

         field2149[var1] = field2291[var1];
         field2291[var1] = false;
      }

      field2290 = field2098;
      field2235 = -1;
      field2303 = -1;
      class73.field855 = null;
      if (field2246 != -1) {
         field2296 = 0;
         class12.method376(field2246, 0, 0, FriendSystem.field379, UserComparator8.field1678, 0, 0, -1);
      }

      Rasterizer2D.method6213();
      if (field2191) {
         if (field2202 == 1) {
            UserComparator5.field1593[field2252 / 100].method6348(field2187 - 8, field2188 - 8);
         }

         if (field2202 == 2) {
            UserComparator5.field1593[field2252 / 100 + 4].method6348(field2187 - 8, field2188 - 8);
         }
      }

      int var2;
      int var3;
      if (!field2276) {
         if (field2235 != -1) {
            var1 = field2235;
            var2 = field2303;
            if ((field2223 >= 2 || field2239 != 0 || field2241) && field2234) {
               var3 = field2223 - 1;
               String var5;
               if (field2239 == 1 && field2223 < 2) {
                  var5 = "Use" + " " + field2209 + " " + "->";
               } else if (field2241 && field2223 < 2) {
                  var5 = field2244 + " " + field2159 + " " + "->";
               } else {
                  var5 = class6.method184(var3);
               }

               if (field2223 > 2) {
                  var5 = var5 + ModelData0.method2792(16777215) + " " + '/' + " " + (field2223 - 2) + " more options";
               }

               NetSocket.field1950.drawRandomAlphaAndSpacing(var5, var1 + 4, var2 + 15, 16777215, 0, field2098 / 1000);
            }
         }
      } else {
         var1 = NetSocket.field1951;
         var2 = Script.field1051;
         var3 = class39.field491;
         int var4 = ModelData0.field1555;
         int var11 = 6116423;
         Rasterizer2D.method6223(var1, var2, var3, var4, var11);
         Rasterizer2D.method6223(var1 + 1, var2 + 1, var3 - 2, 16, 0);
         Rasterizer2D.method6292(var1 + 1, var2 + 18, var3 - 2, var4 - 19, 0);
         NetSocket.field1950.draw("Choose Option", var1 + 3, var2 + 14, var11, -1);
         int var6 = MouseHandler.field154;
         int var7 = MouseHandler.field145 * -976212263;

         for(int var8 = 0; var8 < field2223; ++var8) {
            int var9 = var2 + (field2223 - 1 - var8) * 15 + 31;
            int var10 = 16777215;
            if (var6 > var1 && var6 < var3 + var1 && var7 > var9 - 13 && var7 < var9 + 3) {
               var10 = 16776960;
            }

            NetSocket.field1950.draw(class6.method184(var8), var1 + 3, var9, var10, 0);
         }

         Varps.method4667(NetSocket.field1951, Script.field1051, class39.field491, ModelData0.field1555);
      }

      if (field2298 == 3) {
         for(var1 = 0; var1 < field2296; ++var1) {
            if (field2149[var1]) {
               Rasterizer2D.method6222(field2206[var1], field2295[var1], field2262[var1], field2297[var1], 16711935, 128);
            } else if (field2292[var1]) {
               Rasterizer2D.method6222(field2206[var1], field2295[var1], field2262[var1], field2297[var1], 16711680, 128);
            }
         }
      }

      class103.method2019(class31.field363, ObjectSound.field589.x, ObjectSound.field589.y, field2148);
      field2148 = 0;
   }

   void method3443() {
      int var1 = FriendSystem.field379;
      int var2 = UserComparator8.field1678;
      if (super.contentWidth < var1) {
         var1 = super.contentWidth;
      }

      if (super.contentHeight < var2) {
         var2 = super.contentHeight;
      }

      if (GameShell.field72 != null) {
         try {
            class3.method94(class178.field1984, "resize", new Object[]{class65.method1381()});
         } catch (Throwable var4) {
            ;
         }
      }

   }

   final boolean method3333(PacketWriter var1) {
      AbstractSocket var2 = var1.getSocket();
      PacketBuffer var3 = var1.packetBuffer;
      if (var2 == null) {
         return false;
      } else {
         String var17;
         int var18;
         try {
            int var5;
            if (var1.serverPacket0 == null) {
               if (var1.field707) {
                  if (!var2.isAvailable(1)) {
                     return false;
                  }

                  var2.read(var1.packetBuffer.array, 0, 1);
                  var1.field708 = 0;
                  var1.field707 = false;
               }

               var3.index = 0;
               if (var3.method3798()) {
                  if (!var2.isAvailable(1)) {
                     return false;
                  }

                  var2.read(var1.packetBuffer.array, 1, 1);
                  var1.field708 = 0;
               }

               var1.field707 = true;
               ServerPacket[] var4 = class37.method859();
               var5 = var3.readSmartByteShortIsaac();
               if (var5 < 0 || var5 >= var4.length) {
                  throw new IOException(var5 + " " + var3.index);
               }

               var1.serverPacket0 = var4[var5];
               var1.serverPacket0Length = var1.serverPacket0.length;
            }

            if (var1.serverPacket0Length == -1) {
               if (!var2.isAvailable(1)) {
                  return false;
               }

               var1.getSocket().read(var3.array, 0, 1);
               var1.serverPacket0Length = var3.array[0] & 255;
            }

            if (var1.serverPacket0Length == -2) {
               if (!var2.isAvailable(2)) {
                  return false;
               }

               var1.getSocket().read(var3.array, 0, 2);
               var3.index = 0;
               var1.serverPacket0Length = var3.method3913();
            }

            if (!var2.isAvailable(var1.serverPacket0Length)) {
               return false;
            }

            var3.index = 0;
            var2.read(var3.array, 0, var1.serverPacket0Length);
            var1.field708 = 0;
            field2347.method5372();
            var1.field699 = var1.field705;
            var1.field705 = var1.field716;
            var1.field716 = var1.serverPacket0;
            if (ServerPacket.field2056 == var1.serverPacket0) {
               class79.method1621(false, var1.packetBuffer);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2037 == var1.serverPacket0) {
               class39.method973();
               var1.serverPacket0 = null;
               return false;
            }

            if (ServerPacket.field2055 == var1.serverPacket0) {
               WorldComparator.method1403();
               field2253 = var3.readUnsignedByte();
               field2128 = field2271;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2066 == var1.serverPacket0) {
               WorldComparator.method1403();
               field2294 = var3.method3956();
               field2128 = field2271;
               var1.serverPacket0 = null;
               return true;
            }

            Widget var6;
            int var7;
            int var8;
            int var9;
            int var10;
            int var16;
            if (ServerPacket.field2074 == var1.serverPacket0) {
               var16 = var3.readInt();
               var5 = var3.method3913();
               if (var16 < -70000) {
                  var5 += 32768;
               }

               if (var16 >= 0) {
                  var6 = WorldMapSection3.method1148(var16);
               } else {
                  var6 = null;
               }

               if (var6 != null) {
                  for(var7 = 0; var7 < var6.itemIds.length; ++var7) {
                     var6.itemIds[var7] = 0;
                     var6.itemQuantities[var7] = 0;
                  }
               }

               GraphicsObject.method1082(var5);
               var7 = var3.method3913();

               for(var8 = 0; var8 < var7; ++var8) {
                  var9 = var3.method3913();
                  var10 = var3.readUnsignedByte();
                  if (var10 == 255) {
                     var10 = var3.method3914();
                  }

                  if (var6 != null && var8 < var6.itemIds.length) {
                     var6.itemIds[var8] = var9;
                     var6.itemQuantities[var8] = var10;
                  }

                  WorldMapSection2.method377(var5, var8, var9 - 1, var10);
               }

               if (var6 != null) {
                  WorldMapSection1.method506(var6);
               }

               WorldComparator.method1403();
               field2274[++field2275 - 1 & 31] = var5 & 32767;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2026 == var1.serverPacket0) {
               var16 = var3.method3914();
               var5 = var3.method3934();
               var6 = WorldMapSection3.method1148(var16);
               if (var6.modelType != 1 || var5 != var6.modelId) {
                  var6.modelType = 1;
                  var6.modelId = var5;
                  WorldMapSection1.method506(var6);
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2014 == var1.serverPacket0) {
               var16 = var3.readInt();
               var17 = var3.readStringCp1252NullTerminated();
               var6 = WorldMapSection3.method1148(var16);
               if (!var17.equals(var6.text)) {
                  var6.text = var17;
                  WorldMapSection1.method506(var6);
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2023 == var1.serverPacket0) {
               for(var16 = 0; var16 < field2141.length; ++var16) {
                  if (field2141[var16] != null) {
                     field2141[var16].sequence = -1;
                  }
               }

               for(var16 = 0; var16 < field2249.length; ++var16) {
                  if (field2249[var16] != null) {
                     field2249[var16].sequence = -1;
                  }
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2060 == var1.serverPacket0) {
               var16 = var3.method3913();
               var5 = var3.readUnsignedByte();
               var18 = var3.method3913();
               class17.method467(var16, var5, var18);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2007 == var1.serverPacket0) {
               class162.method3075(class158.field1739);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2003 == var1.serverPacket0) {
               class162.method3075(class158.field1737);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2079 == var1.serverPacket0) {
               ClientPreferences.toBuffer(var3, var1.serverPacket0Length);
               class69.method1423();
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2042 == var1.serverPacket0) {
               World var41 = new World();
               var41.host = var3.readStringCp1252NullTerminated();
               var41.id = var3.method3913();
               var5 = var3.readInt();
               var41.properties = var5;
               class69.method1443(45);
               var2.close();
               var2 = null;
               UrlRequest.method2877(var41);
               var1.serverPacket0 = null;
               return false;
            }

            if (ServerPacket.field2039 == var1.serverPacket0) {
               var16 = var3.readInt();
               var5 = var3.method3913();
               if (var16 < -70000) {
                  var5 += 32768;
               }

               if (var16 >= 0) {
                  var6 = WorldMapSection3.method1148(var16);
               } else {
                  var6 = null;
               }

               for(; var3.index < var1.serverPacket0Length; WorldMapSection2.method377(var5, var7, var8 - 1, var9)) {
                  var7 = var3.method3925();
                  var8 = var3.method3913();
                  var9 = 0;
                  if (var8 != 0) {
                     var9 = var3.readUnsignedByte();
                     if (var9 == 255) {
                        var9 = var3.readInt();
                     }
                  }

                  if (var6 != null && var7 >= 0 && var7 < var6.itemIds.length) {
                     var6.itemIds[var7] = var8;
                     var6.itemQuantities[var7] = var9;
                  }
               }

               if (var6 != null) {
                  WorldMapSection1.method506(var6);
               }

               WorldComparator.method1403();
               field2274[++field2275 - 1 & 31] = var5 & 32767;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2050 == var1.serverPacket0) {
               class185.field2382 = var3.readUnsignedByteNegate();
               HealthBar.field343 = var3.method4033();
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2041 == var1.serverPacket0) {
               var16 = var3.method3949();
               WorldMapManager.method141(var16);
               field2274[++field2275 - 1 & 31] = var16 & 32767;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2052 == var1.serverPacket0) {
               var3.index += 28;
               if (var3.method3928()) {
                  Script.method1815(var3, var3.index - 28);
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2018 == var1.serverPacket0) {
               var16 = var3.method3934();
               if (var16 == 65535) {
                  var16 = -1;
               }

               ObjectSound.method1093(var16);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2035 == var1.serverPacket0) {
               var16 = var3.method3954();
               var5 = var3.method3950();
               if (var5 == 65535) {
                  var5 = -1;
               }

               class257.method5062(var5, var16);
               var1.serverPacket0 = null;
               return true;
            }

            Widget var56;
            if (ServerPacket.field2054 == var1.serverPacket0) {
               var16 = var3.method4106();
               var5 = var3.method3953();
               var18 = var3.method3952();
               var56 = WorldMapSection3.method1148(var16);
               if (var18 != var56.rawX || var5 != var56.rawY || var56.xAlignment != 0 || var56.yAlignment != 0) {
                  var56.rawX = var18;
                  var56.rawY = var5;
                  var56.xAlignment = 0;
                  var56.yAlignment = 0;
                  WorldMapSection1.method506(var56);
                  this.method3661(var56);
                  if (var56.type == 0) {
                     MusicPatch.method4734(UserComparator3.field1708[var16 >> 16], var56, false);
                  }
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2009 == var1.serverPacket0) {
               for(var16 = 0; var16 < VarpDefinition.field2925; ++var16) {
                  VarpDefinition var55 = UserComparator10.method2912(var16);
                  if (var55 != null) {
                     Varps.field2763[var16] = 0;
                     Varps.field2762[var16] = 0;
                  }
               }

               WorldComparator.method1403();
               field2273 += 32;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2027 == var1.serverPacket0) {
               ServerPacket.field2028.ignoreList.read(var3, var1.serverPacket0Length);
               GrandExchangeEvent.method1335();
               field2279 = field2271;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2012 == var1.serverPacket0) {
               HealthBar.field343 = var3.method4033();
               class185.field2382 = var3.readUnsignedByteNegate();

               while(var3.index < var1.serverPacket0Length) {
                  var16 = var3.readUnsignedByte();
                  class158 var54 = World.method698()[var16];
                  class162.method3075(var54);
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2068 == var1.serverPacket0) {
               if (field2246 != -1) {
                  WorldMapData2.method338(field2246, 0);
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2048 == var1.serverPacket0) {
               WorldMapLabelSize.method1319(var3, var1.serverPacket0Length);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2016 == var1.serverPacket0) {
               var16 = var3.method3956();
               var5 = var3.method3914();
               var6 = WorldMapSection3.method1148(var5);
               if (var16 != var6.sequenceId || var16 == -1) {
                  var6.sequenceId = var16;
                  var6.modelFrame = 0;
                  var6.modelFrameCycle = 0;
                  WorldMapSection1.method506(var6);
               }

               var1.serverPacket0 = null;
               return true;
            }

            boolean var51;
            if (ServerPacket.field2059 == var1.serverPacket0) {
               var51 = var3.readUnsignedByte() == 1;
               if (var51) {
                  TextureProvider.field1249 = Tile.method2779() - var3.readLong();
                  Message.field553 = new GrandExchangeEvents(var3, true);
               } else {
                  Message.field553 = null;
               }

               field2282 = field2271;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2070 == var1.serverPacket0) {
               field2332 = true;
               WorldMapSection2.field129 = var3.readUnsignedByte();
               class165.field1790 = var3.readUnsignedByte();
               UrlRequest.field1615 = var3.method3913();
               ServerPacket.field2084 = var3.readUnsignedByte();
               WorldMapManager.field46 = var3.readUnsignedByte();
               if (WorldMapManager.field46 >= 100) {
                  class178.field1983 = WorldMapSection2.field129 * 128 + 64;
                  Tiles.field219 = class165.field1790 * 128 + 64;
                  Buffer.field2445 = MilliClock.method2923(class178.field1983, Tiles.field219, class31.field363) - UrlRequest.field1615;
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2072 == var1.serverPacket0) {
               class162.method3075(class158.field1738);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2053 == var1.serverPacket0) {
               IndexCacheLoader.method1102(false, var3);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2081 == var1.serverPacket0) {
               class162.method3075(class158.field1736);
               var1.serverPacket0 = null;
               return true;
            }

            WidgetGroupParent var19;
            Widget var20;
            if (ServerPacket.field2020 == var1.serverPacket0) {
               var16 = var3.readInt();
               var5 = var3.readInt();
               WidgetGroupParent var44 = (WidgetGroupParent)field2247.get((long)var5);
               var19 = (WidgetGroupParent)field2247.get((long)var16);
               if (var19 != null) {
                  class57.method1213(var19, var44 == null || var19.group != var44.group);
               }

               if (var44 != null) {
                  var44.remove();
                  field2247.put(var44, (long)var16);
               }

               var20 = WorldMapSection3.method1148(var5);
               if (var20 != null) {
                  WorldMapSection1.method506(var20);
               }

               var20 = WorldMapSection3.method1148(var16);
               if (var20 != null) {
                  WorldMapSection1.method506(var20);
                  MusicPatch.method4734(UserComparator3.field1708[var20.id >>> 16], var20, true);
               }

               if (field2246 != -1) {
                  WorldMapData2.method338(field2246, 1);
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2022 == var1.serverPacket0) {
               var16 = var3.readUnsignedByte();
               class95.method1797(var16);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2031 == var1.serverPacket0) {
               field2106 = var3.readUnsignedByte();
               if (field2106 == 1) {
                  field2107 = var3.method3913();
               }

               if (field2106 >= 2 && field2106 <= 6) {
                  if (field2106 == 2) {
                     field2112 = 64;
                     field2198 = 64;
                  }

                  if (field2106 == 3) {
                     field2112 = 0;
                     field2198 = 64;
                  }

                  if (field2106 == 4) {
                     field2112 = 128;
                     field2198 = 64;
                  }

                  if (field2106 == 5) {
                     field2112 = 64;
                     field2198 = 0;
                  }

                  if (field2106 == 6) {
                     field2112 = 64;
                     field2198 = 128;
                  }

                  field2106 = 2;
                  field2109 = var3.method3913();
                  field2110 = var3.method3913();
                  field2111 = var3.readUnsignedByte();
               }

               if (field2106 == 10) {
                  field2108 = var3.method3913();
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2062 == var1.serverPacket0) {
               field2165 = var3.readUnsignedByte();
               if (field2165 == 255) {
                  field2165 = 0;
               }

               field2318 = var3.readUnsignedByte();
               if (field2318 == 255) {
                  field2318 = 0;
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2004 == var1.serverPacket0) {
               var16 = var3.readInt();
               WidgetGroupParent var52 = (WidgetGroupParent)field2247.get((long)var16);
               if (var52 != null) {
                  class57.method1213(var52, true);
               }

               if (field2323 != null) {
                  WorldMapSection1.method506(field2323);
                  field2323 = null;
               }

               var1.serverPacket0 = null;
               return true;
            }

            Widget var49;
            if (ServerPacket.field2025 == var1.serverPacket0) {
               var16 = var3.method3914();
               var49 = WorldMapSection3.method1148(var16);
               var49.modelType = 3;
               var49.modelId = ObjectSound.field589.appearance.getChatHeadId();
               WorldMapSection1.method506(var49);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field1999 == var1.serverPacket0) {
               var16 = var3.method3913();
               var5 = var3.readInt();
               Varps.field2763[var16] = var5;
               if (Varps.field2762[var16] != var5) {
                  Varps.field2762[var16] = var5;
               }

               MusicPatch.method4735(var16);
               field2096[++field2273 - 1 & 31] = var16;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2036 == var1.serverPacket0) {
               var16 = var3.method3950();
               var5 = var3.method3949();
               var18 = var3.method4106();
               var56 = WorldMapSection3.method1148(var18);
               var56.field2644 = var16 + (var5 << 16);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2006 == var1.serverPacket0) {
               class162.method3075(class158.field1734);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2030 == var1.serverPacket0) {
               var16 = var3.method3934();
               var5 = var3.method3914();
               var6 = WorldMapSection3.method1148(var5);
               if (var6.modelType != 2 || var16 != var6.modelId) {
                  var6.modelType = 2;
                  var6.modelId = var16;
                  WorldMapSection1.method506(var6);
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2002 == var1.serverPacket0) {
               var16 = var3.readInt();
               var5 = var3.method3913();
               if (var5 == 65535) {
                  var5 = -1;
               }

               var18 = var3.method3914();
               var56 = WorldMapSection3.method1148(var16);
               ItemDefinition var58;
               if (!var56.isIf3) {
                  if (var5 == -1) {
                     var56.modelType = 0;
                     var1.serverPacket0 = null;
                     return true;
                  }

                  var58 = Varcs.getItemDefinition(var5);
                  var56.modelType = 4;
                  var56.modelId = var5;
                  var56.modelAngleX = var58.xan2d;
                  var56.modelAngleY = var58.yan2d;
                  var56.modelZoom = var58.zoom2d * 100 / var18;
                  WorldMapSection1.method506(var56);
               } else {
                  var56.itemId = var5;
                  var56.itemQuantity = var18;
                  var58 = Varcs.getItemDefinition(var5);
                  var56.modelAngleX = var58.xan2d;
                  var56.modelAngleY = var58.yan2d;
                  var56.modelAngleZ = var58.zan2d;
                  var56.modelOffsetX = var58.offsetX2d;
                  var56.modelOffsetY = var58.offsetY2d;
                  var56.modelZoom = var58.zoom2d;
                  if (var58.isStackable == 1) {
                     var56.field2718 = 1;
                  } else {
                     var56.field2718 = 2;
                  }

                  if (var56.field2643 > 0) {
                     var56.modelZoom = var56.modelZoom * 32 / var56.field2643;
                  } else if (var56.rawWidth > 0) {
                     var56.modelZoom = var56.modelZoom * 32 / var56.rawWidth;
                  }

                  WorldMapSection1.method506(var56);
               }

               var1.serverPacket0 = null;
               return true;
            }

            String var40;
            boolean var43;
            if (ServerPacket.field2065 == var1.serverPacket0) {
               var16 = var3.method3925();
               var43 = var3.readUnsignedByte() == 1;
               var40 = "";
               boolean var45 = false;
               if (var43) {
                  var40 = var3.readStringCp1252NullTerminated();
                  if (ServerPacket.field2028.method766(new Username(var40, field2363))) {
                     var45 = true;
                  }
               }

               String var57 = var3.readStringCp1252NullTerminated();
               if (!var45) {
                  Message.set(var16, var40, var57);
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2044 == var1.serverPacket0) {
               field2332 = true;
               ClientPreferences.field406 = var3.readUnsignedByte();
               UserComparator8.field1680 = var3.readUnsignedByte();
               class103.field1124 = var3.method3913();
               World.field362 = var3.readUnsignedByte();
               class252.field3263 = var3.readUnsignedByte();
               if (class252.field3263 >= 100) {
                  var16 = ClientPreferences.field406 * 128 + 64;
                  var5 = UserComparator8.field1680 * 128 + 64;
                  var18 = MilliClock.method2923(var16, var5, class31.field363) - class103.field1124;
                  var7 = var16 - class178.field1983;
                  var8 = var18 - Buffer.field2445;
                  var9 = var5 - Tiles.field219;
                  var10 = (int)Math.sqrt((double)(var7 * var7 + var9 * var9));
                  ScriptEvent.field547 = (int)(Math.atan2((double)var8, (double)var10) * 325.949D) & 2047;
                  WorldMapSectionType.field1062 = (int)(Math.atan2((double)var7, (double)var9) * -325.949D) & 2047;
                  if (ScriptEvent.field547 < 128) {
                     ScriptEvent.field547 = 128;
                  }

                  if (ScriptEvent.field547 > 383) {
                     ScriptEvent.field547 = 383;
                  }
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field1998 == var1.serverPacket0) {
               var16 = var3.method3914();
               var5 = var3.method3934();
               var6 = WorldMapSection3.method1148(var16);
               if (var6 != null && var6.type == 0) {
                  if (var5 > var6.scrollHeight - var6.height) {
                     var5 = var6.scrollHeight - var6.height;
                  }

                  if (var5 < 0) {
                     var5 = 0;
                  }

                  if (var5 != var6.scrollY) {
                     var6.scrollY = var5;
                     WorldMapSection1.method506(var6);
                  }
               }

               var1.serverPacket0 = null;
               return true;
            }

            String var38;
            if (ServerPacket.field2057 == var1.serverPacket0) {
               var38 = var3.readStringCp1252NullTerminated();
               Object[] var50 = new Object[var38.length() + 1];

               for(var18 = var38.length() - 1; var18 >= 0; --var18) {
                  if (var38.charAt(var18) == 's') {
                     var50[var18 + 1] = var3.readStringCp1252NullTerminated();
                  } else {
                     var50[var18 + 1] = new Integer(var3.readInt());
                  }
               }

               var50[0] = new Integer(var3.readInt());
               ScriptEvent var42 = new ScriptEvent();
               var42.args = var50;
               IndexCacheLoader.method1096(var42);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2077 == var1.serverPacket0) {
               var16 = var3.method4106();
               var49 = WorldMapSection3.method1148(var16);

               for(var18 = 0; var18 < var49.itemIds.length; ++var18) {
                  var49.itemIds[var18] = -1;
                  var49.itemIds[var18] = 0;
               }

               WorldMapSection1.method506(var49);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2075 == var1.serverPacket0) {
               field2304 = var3.readUnsignedByteNegate();
               field2173 = var3.readUnsignedByteNegate();
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2045 == var1.serverPacket0) {
               var16 = var3.method3934();
               var5 = var3.method3934();
               var18 = var3.method3934();
               var7 = var3.method3914();
               var20 = WorldMapSection3.method1148(var7);
               if (var16 != var20.modelAngleX || var18 != var20.modelAngleY || var5 != var20.modelZoom) {
                  var20.modelAngleX = var16;
                  var20.modelAngleY = var18;
                  var20.modelZoom = var5;
                  WorldMapSection1.method506(var20);
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2001 == var1.serverPacket0) {
               class162.method3075(class158.field1743);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2069 == var1.serverPacket0) {
               field2319 = var3.readUnsignedByte();
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2019 == var1.serverPacket0) {
               var16 = var3.method4106();
               var5 = var3.method3950();
               var18 = var5 >> 10 & 31;
               var7 = var5 >> 5 & 31;
               var8 = var5 & 31;
               var9 = (var7 << 11) + (var18 << 19) + (var8 << 3);
               Widget var59 = WorldMapSection3.method1148(var16);
               if (var9 != var59.color) {
                  var59.color = var9;
                  WorldMapSection1.method506(var59);
               }

               var1.serverPacket0 = null;
               return true;
            }

            long var12;
            if (ServerPacket.field2051 == var1.serverPacket0) {
               var16 = var3.index + var1.serverPacket0Length;
               var5 = var3.method3913();
               var18 = var3.method3913();
               if (var5 != field2246) {
                  field2246 = var5;
                  this.method3337(false);
                  class162.method3079(field2246);
                  class83.method1702(field2246);

                  for(var7 = 0; var7 < 100; ++var7) {
                     field2291[var7] = true;
                  }
               }

               WidgetGroupParent var21;
               for(; var18-- > 0; var21.keep = true) {
                  var7 = var3.readInt();
                  var8 = var3.method3913();
                  var9 = var3.readUnsignedByte();
                  var21 = (WidgetGroupParent)field2247.get((long)var7);
                  if (var21 != null && var8 != var21.group) {
                     class57.method1213(var21, true);
                     var21 = null;
                  }

                  if (var21 == null) {
                     var21 = class65.method1379(var7, var8, var9);
                  }
               }

               for(var19 = (WidgetGroupParent)field2247.first(); var19 != null; var19 = (WidgetGroupParent)field2247.next()) {
                  if (var19.keep) {
                     var19.keep = false;
                  } else {
                     class57.method1213(var19, true);
                  }
               }

               field2243 = new NodeHashTable(512);

               while(var3.index < var16) {
                  var7 = var3.readInt();
                  var8 = var3.method3913();
                  var9 = var3.method3913();
                  var10 = var3.readInt();

                  for(int var11 = var8; var11 <= var9; ++var11) {
                     var12 = (long)var11 + ((long)var7 << 32);
                     field2243.put(new IntegerNode(var10), var12);
                  }
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field1997 == var1.serverPacket0) {
               field2332 = false;

               for(var16 = 0; var16 < 5; ++var16) {
                  field2333[var16] = false;
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field1996 == var1.serverPacket0) {
               class162.method3075(class158.field1735);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2082 == var1.serverPacket0) {
               var16 = var3.method3934();
               field2246 = var16;
               this.method3337(false);
               class162.method3079(var16);
               class83.method1702(field2246);

               for(var5 = 0; var5 < 100; ++var5) {
                  field2291[var5] = true;
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2040 == var1.serverPacket0) {
               if (TotalQuantityComparator.field983 != null) {
                  TotalQuantityComparator.field983.method5769(var3);
               }

               SoundSystemProvider.method330();
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2017 == var1.serverPacket0) {
               WorldComparator.method1403();
               var16 = var3.method3958();
               var5 = var3.readUnsignedByteNegate();
               var18 = var3.readUnsignedByte();
               field2220[var5] = var16;
               field2218[var5] = var18;
               field2219[var5] = 1;

               for(var7 = 0; var7 < 98; ++var7) {
                  if (var16 >= Skills.field3312[var7]) {
                     field2219[var5] = var7 + 2;
                  }
               }

               field2217[++field2277 - 1 & 31] = var5;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2078 == var1.serverPacket0) {
               class285.method5571(var3.readStringCp1252NullTerminated());
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2034 == var1.serverPacket0) {
               if (var1.serverPacket0Length == 0) {
                  TotalQuantityComparator.field983 = null;
               } else {
                  if (TotalQuantityComparator.field983 == null) {
                     TotalQuantityComparator.field983 = new ClanChat(field2363, class178.field1984);
                  }

                  TotalQuantityComparator.field983.readUpdate(var3);
               }

               SoundSystemProvider.method330();
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2047 == var1.serverPacket0) {
               byte[] var39 = new byte[var1.serverPacket0Length];
               var3.method3808(var39, 0, var39.length);
               Buffer var47 = new Buffer(var39);
               var40 = var47.readStringCp1252NullTerminated();
               UrlRequest.isDone(var40, true, false);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2038 == var1.serverPacket0) {
               var16 = var3.readUnsignedByte();
               if (var3.readUnsignedByte() == 0) {
                  field2338[var16] = new GrandExchangeOffer();
                  var3.index += 18;
               } else {
                  --var3.index;
                  field2338[var16] = new GrandExchangeOffer(var3, false);
               }

               field2301 = field2271;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2024 == var1.serverPacket0) {
               ServerPacket.field2028.method767();
               field2279 = field2271;
               var1.serverPacket0 = null;
               return true;
            }

            long var22;
            long var24;
            if (ServerPacket.field2005 == var1.serverPacket0) {
               var38 = var3.readStringCp1252NullTerminated();
               var22 = (long)var3.method3913();
               var24 = (long)var3.readMedium();
               PlayerType var26 = (PlayerType)class10.method352(class57.method1226(), var3.readUnsignedByte());
               long var27 = (var22 << 32) + var24;
               boolean var29 = false;

               for(int var13 = 0; var13 < 100; ++var13) {
                  if (field2283[var13] == var27) {
                     var29 = true;
                     break;
                  }
               }

               if (ServerPacket.field2028.method766(new Username(var38, field2363))) {
                  var29 = true;
               }

               if (!var29 && field2123 == 0) {
                  field2283[field2307] = var27;
                  field2307 = (field2307 + 1) % 100;
                  String var30 = AbstractFont.method5851(class255.method5060(WorldMapLabel.method1781(var3)));
                  byte var46;
                  if (var26.isPrivileged) {
                     var46 = 7;
                  } else {
                     var46 = 3;
                  }

                  if (var26.modIcon != -1) {
                     Message.set(var46, class93.method1786(var26.modIcon) + var38, var30);
                  } else {
                     Message.set(var46, var38, var30);
                  }
               }

               var1.serverPacket0 = null;
               return true;
            }

            long var31;
            if (ServerPacket.field2049 == var1.serverPacket0) {
               var38 = var3.readStringCp1252NullTerminated();
               var22 = var3.readLong();
               var24 = (long)var3.method3913();
               var31 = (long)var3.readMedium();
               PlayerType var60 = (PlayerType)class10.method352(class57.method1226(), var3.readUnsignedByte());
               var12 = (var24 << 32) + var31;
               boolean var14 = false;

               for(int var15 = 0; var15 < 100; ++var15) {
                  if (field2283[var15] == var12) {
                     var14 = true;
                     break;
                  }
               }

               if (var60.isUser && ServerPacket.field2028.method766(new Username(var38, field2363))) {
                  var14 = true;
               }

               if (!var14 && field2123 == 0) {
                  field2283[field2307] = var12;
                  field2307 = (field2307 + 1) % 100;
                  String var34 = AbstractFont.method5851(class255.method5060(WorldMapLabel.method1781(var3)));
                  if (var60.modIcon != -1) {
                     class71.method1469(9, class93.method1786(var60.modIcon) + var38, var34, VarpDefinition.read(var22));
                  } else {
                     class71.method1469(9, var38, var34, VarpDefinition.read(var22));
                  }
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2033 == var1.serverPacket0) {
               var38 = var3.readStringCp1252NullTerminated();
               var17 = AbstractFont.method5851(class255.method5060(WorldMapLabel.method1781(var3)));
               Message.set(6, var38, var17);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2032 == var1.serverPacket0) {
               for(var16 = 0; var16 < Varps.field2762.length; ++var16) {
                  if (Varps.field2763[var16] != Varps.field2762[var16]) {
                     Varps.field2762[var16] = Varps.field2763[var16];
                     MusicPatch.method4735(var16);
                     field2096[++field2273 - 1 & 31] = var16;
                  }
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2000 == var1.serverPacket0) {
               var16 = var3.readInt();
               if (var16 != field2102) {
                  field2102 = var16;
                  WorldMapLabelSize.method1317();
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2011 == var1.serverPacket0) {
               var51 = var3.readBoolean();
               if (var51) {
                  if (UserComparator9.field1598 == null) {
                     UserComparator9.field1598 = new class252();
                  }
               } else {
                  UserComparator9.field1598 = null;
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2064 == var1.serverPacket0) {
               var16 = var3.readInt();
               var5 = var3.readInt();
               var18 = GzipDecompressor.method3212();
               PacketBufferNode var53 = FaceNormal.method2884(ClientPacket.field1847, field2133.isaacCipher);
               var53.packetBuffer.method3938(var18);
               var53.packetBuffer.writeByte(GameShell.field71);
               var53.packetBuffer.writeIntME(var16);
               var53.packetBuffer.writeIntLE(var5);
               field2133.method1281(var53);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2061 == var1.serverPacket0) {
               var16 = var3.method4025();
               var5 = var3.method4025();
               var40 = var3.readStringCp1252NullTerminated();
               if (var5 >= 1 && var5 <= 8) {
                  if (var40.equalsIgnoreCase("null")) {
                     var40 = null;
                  }

                  field2210[var5 - 1] = var40;
                  field2211[var5 - 1] = var16 == 0;
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2058 == var1.serverPacket0) {
               byte var48 = var3.method4110();
               var5 = var3.method3950();
               Varps.field2763[var5] = var48;
               if (Varps.field2762[var5] != var48) {
                  Varps.field2762[var5] = var48;
               }

               MusicPatch.method4735(var5);
               field2096[++field2273 - 1 & 31] = var5;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2071 == var1.serverPacket0) {
               ServerPacket.field2028.method716(var3, var1.serverPacket0Length);
               field2279 = field2271;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2010 == var1.serverPacket0) {
               class162.method3075(class158.field1741);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2008 == var1.serverPacket0) {
               class162.method3075(class158.field1740);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2043 == var1.serverPacket0) {
               var16 = var3.readInt();
               var43 = var3.readUnsignedByte() == 1;
               var6 = WorldMapSection3.method1148(var16);
               if (var43 != var6.isHidden) {
                  var6.isHidden = var43;
                  WorldMapSection1.method506(var6);
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2015 == var1.serverPacket0) {
               var16 = var3.method4025();
               var5 = var3.method4106();
               var18 = var3.method3934();
               var19 = (WidgetGroupParent)field2247.get((long)var5);
               if (var19 != null) {
                  class57.method1213(var19, var18 != var19.group);
               }

               class65.method1379(var5, var18, var16);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2021 == var1.serverPacket0) {
               class162.method3075(class158.field1747);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2046 == var1.serverPacket0) {
               class79.method1621(true, var1.packetBuffer);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2067 == var1.serverPacket0) {
               field2105 = var3.method3913() * 30;
               field2128 = field2271;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2083 == var1.serverPacket0) {
               var16 = var3.readUnsignedByte();
               var5 = var3.readUnsignedByte();
               var18 = var3.readUnsignedByte();
               var7 = var3.readUnsignedByte();
               field2333[var16] = true;
               field2334[var16] = var5;
               field2335[var16] = var18;
               field2336[var16] = var7;
               field2337[var16] = 0;
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2013 == var1.serverPacket0) {
               IndexCacheLoader.method1102(true, var3);
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2063 == var1.serverPacket0) {
               OverlayDefinition.field3690 = ScriptFrame.method462(var3.readUnsignedByte());
               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2073 == var1.serverPacket0) {
               var16 = var3.method3958();
               var5 = var3.method3950();
               if (var5 == 65535) {
                  var5 = -1;
               }

               var18 = var3.method3914();
               var7 = var3.method3913();
               if (var7 == 65535) {
                  var7 = -1;
               }

               for(var8 = var7; var8 <= var5; ++var8) {
                  var31 = ((long)var18 << 32) + (long)var8;
                  Node var33 = field2243.get(var31);
                  if (var33 != null) {
                     var33.remove();
                  }

                  field2243.put(new IntegerNode(var16), var31);
               }

               var1.serverPacket0 = null;
               return true;
            }

            if (ServerPacket.field2076 == var1.serverPacket0) {
               HealthBar.field343 = var3.readUnsignedByteNegate();
               class185.field2382 = var3.readUnsignedByte();

               for(var16 = class185.field2382; var16 < class185.field2382 + 8; ++var16) {
                  for(var5 = HealthBar.field343; var5 < HealthBar.field343 + 8; ++var5) {
                     if (field2272[class31.field363][var16][var5] != null) {
                        field2272[class31.field363][var16][var5] = null;
                        class240.method4819(var16, var5);
                     }
                  }
               }

               for(class37 var37 = (class37)field2131.last(); var37 != null; var37 = (class37)field2131.previous()) {
                  if (var37.field446 >= class185.field2382 && var37.field446 < class185.field2382 + 8 && var37.field449 >= HealthBar.field343 && var37.field449 < HealthBar.field343 + 8 && var37.field458 == class31.field363) {
                     var37.field457 = 0;
                  }
               }

               var1.serverPacket0 = null;
               return true;
            }

            Projectile.setDestination("" + (var1.serverPacket0 != null ? var1.serverPacket0.id : -1) + "," + (var1.field705 != null ? var1.field705.id : -1) + "," + (var1.field699 != null ? var1.field699.id : -1) + "," + var1.serverPacket0Length, (Throwable)null);
            class39.method973();
         } catch (IOException var35) {
            class93.method1784();
         } catch (Exception var36) {
            var17 = "" + (var1.serverPacket0 != null ? var1.serverPacket0.id : -1) + "," + (var1.field705 != null ? var1.field705.id : -1) + "," + (var1.field699 != null ? var1.field699.id : -1) + "," + var1.serverPacket0Length + "," + (ObjectSound.field589.pathX[0] + class21.field230) + "," + (ObjectSound.field589.pathY[0] + class79.field902) + ",";

            for(var18 = 0; var18 < var1.serverPacket0Length && var18 < 50; ++var18) {
               var17 = var17 + var3.array[var18] + ",";
            }

            Projectile.setDestination(var17, var36);
            class39.method973();
         }

         return true;
      }
   }

   final void method3418() {
      boolean var1 = false;

      int var2;
      int var5;
      while(!var1) {
         var1 = true;

         for(var2 = 0; var2 < field2223 - 1; ++var2) {
            if (field2226[var2] < 1000 && field2226[var2 + 1] > 1000) {
               String var3 = field2229[var2];
               field2229[var2] = field2229[var2 + 1];
               field2229[var2 + 1] = var3;
               String var4 = field2359[var2];
               field2359[var2] = field2359[var2 + 1];
               field2359[var2 + 1] = var4;
               var5 = field2226[var2];
               field2226[var2] = field2226[var2 + 1];
               field2226[var2 + 1] = var5;
               var5 = field2224[var2];
               field2224[var2] = field2224[var2 + 1];
               field2224[var2 + 1] = var5;
               var5 = field2225[var2];
               field2225[var2] = field2225[var2 + 1];
               field2225[var2 + 1] = var5;
               var5 = field2227[var2];
               field2227[var2] = field2227[var2 + 1];
               field2227[var2 + 1] = var5;
               boolean var6 = field2215[var2];
               field2215[var2] = field2215[var2 + 1];
               field2215[var2 + 1] = var6;
               var1 = false;
            }
         }
      }

      if (World.field361 == null) {
         if (field2259 == null) {
            int var17;
            label318: {
               int var16 = MouseHandler.field158;
               int var9;
               int var14;
               if (field2276) {
                  int var7;
                  int var13;
                  int var18;
                  if (var16 != 1 && (WorldMapSection0.field1101 || var16 != 4)) {
                     var2 = MouseHandler.field154;
                     var13 = MouseHandler.field145 * -976212263;
                     if (var2 < NetSocket.field1951 - 10 || var2 > NetSocket.field1951 + class39.field491 + 10 || var13 < Script.field1051 - 10 || var13 > ModelData0.field1555 + Script.field1051 + 10) {
                        field2276 = false;
                        var14 = NetSocket.field1951;
                        var5 = Script.field1051;
                        var17 = class39.field491;
                        var7 = ModelData0.field1555;

                        for(var18 = 0; var18 < field2296; ++var18) {
                           if (field2262[var18] + field2206[var18] > var14 && field2206[var18] < var17 + var14 && field2295[var18] + field2297[var18] > var5 && field2295[var18] < var5 + var7) {
                              field2291[var18] = true;
                           }
                        }
                     }
                  }

                  if (var16 == 1 || !WorldMapSection0.field1101 && var16 == 4) {
                     var2 = NetSocket.field1951;
                     var13 = Script.field1051;
                     var14 = class39.field491;
                     var5 = MouseHandler.field159;
                     var17 = MouseHandler.field148;
                     var7 = -1;

                     for(var18 = 0; var18 < field2223; ++var18) {
                        var9 = var13 + (field2223 - 1 - var18) * 15 + 31;
                        if (var5 > var2 && var5 < var2 + var14 && var17 > var9 - 13 && var17 < var9 + 3) {
                           var7 = var18;
                        }
                     }

                     if (var7 != -1) {
                        class6.method187(var7);
                     }

                     field2276 = false;
                     var18 = NetSocket.field1951;
                     var9 = Script.field1051;
                     int var10 = class39.field491;
                     int var11 = ModelData0.field1555;

                     for(int var12 = 0; var12 < field2296; ++var12) {
                        if (field2206[var12] + field2262[var12] > var18 && field2206[var12] < var18 + var10 && field2297[var12] + field2295[var12] > var9 && field2295[var12] < var11 + var9) {
                           field2291[var12] = true;
                        }
                     }
                  }
               } else {
                  var2 = field2223 - 1;
                  if ((var16 == 1 || !WorldMapSection0.field1101 && var16 == 4) && var2 >= 0) {
                     var14 = field2226[var2];
                     if (var14 == 39 || var14 == 40 || var14 == 41 || var14 == 42 || var14 == 43 || var14 == 33 || var14 == 34 || var14 == 35 || var14 == 36 || var14 == 37 || var14 == 38 || var14 == 1005) {
                        var5 = field2224[var2];
                        var17 = field2225[var2];
                        Widget var15 = WorldMapSection3.method1148(var17);
                        var9 = class257.method5068(var15);
                        boolean var8 = (var9 >> 28 & 1) != 0;
                        if (var8) {
                           break label318;
                        }

                        Object var10000 = null;
                        if (ServerPacket.method3317(class257.method5068(var15))) {
                           break label318;
                        }
                     }
                  }

                  if ((var16 == 1 || !WorldMapSection0.field1101 && var16 == 4) && this.method3335()) {
                     var16 = 2;
                  }

                  if ((var16 == 1 || !WorldMapSection0.field1101 && var16 == 4) && field2223 > 0) {
                     class6.method187(var2);
                  }

                  if (var16 == 2 && field2223 > 0) {
                     this.method3704(MouseHandler.field159, MouseHandler.field148);
                  }
               }

               return;
            }

            if (World.field361 != null && !field2116 && field2223 > 0 && !this.method3335()) {
               class12.method374(field2195, field2288);
            }

            field2116 = false;
            field2199 = 0;
            if (World.field361 != null) {
               WorldMapSection1.method506(World.field361);
            }

            World.field361 = WorldMapSection3.method1148(var17);
            field2194 = var5;
            field2195 = MouseHandler.field159;
            field2288 = MouseHandler.field148;
            if (var2 >= 0) {
               WorldComparator.method1402(var2);
            }

            WorldMapSection1.method506(World.field361);
         }
      }
   }

   final boolean method3335() {
      int var1 = field2223 - 1;
      boolean var3 = field2309 == 1 && field2223 > 2;
      if (!var3) {
         boolean var4;
         if (var1 < 0) {
            var4 = false;
         } else {
            int var5 = field2226[var1];
            if (var5 >= 2000) {
               var5 -= 2000;
            }

            if (var5 == 1007) {
               var4 = true;
            } else {
               var4 = false;
            }
         }

         var3 = var4;
      }

      return var3 && !field2215[var1];
   }

   final void method3704(int var1, int var2) {
      WidgetGroupParent.method998(var1, var2);
      class243.field2904.method2248(class31.field363, var1, var2, false);
      field2276 = true;
   }

   final void method3337(boolean var1) {
      WorldMapManager.method102(field2246, FriendSystem.field379, UserComparator8.field1678, var1);
   }

   void method3661(Widget var1) {
      Widget var2 = var1.parentId == -1 ? null : WorldMapSection3.method1148(var1.parentId);
      int var3;
      int var4;
      if (var2 == null) {
         var3 = FriendSystem.field379;
         var4 = UserComparator8.field1678;
      } else {
         var3 = var2.width;
         var4 = var2.height;
      }

      GameObject.method2903(var1, var3, var4, false);
      FloorDecoration.method2556(var1, var3, var4);
   }

   final void method3434() {
      WorldMapSection1.method506(field2259);
      ++class251.field3254;
      if (field2267 && field2264) {
         int var1 = MouseHandler.field154;
         int var2 = MouseHandler.field145 * -976212263;
         var1 -= field2349;
         var2 -= field2281;
         if (var1 < field2156) {
            var1 = field2156;
         }

         if (var1 + field2259.width > field2156 + field2260.width) {
            var1 = field2156 + field2260.width - field2259.width;
         }

         if (var2 < field2266) {
            var2 = field2266;
         }

         if (var2 + field2259.height > field2266 + field2260.height) {
            var2 = field2266 + field2260.height - field2259.height;
         }

         int var3 = var1 - field2268;
         int var4 = var2 - field2269;
         int var5 = field2259.dragZoneSize;
         if (class251.field3254 > field2259.dragThreshold && (var3 > var5 || var3 < -var5 || var4 > var5 || var4 < -var5)) {
            field2270 = true;
         }

         int var6 = var1 - field2156 + field2260.scrollX;
         int var7 = var2 - field2266 + field2260.scrollY;
         ScriptEvent var8;
         if (field2259.onDrag != null && field2270) {
            var8 = new ScriptEvent();
            var8.widget = field2259;
            var8.mouseX = var6;
            var8.mouseY = var7;
            var8.args = field2259.onDrag;
            IndexCacheLoader.method1096(var8);
         }

         if (MouseHandler.field150 == 0) {
            if (field2270) {
               if (field2259.onDragComplete != null) {
                  var8 = new ScriptEvent();
                  var8.widget = field2259;
                  var8.mouseX = var6;
                  var8.mouseY = var7;
                  var8.dragTarget = field2254;
                  var8.args = field2259.onDragComplete;
                  IndexCacheLoader.method1096(var8);
               }

               if (field2254 != null && PlayerType.method4811(field2259) != null) {
                  PacketBufferNode var9 = FaceNormal.method2884(ClientPacket.field1893, field2133.isaacCipher);
                  var9.packetBuffer.method4029(field2259.childIndex);
                  var9.packetBuffer.method4029(field2254.itemId);
                  var9.packetBuffer.writeShort(field2254.childIndex);
                  var9.packetBuffer.writeIntLE(field2259.id);
                  var9.packetBuffer.writeIntME(field2254.id);
                  var9.packetBuffer.writeShort(field2259.itemId);
                  field2133.method1281(var9);
               }
            } else if (this.method3335()) {
               this.method3704(field2349 + field2268, field2269 + field2281);
            } else if (field2223 > 0) {
               class12.method374(field2349 + field2268, field2281 + field2269);
            }

            field2259 = null;
         }

      } else {
         if (class251.field3254 > 1) {
            field2259 = null;
         }

      }
   }

   public Username username() {
      return ObjectSound.field589 != null ? ObjectSound.field589.username : null;
   }

   static void method3739(ScriptEvent var0, int var1) {
      Object[] var2 = var0.args;
      Script var3;
      int var17;
      if (ModelData0.method2793(var0.field544)) {
         MilliClock.field1663 = (class17)var2[0];
         AreaDefinition var4 = Clock.mark(MilliClock.field1663.field176);
         var3 = WorldMapManager.method144(var0.field544, var4.field2883, var4.field2887);
      } else {
         var17 = ((Integer)var2[0]).intValue();
         var3 = class71.method1464(var17);
      }

      if (var3 != null) {
         class31.field364 = 0;
         Interpreter.field469 = 0;
         var17 = -1;
         int[] var5 = var3.opcodes;
         int[] var6 = var3.intOperands;
         byte var7 = -1;
         Interpreter.field480 = 0;
         Interpreter.field475 = false;

         try {
            int var10;
            try {
               Interpreter.field474 = new int[var3.localIntCount];
               int var8 = 0;
               Interpreter.field464 = new String[var3.localStringCount];
               int var9 = 0;

               int var11;
               String var18;
               for(var10 = 1; var10 < var2.length; ++var10) {
                  if (var2[var10] instanceof Integer) {
                     var11 = ((Integer)var2[var10]).intValue();
                     if (var11 == -2147483647) {
                        var11 = var0.mouseX;
                     }

                     if (var11 == -2147483646) {
                        var11 = var0.mouseY;
                     }

                     if (var11 == -2147483645) {
                        var11 = var0.widget != null ? var0.widget.id : -1;
                     }

                     if (var11 == -2147483644) {
                        var11 = var0.opIndex;
                     }

                     if (var11 == -2147483643) {
                        var11 = var0.widget != null ? var0.widget.childIndex : -1;
                     }

                     if (var11 == -2147483642) {
                        var11 = var0.dragTarget != null ? var0.dragTarget.id : -1;
                     }

                     if (var11 == -2147483641) {
                        var11 = var0.dragTarget != null ? var0.dragTarget.childIndex : -1;
                     }

                     if (var11 == -2147483640) {
                        var11 = var0.keyTyped;
                     }

                     if (var11 == -2147483639) {
                        var11 = var0.keyPressed;
                     }

                     Interpreter.field474[var8++] = var11;
                  } else if (var2[var10] instanceof String) {
                     var18 = (String)var2[var10];
                     if (var18.equals("event_opbase")) {
                        var18 = var0.targetName;
                     }

                     Interpreter.field464[var9++] = var18;
                  }
               }

               var10 = 0;
               Interpreter.field472 = var0.field543;

               while(true) {
                  ++var10;
                  if (var10 > var1) {
                     throw new RuntimeException();
                  }

                  ++var17;
                  int var29 = var5[var17];
                  int var20;
                  if (var29 >= 100) {
                     boolean var33;
                     if (var3.intOperands[var17] == 1) {
                        var33 = true;
                     } else {
                        var33 = false;
                     }

                     var20 = UserComparator9.method2852(var29, var3, var33);
                     switch(var20) {
                     case 0:
                        return;
                     case 1:
                     default:
                        break;
                     case 2:
                        throw new IllegalStateException();
                     }
                  } else if (var29 == 0) {
                     Interpreter.field467[++class31.field364 - 1] = var6[var17];
                  } else if (var29 == 1) {
                     var11 = var6[var17];
                     Interpreter.field467[++class31.field364 - 1] = Varps.field2762[var11];
                  } else if (var29 == 2) {
                     var11 = var6[var17];
                     Varps.field2762[var11] = Interpreter.field467[--class31.field364];
                     MusicPatch.method4735(var11);
                  } else if (var29 == 3) {
                     Interpreter.field462[++Interpreter.field469 - 1] = var3.stringOperands[var17];
                  } else if (var29 == 6) {
                     var17 += var6[var17];
                  } else if (var29 == 7) {
                     class31.field364 -= 2;
                     if (Interpreter.field467[class31.field364] != Interpreter.field467[class31.field364 + 1]) {
                        var17 += var6[var17];
                     }
                  } else if (var29 == 8) {
                     class31.field364 -= 2;
                     if (Interpreter.field467[class31.field364] == Interpreter.field467[class31.field364 + 1]) {
                        var17 += var6[var17];
                     }
                  } else if (var29 == 9) {
                     class31.field364 -= 2;
                     if (Interpreter.field467[class31.field364] < Interpreter.field467[class31.field364 + 1]) {
                        var17 += var6[var17];
                     }
                  } else if (var29 == 10) {
                     class31.field364 -= 2;
                     if (Interpreter.field467[class31.field364] > Interpreter.field467[class31.field364 + 1]) {
                        var17 += var6[var17];
                     }
                  } else if (var29 == 21) {
                     if (Interpreter.field480 == 0) {
                        return;
                     }

                     ScriptFrame var34 = Interpreter.field471[--Interpreter.field480];
                     var3 = var34.script;
                     var5 = var3.opcodes;
                     var6 = var3.intOperands;
                     var17 = var34.pc;
                     Interpreter.field474 = var34.intLocals;
                     Interpreter.field464 = var34.stringLocals;
                  } else if (var29 == 25) {
                     var11 = var6[var17];
                     Interpreter.field467[++class31.field364 - 1] = AbstractSoundSystem.method1697(var11);
                  } else if (var29 == 27) {
                     var11 = var6[var17];
                     SoundSystemProvider.method336(var11, Interpreter.field467[--class31.field364]);
                  } else if (var29 == 31) {
                     class31.field364 -= 2;
                     if (Interpreter.field467[class31.field364] <= Interpreter.field467[class31.field364 + 1]) {
                        var17 += var6[var17];
                     }
                  } else if (var29 == 32) {
                     class31.field364 -= 2;
                     if (Interpreter.field467[class31.field364] >= Interpreter.field467[class31.field364 + 1]) {
                        var17 += var6[var17];
                     }
                  } else if (var29 == 33) {
                     Interpreter.field467[++class31.field364 - 1] = Interpreter.field474[var6[var17]];
                  } else if (var29 == 34) {
                     Interpreter.field474[var6[var17]] = Interpreter.field467[--class31.field364];
                  } else if (var29 == 35) {
                     Interpreter.field462[++Interpreter.field469 - 1] = Interpreter.field464[var6[var17]];
                  } else if (var29 == 36) {
                     Interpreter.field464[var6[var17]] = Interpreter.field462[--Interpreter.field469];
                  } else if (var29 == 37) {
                     var11 = var6[var17];
                     Interpreter.field469 -= var11;
                     String var31 = class83.method1699(Interpreter.field462, Interpreter.field469, var11);
                     Interpreter.field462[++Interpreter.field469 - 1] = var31;
                  } else if (var29 == 38) {
                     --class31.field364;
                  } else if (var29 == 39) {
                     --Interpreter.field469;
                  } else {
                     int var15;
                     if (var29 != 40) {
                        if (var29 == 42) {
                           Interpreter.field467[++class31.field364 - 1] = class17.field181.getInt(var6[var17]);
                        } else if (var29 == 43) {
                           class17.field181.setInt(var6[var17], Interpreter.field467[--class31.field364]);
                        } else if (var29 == 44) {
                           var11 = var6[var17] >> 16;
                           var20 = var6[var17] & '\uffff';
                           int var21 = Interpreter.field467[--class31.field364];
                           if (var21 < 0 || var21 > 5000) {
                              throw new RuntimeException();
                           }

                           Interpreter.field465[var11] = var21;
                           byte var22 = -1;
                           if (var20 == 105) {
                              var22 = 0;
                           }

                           for(var15 = 0; var15 < var21; ++var15) {
                              Interpreter.field466[var11][var15] = var22;
                           }
                        } else if (var29 == 45) {
                           var11 = var6[var17];
                           var20 = Interpreter.field467[--class31.field364];
                           if (var20 < 0 || var20 >= Interpreter.field465[var11]) {
                              throw new RuntimeException();
                           }

                           Interpreter.field467[++class31.field364 - 1] = Interpreter.field466[var11][var20];
                        } else if (var29 == 46) {
                           var11 = var6[var17];
                           class31.field364 -= 2;
                           var20 = Interpreter.field467[class31.field364];
                           if (var20 < 0 || var20 >= Interpreter.field465[var11]) {
                              throw new RuntimeException();
                           }

                           Interpreter.field466[var11][var20] = Interpreter.field467[class31.field364 + 1];
                        } else if (var29 == 47) {
                           var18 = class17.field181.getString(var6[var17]);
                           if (var18 == null) {
                              var18 = "null";
                           }

                           Interpreter.field462[++Interpreter.field469 - 1] = var18;
                        } else if (var29 == 48) {
                           class17.field181.setString(var6[var17], Interpreter.field462[--Interpreter.field469]);
                        } else {
                           if (var29 != 60) {
                              throw new IllegalStateException();
                           }

                           IterableNodeHashTable var32 = var3.switches[var6[var17]];
                           IntegerNode var30 = (IntegerNode)var32.get((long)Interpreter.field467[--class31.field364]);
                           if (var30 != null) {
                              var17 += var30.integer;
                           }
                        }
                     } else {
                        var11 = var6[var17];
                        Script var12 = class71.method1464(var11);
                        int[] var13 = new int[var12.localIntCount];
                        String[] var14 = new String[var12.localStringCount];

                        for(var15 = 0; var15 < var12.intArgumentCount; ++var15) {
                           var13[var15] = Interpreter.field467[var15 + (class31.field364 - var12.intArgumentCount)];
                        }

                        for(var15 = 0; var15 < var12.stringArgumentCount; ++var15) {
                           var14[var15] = Interpreter.field462[var15 + (Interpreter.field469 - var12.stringArgumentCount)];
                        }

                        class31.field364 -= var12.intArgumentCount;
                        Interpreter.field469 -= var12.stringArgumentCount;
                        ScriptFrame var19 = new ScriptFrame();
                        var19.script = var3;
                        var19.pc = var17;
                        var19.intLocals = Interpreter.field474;
                        var19.stringLocals = Interpreter.field464;
                        Interpreter.field471[++Interpreter.field480 - 1] = var19;
                        var3 = var12;
                        var5 = var12.opcodes;
                        var6 = var12.intOperands;
                        var17 = -1;
                        Interpreter.field474 = var13;
                        Interpreter.field464 = var14;
                     }
                  }
               }
            } catch (Exception var27) {
               StringBuilder var24 = new StringBuilder(30);
               var24.append("").append(var3.key).append(" ");

               for(var10 = Interpreter.field480 - 1; var10 >= 0; --var10) {
                  var24.append("").append(Interpreter.field471[var10].script.key).append(" ");
               }

               var24.append("").append(var7);
               Projectile.setDestination(var24.toString(), var27);
            }
         } finally {
            if (Interpreter.field475) {
               Interpreter.field476 = true;
               Canvas.method360();
               Interpreter.field476 = false;
               Interpreter.field475 = false;
            }

         }
      }
   }
}
