public final class TilePaint {
   int rgb;
   int texture;
   int neColor;
   int swColor;
   boolean isFlat = true;
   int nwColor;
   int seColor;

   TilePaint(int var1, int var2, int var3, int var4, int var5, int var6, boolean var7) {
      this.swColor = var1;
      this.seColor = var2;
      this.neColor = var3;
      this.nwColor = var4;
      this.texture = var5;
      this.rgb = var6;
      this.isFlat = var7;
   }

   public static void method2436(byte[] var0) {
      Buffer var1 = new Buffer(var0);
      var1.index = var0.length - 2;
      class328.field3985 = var1.method3913();
      class328.field3982 = new int[class328.field3985];
      class328.field3984 = new int[class328.field3985];
      class328.field3987 = new int[class328.field3985];
      VarcInt.field2811 = new int[class328.field3985];
      class328.field3989 = new byte[class328.field3985][];
      var1.index = var0.length - 7 - class328.field3985 * 8;
      class328.field3983 = var1.method3913();
      class328.field3988 = var1.method3913();
      int var2 = (var1.readUnsignedByte() & 255) + 1;

      int var3;
      for(var3 = 0; var3 < class328.field3985; ++var3) {
         class328.field3982[var3] = var1.method3913();
      }

      for(var3 = 0; var3 < class328.field3985; ++var3) {
         class328.field3984[var3] = var1.method3913();
      }

      for(var3 = 0; var3 < class328.field3985; ++var3) {
         class328.field3987[var3] = var1.method3913();
      }

      for(var3 = 0; var3 < class328.field3985; ++var3) {
         VarcInt.field2811[var3] = var1.method3913();
      }

      var1.index = var0.length - 7 - class328.field3985 * 8 - (var2 - 1) * 3;
      class328.field3986 = new int[var2];

      for(var3 = 1; var3 < var2; ++var3) {
         class328.field3986[var3] = var1.readMedium();
         if (class328.field3986[var3] == 0) {
            class328.field3986[var3] = 1;
         }
      }

      var1.index = 0;

      for(var3 = 0; var3 < class328.field3985; ++var3) {
         int var4 = class328.field3987[var3];
         int var5 = VarcInt.field2811[var3];
         int var6 = var4 * var5;
         byte[] var7 = new byte[var6];
         class328.field3989[var3] = var7;
         int var8 = var1.readUnsignedByte();
         int var9;
         if (var8 == 0) {
            for(var9 = 0; var9 < var6; ++var9) {
               var7[var9] = var1.readByte();
            }
         } else if (var8 == 1) {
            for(var9 = 0; var9 < var4; ++var9) {
               for(int var10 = 0; var10 < var5; ++var10) {
                  var7[var9 + var4 * var10] = var1.readByte();
               }
            }
         }
      }

   }

   static final void method2437() {
      MouseHandler.method461();
      UnderlayDefinition.field3561.clear();
      class65.method1380();
      ObjectDefinition.field3390.clear();
      ObjectDefinition.field3394.clear();
      ObjectDefinition.field3392.clear();
      ObjectDefinition.field3410.clear();
      NpcDefinition.field3570.clear();
      NpcDefinition.field3571.clear();
      PacketWriter.method1288();
      ScriptFrame.method464();
      class192.method3889();
      VarbitDefinition.field3500.clear();
      class31.method706();
      HitSplatDefinition.field3357.clear();
      HitSplatDefinition.field3358.clear();
      HitSplatDefinition.field3362.clear();
      HealthBarDefinition.field3452.clear();
      HealthBarDefinition.field3449.clear();
      SecureRandomCallable.method1020();
      class245.method4906();
      AreaDefinition.field2884.clear();
      WidgetGroupParent.method1002();
      Widget.field2582.clear();
      Widget.field2583.clear();
      Widget.field2584.clear();
      Widget.field2585.clear();
      ((TextureProvider)Rasterizer3D.field1451).clear();
      Script.field1052.clear();
      class93.field1028.method4980();
      Canvas.field118.method4980();
      class178.field1967.method4980();
      class71.field846.method4980();
      class320.field3912.method4980();
      ServerPacket.field1995.method4980();
      class85.field966.method4980();
      RunException.field1608.method4980();
      class65.field801.method4980();
      WorldMapLabelSize.field724.method4980();
      IsaacCipher.field2480.method4980();
      UrlRequester.field1587.method4980();
   }
}
