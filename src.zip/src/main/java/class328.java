public class class328 {
   public static int[] field3984;
   public static int field3988;
   public static int field3985;
   public static int[] field3987;
   public static byte[][] field3989;
   public static int[] field3982;
   public static int field3983;
   public static int[] field3986;
}
