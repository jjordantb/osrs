import java.applet.Applet;

public class RunException extends RuntimeException {
   public static Applet field1605;
   public static String field1601;
   static IndexCache field1608;
   String string;
   Throwable throwable;

   RunException(Throwable var1, String var2) {
      this.string = var2;
      this.throwable = var1;
   }

   static int method2855(int var0, int var1) {
      long var2 = (long)((var0 << 16) + var1);
      return class205.field2491 != null && var2 == class205.field2491.key ? NetCache.field2841.index * 99 / (NetCache.field2841.array.length - class205.field2491.padding) + 1 : 0;
   }
}
