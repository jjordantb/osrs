public class class255 implements Enumerated {
   static final class255 field3305 = new class255(20, 2);
   static final class255 field3292 = new class255(5, 1);
   public static final class255 field3286 = new class255(9, 2);
   static final class255 field3304 = new class255(14, 2);
   public static final class255 field3298 = new class255(2, 0);
   static final class255 field3297 = new class255(19, 2);
   public static final class255 field3301 = new class255(0, 0);
   static final class255 field3302 = new class255(18, 2);
   static final class255 field3295 = new class255(8, 1);
   static final class255 field3299 = new class255(15, 2);
   static final class255 field3306 = new class255(10, 2);
   static final class255 field3291 = new class255(4, 1);
   static final class255 field3289 = new class255(13, 2);
   static final class255 field3294 = new class255(7, 1);
   static final class255 field3296 = new class255(12, 2);
   public static final class255 field3309 = new class255(3, 0);
   static final class255 field3303 = new class255(1, 0);
   static final class255 field3308 = new class255(22, 3);
   static final class255 field3287 = new class255(21, 2);
   static final class255 field3290 = new class255(17, 2);
   static final class255 field3293 = new class255(6, 1);
   static final class255 field3300 = new class255(16, 2);
   static final class255 field3288 = new class255(11, 2);
   public final int field3307;

   class255(int var1, int var2) {
      this.field3307 = var1;
   }

   public int ordinal() {
      return this.field3307;
   }

   public static String method5060(String var0) {
      int var1 = var0.length();
      char[] var2 = new char[var1];
      byte var3 = 2;

      for(int var4 = 0; var4 < var1; ++var4) {
         char var5 = var0.charAt(var4);
         if (var3 == 0) {
            var5 = Character.toLowerCase(var5);
         } else if (var3 == 2 || Character.isUpperCase(var5)) {
            char var6;
            if (var5 != 'µ' && var5 != '\u0083') {
               var6 = Character.toTitleCase(var5);
            } else {
               var6 = var5;
            }

            var5 = var6;
         }

         if (Character.isLetter(var5)) {
            var3 = 0;
         } else if (var5 != '.' && var5 != '?' && var5 != '!') {
            if (Character.isSpaceChar(var5)) {
               if (var3 != 2) {
                  var3 = 1;
               }
            } else {
               var3 = 1;
            }
         } else {
            var3 = 2;
         }

         var2[var4] = var5;
      }

      return new String(var2);
   }
}
