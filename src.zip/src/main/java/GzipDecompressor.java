import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.util.Iterator;
import java.util.zip.Inflater;

public class GzipDecompressor {
   Inflater inflater;

   public GzipDecompressor() {
      this(-1, 1000000, 1000000);
   }

   GzipDecompressor(int var1, int var2, int var3) {
   }

   public void decompress(Buffer var1, byte[] var2) {
      if (var1.array[var1.index] == 31 && var1.array[var1.index + 1] == -117) {
         if (this.inflater == null) {
            this.inflater = new Inflater(true);
         }

         try {
            this.inflater.setInput(var1.array, var1.index + 10, var1.array.length - (var1.index + 8 + 10));
            this.inflater.inflate(var2);
         } catch (Exception var4) {
            this.inflater.reset();
            throw new RuntimeException("");
         }

         this.inflater.reset();
      } else {
         throw new RuntimeException("");
      }
   }

   protected static int method3212() {
      int var0 = 0;
      if (TotalQuantityComparator.field981 == null || !TotalQuantityComparator.field981.isValid()) {
         try {
            Iterator var1 = ManagementFactory.getGarbageCollectorMXBeans().iterator();

            while(var1.hasNext()) {
               GarbageCollectorMXBean var2 = (GarbageCollectorMXBean)var1.next();
               if (var2.isValid()) {
                  TotalQuantityComparator.field981 = var2;
                  GameShell.field96 = -1L;
                  GameShell.field97 = -1L;
               }
            }
         } catch (Throwable var11) {
            ;
         }
      }

      if (TotalQuantityComparator.field981 != null) {
         long var9 = Tile.method2779();
         long var3 = TotalQuantityComparator.field981.getCollectionTime();
         if (GameShell.field97 != -1L) {
            long var5 = var3 - GameShell.field97;
            long var7 = var9 - GameShell.field96;
            if (var7 != 0L) {
               var0 = (int)(100L * var5 / var7);
            }
         }

         GameShell.field97 = var3;
         GameShell.field96 = var9;
      }

      return var0;
   }

   static final int method3219(int var0, int var1) {
      int var2 = HealthBar.method638(var0 - 1, var1 - 1) + HealthBar.method638(1 + var0, var1 - 1) + HealthBar.method638(var0 - 1, var1 + 1) + HealthBar.method638(1 + var0, 1 + var1);
      int var3 = HealthBar.method638(var0 - 1, var1) + HealthBar.method638(var0 + 1, var1) + HealthBar.method638(var0, var1 - 1) + HealthBar.method638(var0, 1 + var1);
      int var4 = HealthBar.method638(var0, var1);
      return var2 / 16 + var3 / 8 + var4 / 4;
   }

   public static void decompress(String[] var0, short[] var1, int var2, int var3) {
      if (var2 < var3) {
         int var4 = (var3 + var2) / 2;
         int var5 = var2;
         String var6 = var0[var4];
         var0[var4] = var0[var3];
         var0[var3] = var6;
         short var7 = var1[var4];
         var1[var4] = var1[var3];
         var1[var3] = var7;

         for(int var8 = var2; var8 < var3; ++var8) {
            if (var6 == null || var0[var8] != null && var0[var8].compareTo(var6) < (var8 & 1)) {
               String var9 = var0[var8];
               var0[var8] = var0[var5];
               var0[var5] = var9;
               short var10 = var1[var8];
               var1[var8] = var1[var5];
               var1[var5++] = var10;
            }
         }

         var0[var3] = var0[var5];
         var0[var5] = var6;
         var1[var3] = var1[var5];
         var1[var5] = var7;
         decompress(var0, var1, var2, var5 - 1);
         decompress(var0, var1, var5 + 1, var3);
      }

   }

   static int method3216(int var0, Script var1, boolean var2) {
      Widget var3 = WorldMapSection3.method1148(Interpreter.field467[--class31.field364]);
      if (var0 == 2500) {
         Interpreter.field467[++class31.field364 - 1] = var3.x;
         return 1;
      } else if (var0 == 2501) {
         Interpreter.field467[++class31.field364 - 1] = var3.y;
         return 1;
      } else if (var0 == 2502) {
         Interpreter.field467[++class31.field364 - 1] = var3.width;
         return 1;
      } else if (var0 == 2503) {
         Interpreter.field467[++class31.field364 - 1] = var3.height;
         return 1;
      } else if (var0 == 2504) {
         Interpreter.field467[++class31.field364 - 1] = var3.isHidden ? 1 : 0;
         return 1;
      } else if (var0 == 2505) {
         Interpreter.field467[++class31.field364 - 1] = var3.parentId;
         return 1;
      } else {
         return 2;
      }
   }
}
