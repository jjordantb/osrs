import java.io.IOException;

public class VarpDefinition extends DualNode {
   static EvictingDualNodeHashTable field2927 = new EvictingDualNodeHashTable(64);
   static AbstractIndexCache field2926;
   public static int field2925;
   public static short[][] field2929;
   public int type = 0;

   void read(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.readNext(var1, var2);
      }
   }

   void readNext(Buffer var1, int var2) {
      if (var2 == 5) {
         this.type = var1.method3913();
      }

   }

   static int method4926(int var0, Script var1, boolean var2) {
      if (var0 == 3600) {
         if (ServerPacket.field2028.field383 == 0) {
            Interpreter.field467[++class31.field364 - 1] = -2;
         } else if (ServerPacket.field2028.field383 == 1) {
            Interpreter.field467[++class31.field364 - 1] = -1;
         } else {
            Interpreter.field467[++class31.field364 - 1] = ServerPacket.field2028.friendsList.size();
         }

         return 1;
      } else {
         int var3;
         if (var0 == 3601) {
            var3 = Interpreter.field467[--class31.field364];
            if (ServerPacket.field2028.method714() && var3 >= 0 && var3 < ServerPacket.field2028.friendsList.size()) {
               Friend var8 = (Friend)ServerPacket.field2028.friendsList.get(var3);
               Interpreter.field462[++Interpreter.field469 - 1] = var8.name();
               Interpreter.field462[++Interpreter.field469 - 1] = var8.previousName();
            } else {
               Interpreter.field462[++Interpreter.field469 - 1] = "";
               Interpreter.field462[++Interpreter.field469 - 1] = "";
            }

            return 1;
         } else if (var0 == 3602) {
            var3 = Interpreter.field467[--class31.field364];
            if (ServerPacket.field2028.method714() && var3 >= 0 && var3 < ServerPacket.field2028.friendsList.size()) {
               Interpreter.field467[++class31.field364 - 1] = ((Buddy)ServerPacket.field2028.friendsList.get(var3)).world;
            } else {
               Interpreter.field467[++class31.field364 - 1] = 0;
            }

            return 1;
         } else if (var0 == 3603) {
            var3 = Interpreter.field467[--class31.field364];
            if (ServerPacket.field2028.method714() && var3 >= 0 && var3 < ServerPacket.field2028.friendsList.size()) {
               Interpreter.field467[++class31.field364 - 1] = ((Buddy)ServerPacket.field2028.friendsList.get(var3)).rank;
            } else {
               Interpreter.field467[++class31.field364 - 1] = 0;
            }

            return 1;
         } else {
            String var5;
            if (var0 == 3604) {
               var5 = Interpreter.field462[--Interpreter.field469];
               int var6 = Interpreter.field467[--class31.field364];
               class147.method2948(var5, var6);
               return 1;
            } else if (var0 == 3605) {
               var5 = Interpreter.field462[--Interpreter.field469];
               ServerPacket.field2028.method721(var5);
               return 1;
            } else if (var0 == 3606) {
               var5 = Interpreter.field462[--Interpreter.field469];
               ServerPacket.field2028.removeFriend(var5);
               return 1;
            } else if (var0 == 3607) {
               var5 = Interpreter.field462[--Interpreter.field469];
               ServerPacket.field2028.method723(var5);
               return 1;
            } else if (var0 == 3608) {
               var5 = Interpreter.field462[--Interpreter.field469];
               ServerPacket.field2028.removeIgnore(var5);
               return 1;
            } else if (var0 == 3609) {
               var5 = Interpreter.field462[--Interpreter.field469];
               var5 = Messages.method1144(var5);
               Interpreter.field467[++class31.field364 - 1] = ServerPacket.field2028.method739(new Username(var5, Client.field2363), false) ? 1 : 0;
               return 1;
            } else if (var0 == 3611) {
               if (TotalQuantityComparator.field983 != null) {
                  Interpreter.field462[++Interpreter.field469 - 1] = TotalQuantityComparator.field983.name;
               } else {
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
               }

               return 1;
            } else if (var0 == 3612) {
               if (TotalQuantityComparator.field983 != null) {
                  Interpreter.field467[++class31.field364 - 1] = TotalQuantityComparator.field983.size();
               } else {
                  Interpreter.field467[++class31.field364 - 1] = 0;
               }

               return 1;
            } else if (var0 == 3613) {
               var3 = Interpreter.field467[--class31.field364];
               if (TotalQuantityComparator.field983 != null && var3 < TotalQuantityComparator.field983.size()) {
                  Interpreter.field462[++Interpreter.field469 - 1] = TotalQuantityComparator.field983.get(var3).method5384().name();
               } else {
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
               }

               return 1;
            } else if (var0 == 3614) {
               var3 = Interpreter.field467[--class31.field364];
               if (TotalQuantityComparator.field983 != null && var3 < TotalQuantityComparator.field983.size()) {
                  Interpreter.field467[++class31.field364 - 1] = ((Buddy)TotalQuantityComparator.field983.get(var3)).method5829();
               } else {
                  Interpreter.field467[++class31.field364 - 1] = 0;
               }

               return 1;
            } else if (var0 == 3615) {
               var3 = Interpreter.field467[--class31.field364];
               if (TotalQuantityComparator.field983 != null && var3 < TotalQuantityComparator.field983.size()) {
                  Interpreter.field467[++class31.field364 - 1] = ((Buddy)TotalQuantityComparator.field983.get(var3)).rank;
               } else {
                  Interpreter.field467[++class31.field364 - 1] = 0;
               }

               return 1;
            } else if (var0 == 3616) {
               Interpreter.field467[++class31.field364 - 1] = TotalQuantityComparator.field983 != null ? TotalQuantityComparator.field983.field3758 : 0;
               return 1;
            } else if (var0 == 3617) {
               var5 = Interpreter.field462[--Interpreter.field469];
               GrandExchangeOffer.method1260(var5);
               return 1;
            } else if (var0 == 3618) {
               Interpreter.field467[++class31.field364 - 1] = TotalQuantityComparator.field983 != null ? TotalQuantityComparator.field983.field3759 : 0;
               return 1;
            } else if (var0 == 3619) {
               var5 = Interpreter.field462[--Interpreter.field469];
               HitSplatDefinition.method5129(var5);
               return 1;
            } else if (var0 == 3620) {
               SecureRandomCallable.method1011();
               return 1;
            } else if (var0 == 3621) {
               if (!ServerPacket.field2028.method714()) {
                  Interpreter.field467[++class31.field364 - 1] = -1;
               } else {
                  Interpreter.field467[++class31.field364 - 1] = ServerPacket.field2028.ignoreList.size();
               }

               return 1;
            } else if (var0 == 3622) {
               var3 = Interpreter.field467[--class31.field364];
               if (ServerPacket.field2028.method714() && var3 >= 0 && var3 < ServerPacket.field2028.ignoreList.size()) {
                  Ignored var4 = (Ignored)ServerPacket.field2028.ignoreList.get(var3);
                  Interpreter.field462[++Interpreter.field469 - 1] = var4.name();
                  Interpreter.field462[++Interpreter.field469 - 1] = var4.previousName();
               } else {
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
               }

               return 1;
            } else if (var0 == 3623) {
               var5 = Interpreter.field462[--Interpreter.field469];
               var5 = Messages.method1144(var5);
               Interpreter.field467[++class31.field364 - 1] = ServerPacket.field2028.method766(new Username(var5, Client.field2363)) ? 1 : 0;
               return 1;
            } else if (var0 == 3624) {
               var3 = Interpreter.field467[--class31.field364];
               if (TotalQuantityComparator.field983 != null && var3 < TotalQuantityComparator.field983.size() && TotalQuantityComparator.field983.get(var3).method5384().equals(ObjectSound.field589.username)) {
                  Interpreter.field467[++class31.field364 - 1] = 1;
               } else {
                  Interpreter.field467[++class31.field364 - 1] = 0;
               }

               return 1;
            } else if (var0 == 3625) {
               if (TotalQuantityComparator.field983 != null && TotalQuantityComparator.field983.owner != null) {
                  Interpreter.field462[++Interpreter.field469 - 1] = TotalQuantityComparator.field983.owner;
               } else {
                  Interpreter.field462[++Interpreter.field469 - 1] = "";
               }

               return 1;
            } else if (var0 == 3626) {
               var3 = Interpreter.field467[--class31.field364];
               if (TotalQuantityComparator.field983 != null && var3 < TotalQuantityComparator.field983.size() && ((ClanMate)TotalQuantityComparator.field983.get(var3)).method5324()) {
                  Interpreter.field467[++class31.field364 - 1] = 1;
               } else {
                  Interpreter.field467[++class31.field364 - 1] = 0;
               }

               return 1;
            } else if (var0 != 3627) {
               if (var0 == 3628) {
                  ServerPacket.field2028.friendsList.removeComparator();
                  return 1;
               } else {
                  boolean var7;
                  if (var0 == 3629) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.friendsList.addComparator(new UserComparator1(var7));
                     return 1;
                  } else if (var0 == 3630) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.friendsList.addComparator(new UserComparator2(var7));
                     return 1;
                  } else if (var0 == 3631) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.friendsList.addComparator(new UserComparator3(var7));
                     return 1;
                  } else if (var0 == 3632) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.friendsList.addComparator(new UserComparator4(var7));
                     return 1;
                  } else if (var0 == 3633) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.friendsList.addComparator(new UserComparator5(var7));
                     return 1;
                  } else if (var0 == 3634) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.friendsList.addComparator(new UserComparator6(var7));
                     return 1;
                  } else if (var0 == 3635) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.friendsList.addComparator(new UserComparator7(var7));
                     return 1;
                  } else if (var0 == 3636) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.friendsList.addComparator(new UserComparator8(var7));
                     return 1;
                  } else if (var0 == 3637) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.friendsList.addComparator(new UserComparator9(var7));
                     return 1;
                  } else if (var0 == 3638) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.friendsList.addComparator(new UserComparator10(var7));
                     return 1;
                  } else if (var0 == 3639) {
                     ServerPacket.field2028.friendsList.sort();
                     return 1;
                  } else if (var0 == 3640) {
                     ServerPacket.field2028.ignoreList.removeComparator();
                     return 1;
                  } else if (var0 == 3641) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.ignoreList.addComparator(new UserComparator1(var7));
                     return 1;
                  } else if (var0 == 3642) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.ignoreList.addComparator(new UserComparator2(var7));
                     return 1;
                  } else if (var0 == 3643) {
                     ServerPacket.field2028.ignoreList.sort();
                     return 1;
                  } else if (var0 == 3644) {
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.removeComparator();
                     }

                     return 1;
                  } else if (var0 == 3645) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.addComparator(new UserComparator1(var7));
                     }

                     return 1;
                  } else if (var0 == 3646) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.addComparator(new UserComparator2(var7));
                     }

                     return 1;
                  } else if (var0 == 3647) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.addComparator(new UserComparator3(var7));
                     }

                     return 1;
                  } else if (var0 == 3648) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.addComparator(new UserComparator4(var7));
                     }

                     return 1;
                  } else if (var0 == 3649) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.addComparator(new UserComparator5(var7));
                     }

                     return 1;
                  } else if (var0 == 3650) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.addComparator(new UserComparator6(var7));
                     }

                     return 1;
                  } else if (var0 == 3651) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.addComparator(new UserComparator7(var7));
                     }

                     return 1;
                  } else if (var0 == 3652) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.addComparator(new UserComparator8(var7));
                     }

                     return 1;
                  } else if (var0 == 3653) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.addComparator(new UserComparator9(var7));
                     }

                     return 1;
                  } else if (var0 == 3654) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.addComparator(new UserComparator10(var7));
                     }

                     return 1;
                  } else if (var0 == 3655) {
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.sort();
                     }

                     return 1;
                  } else if (var0 == 3656) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     ServerPacket.field2028.friendsList.addComparator(new class147(var7));
                     return 1;
                  } else if (var0 == 3657) {
                     var7 = Interpreter.field467[--class31.field364] == 1;
                     if (TotalQuantityComparator.field983 != null) {
                        TotalQuantityComparator.field983.addComparator(new class147(var7));
                     }

                     return 1;
                  } else {
                     return 2;
                  }
               }
            } else {
               var3 = Interpreter.field467[--class31.field364];
               if (TotalQuantityComparator.field983 != null && var3 < TotalQuantityComparator.field983.size() && ((ClanMate)TotalQuantityComparator.field983.get(var3)).method5327()) {
                  Interpreter.field467[++class31.field364 - 1] = 1;
               } else {
                  Interpreter.field467[++class31.field364 - 1] = 0;
               }

               return 1;
            }
         }
      }
   }

   public static String read(long var0) {
      if (var0 > 0L && var0 < 6582952005840035281L) {
         if (var0 % 37L == 0L) {
            return null;
         } else {
            int var2 = 0;

            for(long var3 = var0; 0L != var3; var3 /= 37L) {
               ++var2;
            }

            StringBuilder var5;
            char var8;
            for(var5 = new StringBuilder(var2); 0L != var0; var5.append(var8)) {
               long var6 = var0;
               var0 /= 37L;
               var8 = class296.field3725[(int)(var6 - 37L * var0)];
               if (var8 == '_') {
                  int var9 = var5.length() - 1;
                  var5.setCharAt(var9, Character.toUpperCase(var5.charAt(var9)));
                  var8 = ' ';
               }
            }

            var5.reverse();
            var5.setCharAt(0, Character.toUpperCase(var5.charAt(0)));
            return var5.toString();
         }
      } else {
         return null;
      }
   }

   public static void method4928(Huffman var0) {
      class303.field3768 = var0;
   }

   static void method4912(Buffer var0) {
      if (Client.field2151 != null) {
         var0.method3905(Client.field2151, 0, Client.field2151.length);
      } else {
         byte[] var2 = new byte[24];

         try {
            class178.field1985.seek(0L);
            class178.field1985.readFill(var2);

            int var3;
            for(var3 = 0; var3 < 24 && var2[var3] == 0; ++var3) {
               ;
            }

            if (var3 >= 24) {
               throw new IOException();
            }
         } catch (Exception var6) {
            for(int var4 = 0; var4 < 24; ++var4) {
               var2[var4] = -1;
            }
         }

         var0.method3905(var2, 0, var2.length);
      }
   }
}
