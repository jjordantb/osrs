public class Frames extends DualNode {
   static IndexedSprite field1635;
   static AbstractIndexCache field1632;
   Animation[] frames;

   public Frames(AbstractIndexCache var1, AbstractIndexCache var2, int var3, boolean var4) {
      NodeDeque var5 = new NodeDeque();
      int var6 = var1.method5025(var3);
      this.frames = new Animation[var6];
      int[] var7 = var1.method4975(var3);

      for(int var8 = 0; var8 < var7.length; ++var8) {
         byte[] var9 = var1.takeRecord(var3, var7[var8]);
         Skeleton var10 = null;
         int var11 = (var9[0] & 255) << 8 | var9[1] & 255;

         for(Skeleton var12 = (Skeleton)var5.last(); var12 != null; var12 = (Skeleton)var5.previous()) {
            if (var11 == var12.id) {
               var10 = var12;
               break;
            }
         }

         if (var10 == null) {
            byte[] var13 = var2.getRecord(var11, 0);
            var10 = new Skeleton(var11, var13);
            var5.addFirst(var10);
         }

         this.frames[var7[var8]] = new Animation(var9, var10);
      }

   }

   public boolean hasAlphaTransform(int var1) {
      return this.frames[var1].hasAlphaTransform;
   }
}
