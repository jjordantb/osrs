import java.util.Comparator;

public class UserComparator1 implements Comparator {
   public static int field3824;
   final boolean field3825;

   public UserComparator1(boolean var1) {
      this.field3825 = var1;
   }

   int method5963(User var1, User var2) {
      return this.field3825 ? var1.compareTo0(var2) : var2.compareTo0(var1);
   }

   public int compare(Object var1, Object var2) {
      return this.method5963((User)var1, (User)var2);
   }

   public boolean equals(Object var1) {
      return super.equals(var1);
   }
}
