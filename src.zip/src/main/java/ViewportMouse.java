public class ViewportMouse {
   static int field1504;
   public static int field1510 = 0;
   public static boolean field1506 = false;
   public static int field1508 = 0;
   public static boolean field1503 = false;
   public static int field1507 = 0;
   public static long[] field1509 = new long[1000];
   static int field1512;
}
