public class Message extends DualNode {
   static GrandExchangeEvents field553;
   public static int field561;
   TriBool isFromIgnored;
   Username senderUsername;
   int type;
   int count;
   TriBool isFromFriend;
   String text;
   String sender;
   int cycle;
   String prefix;

   Message(int var1, String var2, String var3, String var4) {
      this.isFromFriend = TriBool.field3723;
      this.isFromIgnored = TriBool.field3723;
      int var5 = ++Messages.field608 - 1;
      this.count = var5;
      this.cycle = Client.field2098;
      this.type = var1;
      this.sender = var2;
      this.method1051();
      this.prefix = var3;
      this.text = var4;
   }

   void method1048() {
      this.isFromIgnored = TriBool.field3723;
   }

   final boolean method1046() {
      if (this.isFromFriend == TriBool.field3723) {
         this.method1047();
      }

      return this.isFromFriend == TriBool.field3722;
   }

   void set(int var1, String var2, String var3, String var4) {
      int var5 = ++Messages.field608 - 1;
      this.count = var5;
      this.cycle = Client.field2098;
      this.type = var1;
      this.sender = var2;
      this.method1051();
      this.prefix = var3;
      this.text = var4;
   }

   final boolean method1043() {
      if (this.isFromIgnored == TriBool.field3723) {
         this.method1050();
      }

      return this.isFromIgnored == TriBool.field3722;
   }

   final void method1051() {
      if (this.sender != null) {
         this.senderUsername = new Username(Messages.method1144(this.sender), Client.field2363);
      } else {
         this.senderUsername = null;
      }

   }

   void method1050() {
      this.isFromIgnored = ServerPacket.field2028.ignoreList.contains(this.senderUsername) ? TriBool.field3722 : TriBool.field3721;
   }

   void method1047() {
      this.isFromFriend = ServerPacket.field2028.friendsList.contains(this.senderUsername) ? TriBool.field3722 : TriBool.field3721;
   }

   void method1053() {
      this.isFromFriend = TriBool.field3723;
   }

   static int method1054(int var0, Script var1, boolean var2) {
      Widget var3 = var2 ? class85.field961 : Interpreter.field477;
      if (var0 == 1700) {
         Interpreter.field467[++class31.field364 - 1] = var3.itemId;
         return 1;
      } else if (var0 == 1701) {
         if (var3.itemId != -1) {
            Interpreter.field467[++class31.field364 - 1] = var3.itemQuantity;
         } else {
            Interpreter.field467[++class31.field364 - 1] = 0;
         }

         return 1;
      } else if (var0 == 1702) {
         Interpreter.field467[++class31.field364 - 1] = var3.childIndex;
         return 1;
      } else {
         return 2;
      }
   }

   static void set(int var0, String var1, String var2) {
      class71.method1469(var0, var1, var2, (String)null);
   }

   static boolean method1074() {
      return Client.field2233;
   }
}
