public class TriBool {
   public static final TriBool field3721 = new TriBool();
   public static final TriBool field3723 = new TriBool();
   public static final TriBool field3722 = new TriBool();
}
