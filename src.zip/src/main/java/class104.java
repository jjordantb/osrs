public class class104 extends TaskDataNode {
   int field1135;
   int field1130;
   int field1140;
   int field1131;
   int field1137;
   int field1139;
   int field1141;
   int field1134;
   boolean field1133;
   int field1136;
   int field1138;
   int field1132;
   int field1129;
   int field1143;
   int field1142;

   class104(class88 var1, int var2, int var3, int var4) {
      super.field1557 = var1;
      this.field1139 = var1.field989;
      this.field1138 = var1.field991;
      this.field1133 = var1.field987;
      this.field1129 = var2;
      this.field1131 = var3;
      this.field1132 = var4;
      this.field1137 = 0;
      this.method2036();
   }

   class104(class88 var1, int var2, int var3) {
      super.field1557 = var1;
      this.field1139 = var1.field989;
      this.field1138 = var1.field991;
      this.field1133 = var1.field987;
      this.field1129 = var2;
      this.field1131 = var3;
      this.field1132 = 8192;
      this.field1137 = 0;
      this.method2036();
   }

   public boolean method2051() {
      return this.field1137 < 0 || this.field1137 >= ((class88)super.field1557).field988.length << 8;
   }

   public synchronized void method2048(int var1) {
      if (var1 == 0) {
         this.method2039(0);
         this.remove();
      } else if (this.field1134 == 0 && this.field1135 == 0) {
         this.field1140 = 0;
         this.field1131 = 0;
         this.field1130 = 0;
         this.remove();
      } else {
         int var2 = -this.field1130;
         if (this.field1130 > var2) {
            var2 = this.field1130;
         }

         if (-this.field1134 > var2) {
            var2 = -this.field1134;
         }

         if (this.field1134 > var2) {
            var2 = this.field1134;
         }

         if (-this.field1135 > var2) {
            var2 = -this.field1135;
         }

         if (this.field1135 > var2) {
            var2 = this.field1135;
         }

         if (var1 > var2) {
            var1 = var2;
         }

         this.field1140 = var1;
         this.field1131 = Integer.MIN_VALUE;
         this.field1141 = -this.field1130 / var1;
         this.field1142 = -this.field1134 / var1;
         this.field1143 = -this.field1135 / var1;
      }
   }

   int method2059(int[] var1, int var2, int var3, int var4, int var5) {
      while(true) {
         if (this.field1140 > 0) {
            int var6 = var2 + this.field1140;
            if (var6 > var4) {
               var6 = var4;
            }

            this.field1140 += var2;
            if (this.field1129 == -256 && (this.field1137 & 255) == 0) {
               if (class5.field52) {
                  var2 = method2173(0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1134, this.field1135, this.field1142, this.field1143, 0, var6, var3, this);
               } else {
                  var2 = method2124(((class88)super.field1557).field988, var1, this.field1137, var2, this.field1130, this.field1141, 0, var6, var3, this);
               }
            } else if (class5.field52) {
               var2 = method2076(0, 0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1134, this.field1135, this.field1142, this.field1143, 0, var6, var3, this, this.field1129, var5);
            } else {
               var2 = method2127(0, 0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1130, this.field1141, 0, var6, var3, this, this.field1129, var5);
            }

            this.field1140 -= var2;
            if (this.field1140 != 0) {
               return var2;
            }

            if (!this.method2060()) {
               continue;
            }

            return var4;
         }

         if (this.field1129 == -256 && (this.field1137 & 255) == 0) {
            if (class5.field52) {
               return method2064(0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1134, this.field1135, 0, var4, var3, this);
            }

            return method2063(((class88)super.field1557).field988, var1, this.field1137, var2, this.field1130, 0, var4, var3, this);
         }

         if (class5.field52) {
            return method2091(0, 0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1134, this.field1135, 0, var4, var3, this, this.field1129, var5);
         }

         return method2067(0, 0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1130, 0, var4, var3, this, this.field1129, var5);
      }
   }

   int method2058(int[] var1, int var2, int var3, int var4, int var5) {
      while(true) {
         if (this.field1140 > 0) {
            int var6 = var2 + this.field1140;
            if (var6 > var4) {
               var6 = var4;
            }

            this.field1140 += var2;
            if (this.field1129 == 256 && (this.field1137 & 255) == 0) {
               if (class5.field52) {
                  var2 = method2075(0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1134, this.field1135, this.field1142, this.field1143, 0, var6, var3, this);
               } else {
                  var2 = method2069(((class88)super.field1557).field988, var1, this.field1137, var2, this.field1130, this.field1141, 0, var6, var3, this);
               }
            } else if (class5.field52) {
               var2 = method2074(0, 0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1134, this.field1135, this.field1142, this.field1143, 0, var6, var3, this, this.field1129, var5);
            } else {
               var2 = method2073(0, 0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1130, this.field1141, 0, var6, var3, this, this.field1129, var5);
            }

            this.field1140 -= var2;
            if (this.field1140 != 0) {
               return var2;
            }

            if (!this.method2060()) {
               continue;
            }

            return var4;
         }

         if (this.field1129 == 256 && (this.field1137 & 255) == 0) {
            if (class5.field52) {
               return method2062(0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1134, this.field1135, 0, var4, var3, this);
            }

            return method2070(((class88)super.field1557).field988, var1, this.field1137, var2, this.field1130, 0, var4, var3, this);
         }

         if (class5.field52) {
            return method2136(0, 0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1134, this.field1135, 0, var4, var3, this, this.field1129, var5);
         }

         return method2065(0, 0, ((class88)super.field1557).field988, var1, this.field1137, var2, this.field1130, 0, var4, var3, this, this.field1129, var5);
      }
   }

   public boolean method2052() {
      return this.field1140 != 0;
   }

   public synchronized void method2046(int var1) {
      if (this.field1129 < 0) {
         this.field1129 = -var1;
      } else {
         this.field1129 = var1;
      }

   }

   boolean method2060() {
      int var1 = this.field1131;
      int var2;
      int var3;
      if (var1 == Integer.MIN_VALUE) {
         var3 = 0;
         var2 = 0;
         var1 = 0;
      } else {
         var2 = method2151(var1, this.field1132);
         var3 = method2107(var1, this.field1132);
      }

      if (var1 == this.field1130 && var2 == this.field1134 && var3 == this.field1135) {
         if (this.field1131 == Integer.MIN_VALUE) {
            this.field1131 = 0;
            this.field1135 = 0;
            this.field1134 = 0;
            this.field1130 = 0;
            this.remove();
            return true;
         } else {
            this.method2036();
            return false;
         }
      } else {
         if (this.field1130 < var1) {
            this.field1141 = 1;
            this.field1140 = var1 - this.field1130;
         } else if (this.field1130 > var1) {
            this.field1141 = -1;
            this.field1140 = this.field1130 - var1;
         } else {
            this.field1141 = 0;
         }

         if (this.field1134 < var2) {
            this.field1142 = 1;
            if (this.field1140 == 0 || this.field1140 > var2 - this.field1134) {
               this.field1140 = var2 - this.field1134;
            }
         } else if (this.field1134 > var2) {
            this.field1142 = -1;
            if (this.field1140 == 0 || this.field1140 > this.field1134 - var2) {
               this.field1140 = this.field1134 - var2;
            }
         } else {
            this.field1142 = 0;
         }

         if (this.field1135 < var3) {
            this.field1143 = 1;
            if (this.field1140 == 0 || this.field1140 > var3 - this.field1135) {
               this.field1140 = var3 - this.field1135;
            }
         } else if (this.field1135 > var3) {
            this.field1143 = -1;
            if (this.field1140 == 0 || this.field1140 > this.field1135 - var3) {
               this.field1140 = this.field1135 - var3;
            }
         } else {
            this.field1143 = 0;
         }

         return false;
      }
   }

   int vmethod2806() {
      int var1 = this.field1130 * 3 >> 6;
      var1 = (var1 ^ var1 >> 31) + (var1 >>> 31);
      if (this.field1136 == 0) {
         var1 -= var1 * this.field1137 / (((class88)super.field1557).field988.length << 8);
      } else if (this.field1136 >= 0) {
         var1 -= var1 * this.field1139 / ((class88)super.field1557).field988.length;
      }

      return var1 > 255 ? 255 : var1;
   }

   public synchronized int method2032() {
      return this.field1129 < 0 ? -this.field1129 : this.field1129;
   }

   public synchronized int method2041() {
      return this.field1131 == Integer.MIN_VALUE ? 0 : this.field1131;
   }

   void method2036() {
      this.field1130 = this.field1131;
      this.field1134 = method2151(this.field1131, this.field1132);
      this.field1135 = method2107(this.field1131, this.field1132);
   }

   public synchronized void vmethod4652(int[] var1, int var2, int var3) {
      if (this.field1131 == 0 && this.field1140 == 0) {
         this.vmethod4633(var3);
      } else {
         class88 var4 = (class88)super.field1557;
         int var5 = this.field1139 << 8;
         int var6 = this.field1138 << 8;
         int var7 = var4.field988.length << 8;
         int var8 = var6 - var5;
         if (var8 <= 0) {
            this.field1136 = 0;
         }

         int var9 = var2;
         var3 += var2;
         if (this.field1137 < 0) {
            if (this.field1129 <= 0) {
               this.method2183();
               this.remove();
               return;
            }

            this.field1137 = 0;
         }

         if (this.field1137 >= var7) {
            if (this.field1129 >= 0) {
               this.method2183();
               this.remove();
               return;
            }

            this.field1137 = var7 - 1;
         }

         if (this.field1136 < 0) {
            if (this.field1133) {
               if (this.field1129 < 0) {
                  var9 = this.method2059(var1, var2, var5, var3, var4.field988[this.field1139]);
                  if (this.field1137 >= var5) {
                     return;
                  }

                  this.field1137 = var5 + var5 - 1 - this.field1137;
                  this.field1129 = -this.field1129;
               }

               while(true) {
                  var9 = this.method2058(var1, var9, var6, var3, var4.field988[this.field1138 - 1]);
                  if (this.field1137 < var6) {
                     return;
                  }

                  this.field1137 = var6 + var6 - 1 - this.field1137;
                  this.field1129 = -this.field1129;
                  var9 = this.method2059(var1, var9, var5, var3, var4.field988[this.field1139]);
                  if (this.field1137 >= var5) {
                     return;
                  }

                  this.field1137 = var5 + var5 - 1 - this.field1137;
                  this.field1129 = -this.field1129;
               }
            } else if (this.field1129 < 0) {
               while(true) {
                  var9 = this.method2059(var1, var9, var5, var3, var4.field988[this.field1138 - 1]);
                  if (this.field1137 >= var5) {
                     return;
                  }

                  this.field1137 = var6 - 1 - (var6 - 1 - this.field1137) % var8;
               }
            } else {
               while(true) {
                  var9 = this.method2058(var1, var9, var6, var3, var4.field988[this.field1139]);
                  if (this.field1137 < var6) {
                     return;
                  }

                  this.field1137 = var5 + (this.field1137 - var5) % var8;
               }
            }
         } else {
            if (this.field1136 > 0) {
               if (this.field1133) {
                  label158: {
                     if (this.field1129 < 0) {
                        var9 = this.method2059(var1, var2, var5, var3, var4.field988[this.field1139]);
                        if (this.field1137 >= var5) {
                           return;
                        }

                        this.field1137 = var5 + var5 - 1 - this.field1137;
                        this.field1129 = -this.field1129;
                        if (--this.field1136 == 0) {
                           break label158;
                        }
                     }

                     do {
                        var9 = this.method2058(var1, var9, var6, var3, var4.field988[this.field1138 - 1]);
                        if (this.field1137 < var6) {
                           return;
                        }

                        this.field1137 = var6 + var6 - 1 - this.field1137;
                        this.field1129 = -this.field1129;
                        if (--this.field1136 == 0) {
                           break;
                        }

                        var9 = this.method2059(var1, var9, var5, var3, var4.field988[this.field1139]);
                        if (this.field1137 >= var5) {
                           return;
                        }

                        this.field1137 = var5 + var5 - 1 - this.field1137;
                        this.field1129 = -this.field1129;
                     } while(--this.field1136 != 0);
                  }
               } else {
                  int var10;
                  if (this.field1129 < 0) {
                     while(true) {
                        var9 = this.method2059(var1, var9, var5, var3, var4.field988[this.field1138 - 1]);
                        if (this.field1137 >= var5) {
                           return;
                        }

                        var10 = (var6 - 1 - this.field1137) / var8;
                        if (var10 >= this.field1136) {
                           this.field1137 += var8 * this.field1136;
                           this.field1136 = 0;
                           break;
                        }

                        this.field1137 += var8 * var10;
                        this.field1136 -= var10;
                     }
                  } else {
                     while(true) {
                        var9 = this.method2058(var1, var9, var6, var3, var4.field988[this.field1139]);
                        if (this.field1137 < var6) {
                           return;
                        }

                        var10 = (this.field1137 - var5) / var8;
                        if (var10 >= this.field1136) {
                           this.field1137 -= var8 * this.field1136;
                           this.field1136 = 0;
                           break;
                        }

                        this.field1137 -= var8 * var10;
                        this.field1136 -= var10;
                     }
                  }
               }
            }

            if (this.field1129 < 0) {
               this.method2059(var1, var9, 0, var3, 0);
               if (this.field1137 < 0) {
                  this.field1137 = -1;
                  this.method2183();
                  this.remove();
               }
            } else {
               this.method2058(var1, var9, var7, var3, 0);
               if (this.field1137 >= var7) {
                  this.field1137 = var7;
                  this.method2183();
                  this.remove();
               }
            }

         }
      }
   }

   synchronized void method2178(int var1, int var2) {
      this.field1131 = var1;
      this.field1132 = var2;
      this.field1140 = 0;
      this.method2036();
   }

   synchronized void method2039(int var1) {
      this.method2178(var1, this.method2042());
   }

   protected TaskDataNode vmethod4628() {
      return null;
   }

   public synchronized void method2037(int var1) {
      this.field1136 = var1;
   }

   public synchronized void method2043(int var1) {
      int var2 = ((class88)super.field1557).field988.length << 8;
      if (var1 < -1) {
         var1 = -1;
      }

      if (var1 > var2) {
         var1 = var2;
      }

      this.field1137 = var1;
   }

   protected int vmethod4641() {
      return this.field1131 == 0 && this.field1140 == 0 ? 0 : 1;
   }

   public synchronized void method2047(int var1, int var2, int var3) {
      if (var1 == 0) {
         this.method2178(var2, var3);
      } else {
         int var4 = method2151(var2, var3);
         int var5 = method2107(var2, var3);
         if (var4 == this.field1134 && var5 == this.field1135) {
            this.field1140 = 0;
         } else {
            int var6 = var2 - this.field1130;
            if (this.field1130 - var2 > var6) {
               var6 = this.field1130 - var2;
            }

            if (var4 - this.field1134 > var6) {
               var6 = var4 - this.field1134;
            }

            if (this.field1134 - var4 > var6) {
               var6 = this.field1134 - var4;
            }

            if (var5 - this.field1135 > var6) {
               var6 = var5 - this.field1135;
            }

            if (this.field1135 - var5 > var6) {
               var6 = this.field1135 - var5;
            }

            if (var1 > var6) {
               var1 = var6;
            }

            this.field1140 = var1;
            this.field1131 = var2;
            this.field1132 = var3;
            this.field1141 = (var2 - this.field1130) / var1;
            this.field1142 = (var4 - this.field1134) / var1;
            this.field1143 = (var5 - this.field1135) / var1;
         }
      }
   }

   protected TaskDataNode vmethod4630() {
      return null;
   }

   public synchronized void method2044() {
      this.field1129 = (this.field1129 ^ this.field1129 >> 31) + (this.field1129 >>> 31);
      this.field1129 = -this.field1129;
   }

   public synchronized int method2042() {
      return this.field1132 < 0 ? -1 : this.field1132;
   }

   public synchronized void method2138(int var1, int var2) {
      this.method2047(var1, var2, this.method2042());
   }

   public synchronized void method2038(int var1) {
      this.method2178(var1 << 6, this.method2042());
   }

   public synchronized void vmethod4633(int var1) {
      if (this.field1140 > 0) {
         if (var1 >= this.field1140) {
            if (this.field1131 == Integer.MIN_VALUE) {
               this.field1131 = 0;
               this.field1135 = 0;
               this.field1134 = 0;
               this.field1130 = 0;
               this.remove();
               var1 = this.field1140;
            }

            this.field1140 = 0;
            this.method2036();
         } else {
            this.field1130 += this.field1141 * var1;
            this.field1134 += this.field1142 * var1;
            this.field1135 += this.field1143 * var1;
            this.field1140 -= var1;
         }
      }

      class88 var2 = (class88)super.field1557;
      int var3 = this.field1139 << 8;
      int var4 = this.field1138 << 8;
      int var5 = var2.field988.length << 8;
      int var6 = var4 - var3;
      if (var6 <= 0) {
         this.field1136 = 0;
      }

      if (this.field1137 < 0) {
         if (this.field1129 <= 0) {
            this.method2183();
            this.remove();
            return;
         }

         this.field1137 = 0;
      }

      if (this.field1137 >= var5) {
         if (this.field1129 >= 0) {
            this.method2183();
            this.remove();
            return;
         }

         this.field1137 = var5 - 1;
      }

      this.field1137 += this.field1129 * var1;
      if (this.field1136 < 0) {
         if (!this.field1133) {
            if (this.field1129 < 0) {
               if (this.field1137 >= var3) {
                  return;
               }

               this.field1137 = var4 - 1 - (var4 - 1 - this.field1137) % var6;
            } else {
               if (this.field1137 < var4) {
                  return;
               }

               this.field1137 = var3 + (this.field1137 - var3) % var6;
            }

         } else {
            if (this.field1129 < 0) {
               if (this.field1137 >= var3) {
                  return;
               }

               this.field1137 = var3 + var3 - 1 - this.field1137;
               this.field1129 = -this.field1129;
            }

            while(this.field1137 >= var4) {
               this.field1137 = var4 + var4 - 1 - this.field1137;
               this.field1129 = -this.field1129;
               if (this.field1137 >= var3) {
                  return;
               }

               this.field1137 = var3 + var3 - 1 - this.field1137;
               this.field1129 = -this.field1129;
            }

         }
      } else {
         if (this.field1136 > 0) {
            if (this.field1133) {
               label136: {
                  if (this.field1129 < 0) {
                     if (this.field1137 >= var3) {
                        return;
                     }

                     this.field1137 = var3 + var3 - 1 - this.field1137;
                     this.field1129 = -this.field1129;
                     if (--this.field1136 == 0) {
                        break label136;
                     }
                  }

                  do {
                     if (this.field1137 < var4) {
                        return;
                     }

                     this.field1137 = var4 + var4 - 1 - this.field1137;
                     this.field1129 = -this.field1129;
                     if (--this.field1136 == 0) {
                        break;
                     }

                     if (this.field1137 >= var3) {
                        return;
                     }

                     this.field1137 = var3 + var3 - 1 - this.field1137;
                     this.field1129 = -this.field1129;
                  } while(--this.field1136 != 0);
               }
            } else {
               label168: {
                  int var7;
                  if (this.field1129 < 0) {
                     if (this.field1137 >= var3) {
                        return;
                     }

                     var7 = (var4 - 1 - this.field1137) / var6;
                     if (var7 >= this.field1136) {
                        this.field1137 += var6 * this.field1136;
                        this.field1136 = 0;
                        break label168;
                     }

                     this.field1137 += var6 * var7;
                     this.field1136 -= var7;
                  } else {
                     if (this.field1137 < var4) {
                        return;
                     }

                     var7 = (this.field1137 - var3) / var6;
                     if (var7 >= this.field1136) {
                        this.field1137 -= var6 * this.field1136;
                        this.field1136 = 0;
                        break label168;
                     }

                     this.field1137 -= var6 * var7;
                     this.field1136 -= var7;
                  }

                  return;
               }
            }
         }

         if (this.field1129 < 0) {
            if (this.field1137 < 0) {
               this.field1137 = -1;
               this.method2183();
               this.remove();
            }
         } else if (this.field1137 >= var5) {
            this.field1137 = var5;
            this.method2183();
            this.remove();
         }

      }
   }

   void method2183() {
      if (this.field1140 != 0) {
         if (this.field1131 == Integer.MIN_VALUE) {
            this.field1131 = 0;
         }

         this.field1140 = 0;
         this.method2036();
      }

   }

   static int method2062(int var0, byte[] var1, int[] var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, class104 var10) {
      var3 >>= 8;
      var9 >>= 8;
      var5 <<= 2;
      var6 <<= 2;
      if ((var7 = var4 + var9 - var3) > var8) {
         var7 = var8;
      }

      var4 <<= 1;
      var7 <<= 1;

      int var10001;
      byte var11;
      for(var7 -= 6; var4 < var7; var2[var10001] += var11 * var6) {
         var11 = var1[var3++];
         var10001 = var4++;
         var2[var10001] += var11 * var5;
         var10001 = var4++;
         var2[var10001] += var11 * var6;
         var11 = var1[var3++];
         var10001 = var4++;
         var2[var10001] += var11 * var5;
         var10001 = var4++;
         var2[var10001] += var11 * var6;
         var11 = var1[var3++];
         var10001 = var4++;
         var2[var10001] += var11 * var5;
         var10001 = var4++;
         var2[var10001] += var11 * var6;
         var11 = var1[var3++];
         var10001 = var4++;
         var2[var10001] += var11 * var5;
         var10001 = var4++;
      }

      for(var7 += 6; var4 < var7; var2[var10001] += var11 * var6) {
         var11 = var1[var3++];
         var10001 = var4++;
         var2[var10001] += var11 * var5;
         var10001 = var4++;
      }

      var10.field1137 = var3 << 8;
      return var4 >> 1;
   }

   static int method2070(byte[] var0, int[] var1, int var2, int var3, int var4, int var5, int var6, int var7, class104 var8) {
      var2 >>= 8;
      var7 >>= 8;
      var4 <<= 2;
      if ((var5 = var3 + var7 - var2) > var6) {
         var5 = var6;
      }

      int var10001;
      for(var5 -= 3; var3 < var5; var1[var10001] += var0[var2++] * var4) {
         var10001 = var3++;
         var1[var10001] += var0[var2++] * var4;
         var10001 = var3++;
         var1[var10001] += var0[var2++] * var4;
         var10001 = var3++;
         var1[var10001] += var0[var2++] * var4;
         var10001 = var3++;
      }

      for(var5 += 3; var3 < var5; var1[var10001] += var0[var2++] * var4) {
         var10001 = var3++;
      }

      var8.field1137 = var2 << 8;
      return var3;
   }

   static int method2065(int var0, int var1, byte[] var2, int[] var3, int var4, int var5, int var6, int var7, int var8, int var9, class104 var10, int var11, int var12) {
      if (var11 == 0 || (var7 = var5 + (var11 + (var9 - var4) - 257) / var11) > var8) {
         var7 = var8;
      }

      byte var13;
      int var10001;
      while(var5 < var7) {
         var1 = var4 >> 8;
         var13 = var2[var1];
         var10001 = var5++;
         var3[var10001] += ((var13 << 8) + (var2[var1 + 1] - var13) * (var4 & 255)) * var6 >> 6;
         var4 += var11;
      }

      if (var11 == 0 || (var7 = var5 + (var11 + (var9 - var4) - 1) / var11) > var8) {
         var7 = var8;
      }

      for(var1 = var12; var5 < var7; var4 += var11) {
         var13 = var2[var4 >> 8];
         var10001 = var5++;
         var3[var10001] += ((var13 << 8) + (var1 - var13) * (var4 & 255)) * var6 >> 6;
      }

      var10.field1137 = var4;
      return var5;
   }

   static int method2073(int var0, int var1, byte[] var2, int[] var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, class104 var11, int var12, int var13) {
      var11.field1134 -= var11.field1142 * var5;
      var11.field1135 -= var11.field1143 * var5;
      if (var12 == 0 || (var8 = var5 + (var10 - var4 + var12 - 257) / var12) > var9) {
         var8 = var9;
      }

      byte var14;
      int var10001;
      while(var5 < var8) {
         var1 = var4 >> 8;
         var14 = var2[var1];
         var10001 = var5++;
         var3[var10001] += ((var14 << 8) + (var2[var1 + 1] - var14) * (var4 & 255)) * var6 >> 6;
         var6 += var7;
         var4 += var12;
      }

      if (var12 == 0 || (var8 = var5 + (var10 - var4 + var12 - 1) / var12) > var9) {
         var8 = var9;
      }

      for(var1 = var13; var5 < var8; var4 += var12) {
         var14 = var2[var4 >> 8];
         var10001 = var5++;
         var3[var10001] += ((var14 << 8) + (var1 - var14) * (var4 & 255)) * var6 >> 6;
         var6 += var7;
      }

      var11.field1134 += var11.field1142 * var5;
      var11.field1135 += var11.field1143 * var5;
      var11.field1130 = var6;
      var11.field1137 = var4;
      return var5;
   }

   static int method2127(int var0, int var1, byte[] var2, int[] var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, class104 var11, int var12, int var13) {
      var11.field1134 -= var11.field1142 * var5;
      var11.field1135 -= var11.field1143 * var5;
      if (var12 == 0 || (var8 = var5 + (var10 + 256 - var4 + var12) / var12) > var9) {
         var8 = var9;
      }

      int var10001;
      while(var5 < var8) {
         var1 = var4 >> 8;
         byte var14 = var2[var1 - 1];
         var10001 = var5++;
         var3[var10001] += ((var14 << 8) + (var2[var1] - var14) * (var4 & 255)) * var6 >> 6;
         var6 += var7;
         var4 += var12;
      }

      if (var12 == 0 || (var8 = var5 + (var10 - var4 + var12) / var12) > var9) {
         var8 = var9;
      }

      var0 = var13;

      for(var1 = var12; var5 < var8; var4 += var1) {
         var10001 = var5++;
         var3[var10001] += ((var0 << 8) + (var2[var4 >> 8] - var0) * (var4 & 255)) * var6 >> 6;
         var6 += var7;
      }

      var11.field1134 += var11.field1142 * var5;
      var11.field1135 += var11.field1143 * var5;
      var11.field1130 = var6;
      var11.field1137 = var4;
      return var5;
   }

   static int method2124(byte[] var0, int[] var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, class104 var9) {
      var2 >>= 8;
      var8 >>= 8;
      var4 <<= 2;
      var5 <<= 2;
      if ((var6 = var3 + var2 - (var8 - 1)) > var7) {
         var6 = var7;
      }

      var9.field1134 += var9.field1142 * (var6 - var3);
      var9.field1135 += var9.field1143 * (var6 - var3);

      int var10001;
      for(var6 -= 3; var3 < var6; var4 += var5) {
         var10001 = var3++;
         var1[var10001] += var0[var2--] * var4;
         var4 += var5;
         var10001 = var3++;
         var1[var10001] += var0[var2--] * var4;
         var4 += var5;
         var10001 = var3++;
         var1[var10001] += var0[var2--] * var4;
         var4 += var5;
         var10001 = var3++;
         var1[var10001] += var0[var2--] * var4;
      }

      for(var6 += 3; var3 < var6; var4 += var5) {
         var10001 = var3++;
         var1[var10001] += var0[var2--] * var4;
      }

      var9.field1130 = var4 >> 2;
      var9.field1137 = var2 << 8;
      return var3;
   }

   static int method2076(int var0, int var1, byte[] var2, int[] var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, class104 var13, int var14, int var15) {
      var13.field1130 -= var5 * var13.field1141;
      if (var14 == 0 || (var10 = var5 + (var12 + 256 - var4 + var14) / var14) > var11) {
         var10 = var11;
      }

      var5 <<= 1;

      int var10001;
      for(var10 <<= 1; var5 < var10; var4 += var14) {
         var1 = var4 >> 8;
         byte var16 = var2[var1 - 1];
         var0 = (var2[var1] - var16) * (var4 & 255) + (var16 << 8);
         var10001 = var5++;
         var3[var10001] += var0 * var6 >> 6;
         var6 += var8;
         var10001 = var5++;
         var3[var10001] += var0 * var7 >> 6;
         var7 += var9;
      }

      if (var14 == 0 || (var10 = (var5 >> 1) + (var12 - var4 + var14) / var14) > var11) {
         var10 = var11;
      }

      var10 <<= 1;

      for(var1 = var15; var5 < var10; var4 += var14) {
         var0 = (var1 << 8) + (var4 & 255) * (var2[var4 >> 8] - var1);
         var10001 = var5++;
         var3[var10001] += var0 * var6 >> 6;
         var6 += var8;
         var10001 = var5++;
         var3[var10001] += var0 * var7 >> 6;
         var7 += var9;
      }

      var5 >>= 1;
      var13.field1130 += var13.field1141 * var5;
      var13.field1134 = var6;
      var13.field1135 = var7;
      var13.field1137 = var4;
      return var5;
   }

   static int method2136(int var0, int var1, byte[] var2, int[] var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, class104 var11, int var12, int var13) {
      if (var12 == 0 || (var8 = var5 + (var10 - var4 + var12 - 257) / var12) > var9) {
         var8 = var9;
      }

      var5 <<= 1;

      byte var14;
      int var10001;
      for(var8 <<= 1; var5 < var8; var4 += var12) {
         var1 = var4 >> 8;
         var14 = var2[var1];
         var0 = (var14 << 8) + (var4 & 255) * (var2[var1 + 1] - var14);
         var10001 = var5++;
         var3[var10001] += var0 * var6 >> 6;
         var10001 = var5++;
         var3[var10001] += var0 * var7 >> 6;
      }

      if (var12 == 0 || (var8 = (var5 >> 1) + (var10 - var4 + var12 - 1) / var12) > var9) {
         var8 = var9;
      }

      var8 <<= 1;

      for(var1 = var13; var5 < var8; var4 += var12) {
         var14 = var2[var4 >> 8];
         var0 = (var14 << 8) + (var1 - var14) * (var4 & 255);
         var10001 = var5++;
         var3[var10001] += var0 * var6 >> 6;
         var10001 = var5++;
         var3[var10001] += var0 * var7 >> 6;
      }

      var11.field1137 = var4;
      return var5 >> 1;
   }

   static int method2173(int var0, byte[] var1, int[] var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, class104 var12) {
      var3 >>= 8;
      var11 >>= 8;
      var5 <<= 2;
      var6 <<= 2;
      var7 <<= 2;
      var8 <<= 2;
      if ((var9 = var3 + var4 - (var11 - 1)) > var10) {
         var9 = var10;
      }

      var12.field1130 += var12.field1141 * (var9 - var4);
      var4 <<= 1;
      var9 <<= 1;

      byte var13;
      int var10001;
      for(var9 -= 6; var4 < var9; var6 += var8) {
         var13 = var1[var3--];
         var10001 = var4++;
         var2[var10001] += var13 * var5;
         var5 += var7;
         var10001 = var4++;
         var2[var10001] += var13 * var6;
         var6 += var8;
         var13 = var1[var3--];
         var10001 = var4++;
         var2[var10001] += var13 * var5;
         var5 += var7;
         var10001 = var4++;
         var2[var10001] += var13 * var6;
         var6 += var8;
         var13 = var1[var3--];
         var10001 = var4++;
         var2[var10001] += var13 * var5;
         var5 += var7;
         var10001 = var4++;
         var2[var10001] += var13 * var6;
         var6 += var8;
         var13 = var1[var3--];
         var10001 = var4++;
         var2[var10001] += var13 * var5;
         var5 += var7;
         var10001 = var4++;
         var2[var10001] += var13 * var6;
      }

      for(var9 += 6; var4 < var9; var6 += var8) {
         var13 = var1[var3--];
         var10001 = var4++;
         var2[var10001] += var13 * var5;
         var5 += var7;
         var10001 = var4++;
         var2[var10001] += var13 * var6;
      }

      var12.field1134 = var5 >> 2;
      var12.field1135 = var6 >> 2;
      var12.field1137 = var3 << 8;
      return var4 >> 1;
   }

   static int method2074(int var0, int var1, byte[] var2, int[] var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, class104 var13, int var14, int var15) {
      var13.field1130 -= var5 * var13.field1141;
      if (var14 == 0 || (var10 = var5 + (var12 - var4 + var14 - 257) / var14) > var11) {
         var10 = var11;
      }

      var5 <<= 1;

      byte var16;
      int var10001;
      for(var10 <<= 1; var5 < var10; var4 += var14) {
         var1 = var4 >> 8;
         var16 = var2[var1];
         var0 = (var16 << 8) + (var4 & 255) * (var2[var1 + 1] - var16);
         var10001 = var5++;
         var3[var10001] += var0 * var6 >> 6;
         var6 += var8;
         var10001 = var5++;
         var3[var10001] += var0 * var7 >> 6;
         var7 += var9;
      }

      if (var14 == 0 || (var10 = (var5 >> 1) + (var12 - var4 + var14 - 1) / var14) > var11) {
         var10 = var11;
      }

      var10 <<= 1;

      for(var1 = var15; var5 < var10; var4 += var14) {
         var16 = var2[var4 >> 8];
         var0 = (var16 << 8) + (var1 - var16) * (var4 & 255);
         var10001 = var5++;
         var3[var10001] += var0 * var6 >> 6;
         var6 += var8;
         var10001 = var5++;
         var3[var10001] += var0 * var7 >> 6;
         var7 += var9;
      }

      var5 >>= 1;
      var13.field1130 += var13.field1141 * var5;
      var13.field1134 = var6;
      var13.field1135 = var7;
      var13.field1137 = var4;
      return var5;
   }

   static int method2067(int var0, int var1, byte[] var2, int[] var3, int var4, int var5, int var6, int var7, int var8, int var9, class104 var10, int var11, int var12) {
      if (var11 == 0 || (var7 = var5 + (var11 + (var9 + 256 - var4)) / var11) > var8) {
         var7 = var8;
      }

      int var10001;
      while(var5 < var7) {
         var1 = var4 >> 8;
         byte var13 = var2[var1 - 1];
         var10001 = var5++;
         var3[var10001] += ((var13 << 8) + (var2[var1] - var13) * (var4 & 255)) * var6 >> 6;
         var4 += var11;
      }

      if (var11 == 0 || (var7 = var5 + (var11 + (var9 - var4)) / var11) > var8) {
         var7 = var8;
      }

      var0 = var12;

      for(var1 = var11; var5 < var7; var4 += var1) {
         var10001 = var5++;
         var3[var10001] += ((var0 << 8) + (var2[var4 >> 8] - var0) * (var4 & 255)) * var6 >> 6;
      }

      var10.field1137 = var4;
      return var5;
   }

   static int method2069(byte[] var0, int[] var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, class104 var9) {
      var2 >>= 8;
      var8 >>= 8;
      var4 <<= 2;
      var5 <<= 2;
      if ((var6 = var3 + var8 - var2) > var7) {
         var6 = var7;
      }

      var9.field1134 += var9.field1142 * (var6 - var3);
      var9.field1135 += var9.field1143 * (var6 - var3);

      int var10001;
      for(var6 -= 3; var3 < var6; var4 += var5) {
         var10001 = var3++;
         var1[var10001] += var0[var2++] * var4;
         var4 += var5;
         var10001 = var3++;
         var1[var10001] += var0[var2++] * var4;
         var4 += var5;
         var10001 = var3++;
         var1[var10001] += var0[var2++] * var4;
         var4 += var5;
         var10001 = var3++;
         var1[var10001] += var0[var2++] * var4;
      }

      for(var6 += 3; var3 < var6; var4 += var5) {
         var10001 = var3++;
         var1[var10001] += var0[var2++] * var4;
      }

      var9.field1130 = var4 >> 2;
      var9.field1137 = var2 << 8;
      return var3;
   }

   static int method2063(byte[] var0, int[] var1, int var2, int var3, int var4, int var5, int var6, int var7, class104 var8) {
      var2 >>= 8;
      var7 >>= 8;
      var4 <<= 2;
      if ((var5 = var3 + var2 - (var7 - 1)) > var6) {
         var5 = var6;
      }

      int var10001;
      for(var5 -= 3; var3 < var5; var1[var10001] += var0[var2--] * var4) {
         var10001 = var3++;
         var1[var10001] += var0[var2--] * var4;
         var10001 = var3++;
         var1[var10001] += var0[var2--] * var4;
         var10001 = var3++;
         var1[var10001] += var0[var2--] * var4;
         var10001 = var3++;
      }

      for(var5 += 3; var3 < var5; var1[var10001] += var0[var2--] * var4) {
         var10001 = var3++;
      }

      var8.field1137 = var2 << 8;
      return var3;
   }

   static int method2091(int var0, int var1, byte[] var2, int[] var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, class104 var11, int var12, int var13) {
      if (var12 == 0 || (var8 = var5 + (var10 + 256 - var4 + var12) / var12) > var9) {
         var8 = var9;
      }

      var5 <<= 1;

      int var10001;
      for(var8 <<= 1; var5 < var8; var4 += var12) {
         var1 = var4 >> 8;
         byte var14 = var2[var1 - 1];
         var0 = (var2[var1] - var14) * (var4 & 255) + (var14 << 8);
         var10001 = var5++;
         var3[var10001] += var0 * var6 >> 6;
         var10001 = var5++;
         var3[var10001] += var0 * var7 >> 6;
      }

      if (var12 == 0 || (var8 = (var5 >> 1) + (var10 - var4 + var12) / var12) > var9) {
         var8 = var9;
      }

      var8 <<= 1;

      for(var1 = var13; var5 < var8; var4 += var12) {
         var0 = (var1 << 8) + (var4 & 255) * (var2[var4 >> 8] - var1);
         var10001 = var5++;
         var3[var10001] += var0 * var6 >> 6;
         var10001 = var5++;
         var3[var10001] += var0 * var7 >> 6;
      }

      var11.field1137 = var4;
      return var5 >> 1;
   }

   static int method2075(int var0, byte[] var1, int[] var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, class104 var12) {
      var3 >>= 8;
      var11 >>= 8;
      var5 <<= 2;
      var6 <<= 2;
      var7 <<= 2;
      var8 <<= 2;
      if ((var9 = var11 + var4 - var3) > var10) {
         var9 = var10;
      }

      var12.field1130 += var12.field1141 * (var9 - var4);
      var4 <<= 1;
      var9 <<= 1;

      byte var13;
      int var10001;
      for(var9 -= 6; var4 < var9; var6 += var8) {
         var13 = var1[var3++];
         var10001 = var4++;
         var2[var10001] += var13 * var5;
         var5 += var7;
         var10001 = var4++;
         var2[var10001] += var13 * var6;
         var6 += var8;
         var13 = var1[var3++];
         var10001 = var4++;
         var2[var10001] += var13 * var5;
         var5 += var7;
         var10001 = var4++;
         var2[var10001] += var13 * var6;
         var6 += var8;
         var13 = var1[var3++];
         var10001 = var4++;
         var2[var10001] += var13 * var5;
         var5 += var7;
         var10001 = var4++;
         var2[var10001] += var13 * var6;
         var6 += var8;
         var13 = var1[var3++];
         var10001 = var4++;
         var2[var10001] += var13 * var5;
         var5 += var7;
         var10001 = var4++;
         var2[var10001] += var13 * var6;
      }

      for(var9 += 6; var4 < var9; var6 += var8) {
         var13 = var1[var3++];
         var10001 = var4++;
         var2[var10001] += var13 * var5;
         var5 += var7;
         var10001 = var4++;
         var2[var10001] += var13 * var6;
      }

      var12.field1134 = var5 >> 2;
      var12.field1135 = var6 >> 2;
      var12.field1137 = var3 << 8;
      return var4 >> 1;
   }

   static int method2064(int var0, byte[] var1, int[] var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, class104 var10) {
      var3 >>= 8;
      var9 >>= 8;
      var5 <<= 2;
      var6 <<= 2;
      if ((var7 = var3 + var4 - (var9 - 1)) > var8) {
         var7 = var8;
      }

      var4 <<= 1;
      var7 <<= 1;

      int var10001;
      byte var11;
      for(var7 -= 6; var4 < var7; var2[var10001] += var11 * var6) {
         var11 = var1[var3--];
         var10001 = var4++;
         var2[var10001] += var11 * var5;
         var10001 = var4++;
         var2[var10001] += var11 * var6;
         var11 = var1[var3--];
         var10001 = var4++;
         var2[var10001] += var11 * var5;
         var10001 = var4++;
         var2[var10001] += var11 * var6;
         var11 = var1[var3--];
         var10001 = var4++;
         var2[var10001] += var11 * var5;
         var10001 = var4++;
         var2[var10001] += var11 * var6;
         var11 = var1[var3--];
         var10001 = var4++;
         var2[var10001] += var11 * var5;
         var10001 = var4++;
      }

      for(var7 += 6; var4 < var7; var2[var10001] += var11 * var6) {
         var11 = var1[var3--];
         var10001 = var4++;
         var2[var10001] += var11 * var5;
         var10001 = var4++;
      }

      var10.field1137 = var3 << 8;
      return var4 >> 1;
   }

   public static class104 method2045(class88 var0, int var1, int var2) {
      return var0.field988 != null && var0.field988.length != 0 ? new class104(var0, (int)((long)var0.field990 * 256L * (long)var1 / (long)(AbstractSoundSystem.field936 * 100)), var2 << 6) : null;
   }

   static int method2151(int var0, int var1) {
      return var1 < 0 ? var0 : (int)((double)var0 * Math.sqrt((double)(16384 - var1) * 1.220703125E-4D) + 0.5D);
   }

   public static class104 method2035(class88 var0, int var1, int var2, int var3) {
      return var0.field988 != null && var0.field988.length != 0 ? new class104(var0, var1, var2, var3) : null;
   }

   static int method2107(int var0, int var1) {
      return var1 < 0 ? -var0 : (int)((double)var0 * Math.sqrt((double)var1 * 1.220703125E-4D) + 0.5D);
   }
}
