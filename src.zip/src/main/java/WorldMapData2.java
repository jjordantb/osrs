import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

public class WorldMapData2 extends WorldMapData {
   static short[] field106;
   HashSet field108;
   HashSet field105;
   List field107;

   void method339(Buffer var1, Buffer var2, Buffer var3, int var4, boolean var5) {
      this.read(var1, var4);
      int var6 = var3.method3913();
      this.field108 = new HashSet(var6);

      int var7;
      for(var7 = 0; var7 < var6; ++var7) {
         class85 var8 = new class85();

         try {
            var8.method1724(var2, var3);
         } catch (IllegalStateException var13) {
            continue;
         }

         this.field108.add(var8);
      }

      var7 = var3.method3913();
      this.field105 = new HashSet(var7);

      for(int var11 = 0; var11 < var7; ++var11) {
         class6 var9 = new class6();

         try {
            var9.method171(var2, var3);
         } catch (IllegalStateException var12) {
            continue;
         }

         this.field105.add(var9);
      }

      this.method340(var2, var5);
   }

   void method340(Buffer var1, boolean var2) {
      this.field107 = new LinkedList();
      int var3 = var1.method3913();

      for(int var4 = 0; var4 < var3; ++var4) {
         int var5 = var1.method4040();
         TileLocation var6 = new TileLocation(var1.readInt());
         boolean var7 = var1.readUnsignedByte() == 1;
         if (var2 || !var7) {
            this.field107.add(new class73(var5, var6));
         }
      }

   }

   public static String method347(int var0, boolean var1) {
      if (var1 && var0 >= 0) {
         int var3 = var0;
         String var2;
         if (var1 && var0 >= 0) {
            int var4 = 2;

            for(int var5 = var0 / 10; var5 != 0; ++var4) {
               var5 /= 10;
            }

            char[] var6 = new char[var4];
            var6[0] = '+';

            for(int var7 = var4 - 1; var7 > 0; --var7) {
               int var8 = var3;
               var3 /= 10;
               int var9 = var8 - var3 * 10;
               if (var9 >= 10) {
                  var6[var7] = (char)(var9 + 87);
               } else {
                  var6[var7] = (char)(var9 + 48);
               }
            }

            var2 = new String(var6);
         } else {
            var2 = Integer.toString(var0, 10);
         }

         return var2;
      } else {
         return Integer.toString(var0);
      }
   }

   static final void method343(Actor var0, int var1) {
      class178.method3311(var0.x, var0.y, var1);
   }

   static final void method338(int var0, int var1) {
      if (class196.method4189(var0)) {
         WorldMapRegion.method1879(UserComparator3.field1708[var0], var1);
      }
   }
}
