import java.io.File;
import java.io.RandomAccessFile;

public class class6 extends class69 {
   static int[] field54;
   int field62;
   int field56;
   int field59;
   int field55;

   int method161() {
      return this.field56;
   }

   int method162() {
      return this.field55;
   }

   int method167() {
      return this.field59;
   }

   void method171(Buffer var1, Buffer var2) {
      int var3 = var2.readUnsignedByte();
      if (var3 != class83.field939.field941) {
         throw new IllegalStateException("");
      } else {
         super.field828 = var2.readUnsignedByte();
         super.field826 = var2.readUnsignedByte();
         super.field824 = var2.method3913();
         super.field829 = var2.method3913();
         this.field59 = var2.readUnsignedByte();
         this.field62 = var2.readUnsignedByte();
         super.field825 = var2.method3913();
         super.field827 = var2.method3913();
         this.field56 = var2.readUnsignedByte();
         this.field55 = var2.readUnsignedByte();
         super.field826 = Math.min(super.field826, 4);
         super.field830 = new short[1][64][64];
         super.field831 = new short[super.field826][64][64];
         super.field832 = new byte[super.field826][64][64];
         super.field833 = new byte[super.field826][64][64];
         super.field834 = new class93[super.field826][64][64][];
         var3 = var1.readUnsignedByte();
         if (var3 != class95.field1036.field1038) {
            throw new IllegalStateException("");
         } else {
            int var4 = var1.readUnsignedByte();
            int var5 = var1.readUnsignedByte();
            int var6 = var1.readUnsignedByte();
            int var7 = var1.readUnsignedByte();
            if (var4 == super.field825 && var5 == super.field827 && var6 == this.field56 && var7 == this.field55) {
               for(int var8 = 0; var8 < 8; ++var8) {
                  for(int var9 = 0; var9 < 8; ++var9) {
                     this.method1422(var8 + this.field56 * 8, var9 + this.field55 * 8, var1);
                  }
               }

            } else {
               throw new IllegalStateException("");
            }
         }
      }
   }

   int method160() {
      return this.field62;
   }

   boolean method158(int var1, int var2) {
      if (var1 < this.field56 * 8) {
         return false;
      } else if (var2 < this.field55 * 8) {
         return false;
      } else if (var1 >= this.field56 * 8 + 8) {
         return false;
      } else {
         return var2 < this.field55 * 8 + 8;
      }
   }

   public boolean equals(Object var1) {
      if (!(var1 instanceof class6)) {
         return false;
      } else {
         class6 var2 = (class6)var1;
         if (super.field825 == var2.field825 && super.field827 == var2.field827) {
            return var2.field56 == this.field56 && var2.field55 == this.field55;
         } else {
            return false;
         }
      }
   }

   public int hashCode() {
      return super.field825 | super.field827 << 8 | this.field56 << 16 | this.field55 << 24;
   }

   static final void method183(String var0) {
      Message.set(30, "", var0);
   }

   static File method185(String var0) {
      if (!class162.field1777) {
         throw new RuntimeException("");
      } else {
         File var1 = (File)class162.field1774.get(var0);
         if (var1 != null) {
            return var1;
         } else {
            File var2 = new File(class294.field3720, var0);
            RandomAccessFile var3 = null;

            try {
               File var4 = new File(var2.getParent());
               if (!var4.exists()) {
                  throw new RuntimeException("");
               } else {
                  var3 = new RandomAccessFile(var2, "rw");
                  int var5 = var3.read();
                  var3.seek(0L);
                  var3.write(var5);
                  var3.seek(0L);
                  var3.close();
                  class162.field1774.put(var0, var2);
                  return var2;
               }
            } catch (Exception var8) {
               try {
                  if (var3 != null) {
                     var3.close();
                     var3 = null;
                  }
               } catch (Exception var7) {
                  ;
               }

               throw new RuntimeException();
            }
         }
      }
   }

   static void method157(Player var0, int var1, int var2) {
      if (var0.sequence == var1 && var1 != -1) {
         int var3 = WorldMapCacheName.method547(var1).field3463;
         if (var3 == 1) {
            var0.sequenceFrame = 0;
            var0.sequenceFrameCycle = 0;
            var0.sequenceDelay = var2;
            var0.field313 = 0;
         }

         if (var3 == 2) {
            var0.field313 = 0;
         }
      } else if (var1 == -1 || var0.sequence == -1 || WorldMapCacheName.method547(var1).field3475 >= WorldMapCacheName.method547(var0.sequence).field3475) {
         var0.sequence = var1;
         var0.sequenceFrame = 0;
         var0.sequenceFrameCycle = 0;
         var0.sequenceDelay = var2;
         var0.field313 = 0;
         var0.field297 = var0.pathLength;
      }

   }

   static final void method164(int var0, int var1, int var2, int var3) {
      ++Client.field2184;
      EnumDefinition.method5305();
      World.method700();
      if (Client.field2212 >= 0 && Client.field2141[Client.field2212] != null) {
         Player.method845(Client.field2141[Client.field2212], false);
      }

      FloorDecoration.method2555(true);
      int var4 = Players.field951;
      int[] var5 = Players.field947;

      int var6;
      for(var6 = 0; var6 < var4; ++var6) {
         if (var5[var6] != Client.field2212 && var5[var6] != Client.field2190) {
            Player.method845(Client.field2141[var5[var6]], true);
         }
      }

      FloorDecoration.method2555(false);

      for(Projectile var28 = (Projectile) Client.field2216.last(); var28 != null; var28 = (Projectile) Client.field2216.previous()) {
         if (var28.plane == class31.field363 && Client.field2098 <= var28.cycleEnd) {
            if (Client.field2098 >= var28.cycleStart) {
               if (var28.targetIndex > 0) {
                  Npc var33 = Client.field2249[var28.targetIndex - 1];
                  if (var33 != null && var33.x >= 0 && var33.x < 13312 && var33.y >= 0 && var33.y < 13312) {
                     var28.setDestination(var33.x, var33.y, MilliClock.method2923(var33.x, var33.y, var28.plane) - var28.int5, Client.field2098);
                  }
               }

               if (var28.targetIndex < 0) {
                  var6 = -var28.targetIndex - 1;
                  Object var34;
                  if (var6 == Client.field2190) {
                     var34 = ObjectSound.field589;
                  } else {
                     var34 = Client.field2141[var6];
                  }

                  if (var34 != null && ((Actor)var34).x >= 0 && ((Actor)var34).x < 13312 && ((Actor)var34).y >= 0 && ((Actor)var34).y < 13312) {
                     var28.setDestination(((Actor)var34).x, ((Actor)var34).y, MilliClock.method2923(((Actor)var34).x, ((Actor)var34).y, var28.plane) - var28.int5, Client.field2098);
                  }
               }

               var28.advance(Client.field2148);
               class243.field2904.method2260(class31.field363, (int)var28.x, (int)var28.y, (int)var28.z, 60, var28, var28.yaw, -1L, false);
            }
         } else {
            var28.remove();
         }
      }

      for(GraphicsObject var36 = (GraphicsObject) Client.field2154.last(); var36 != null; var36 = (GraphicsObject) Client.field2154.previous()) {
         if (var36.plane == class31.field363 && !var36.isFinished) {
            if (Client.field2098 >= var36.cycleStart) {
               var36.advance(Client.field2148);
               if (var36.isFinished) {
                  var36.remove();
               } else {
                  class243.field2904.method2260(var36.plane, var36.x, var36.y, var36.height, 60, var36, 0, -1L, false);
               }
            }
         } else {
            var36.remove();
         }
      }

      TotalQuantityComparator.method1768(var0, var1, var2, var3, true);
      var0 = Client.field2100;
      var1 = Client.field2136;
      var2 = Client.field2087;
      var3 = Client.field2207;
      Rasterizer2D.method6243(var0, var1, var0 + var2, var3 + var1);
      Rasterizer3D.method2615();
      int var7;
      int var8;
      int var9;
      int var11;
      int var12;
      int var13;
      int var14;
      int var15;
      int var16;
      int var18;
      int var19;
      int var29;
      if (!Client.field2332) {
         var4 = Client.field2155;
         if (Client.field2172 / 256 > var4) {
            var4 = Client.field2172 / 256;
         }

         if (Client.field2333[4] && Client.field2335[4] + 128 > var4) {
            var4 = Client.field2335[4] + 128;
         }

         var29 = Client.field2101 & 2047;
         var6 = class71.field842;
         var7 = ViewportMouse.field1512;
         var8 = class71.field844;
         var9 = var4 * 3 + 600;
         var12 = var3 - 334;
         if (var12 < 0) {
            var12 = 0;
         } else if (var12 > 100) {
            var12 = 100;
         }

         var13 = (Client.field2341 - Client.field2340) * var12 / 100 + Client.field2340;
         var11 = var13 * var9 / 256;
         var12 = 2048 - var4 & 2047;
         var13 = 2048 - var29 & 2047;
         var14 = 0;
         var15 = 0;
         var16 = var11;
         int var17;
         if (var12 != 0) {
            var17 = Rasterizer3D.field1446[var12];
            var18 = Rasterizer3D.field1453[var12];
            var19 = var18 * var15 - var17 * var11 >> 16;
            var16 = var17 * var15 + var18 * var11 >> 16;
            var15 = var19;
         }

         if (var13 != 0) {
            var17 = Rasterizer3D.field1446[var13];
            var18 = Rasterizer3D.field1453[var13];
            var19 = var16 * var17 + var18 * var14 >> 16;
            var16 = var18 * var16 - var17 * var14 >> 16;
            var14 = var19;
         }

         class178.field1983 = var6 - var14;
         Buffer.field2445 = var7 - var15;
         Tiles.field219 = var8 - var16;
         ScriptEvent.field547 = var4;
         WorldMapSectionType.field1062 = var29;
         if (Client.field2161 == 1 && Client.field2255 >= 2 && Client.field2098 % 50 == 0 && (class71.field842 >> 7 != ObjectSound.field589.x >> 7 || class71.field844 >> 7 != ObjectSound.field589.y >> 7)) {
            var17 = ObjectSound.field589.plane;
            var18 = (class71.field842 >> 7) + class21.field230;
            var19 = (class71.field844 >> 7) + class79.field902;
            class21.method543(var18, var19, var17, true);
         }
      }

      int var10;
      if (!Client.field2332) {
         if (GameShell.field72.roofsHidden) {
            var29 = class31.field363;
         } else {
            label804: {
               var6 = 3;
               if (ScriptEvent.field547 < 310) {
                  if (Client.field2161 == 1) {
                     var7 = class71.field842 >> 7;
                     var8 = class71.field844 >> 7;
                  } else {
                     var7 = ObjectSound.field589.x >> 7;
                     var8 = ObjectSound.field589.y >> 7;
                  }

                  var9 = class178.field1983 >> 7;
                  var10 = Tiles.field219 >> 7;
                  if (var9 < 0 || var10 < 0 || var9 >= 104 || var10 >= 104) {
                     var29 = class31.field363;
                     break label804;
                  }

                  if (var7 < 0 || var8 < 0 || var7 >= 104 || var8 >= 104) {
                     var29 = class31.field363;
                     break label804;
                  }

                  if ((Tiles.field203[class31.field363][var9][var10] & 4) != 0) {
                     var6 = class31.field363;
                  }

                  if (var7 > var9) {
                     var11 = var7 - var9;
                  } else {
                     var11 = var9 - var7;
                  }

                  if (var8 > var10) {
                     var12 = var8 - var10;
                  } else {
                     var12 = var10 - var8;
                  }

                  if (var11 > var12) {
                     var13 = var12 * 65536 / var11;
                     var14 = 32768;

                     while(var9 != var7) {
                        if (var9 < var7) {
                           ++var9;
                        } else if (var9 > var7) {
                           --var9;
                        }

                        if ((Tiles.field203[class31.field363][var9][var10] & 4) != 0) {
                           var6 = class31.field363;
                        }

                        var14 += var13;
                        if (var14 >= 65536) {
                           var14 -= 65536;
                           if (var10 < var8) {
                              ++var10;
                           } else if (var10 > var8) {
                              --var10;
                           }

                           if ((Tiles.field203[class31.field363][var9][var10] & 4) != 0) {
                              var6 = class31.field363;
                           }
                        }
                     }
                  } else if (var12 > 0) {
                     var13 = var11 * 65536 / var12;
                     var14 = 32768;

                     while(var8 != var10) {
                        if (var10 < var8) {
                           ++var10;
                        } else if (var10 > var8) {
                           --var10;
                        }

                        if ((Tiles.field203[class31.field363][var9][var10] & 4) != 0) {
                           var6 = class31.field363;
                        }

                        var14 += var13;
                        if (var14 >= 65536) {
                           var14 -= 65536;
                           if (var9 < var7) {
                              ++var9;
                           } else if (var9 > var7) {
                              --var9;
                           }

                           if ((Tiles.field203[class31.field363][var9][var10] & 4) != 0) {
                              var6 = class31.field363;
                           }
                        }
                     }
                  }
               }

               if (ObjectSound.field589.x >= 0 && ObjectSound.field589.y >= 0 && ObjectSound.field589.x < 13312 && ObjectSound.field589.y < 13312) {
                  if ((Tiles.field203[class31.field363][ObjectSound.field589.x >> 7][ObjectSound.field589.y >> 7] & 4) != 0) {
                     var6 = class31.field363;
                  }

                  var29 = var6;
               } else {
                  var29 = class31.field363;
               }
            }
         }

         var4 = var29;
      } else {
         if (GameShell.field72.roofsHidden) {
            var29 = class31.field363;
         } else {
            var6 = MilliClock.method2923(class178.field1983, Tiles.field219, class31.field363);
            if (var6 - Buffer.field2445 < 800 && (Tiles.field203[class31.field363][class178.field1983 >> 7][Tiles.field219 >> 7] & 4) != 0) {
               var29 = class31.field363;
            } else {
               var29 = 3;
            }
         }

         var4 = var29;
      }

      var29 = class178.field1983;
      var6 = Buffer.field2445;
      var7 = Tiles.field219;
      var8 = ScriptEvent.field547;
      var9 = WorldMapSectionType.field1062;

      for(var10 = 0; var10 < 5; ++var10) {
         if (Client.field2333[var10]) {
            var11 = (int)(Math.random() * (double)(Client.field2334[var10] * 2 + 1) - (double) Client.field2334[var10] + Math.sin((double) Client.field2336[var10] / 100.0D * (double) Client.field2337[var10]) * (double) Client.field2335[var10]);
            if (var10 == 0) {
               class178.field1983 += var11;
            }

            if (var10 == 1) {
               Buffer.field2445 += var11;
            }

            if (var10 == 2) {
               Tiles.field219 += var11;
            }

            if (var10 == 3) {
               WorldMapSectionType.field1062 = var11 + WorldMapSectionType.field1062 & 2047;
            }

            if (var10 == 4) {
               ScriptEvent.field547 += var11;
               if (ScriptEvent.field547 < 128) {
                  ScriptEvent.field547 = 128;
               }

               if (ScriptEvent.field547 > 383) {
                  ScriptEvent.field547 = 383;
               }
            }
         }
      }

      var10 = MouseHandler.field154;
      var11 = MouseHandler.field145 * -976212263;
      if (MouseHandler.field158 != 0) {
         var10 = MouseHandler.field159;
         var11 = MouseHandler.field148;
      }

      if (var10 >= var0 && var10 < var0 + var2 && var11 >= var1 && var11 < var3 + var1) {
         var12 = var10 - var0;
         var13 = var11 - var1;
         ViewportMouse.field1507 = var12;
         ViewportMouse.field1510 = var13;
         ViewportMouse.field1506 = true;
         ViewportMouse.field1508 = 0;
         ViewportMouse.field1503 = false;
      } else {
         SoundSystemProvider.method334();
      }

      class162.method3077();
      Rasterizer2D.method6223(var0, var1, var2, var3, 0);
      class162.method3077();
      var12 = Rasterizer3D.field1440;
      Rasterizer3D.field1440 = Client.field2350;
      class243.field2904.draw(class178.field1983, Buffer.field2445, Tiles.field219, ScriptEvent.field547, WorldMapSectionType.field1062, var4);
      Rasterizer3D.field1440 = var12;
      class162.method3077();
      class243.field2904.clearTempGameObjects();
      Client.field2355 = 0;
      boolean var35 = false;
      var14 = -1;
      var15 = -1;
      var16 = Players.field951;
      int[] var30 = Players.field947;

      for(var18 = 0; var18 < var16 + Client.field2129; ++var18) {
         Object var31;
         if (var18 < var16) {
            var31 = Client.field2141[var30[var18]];
            if (var30[var18] == Client.field2212) {
               var35 = true;
               var14 = var18;
               continue;
            }

            if (var31 == ObjectSound.field589) {
               var15 = var18;
               continue;
            }
         } else {
            var31 = Client.field2249[Client.field2130[var18 - var16]];
         }

         FriendSystem.method791((Actor)var31, var18, var0, var1, var2, var3);
      }

      if (Client.field2205 && var15 != -1) {
         FriendSystem.method791(ObjectSound.field589, var15, var0, var1, var2, var3);
      }

      if (var35) {
         FriendSystem.method791(Client.field2141[Client.field2212], var14, var0, var1, var2, var3);
      }

      for(var18 = 0; var18 < Client.field2355; ++var18) {
         var19 = Client.field2175[var18];
         int var20 = Client.field2176[var18];
         int var21 = Client.field2200[var18];
         int var22 = Client.field2181[var18];
         boolean var23 = true;

         while(var23) {
            var23 = false;

            for(int var24 = 0; var24 < var18; ++var24) {
               if (var20 + 2 > Client.field2176[var24] - Client.field2181[var24] && var20 - var22 < Client.field2176[var24] + 2 && var19 - var21 < Client.field2200[var24] + Client.field2175[var24] && var21 + var19 > Client.field2175[var24] - Client.field2200[var24] && Client.field2176[var24] - Client.field2181[var24] < var20) {
                  var20 = Client.field2176[var24] - Client.field2181[var24];
                  var23 = true;
               }
            }
         }

         Client.field2095 = Client.field2175[var18];
         Client.field2346 = Client.field2176[var18] = var20;
         String var32 = Client.field2182[var18];
         if (Client.field2250 == 0) {
            int var25 = 16776960;
            if (Client.field2179[var18] < 6) {
               var25 = Client.field2302[Client.field2179[var18]];
            }

            if (Client.field2179[var18] == 6) {
               var25 = Client.field2184 % 20 < 10 ? 16711680 : 16776960;
            }

            if (Client.field2179[var18] == 7) {
               var25 = Client.field2184 % 20 < 10 ? 255 : '\uffff';
            }

            if (Client.field2179[var18] == 8) {
               var25 = Client.field2184 % 20 < 10 ? '뀀' : 8454016;
            }

            int var26;
            if (Client.field2179[var18] == 9) {
               var26 = 150 - Client.field2261[var18];
               if (var26 < 50) {
                  var25 = var26 * 1280 + 16711680;
               } else if (var26 < 100) {
                  var25 = 16776960 - (var26 - 50) * 327680;
               } else if (var26 < 150) {
                  var25 = (var26 - 100) * 5 + '\uff00';
               }
            }

            if (Client.field2179[var18] == 10) {
               var26 = 150 - Client.field2261[var18];
               if (var26 < 50) {
                  var25 = var26 * 5 + 16711680;
               } else if (var26 < 100) {
                  var25 = 16711935 - (var26 - 50) * 327680;
               } else if (var26 < 150) {
                  var25 = (var26 - 100) * 327680 + 255 - (var26 - 100) * 5;
               }
            }

            if (Client.field2179[var18] == 11) {
               var26 = 150 - Client.field2261[var18];
               if (var26 < 50) {
                  var25 = 16777215 - var26 * 327685;
               } else if (var26 < 100) {
                  var25 = (var26 - 50) * 327685 + '\uff00';
               } else if (var26 < 150) {
                  var25 = 16777215 - (var26 - 100) * 327680;
               }
            }

            if (Client.field2180[var18] == 0) {
               NetSocket.field1950.drawCentered(var32, var0 + Client.field2095, Client.field2346 + var1, var25, 0);
            }

            if (Client.field2180[var18] == 1) {
               NetSocket.field1950.drawCenteredWave(var32, var0 + Client.field2095, Client.field2346 + var1, var25, 0, Client.field2184);
            }

            if (Client.field2180[var18] == 2) {
               NetSocket.field1950.drawCenteredWave2(var32, var0 + Client.field2095, Client.field2346 + var1, var25, 0, Client.field2184);
            }

            if (Client.field2180[var18] == 3) {
               NetSocket.field1950.drawCenteredShake(var32, var0 + Client.field2095, Client.field2346 + var1, var25, 0, Client.field2184, 150 - Client.field2261[var18]);
            }

            if (Client.field2180[var18] == 4) {
               var26 = (150 - Client.field2261[var18]) * (NetSocket.field1950.stringWidth(var32) + 100) / 150;
               Rasterizer2D.method6217(var0 + Client.field2095 - 50, var1, var0 + Client.field2095 + 50, var3 + var1);
               NetSocket.field1950.draw(var32, var0 + Client.field2095 + 50 - var26, Client.field2346 + var1, var25, 0);
               Rasterizer2D.method6243(var0, var1, var0 + var2, var3 + var1);
            }

            if (Client.field2180[var18] == 5) {
               var26 = 150 - Client.field2261[var18];
               int var27 = 0;
               if (var26 < 25) {
                  var27 = var26 - 25;
               } else if (var26 > 125) {
                  var27 = var26 - 125;
               }

               Rasterizer2D.method6217(var0, Client.field2346 + var1 - NetSocket.field1950.ascent - 1, var0 + var2, Client.field2346 + var1 + 5);
               NetSocket.field1950.drawCentered(var32, var0 + Client.field2095, var27 + Client.field2346 + var1, var25, 0);
               Rasterizer2D.method6243(var0, var1, var0 + var2, var3 + var1);
            }
         } else {
            NetSocket.field1950.drawCentered(var32, var0 + Client.field2095, Client.field2346 + var1, 16776960, 0);
         }
      }

      if (Client.field2106 == 2) {
         class178.method3311((Client.field2109 - class21.field230 << 7) + Client.field2112, (Client.field2110 - class79.field902 << 7) + Client.field2198, Client.field2111 * 2);
         if (Client.field2095 > -1 && Client.field2098 % 20 < 10) {
            class21.field229[0].method6348(var0 + Client.field2095 - 12, Client.field2346 + var1 - 28);
         }
      }

      ((TextureProvider)Rasterizer3D.field1451).animate(Client.field2148);
      class73.method1484(var0, var1, var2, var3);
      class178.field1983 = var29;
      Buffer.field2445 = var6;
      Tiles.field219 = var7;
      ScriptEvent.field547 = var8;
      WorldMapSectionType.field1062 = var9;
      if (Client.field2097 && Tiles.method540(true, false) == 0) {
         Client.field2097 = false;
      }

      if (Client.field2097) {
         Rasterizer2D.method6223(var0, var1, var2, var3, 0);
         MouseRecorder.method1009("Loading - please wait.", false);
      }

   }

   static final void method187(int var0) {
      if (var0 >= 0) {
         int var1 = Client.field2224[var0];
         int var2 = Client.field2225[var0];
         int var3 = Client.field2226[var0];
         int var4 = Client.field2227[var0];
         String var5 = Client.field2359[var0];
         String var6 = Client.field2229[var0];
         WorldMapSectionType.method1828(var1, var2, var3, var4, var5, var6, MouseHandler.field159, MouseHandler.field148);
      }
   }

   static String method184(int var0) {
      if (var0 < 0) {
         return "";
      } else {
         return Client.field2229[var0].length() > 0 ? Client.field2359[var0] + " " + Client.field2229[var0] : Client.field2359[var0];
      }
   }
}
