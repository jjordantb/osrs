public class UserComparator5 extends AbstractUserComparator {
   static int field1595;
   static Sprite[] field1593;
   final boolean field1594;

   public UserComparator5(boolean var1) {
      this.field1594 = var1;
   }

   int method2839(Buddy var1, Buddy var2) {
      if (var1.world != 0) {
         if (var2.world == 0) {
            return this.field1594 ? -1 : 1;
         }
      } else if (var2.world != 0) {
         return this.field1594 ? 1 : -1;
      }

      return this.method5349(var1, var2);
   }

   public int compare(Object var1, Object var2) {
      return this.method2839((Buddy)var1, (Buddy)var2);
   }

   public static final boolean method2846(int var0, int var1, class177 var2, CollisionMap var3) {
      int var4 = var0;
      int var5 = var1;
      byte var6 = 64;
      byte var7 = 64;
      int var8 = var0 - var6;
      int var9 = var1 - var7;
      class180.field1988[var6][var7] = 99;
      class180.field1986[var6][var7] = 0;
      byte var10 = 0;
      int var11 = 0;
      class180.field1989[var10] = var0;
      byte var10001 = var10;
      int var18 = var10 + 1;
      class180.field1993[var10001] = var1;
      int[][] var12 = var3.flags;

      while(var18 != var11) {
         var4 = class180.field1989[var11];
         var5 = class180.field1993[var11];
         var11 = var11 + 1 & 4095;
         int var16 = var4 - var8;
         int var17 = var5 - var9;
         int var13 = var4 - var3.xInset;
         int var14 = var5 - var3.yInset;
         if (var2.vmethod3287(2, var4, var5, var3)) {
            class211.field2514 = var4;
            class180.field1990 = var5;
            return true;
         }

         int var15 = class180.field1986[var16][var17] + 1;
         if (var16 > 0 && class180.field1988[var16 - 1][var17] == 0 && (var12[var13 - 1][var14] & 19136782) == 0 && (var12[var13 - 1][var14 + 1] & 19136824) == 0) {
            class180.field1989[var18] = var4 - 1;
            class180.field1993[var18] = var5;
            var18 = var18 + 1 & 4095;
            class180.field1988[var16 - 1][var17] = 2;
            class180.field1986[var16 - 1][var17] = var15;
         }

         if (var16 < 126 && class180.field1988[var16 + 1][var17] == 0 && (var12[var13 + 2][var14] & 19136899) == 0 && (var12[var13 + 2][var14 + 1] & 19136992) == 0) {
            class180.field1989[var18] = var4 + 1;
            class180.field1993[var18] = var5;
            var18 = var18 + 1 & 4095;
            class180.field1988[var16 + 1][var17] = 8;
            class180.field1986[var16 + 1][var17] = var15;
         }

         if (var17 > 0 && class180.field1988[var16][var17 - 1] == 0 && (var12[var13][var14 - 1] & 19136782) == 0 && (var12[var13 + 1][var14 - 1] & 19136899) == 0) {
            class180.field1989[var18] = var4;
            class180.field1993[var18] = var5 - 1;
            var18 = var18 + 1 & 4095;
            class180.field1988[var16][var17 - 1] = 1;
            class180.field1986[var16][var17 - 1] = var15;
         }

         if (var17 < 126 && class180.field1988[var16][var17 + 1] == 0 && (var12[var13][var14 + 2] & 19136824) == 0 && (var12[var13 + 1][var14 + 2] & 19136992) == 0) {
            class180.field1989[var18] = var4;
            class180.field1993[var18] = var5 + 1;
            var18 = var18 + 1 & 4095;
            class180.field1988[var16][var17 + 1] = 4;
            class180.field1986[var16][var17 + 1] = var15;
         }

         if (var16 > 0 && var17 > 0 && class180.field1988[var16 - 1][var17 - 1] == 0 && (var12[var13 - 1][var14] & 19136830) == 0 && (var12[var13 - 1][var14 - 1] & 19136782) == 0 && (var12[var13][var14 - 1] & 19136911) == 0) {
            class180.field1989[var18] = var4 - 1;
            class180.field1993[var18] = var5 - 1;
            var18 = var18 + 1 & 4095;
            class180.field1988[var16 - 1][var17 - 1] = 3;
            class180.field1986[var16 - 1][var17 - 1] = var15;
         }

         if (var16 < 126 && var17 > 0 && class180.field1988[var16 + 1][var17 - 1] == 0 && (var12[var13 + 1][var14 - 1] & 19136911) == 0 && (var12[var13 + 2][var14 - 1] & 19136899) == 0 && (var12[var13 + 2][var14] & 19136995) == 0) {
            class180.field1989[var18] = var4 + 1;
            class180.field1993[var18] = var5 - 1;
            var18 = var18 + 1 & 4095;
            class180.field1988[var16 + 1][var17 - 1] = 9;
            class180.field1986[var16 + 1][var17 - 1] = var15;
         }

         if (var16 > 0 && var17 < 126 && class180.field1988[var16 - 1][var17 + 1] == 0 && (var12[var13 - 1][var14 + 1] & 19136830) == 0 && (var12[var13 - 1][var14 + 2] & 19136824) == 0 && (var12[var13][var14 + 2] & 19137016) == 0) {
            class180.field1989[var18] = var4 - 1;
            class180.field1993[var18] = var5 + 1;
            var18 = var18 + 1 & 4095;
            class180.field1988[var16 - 1][var17 + 1] = 6;
            class180.field1986[var16 - 1][var17 + 1] = var15;
         }

         if (var16 < 126 && var17 < 126 && class180.field1988[var16 + 1][var17 + 1] == 0 && (var12[var13 + 1][var14 + 2] & 19137016) == 0 && (var12[var13 + 2][var14 + 2] & 19136992) == 0 && (var12[var13 + 2][var14 + 1] & 19136995) == 0) {
            class180.field1989[var18] = var4 + 1;
            class180.field1993[var18] = var5 + 1;
            var18 = var18 + 1 & 4095;
            class180.field1988[var16 + 1][var17 + 1] = 12;
            class180.field1986[var16 + 1][var17 + 1] = var15;
         }
      }

      class211.field2514 = var4;
      class180.field1990 = var5;
      return false;
   }
}
