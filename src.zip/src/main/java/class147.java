public class class147 extends AbstractUserComparator {
   static String field1673;
   final boolean field1675;

   public class147(boolean var1) {
      this.field1675 = var1;
   }

   int method2942(Buddy var1, Buddy var2) {
      if (var2.rank != var1.rank) {
         return this.field1675 ? var1.rank - var2.rank : var2.rank - var1.rank;
      } else {
         return this.method5349(var1, var2);
      }
   }

   public int compare(Object var1, Object var2) {
      return this.method2942((Buddy)var1, (Buddy)var2);
   }

   static final void method2948(String var0, int var1) {
      PacketBufferNode var2 = FaceNormal.method2884(ClientPacket.field1913, Client.field2133.isaacCipher);
      var2.packetBuffer.writeByte(AbstractSoundSystem.method1696(var0) + 1);
      var2.packetBuffer.writeStringCp1252NullTerminated(var0);
      var2.packetBuffer.writeByte(var1);
      Client.field2133.method1281(var2);
   }
}
