public class class211 {
   public static int field2514;

   static void method4329(IndexCache var0, String var1) {
      IndexCacheLoader var2 = new IndexCacheLoader(var0, var1);
      Client.field2358.add(var2);
   }
}
