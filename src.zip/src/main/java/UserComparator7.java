public class UserComparator7 extends AbstractUserComparator {
   final boolean field1702;

   public UserComparator7(boolean var1) {
      this.field1702 = var1;
   }

   int method2961(Buddy var1, Buddy var2) {
      if (var1.world != 0 && var2.world != 0) {
         return this.field1702 ? var1.int2 - var2.int2 : var2.int2 - var1.int2;
      } else {
         return this.method5349(var1, var2);
      }
   }

   public int compare(Object var1, Object var2) {
      return this.method2961((Buddy)var1, (Buddy)var2);
   }
}
