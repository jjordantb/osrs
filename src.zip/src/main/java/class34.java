import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public class class34 {
   static IndexStore field391;
   static int field403;
   static int[][][] field404;
   static Sprite field402;

   static void method795(int var0, TileLocation var1, boolean var2) {
      WorldMapData var3 = class99.method1840().method6043(var0);
      int var4 = ObjectSound.field589.plane;
      int var5 = (ObjectSound.field589.x >> 7) + class21.field230;
      int var6 = (ObjectSound.field589.y >> 7) + class79.field902;
      TileLocation var7 = new TileLocation(var4, var5, var6);
      class99.method1840().method6031(var3, var7, var1, var2);
   }

   public static void method794(String var0, String var1, int buildNumber, int var3) throws IOException {
      class178.buildNumber = var3;
      class178.field1980 = buildNumber;

      try {
         class147.field1673 = System.getProperty("os.name");
      } catch (Exception var29) {
         class147.field1673 = "Unknown";
      }

      WorldMapIcon.field251 = class147.field1673.toLowerCase();

      try {
         class103.homeDirectory = System.getProperty("user.home");
         if (class103.homeDirectory != null) {
            class103.homeDirectory = class103.homeDirectory + "/";
         }
      } catch (Exception var28) {
         ;
      }

      try {
         if (WorldMapIcon.field251.startsWith("win")) {
            if (class103.homeDirectory == null) {
               class103.homeDirectory = System.getenv("USERPROFILE");
            }
         } else if (class103.homeDirectory == null) {
            class103.homeDirectory = System.getenv("HOME");
         }

         if (class103.homeDirectory != null) {
            class103.homeDirectory = class103.homeDirectory + "/";
         }
      } catch (Exception var27) {
         ;
      }

      if (class103.homeDirectory == null) {
         class103.homeDirectory = "~/";
      }

      PlayerAppearance.field2558 = new String[]{"c:/rscache/", "/rscache/", "c:/windows/", "c:/winnt/", "c:/", class103.homeDirectory, "/tmp/", ""};
      class81.field919 = new String[]{".jagex_cache_" + class178.field1980, ".file_store_" + class178.field1980};
      int var18 = 0;

      label278:
      while(var18 < 4) {
         String var6 = var18 == 0 ? "" : "" + var18;
         class178.field1970 = new File(class103.homeDirectory, "jagex_cl_" + var0 + "_" + var1 + var6 + ".dat");
         String var7 = null;
         String var8 = null;
         boolean var9 = false;
         File var36;
         if (class178.field1970.exists()) {
            try {
               AccessFile var10 = new AccessFile(class178.field1970, "rw", 10000L);

               Buffer var11;
               int var12;
               for(var11 = new Buffer((int)var10.length()); var11.index < var11.array.length; var11.index += var12) {
                  var12 = var10.read(var11.array, var11.index, var11.array.length - var11.index);
                  if (var12 == -1) {
                     throw new IOException();
                  }
               }

               var11.index = 0;
               var12 = var11.readUnsignedByte();
               if (var12 < 1 || var12 > 3) {
                  throw new IOException("" + var12);
               }

               int var13 = 0;
               if (var12 > 1) {
                  var13 = var11.readUnsignedByte();
               }

               if (var12 <= 2) {
                  var7 = var11.readStringCp1252NullCircumfixed();
                  if (var13 == 1) {
                     var8 = var11.readStringCp1252NullCircumfixed();
                  }
               } else {
                  var7 = var11.method3922();
                  if (var13 == 1) {
                     var8 = var11.method3922();
                  }
               }

               var10.close();
            } catch (IOException var32) {
               var32.printStackTrace();
            }

            if (var7 != null) {
               var36 = new File(var7);
               if (!var36.exists()) {
                  var7 = null;
               }
            }

            if (var7 != null) {
               var36 = new File(var7, "test.dat");
               if (!AbstractByteArrayCopier.method3742(var36, true)) {
                  var7 = null;
               }
            }
         }

         if (var7 == null && var18 == 0) {
            label253:
            for(int var19 = 0; var19 < class81.field919.length; ++var19) {
               for(int var20 = 0; var20 < PlayerAppearance.field2558.length; ++var20) {
                  File var21 = new File(PlayerAppearance.field2558[var20] + class81.field919[var19] + File.separatorChar + var0 + File.separatorChar);
                  if (var21.exists() && AbstractByteArrayCopier.method3742(new File(var21, "test.dat"), true)) {
                     var7 = var21.toString();
                     var9 = true;
                     break label253;
                  }
               }
            }
         }

         if (var7 == null) {
            var7 = class103.homeDirectory + File.separatorChar + "jagexcache" + var6 + File.separatorChar + var0 + File.separatorChar + var1 + File.separatorChar;
            var9 = true;
         }

         if (var8 != null) {
            File var35 = new File(var8);
            var36 = new File(var7);

            try {
               File[] var39 = var35.listFiles();
               File[] var22 = var39;

               for(int var14 = 0; var14 < var22.length; ++var14) {
                  File var15 = var22[var14];
                  File var16 = new File(var36, var15.getName());
                  boolean var17 = var15.renameTo(var16);
                  if (!var17) {
                     throw new IOException();
                  }
               }
            } catch (Exception var31) {
               var31.printStackTrace();
            }

            var9 = true;
         }

         if (var9) {
            Clock.wait(new File(var7), (File)null);
         }

         File var5 = new File(var7);
         ScriptFrame.field171 = var5;
         if (!ScriptFrame.field171.exists()) {
            ScriptFrame.field171.mkdirs();
         }

         File[] var34 = ScriptFrame.field171.listFiles();
         if (var34 != null) {
            File[] var37 = var34;

            for(int var23 = 0; var23 < var37.length; ++var23) {
               File var24 = var37[var23];
               if (!AbstractByteArrayCopier.method3742(var24, false)) {
                  ++var18;
                  continue label278;
               }
            }
         }
         break;
      }

      UserComparator10.method2913(ScriptFrame.field171);

      try {
         File var4 = new File(class103.homeDirectory, "random.dat");
         int var26;
         if (var4.exists()) {
            class178.field1985 = new BufferedFile(new AccessFile(var4, "rw", 25L), 24, 0);
         } else {
            label206:
            for(int var25 = 0; var25 < class81.field919.length; ++var25) {
               for(var26 = 0; var26 < PlayerAppearance.field2558.length; ++var26) {
                  File var38 = new File(PlayerAppearance.field2558[var26] + class81.field919[var25] + File.separatorChar + "random.dat");
                  if (var38.exists()) {
                     class178.field1985 = new BufferedFile(new AccessFile(var38, "rw", 25L), 24, 0);
                     break label206;
                  }
               }
            }
         }

         if (class178.field1985 == null) {
            RandomAccessFile var33 = new RandomAccessFile(var4, "rw");
            var26 = var33.read();
            var33.seek(0L);
            var33.write(var26);
            var33.seek(0L);
            var33.close();
            class178.field1985 = new BufferedFile(new AccessFile(var4, "rw", 25L), 24, 0);
         }
      } catch (IOException var30) {
         ;
      }

      class178.field1975 = new BufferedFile(new AccessFile(class6.method185("main_file_cache.dat2"), "rw", 1048576000L), 5200, 0);
      class178.field1976 = new BufferedFile(new AccessFile(class6.method185("main_file_cache.idx255"), "rw", 1048576L), 6000, 0);
      class178.field1977 = new BufferedFile[class178.buildNumber];

      for(var18 = 0; var18 < class178.buildNumber; ++var18) {
         class178.field1977[var18] = new BufferedFile(new AccessFile(class6.method185("main_file_cache.idx" + var18), "rw", 1048576L), 6000, 0);
      }

   }
}
