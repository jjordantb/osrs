import java.io.DataInputStream;
import java.net.URL;

public final class Projectile extends Entity {
   double speedZ;
   int cycleStart;
   int sourceZ;
   double x;
   int sourceX;
   double speed;
   int id;
   double speedY;
   int int4;
   double y;
   int yaw;
   int int5;
   boolean isMoving = false;
   int int3;
   int targetIndex;
   int sourceY;
   int plane;
   SequenceDefinition sequenceDefinition;
   double accelerationZ;
   int frameCycle = 0;
   double speedX;
   int cycleEnd;
   double z;
   int frame = 0;
   int pitch;

   Projectile(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11) {
      this.id = var1;
      this.plane = var2;
      this.sourceX = var3;
      this.sourceY = var4;
      this.sourceZ = var5;
      this.cycleStart = var6;
      this.cycleEnd = var7;
      this.int3 = var8;
      this.int4 = var9;
      this.targetIndex = var10;
      this.int5 = var11;
      this.isMoving = false;
      int var12 = IndexStoreActionHandler.method4937(this.id).sequence;
      if (var12 != -1) {
         this.sequenceDefinition = WorldMapCacheName.method547(var12);
      } else {
         this.sequenceDefinition = null;
      }

   }

   protected final Model getModel() {
      SpotAnimationDefinition var1 = IndexStoreActionHandler.method4937(this.id);
      Model var2 = var1.getModel(this.frame);
      if (var2 == null) {
         return null;
      } else {
         var2.rotateZ(this.pitch);
         return var2;
      }
   }

   final void setDestination(int var1, int var2, int var3, int var4) {
      double var5;
      if (!this.isMoving) {
         var5 = (double)(var1 - this.sourceX);
         double var7 = (double)(var2 - this.sourceY);
         double var9 = Math.sqrt(var7 * var7 + var5 * var5);
         this.x = (double)this.sourceX + var5 * (double)this.int4 / var9;
         this.y = (double)this.sourceY + var7 * (double)this.int4 / var9;
         this.z = (double)this.sourceZ;
      }

      var5 = (double)(this.cycleEnd + 1 - var4);
      this.speedX = ((double)var1 - this.x) / var5;
      this.speedY = ((double)var2 - this.y) / var5;
      this.speed = Math.sqrt(this.speedX * this.speedX + this.speedY * this.speedY);
      if (!this.isMoving) {
         this.speedZ = -this.speed * Math.tan((double)this.int3 * 0.02454369D);
      }

      this.accelerationZ = 2.0D * ((double)var3 - this.z - var5 * this.speedZ) / (var5 * var5);
   }

   final void advance(int var1) {
      this.isMoving = true;
      this.x += (double)var1 * this.speedX;
      this.y += this.speedY * (double)var1;
      this.z += this.speedZ * (double)var1 + (double)var1 * 0.5D * this.accelerationZ * (double)var1;
      this.speedZ += this.accelerationZ * (double)var1;
      this.yaw = (int)(Math.atan2(this.speedX, this.speedY) * 325.949D) + 1024 & 2047;
      this.pitch = (int)(Math.atan2(this.speedZ, this.speed) * 325.949D) & 2047;
      if (this.sequenceDefinition != null) {
         this.frameCycle += var1;

         while(true) {
            do {
               do {
                  if (this.frameCycle <= this.sequenceDefinition.frameLengths[this.frame]) {
                     return;
                  }

                  this.frameCycle -= this.sequenceDefinition.frameLengths[this.frame];
                  ++this.frame;
               } while(this.frame < this.sequenceDefinition.frameIds.length);

               this.frame -= this.sequenceDefinition.frameCount;
            } while(this.frame >= 0 && this.frame < this.sequenceDefinition.frameIds.length);

            this.frame = 0;
         }
      }
   }

   public static void setDestination(String var0, Throwable var1) {
      if (var1 != null) {
         var1.printStackTrace();
      } else {
         try {
            String var2 = "";
            if (var1 != null) {
               var2 = TextureProvider.load(var1);
            }

            if (var0 != null) {
               if (var1 != null) {
                  var2 = var2 + " | ";
               }

               var2 = var2 + var0;
            }

            System.out.println("Error: " + var2);
            var2 = var2.replace(':', '.');
            var2 = var2.replace('@', '_');
            var2 = var2.replace('&', '_');
            var2 = var2.replace('#', '_');
            if (RunException.field1605 == null) {
               return;
            }

            URL var3 = new URL(RunException.field1605.getCodeBase(), "clienterror.ws?c=" + UserComparator1.field3824 + "&u=" + RunException.field1601 + "&v1=" + TaskHandler.field1771 + "&v2=" + TaskHandler.field1767 + "&ct=" + class83.field943 + "&e=" + var2);
            DataInputStream var4 = new DataInputStream(var3.openStream());
            var4.read();
            var4.close();
         } catch (Exception var5) {
            ;
         }

      }
   }

   static Script method1331(byte[] var0) {
      Script var1 = new Script();
      Buffer var2 = new Buffer(var0);
      var2.index = var2.array.length - 2;
      int var3 = var2.method3913();
      int var4 = var2.array.length - 2 - var3 - 12;
      var2.index = var4;
      int var5 = var2.readInt();
      var1.localIntCount = var2.method3913();
      var1.localStringCount = var2.method3913();
      var1.intArgumentCount = var2.method3913();
      var1.stringArgumentCount = var2.method3913();
      int var6 = var2.readUnsignedByte();
      int var7;
      int var8;
      if (var6 > 0) {
         var1.switches = var1.method1803(var6);

         for(var7 = 0; var7 < var6; ++var7) {
            var8 = var2.method3913();
            IterableNodeHashTable var9 = new IterableNodeHashTable(var8 > 0 ? TotalQuantityComparator.method1760(var8) : 1);
            var1.switches[var7] = var9;

            while(var8-- > 0) {
               int var10 = var2.readInt();
               int var11 = var2.readInt();
               var9.put(new IntegerNode(var11), (long)var10);
            }
         }
      }

      var2.index = 0;
      var2.method3919();
      var1.opcodes = new int[var5];
      var1.intOperands = new int[var5];
      var1.stringOperands = new String[var5];

      for(var7 = 0; var2.index < var4; var1.opcodes[var7++] = var8) {
         var8 = var2.method3913();
         if (var8 == 3) {
            var1.stringOperands[var7] = var2.readStringCp1252NullTerminated();
         } else if (var8 < 100 && var8 != 21 && var8 != 38 && var8 != 39) {
            var1.intOperands[var7] = var2.readInt();
         } else {
            var1.intOperands[var7] = var2.readUnsignedByte();
         }
      }

      return var1;
   }

   static final void method1332() {
      for(int var0 = 0; var0 < Client.field2129; ++var0) {
         int var1 = Client.field2130[var0];
         Npc var2 = Client.field2249[var1];
         if (var2 != null) {
            class130.method2827(var2, var2.definition.size);
         }
      }

   }
}
