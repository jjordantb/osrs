import java.util.Iterator;

public class IndexStoreActionHandler implements Runnable {
   static Thread field2949;
   static boolean field2950;
   public static int field2947 = 0;
   static NodeDeque field2946 = new NodeDeque();
   public static Object field2945 = new Object();
   static NodeDeque field2948 = new NodeDeque();
   static int[][] field2951;

   public void run() {
      try {
         while(true) {
            NodeDeque var2 = field2946;
            IndexStoreAction var1;
            synchronized(field2946) {
               var1 = (IndexStoreAction)field2946.last();
            }

            Object var14;
            if (var1 != null) {
               if (var1.type == 0) {
                  var1.indexStore.write((int)var1.key, var1.data, var1.data.length);
                  var2 = field2946;
                  synchronized(field2946) {
                     var1.remove();
                  }
               } else if (var1.type == 1) {
                  var1.data = var1.indexStore.read((int)var1.key);
                  var2 = field2946;
                  synchronized(field2946) {
                     field2948.addFirst(var1);
                  }
               }

               var14 = field2945;
               synchronized(field2945) {
                  if (field2947 <= 1) {
                     field2947 = 0;
                     field2945.notifyAll();
                     return;
                  }

                  field2947 = 600;
               }
            } else {
               class276.method5382(100L);
               var14 = field2945;
               synchronized(field2945) {
                  if (field2947 <= 1) {
                     field2947 = 0;
                     field2945.notifyAll();
                     return;
                  }

                  --field2947;
               }
            }
         }
      } catch (Exception var13) {
         Projectile.setDestination((String)null, var13);
      }
   }

   public static SpotAnimationDefinition method4937(int var0) {
      SpotAnimationDefinition var1 = (SpotAnimationDefinition)SpotAnimationDefinition.field3664.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = SpotAnimationDefinition.field3667.takeRecord(13, var0);
         var1 = new SpotAnimationDefinition();
         var1.id = var0;
         if (var2 != null) {
            var1.read(new Buffer(var2));
         }

         SpotAnimationDefinition.field3664.put(var1, (long)var0);
         return var1;
      }
   }

   static final void method4939() {
      for(int var0 = 0; var0 < Players.field951; ++var0) {
         Player var1 = Client.field2141[Players.field947[var0]];
         var1.method812();
      }

      Iterator var2 = Messages.field611.iterator();

      while(var2.hasNext()) {
         Message var3 = (Message)var2.next();
         var3.method1053();
      }

      if (TotalQuantityComparator.field983 != null) {
         TotalQuantityComparator.field983.method5763();
      }

   }
}
