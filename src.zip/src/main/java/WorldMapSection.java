public interface WorldMapSection {
   TileLocation vmethod1861(int var1, int var2);

   boolean vmethod1857(int var1, int var2);

   void vmethod1855(WorldMapData var1);

   void read(Buffer var1);

   int[] vmethod1858(int var1, int var2, int var3);

   boolean vmethod1856(int var1, int var2, int var3);
}
