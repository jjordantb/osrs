import java.awt.Desktop;
import java.awt.Desktop.Action;
import java.net.URI;
import java.net.URL;

public class UrlRequest {
   static int field1615;
   static IndexedSprite field1614;
   static Task field1613;
   volatile byte[] response0;
   final URL url;
   volatile boolean isDone0;

   UrlRequest(URL var1) {
      this.url = var1;
   }

   public boolean isDone() {
      return this.isDone0;
   }

   public byte[] getResponse() {
      return this.response0;
   }

   public static void isDone(String var0, boolean var1, boolean var2) {
      if (var1) {
         if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Action.BROWSE)) {
            try {
               Desktop.getDesktop().browse(new URI(var0));
               return;
            } catch (Exception var4) {
               ;
            }
         }

         if (class12.field125.startsWith("win")) {
            OctantDirection.ordinal(var0, 0, "openjs");
         } else if (class12.field125.startsWith("mac")) {
            OctantDirection.ordinal(var0, 1, "openjs");
         } else {
            OctantDirection.ordinal(var0, 2, "openjs");
         }
      } else {
         OctantDirection.ordinal(var0, 3, "openjs");
      }

   }

   static void method2877(World var0) {
      if (var0.method649() != Client.field2090) {
         Client.field2090 = var0.method649();
         boolean var1 = var0.method649();
         if (var1 != PlayerAppearance.field2560) {
            PacketWriter.method1288();
            PlayerAppearance.field2560 = var1;
         }
      }

      class85.field965 = var0.host;
      Client.field2134 = var0.id;
      Client.field2103 = var0.properties;
      UserComparator4.field1729 = Client.field2088 == 0 ? 'ꩊ' : var0.id + '鱀';
      GrandExchangeEvent.field761 = Client.field2088 == 0 ? 443 : var0.id + '썐';
      UserComparator5.field1595 = UserComparator4.field1729;
   }

   static int getResponse(int var0, int var1) {
      ItemContainer var2 = (ItemContainer)ItemContainer.field267.get((long)var0);
      if (var2 == null) {
         return 0;
      } else {
         return var1 >= 0 && var1 < var2.quantities.length ? var2.quantities[var1] : 0;
      }
   }
}
