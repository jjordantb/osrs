public class OverlayDefinition extends DualNode {
   static class291 field3690;
   public static AbstractIndexCache field3688;
   public static EvictingDualNodeHashTable field3678 = new EvictingDualNodeHashTable(64);
   public int hue;
   public boolean field3679 = true;
   public int rgb = 0;
   public int hue2;
   public int rgb2 = -1;
   public int lightness2;
   public int lightness;
   public int saturation2;
   public int texture = -1;
   public int saturation;

   void setHsl(int var1) {
      double var2 = (double)(var1 >> 16 & 255) / 256.0D;
      double var4 = (double)(var1 >> 8 & 255) / 256.0D;
      double var6 = (double)(var1 & 255) / 256.0D;
      double var8 = var2;
      if (var4 < var2) {
         var8 = var4;
      }

      if (var6 < var8) {
         var8 = var6;
      }

      double var10 = var2;
      if (var4 > var2) {
         var10 = var4;
      }

      if (var6 > var10) {
         var10 = var6;
      }

      double var12 = 0.0D;
      double var14 = 0.0D;
      double var16 = (var10 + var8) / 2.0D;
      if (var10 != var8) {
         if (var16 < 0.5D) {
            var14 = (var10 - var8) / (var8 + var10);
         }

         if (var16 >= 0.5D) {
            var14 = (var10 - var8) / (2.0D - var10 - var8);
         }

         if (var10 == var2) {
            var12 = (var4 - var6) / (var10 - var8);
         } else if (var4 == var10) {
            var12 = (var6 - var2) / (var10 - var8) + 2.0D;
         } else if (var6 == var10) {
            var12 = (var2 - var4) / (var10 - var8) + 4.0D;
         }
      }

      var12 /= 6.0D;
      this.hue = (int)(var12 * 256.0D);
      this.saturation = (int)(var14 * 256.0D);
      this.lightness = (int)(var16 * 256.0D);
      if (this.saturation < 0) {
         this.saturation = 0;
      } else if (this.saturation > 255) {
         this.saturation = 255;
      }

      if (this.lightness < 0) {
         this.lightness = 0;
      } else if (this.lightness > 255) {
         this.lightness = 255;
      }

   }

   public void read(Buffer var1, int var2) {
      while(true) {
         int var3 = var1.readUnsignedByte();
         if (var3 == 0) {
            return;
         }

         this.readNext(var1, var3, var2);
      }
   }

   void readNext(Buffer var1, int var2, int var3) {
      if (var2 == 1) {
         this.rgb = var1.readMedium();
      } else if (var2 == 2) {
         this.texture = var1.readUnsignedByte();
      } else if (var2 == 5) {
         this.field3679 = false;
      } else if (var2 == 7) {
         this.rgb2 = var1.readMedium();
      } else if (var2 == 8) {
         ;
      }

   }

   public void init() {
      if (this.rgb2 != -1) {
         this.setHsl(this.rgb2);
         this.hue2 = this.hue;
         this.saturation2 = this.saturation;
         this.lightness2 = this.lightness;
      }

      this.setHsl(this.rgb);
   }

   static IndexedSprite method5557() {
      IndexedSprite var0 = new IndexedSprite();
      var0.width = class328.field3983;
      var0.height = class328.field3988;
      var0.xOffset = class328.field3982[0];
      var0.yOffset = class328.field3984[0];
      var0.subWidth = class328.field3987[0];
      var0.subHeight = VarcInt.field2811[0];
      var0.palette = class328.field3986;
      var0.pixels = class328.field3989[0];
      class328.field3982 = null;
      class328.field3984 = null;
      class328.field3987 = null;
      VarcInt.field2811 = null;
      class328.field3986 = null;
      class328.field3989 = null;
      return var0;
   }
}
