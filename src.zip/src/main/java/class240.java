public class class240 {
   public static void method4820() {
      if (KeyHandler.field17 != null) {
         KeyHandler var0 = KeyHandler.field17;
         synchronized(KeyHandler.field17) {
            KeyHandler.field17 = null;
         }
      }

   }

   static final void method4819(int var0, int var1) {
      NodeDeque var2 = Client.field2272[class31.field363][var0][var1];
      if (var2 == null) {
         class243.field2904.removeGroundItemPile(class31.field363, var0, var1);
      } else {
         long var3 = -99999999L;
         GroundItem var5 = null;

         GroundItem var6;
         for(var6 = (GroundItem)var2.last(); var6 != null; var6 = (GroundItem)var2.previous()) {
            ItemDefinition var7 = Varcs.getItemDefinition(var6.id);
            long var8 = (long)var7.price;
            if (var7.isStackable == 1) {
               var8 *= (long)(var6.quantity + 1);
            }

            if (var8 > var3) {
               var3 = var8;
               var5 = var6;
            }
         }

         if (var5 == null) {
            class243.field2904.removeGroundItemPile(class31.field363, var0, var1);
         } else {
            var2.addLast(var5);
            GroundItem var12 = null;
            GroundItem var11 = null;

            for(var6 = (GroundItem)var2.last(); var6 != null; var6 = (GroundItem)var2.previous()) {
               if (var5.id != var6.id) {
                  if (var12 == null) {
                     var12 = var6;
                  }

                  if (var6.id != var12.id && var11 == null) {
                     var11 = var6;
                  }
               }
            }

            long var9 = WorldComparator.method1404(var0, var1, 3, false, 0);
            class243.field2904.newGroundItemPile(class31.field363, var0, var1, MilliClock.method2923(var0 * 128 + 64, var1 * 128 + 64, class31.field363), var5, var9, var12, var11);
         }
      }
   }
}
