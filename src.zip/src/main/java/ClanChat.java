public class ClanChat extends UserList {
   public int field3759;
   final Usernamed field3755;
   public String name = null;
   int field3756 = 1;
   public byte field3758;
   public String owner = null;
   final LoginType loginType;

   public ClanChat(LoginType var1, Usernamed var2) {
      super(100);
      this.loginType = var1;
      this.field3755 = var2;
   }

   final void method5790(String var1) {
      this.owner = User.method5400(var1);
   }

   final void method5766(String var1) {
      this.name = User.method5400(var1);
   }

   User newInstance() {
      return new ClanMate();
   }

   final void method5772(ClanMate var1) {
      if (var1.method5384().equals(this.field3755.username())) {
         this.field3759 = var1.rank;
      }

   }

   public final void readUpdate(Buffer var1) {
      this.method5790(var1.readStringCp1252NullTerminated());
      long var2 = var1.readLong();
      this.method5766(BufferedSink.write(var2));
      this.field3758 = var1.readByte();
      int var4 = var1.readUnsignedByte();
      if (var4 != 255) {
         this.clear();

         for(int var5 = 0; var5 < var4; ++var5) {
            ClanMate var6 = (ClanMate)this.addLastNoPreviousUsername(new Username(var1.readStringCp1252NullTerminated(), this.loginType));
            int var7 = var1.method3913();
            var6.set(var7, ++this.field3756 - 1);
            var6.rank = var1.readByte();
            var1.readStringCp1252NullTerminated();
            this.method5772(var6);
         }

      }
   }

   public final void method5771() {
      for(int var1 = 0; var1 < this.size(); ++var1) {
         ((ClanMate)this.get(var1)).method5326();
      }

   }

   User[] newTypedArray(int var1) {
      return new ClanMate[var1];
   }

   public final void method5763() {
      for(int var1 = 0; var1 < this.size(); ++var1) {
         ((ClanMate)this.get(var1)).method5323();
      }

   }

   public final void method5769(Buffer var1) {
      Username var2 = new Username(var1.readStringCp1252NullTerminated(), this.loginType);
      int var3 = var1.method3913();
      byte var4 = var1.readByte();
      boolean var5 = false;
      if (var4 == -128) {
         var5 = true;
      }

      ClanMate var6;
      if (var5) {
         if (this.size() == 0) {
            return;
         }

         var6 = (ClanMate)this.getByCurrentUsername(var2);
         if (var6 != null && var6.method5829() == var3) {
            this.remove(var6);
         }
      } else {
         var1.readStringCp1252NullTerminated();
         var6 = (ClanMate)this.getByCurrentUsername(var2);
         if (var6 == null) {
            if (this.size() > super.capacity) {
               return;
            }

            var6 = (ClanMate)this.addLastNoPreviousUsername(var2);
         }

         var6.set(var3, ++this.field3756 - 1);
         var6.rank = var4;
         this.method5772(var6);
      }

   }

   static boolean method5784(CharSequence var0, int var1, boolean var2) {
      if (var1 >= 2 && var1 <= 36) {
         boolean var3 = false;
         boolean var4 = false;
         int var5 = 0;
         int var6 = var0.length();

         for(int var7 = 0; var7 < var6; ++var7) {
            char var8 = var0.charAt(var7);
            if (var7 == 0) {
               if (var8 == '-') {
                  var3 = true;
                  continue;
               }

               if (var8 == '+') {
                  continue;
               }
            }

            int var10;
            if (var8 >= '0' && var8 <= '9') {
               var10 = var8 - 48;
            } else if (var8 >= 'A' && var8 <= 'Z') {
               var10 = var8 - 55;
            } else {
               if (var8 < 'a' || var8 > 'z') {
                  return false;
               }

               var10 = var8 - 87;
            }

            if (var10 >= var1) {
               return false;
            }

            if (var3) {
               var10 = -var10;
            }

            int var9 = var10 + var5 * var1;
            if (var9 / var1 != var5) {
               return false;
            }

            var5 = var9;
            var4 = true;
         }

         return var4;
      } else {
         throw new IllegalArgumentException("");
      }
   }
}
