public class PlayerAppearance {
   static String[] field2558;
   public static short[][] field2550;
   static EvictingDualNodeHashTable field2548 = new EvictingDualNodeHashTable(260);
   public static short[] field2554;
   static final int[] field2556 = new int[]{8, 11, 4, 6, 9, 7, 10};
   public static boolean field2560;
   long field2552;
   public boolean isFemale;
   int[] equipment;
   long field2557;
   public int npcTransformId;
   int[] bodyColors;

   public void method4504(Buffer var1) {
      var1.writeByte(this.isFemale ? 1 : 0);

      int var2;
      for(var2 = 0; var2 < 7; ++var2) {
         int var3 = this.equipment[field2556[var2]];
         if (var3 == 0) {
            var1.writeByte(-1);
         } else {
            var1.writeByte(var3 - 256);
         }
      }

      for(var2 = 0; var2 < 5; ++var2) {
         var1.writeByte(this.bodyColors[var2]);
      }

   }

   public int getChatHeadId() {
      return this.npcTransformId == -1 ? (this.equipment[0] << 15) + this.equipment[1] + (this.equipment[11] << 5) + (this.equipment[8] << 10) + (this.bodyColors[0] << 25) + (this.bodyColors[4] << 20) : 305419896 + NetFileRequest.method4959(this.npcTransformId).id;
   }

   public void method4502(int var1, boolean var2) {
      int var3 = this.bodyColors[var1];
      boolean var4;
      if (!var2) {
         do {
            --var3;
            if (var3 < 0) {
               var3 = VarpDefinition.field2929[var1].length - 1;
            }

            if (var1 == 4 && var3 >= 8) {
               var4 = false;
            } else {
               var4 = true;
            }
         } while(!var4);
      } else {
         do {
            ++var3;
            if (var3 >= VarpDefinition.field2929[var1].length) {
               var3 = 0;
            }

            if (var1 == 4 && var3 >= 8) {
               var4 = false;
            } else {
               var4 = true;
            }
         } while(!var4);
      }

      this.bodyColors[var1] = var3;
      this.method4505();
   }

   public void method4500(int[] var1, int[] var2, boolean var3, int var4) {
      if (var1 == null) {
         var1 = new int[12];

         for(int var5 = 0; var5 < 7; ++var5) {
            for(int var6 = 0; var6 < KitDefinition.field3344; ++var6) {
               KitDefinition var7 = ClientPacket.method3233(var6);
               if (var7 != null && !var7.field3353 && var7.field3342 == var5 + (var3 ? 7 : 0)) {
                  var1[field2556[var5]] = var6 + 256;
                  break;
               }
            }
         }
      }

      this.equipment = var1;
      this.bodyColors = var2;
      this.isFemale = var3;
      this.npcTransformId = var4;
      this.method4505();
   }

   void method4505() {
      long var1 = this.field2552;
      int var3 = this.equipment[5];
      int var4 = this.equipment[9];
      this.equipment[5] = var4;
      this.equipment[9] = var3;
      this.field2552 = 0L;

      int var5;
      for(var5 = 0; var5 < 12; ++var5) {
         this.field2552 <<= 4;
         if (this.equipment[var5] >= 256) {
            this.field2552 += (long)(this.equipment[var5] - 256);
         }
      }

      if (this.equipment[0] >= 256) {
         this.field2552 += (long)(this.equipment[0] - 256 >> 4);
      }

      if (this.equipment[1] >= 256) {
         this.field2552 += (long)(this.equipment[1] - 256 >> 8);
      }

      for(var5 = 0; var5 < 5; ++var5) {
         this.field2552 <<= 3;
         this.field2552 += (long)this.bodyColors[var5];
      }

      this.field2552 <<= 1;
      this.field2552 += (long)(this.isFemale ? 1 : 0);
      this.equipment[5] = var3;
      this.equipment[9] = var4;
      if (var1 != 0L && var1 != this.field2552) {
         field2548.remove(var1);
      }

   }

   ModelData getModelData() {
      if (this.npcTransformId != -1) {
         return NetFileRequest.method4959(this.npcTransformId).getModelData();
      } else {
         boolean var1 = false;

         int var3;
         for(int var2 = 0; var2 < 12; ++var2) {
            var3 = this.equipment[var2];
            if (var3 >= 256 && var3 < 512 && !ClientPacket.method3233(var3 - 256).method5092()) {
               var1 = true;
            }

            if (var3 >= 512 && !Varcs.getItemDefinition(var3 - 512).method5477(this.isFemale)) {
               var1 = true;
            }
         }

         if (var1) {
            return null;
         } else {
            ModelData[] var7 = new ModelData[12];
            var3 = 0;

            int var5;
            for(int var4 = 0; var4 < 12; ++var4) {
               var5 = this.equipment[var4];
               ModelData var6;
               if (var5 >= 256 && var5 < 512) {
                  var6 = ClientPacket.method3233(var5 - 256).method5093();
                  if (var6 != null) {
                     var7[var3++] = var6;
                  }
               }

               if (var5 >= 512) {
                  var6 = Varcs.getItemDefinition(var5 - 512).method5509(this.isFemale);
                  if (var6 != null) {
                     var7[var3++] = var6;
                  }
               }
            }

            ModelData var8 = new ModelData(var7, var3);

            for(var5 = 0; var5 < 5; ++var5) {
               if (this.bodyColors[var5] < VarpDefinition.field2929[var5].length) {
                  var8.recolor(KeyHandler.field16[var5], VarpDefinition.field2929[var5][this.bodyColors[var5]]);
               }

               if (this.bodyColors[var5] < field2550[var5].length) {
                  var8.recolor(field2554[var5], field2550[var5][this.bodyColors[var5]]);
               }
            }

            return var8;
         }
      }
   }

   public Model getModel(SequenceDefinition var1, int var2, SequenceDefinition var3, int var4) {
      if (this.npcTransformId != -1) {
         return NetFileRequest.method4959(this.npcTransformId).getModel(var1, var2, var3, var4);
      } else {
         long var5 = this.field2552;
         int[] var7 = this.equipment;
         if (var1 != null && (var1.shield >= 0 || var1.weapon >= 0)) {
            var7 = new int[12];

            for(int var18 = 0; var18 < 12; ++var18) {
               var7[var18] = this.equipment[var18];
            }

            if (var1.shield >= 0) {
               var5 += (long)(var1.shield - this.equipment[5] << 40);
               var7[5] = var1.shield;
            }

            if (var1.weapon >= 0) {
               var5 += (long)(var1.weapon - this.equipment[3] << 48);
               var7[3] = var1.weapon;
            }
         }

         Model var8 = (Model)field2548.get(var5);
         if (var8 == null) {
            boolean var9 = false;

            int var11;
            for(int var10 = 0; var10 < 12; ++var10) {
               var11 = var7[var10];
               if (var11 >= 256 && var11 < 512 && !ClientPacket.method3233(var11 - 256).method5091()) {
                  var9 = true;
               }

               if (var11 >= 512 && !Varcs.getItemDefinition(var11 - 512).method5475(this.isFemale)) {
                  var9 = true;
               }
            }

            if (var9) {
               if (this.field2557 != -1L) {
                  var8 = (Model)field2548.get(this.field2557);
               }

               if (var8 == null) {
                  return null;
               }
            }

            if (var8 == null) {
               ModelData[] var15 = new ModelData[12];
               var11 = 0;

               int var13;
               for(int var12 = 0; var12 < 12; ++var12) {
                  var13 = var7[var12];
                  ModelData var14;
                  if (var13 >= 256 && var13 < 512) {
                     var14 = ClientPacket.method3233(var13 - 256).method5088();
                     if (var14 != null) {
                        var15[var11++] = var14;
                     }
                  }

                  if (var13 >= 512) {
                     var14 = Varcs.getItemDefinition(var13 - 512).method5476(this.isFemale);
                     if (var14 != null) {
                        var15[var11++] = var14;
                     }
                  }
               }

               ModelData var17 = new ModelData(var15, var11);

               for(var13 = 0; var13 < 5; ++var13) {
                  if (this.bodyColors[var13] < VarpDefinition.field2929[var13].length) {
                     var17.recolor(KeyHandler.field16[var13], VarpDefinition.field2929[var13][this.bodyColors[var13]]);
                  }

                  if (this.bodyColors[var13] < field2550[var13].length) {
                     var17.recolor(field2554[var13], field2550[var13][this.bodyColors[var13]]);
                  }
               }

               var8 = var17.toModel(64, 850, -30, -50, -30);
               field2548.put(var8, var5);
               this.field2557 = var5;
            }
         }

         if (var1 == null && var3 == null) {
            return var8;
         } else {
            Model var16;
            if (var1 != null && var3 != null) {
               var16 = var1.animateSequence2(var8, var2, var3, var4);
            } else if (var1 != null) {
               var16 = var1.animateSequence(var8, var2);
            } else {
               var16 = var3.animateSequence(var8, var4);
            }

            return var16;
         }
      }
   }

   public void method4503(boolean var1) {
      if (this.isFemale != var1) {
         this.method4500((int[])null, this.bodyColors, var1, -1);
      }
   }

   public void method4501(int var1, boolean var2) {
      if (var1 != 1 || !this.isFemale) {
         int var3 = this.equipment[field2556[var1]];
         if (var3 != 0) {
            var3 -= 256;

            KitDefinition var4;
            do {
               if (!var2) {
                  --var3;
                  if (var3 < 0) {
                     var3 = KitDefinition.field3344 - 1;
                  }
               } else {
                  ++var3;
                  if (var3 >= KitDefinition.field3344) {
                     var3 = 0;
                  }
               }

               var4 = ClientPacket.method3233(var3);
            } while(var4 == null || var4.field3353 || var4.field3342 != (this.isFemale ? 7 : 0) + var1);

            this.equipment[field2556[var1]] = var3 + 256;
            this.method4505();
         }
      }
   }
}
