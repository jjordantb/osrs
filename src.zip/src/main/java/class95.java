public class class95 {
   static final class95 field1042 = new class95(0);
   static final class95 field1036 = new class95(1);
   final int field1038;

   class95(int var1) {
      this.field1038 = var1;
   }

   public static UnderlayDefinition method1799(int var0) {
      UnderlayDefinition var1 = (UnderlayDefinition)UnderlayDefinition.field3561.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         byte[] var2 = UnderlayDefinition.field3567.takeRecord(1, var0);
         var1 = new UnderlayDefinition();
         if (var2 != null) {
            var1.read(new Buffer(var2), var0);
         }

         var1.init();
         UnderlayDefinition.field3561.put(var1, (long)var0);
         return var1;
      }
   }

   public static boolean method1798(char var0) {
      if (var0 >= ' ' && var0 <= '~') {
         return true;
      } else if (var0 >= ' ' && var0 <= 'ÿ') {
         return true;
      } else {
         return var0 == '€' || var0 == 'Œ' || var0 == '—' || var0 == 'œ' || var0 == 'Ÿ';
      }
   }

   static Frames method1800(int var0) {
      Frames var1 = (Frames)SequenceDefinition.field3467.get((long)var0);
      if (var1 != null) {
         return var1;
      } else {
         AbstractIndexCache var3 = SequenceDefinition.field3464;
         AbstractIndexCache var4 = SequenceDefinition.field3465;
         boolean var5 = true;
         int[] var6 = var3.method4975(var0);

         for(int var7 = 0; var7 < var6.length; ++var7) {
            byte[] var8 = var3.getRecord(var0, var6[var7]);
            if (var8 == null) {
               var5 = false;
            } else {
               int var9 = (var8[0] & 255) << 8 | var8[1] & 255;
               byte[] var10 = var4.getRecord(var9, 0);
               if (var10 == null) {
                  var5 = false;
               }
            }
         }

         Frames var2;
         if (!var5) {
            var2 = null;
         } else {
            try {
               var2 = new Frames(var3, var4, var0, false);
            } catch (Exception var12) {
               var2 = null;
            }
         }

         if (var2 != null) {
            SequenceDefinition.field3467.put(var2, (long)var0);
         }

         return var2;
      }
   }

   static void method1797(int var0) {
      Client.field2161 = var0;
   }
}
