public class HealthBarDefinition extends DualNode {
   public static EvictingDualNodeHashTable field3452 = new EvictingDualNodeHashTable(64);
   public static AbstractIndexCache field3456;
   public static EvictingDualNodeHashTable field3449 = new EvictingDualNodeHashTable(64);
   public static AbstractIndexCache field3447;
   public int field3450;
   int spriteId1 = -1;
   public int int3 = -1;
   int spriteId2 = -1;
   public int int5 = 70;
   public int int2 = 255;
   public int int4 = 1;
   public int widthPadding = 0;
   public int int1 = 255;
   public int width = 30;

   public Sprite getSprite2() {
      if (this.spriteId2 < 0) {
         return null;
      } else {
         Sprite var1 = (Sprite)field3449.get((long)this.spriteId2);
         if (var1 != null) {
            return var1;
         } else {
            var1 = UserComparator3.method2971(field3447, this.spriteId2, 0);
            if (var1 != null) {
               field3449.put(var1, (long)this.spriteId2);
            }

            return var1;
         }
      }
   }

   void readNext(Buffer var1, int var2) {
      if (var2 == 1) {
         var1.method3913();
      } else if (var2 == 2) {
         this.int1 = var1.readUnsignedByte();
      } else if (var2 == 3) {
         this.int2 = var1.readUnsignedByte();
      } else if (var2 == 4) {
         this.int3 = 0;
      } else if (var2 == 5) {
         this.int5 = var1.method3913();
      } else if (var2 == 6) {
         var1.readUnsignedByte();
      } else if (var2 == 7) {
         this.spriteId1 = var1.method4040();
      } else if (var2 == 8) {
         this.spriteId2 = var1.method4040();
      } else if (var2 == 11) {
         this.int3 = var1.method3913();
      } else if (var2 == 14) {
         this.width = var1.readUnsignedByte();
      } else if (var2 == 15) {
         this.widthPadding = var1.readUnsignedByte();
      }

   }

   public Sprite getSprite1() {
      if (this.spriteId1 < 0) {
         return null;
      } else {
         Sprite var1 = (Sprite)field3449.get((long)this.spriteId1);
         if (var1 != null) {
            return var1;
         } else {
            var1 = UserComparator3.method2971(field3447, this.spriteId1, 0);
            if (var1 != null) {
               field3449.put(var1, (long)this.spriteId1);
            }

            return var1;
         }
      }
   }

   void read(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.readNext(var1, var2);
      }
   }
}
