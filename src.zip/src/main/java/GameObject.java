import java.awt.Image;

public final class GameObject {
   static Image field1636;
   int startX;
   public Entity entity;
   public long tag = 0L;
   int centerX;
   int plane;
   int endY;
   int flags = 0;
   int orientation;
   int lastDrawn;
   int startY;
   int field1646;
   int centerY;
   int height;
   int endX;

   public static void method2901(AbstractIndexCache var0) {
      ParamsDefinition.field3484 = var0;
   }

   public static RectangleMode[] method2904() {
      return new RectangleMode[]{RectangleMode.field4000, RectangleMode.field4001, RectangleMode.field4002};
   }

   static void method2900(Font var0, Font var1, Font var2, boolean var3) {
      if (var3) {
         Login.field649 = (FriendSystem.field379 - 765) / 2;
         Login.field650 = Login.field649 + 202;
         class73.field854 = Login.field650 + 180;
      }

      int var7;
      int var12;
      int var13;
      boolean var15;
      int var16;
      byte var22;
      int var23;
      int var26;
      int var32;
      int var34;
      int var35;
      int var36;
      int var38;
      int var40;
      if (Login.field682) {
         if (AttackOption.field603 == null) {
            AttackOption.field603 = class279.method5407(RunException.field1608, "sl_back", "");
         }

         IndexedSprite[] var8;
         IndexCache var31;
         if (BufferedFile.field1424 == null) {
            var31 = RunException.field1608;
            var32 = var31.getArchiveId("sl_flags");
            var7 = var31.getRecordId(var32, "");
            if (!class65.method1382(var31, var32, var7)) {
               var8 = null;
            } else {
               var8 = SpriteIds.method5817();
            }

            BufferedFile.field1424 = var8;
         }

         if (class85.field967 == null) {
            var31 = RunException.field1608;
            var32 = var31.getArchiveId("sl_arrows");
            var7 = var31.getRecordId(var32, "");
            if (!class65.method1382(var31, var32, var7)) {
               var8 = null;
            } else {
               var8 = SpriteIds.method5817();
            }

            class85.field967 = var8;
         }

         if (Tiles.field224 == null) {
            var31 = RunException.field1608;
            var32 = var31.getArchiveId("sl_stars");
            var7 = var31.getRecordId(var32, "");
            if (!class65.method1382(var31, var32, var7)) {
               var8 = null;
            } else {
               var8 = SpriteIds.method5817();
            }

            Tiles.field224 = var8;
         }

         Rasterizer2D.method6223(Login.field649, 23, 765, 480, 0);
         Rasterizer2D.method6228(Login.field649, 0, 125, 23, 12425273, 9135624);
         Rasterizer2D.method6228(Login.field649 + 125, 0, 640, 23, 5197647, 2697513);
         var0.drawCentered("Select a world", Login.field649 + 62, 15, 0, -1);
         if (Tiles.field224 != null) {
            Tiles.field224[1].method6304(Login.field649 + 140, 1);
            var1.draw("Members only world", Login.field649 + 152, 10, 16777215, -1);
            Tiles.field224[0].method6304(Login.field649 + 140, 12);
            var1.draw("Free world", Login.field649 + 152, 21, 16777215, -1);
         }

         if (class85.field967 != null) {
            var40 = Login.field649 + 280;
            if (World.field352[0] == 0 && World.field354[0] == 0) {
               class85.field967[2].method6304(var40, 4);
            } else {
               class85.field967[0].method6304(var40, 4);
            }

            if (World.field352[0] == 0 && World.field354[0] == 1) {
               class85.field967[3].method6304(var40 + 15, 4);
            } else {
               class85.field967[1].method6304(var40 + 15, 4);
            }

            var0.draw("World", var40 + 32, 17, 16777215, -1);
            var23 = Login.field649 + 390;
            if (World.field352[0] == 1 && World.field354[0] == 0) {
               class85.field967[2].method6304(var23, 4);
            } else {
               class85.field967[0].method6304(var23, 4);
            }

            if (World.field352[0] == 1 && World.field354[0] == 1) {
               class85.field967[3].method6304(var23 + 15, 4);
            } else {
               class85.field967[1].method6304(var23 + 15, 4);
            }

            var0.draw("Players", var23 + 32, 17, 16777215, -1);
            var32 = Login.field649 + 500;
            if (World.field352[0] == 2 && World.field354[0] == 0) {
               class85.field967[2].method6304(var32, 4);
            } else {
               class85.field967[0].method6304(var32, 4);
            }

            if (World.field352[0] == 2 && World.field354[0] == 1) {
               class85.field967[3].method6304(var32 + 15, 4);
            } else {
               class85.field967[1].method6304(var32 + 15, 4);
            }

            var0.draw("Location", var32 + 32, 17, 16777215, -1);
            var7 = Login.field649 + 610;
            if (World.field352[0] == 3 && World.field354[0] == 0) {
               class85.field967[2].method6304(var7, 4);
            } else {
               class85.field967[0].method6304(var7, 4);
            }

            if (World.field352[0] == 3 && World.field354[0] == 1) {
               class85.field967[3].method6304(var7 + 15, 4);
            } else {
               class85.field967[1].method6304(var7 + 15, 4);
            }

            var0.draw("Type", var7 + 32, 17, 16777215, -1);
         }

         Rasterizer2D.method6223(Login.field649 + 708, 4, 50, 16, 0);
         var1.drawCentered("Cancel", Login.field649 + 708 + 25, 16, 16777215, -1);
         Login.field670 = -1;
         if (AttackOption.field603 != null) {
            var22 = 88;
            byte var44 = 19;
            var32 = 765 / (var22 + 1);
            var7 = 480 / (var44 + 1);

            do {
               var26 = var7;
               var34 = var32;
               if (var7 * (var32 - 1) >= World.field349) {
                  --var32;
               }

               if (var32 * (var7 - 1) >= World.field349) {
                  --var7;
               }

               if (var32 * (var7 - 1) >= World.field349) {
                  --var7;
               }
            } while(var26 != var7 || var34 != var32);

            var26 = (765 - var32 * var22) / (var32 + 1);
            if (var26 > 5) {
               var26 = 5;
            }

            var34 = (480 - var44 * var7) / (var7 + 1);
            if (var34 > 5) {
               var34 = 5;
            }

            var35 = (765 - var22 * var32 - var26 * (var32 - 1)) / 2;
            var36 = (480 - var44 * var7 - var34 * (var7 - 1)) / 2;
            var12 = var36 + 23;
            var13 = var35 + Login.field649;
            var38 = 0;
            var15 = false;

            for(var16 = 0; var16 < World.field349; ++var16) {
               World var17 = World.field353[var16];
               boolean var18 = true;
               String var19 = Integer.toString(var17.population);
               if (var17.population == -1) {
                  var19 = "OFF";
                  var18 = false;
               } else if (var17.population > 1980) {
                  var19 = "FULL";
                  var18 = false;
               }

               int var21 = 0;
               byte var20;
               if (var17.method651()) {
                  if (var17.method649()) {
                     var20 = 7;
                  } else {
                     var20 = 6;
                  }
               } else if (var17.method654()) {
                  var21 = 16711680;
                  if (var17.method649()) {
                     var20 = 5;
                  } else {
                     var20 = 4;
                  }
               } else if (var17.method652()) {
                  if (var17.method649()) {
                     var20 = 3;
                  } else {
                     var20 = 2;
                  }
               } else if (var17.method649()) {
                  var20 = 1;
               } else {
                  var20 = 0;
               }

               if (MouseHandler.field154 >= var13 && MouseHandler.field145 * -976212263 >= var12 && MouseHandler.field154 < var22 + var13 && MouseHandler.field145 * -976212263 < var44 + var12 && var18) {
                  Login.field670 = var16;
                  AttackOption.field603[var20].method6383(var13, var12, 128, 16777215);
                  var15 = true;
               } else {
                  AttackOption.field603[var20].method6368(var13, var12);
               }

               if (BufferedFile.field1424 != null) {
                  BufferedFile.field1424[(var17.method649() ? 8 : 0) + var17.location].method6304(var13 + 29, var12);
               }

               var0.drawCentered(Integer.toString(var17.id), var13 + 15, var44 / 2 + var12 + 5, var21, -1);
               var1.drawCentered(var19, var13 + 60, var44 / 2 + var12 + 5, 268435455, -1);
               var12 = var12 + var34 + var44;
               ++var38;
               if (var38 >= var7) {
                  var12 = var36 + 23;
                  var13 = var13 + var22 + var26;
                  var38 = 0;
               }
            }

            if (var15) {
               var16 = var1.stringWidth(World.field353[Login.field670].activity) + 6;
               int var43 = var1.ascent + 8;
               Rasterizer2D.method6223(MouseHandler.field154 - var16 / 2, MouseHandler.field145 * -976212263 + 20 + 5, var16, var43, 16777120);
               Rasterizer2D.method6292(MouseHandler.field154 - var16 / 2, MouseHandler.field145 * -976212263 + 20 + 5, var16, var43, 0);
               var1.drawCentered(World.field353[Login.field670].activity, MouseHandler.field154, MouseHandler.field145 * -976212263 + var1.ascent + 20 + 5 + 4, 0, -1);
            }
         }

         WorldMapManager.field45.drawFull(0, 0);
      } else {
         if (var3) {
            Login.field651.method6368(Login.field649, 0);
            Login.field652.method6368(Login.field649 + 382, 0);
            VarbitDefinition.field3505.method6304(Login.field649 + 382 - VarbitDefinition.field3505.subWidth / 2, 18);
         }

         if (Client.field2163 == 0 || Client.field2163 == 5) {
            var22 = 20;
            var0.drawCentered("RuneScape is loading - please wait...", Login.field650 + 180, 245 - var22, 16777215, -1);
            var23 = 253 - var22;
            Rasterizer2D.method6292(Login.field650 + 180 - 152, var23, 304, 34, 9179409);
            Rasterizer2D.method6292(Login.field650 + 180 - 151, var23 + 1, 302, 32, 0);
            Rasterizer2D.method6223(Login.field650 + 180 - 150, var23 + 2, Login.field664 * 3, 30, 9179409);
            Rasterizer2D.method6223(Login.field664 * 3 + (Login.field650 + 180 - 150), var23 + 2, 300 - Login.field664 * 3, 30, 0);
            var0.drawCentered(Login.field665, Login.field650 + 180, 276 - var22, 16777215, -1);
         }

         String var24;
         String var25;
         short var39;
         short var41;
         if (Client.field2163 == 20) {
            Login.field655.method6304(Login.field650 + 180 - Login.field655.subWidth / 2, 271 - Login.field655.subHeight / 2);
            var39 = 201;
            var0.drawCentered(Login.field671, Login.field650 + 180, var39, 16776960, 0);
            var40 = var39 + 15;
            var0.drawCentered(Login.field672, Login.field650 + 180, var40, 16776960, 0);
            var40 += 15;
            var0.drawCentered(Login.field673, Login.field650 + 180, var40, 16776960, 0);
            var40 += 15;
            var40 += 7;
            if (Login.field669 != 4) {
               var0.draw("Login: ", Login.field650 + 180 - 110, var40, 16777215, 0);
               var41 = 200;
               var24 = GameShell.field72.hideUsername ? IndexStoreAction.method4779(Login.field686) : Login.field686;

               for(var25 = var24; var0.stringWidth(var25) > var41; var25 = var25.substring(0, var25.length() - 1)) {
                  ;
               }

               var0.draw(AbstractFont.method5851(var25), Login.field650 + 180 - 70, var40, 16777215, 0);
               var40 += 15;
               var0.draw("Password: " + IndexStoreAction.method4779(Login.field675), Login.field650 + 180 - 108, var40, 16777215, 0);
               var40 += 15;
            }
         }

         if (Client.field2163 == 10 || Client.field2163 == 11) {
            Login.field655.method6304(Login.field650, 171);
            short var6;
            if (Login.field669 == 0) {
               var39 = 251;
               var0.drawCentered("Welcome to RuneScape", Login.field650 + 180, var39, 16776960, 0);
               var40 = var39 + 30;
               var23 = Login.field650 + 180 - 80;
               var6 = 291;
               class294.field3719.method6304(var23 - 73, var6 - 20);
               var0.drawLines("New User", var23 - 73, var6 - 20, 144, 40, 16777215, 0, 1, 1, 0);
               var23 = Login.field650 + 180 + 80;
               class294.field3719.method6304(var23 - 73, var6 - 20);
               var0.drawLines("Existing User", var23 - 73, var6 - 20, 144, 40, 16777215, 0, 1, 1, 0);
            } else if (Login.field669 == 1) {
               var0.drawCentered(Login.field674, Login.field650 + 180, 201, 16776960, 0);
               var39 = 236;
               var0.drawCentered(Login.field671, Login.field650 + 180, var39, 16777215, 0);
               var40 = var39 + 15;
               var0.drawCentered(Login.field672, Login.field650 + 180, var40, 16777215, 0);
               var40 += 15;
               var0.drawCentered(Login.field673, Login.field650 + 180, var40, 16777215, 0);
               var40 += 15;
               var23 = Login.field650 + 180 - 80;
               var6 = 321;
               class294.field3719.method6304(var23 - 73, var6 - 20);
               var0.drawCentered("Continue", var23, var6 + 5, 16777215, 0);
               var23 = Login.field650 + 180 + 80;
               class294.field3719.method6304(var23 - 73, var6 - 20);
               var0.drawCentered("Cancel", var23, var6 + 5, 16777215, 0);
            } else if (Login.field669 == 2) {
               var39 = 201;
               var0.drawCentered(Login.field671, class73.field854, var39, 16776960, 0);
               var40 = var39 + 15;
               var0.drawCentered(Login.field672, class73.field854, var40, 16776960, 0);
               var40 += 15;
               var0.drawCentered(Login.field673, class73.field854, var40, 16776960, 0);
               var40 += 15;
               var40 += 7;
               var0.draw("Login: ", class73.field854 - 110, var40, 16777215, 0);
               var41 = 200;
               var24 = GameShell.field72.hideUsername ? IndexStoreAction.method4779(Login.field686) : Login.field686;

               for(var25 = var24; var0.stringWidth(var25) > var41; var25 = var25.substring(1)) {
                  ;
               }

               var0.draw(AbstractFont.method5851(var25) + (Login.field656 == 0 & Client.field2098 % 40 < 20 ? ModelData0.method2792(16776960) + "|" : ""), class73.field854 - 70, var40, 16777215, 0);
               var40 += 15;
               var0.draw("Password: " + IndexStoreAction.method4779(Login.field675) + (Login.field656 == 1 & Client.field2098 % 40 < 20 ? ModelData0.method2792(16776960) + "|" : ""), class73.field854 - 108, var40, 16777215, 0);
               var40 += 15;
               var39 = 277;
               var26 = class73.field854 + -117;
               boolean var10 = Client.field2189;
               boolean var11 = Login.field676;
               IndexedSprite var28 = var10 ? (var11 ? UrlRequest.field1614 : Frames.field1635) : (var11 ? Login.field654 : ByteArrayPool.field2470);
               var28.method6304(var26, var39);
               var26 = var26 + var28.subWidth + 5;
               var1.draw("Remember username", var26, var39 + 13, 16776960, 0);
               var26 = class73.field854 + 24;
               boolean var14 = GameShell.field72.hideUsername;
               var15 = Login.field677;
               IndexedSprite var30 = var14 ? (var15 ? UrlRequest.field1614 : Frames.field1635) : (var15 ? Login.field654 : ByteArrayPool.field2470);
               var30.method6304(var26, var39);
               var26 = var26 + var30.subWidth + 5;
               var1.draw("Hide username", var26, var39 + 13, 16776960, 0);
               var40 = var39 + 15;
               var16 = class73.field854 - 80;
               short var27 = 321;
               class294.field3719.method6304(var16 - 73, var27 - 20);
               var0.drawCentered("Login", var16, var27 + 5, 16777215, 0);
               var16 = class73.field854 + 80;
               class294.field3719.method6304(var16 - 73, var27 - 20);
               var0.drawCentered("Cancel", var16, var27 + 5, 16777215, 0);
               var39 = 357;
               switch(Login.field667) {
               case 2:
                  SpriteMask.field2800 = "Having trouble logging in?";
                  break;
               default:
                  SpriteMask.field2800 = "Forgotten your password? <col=ffffff>Click here.";
               }

               Login.field683 = new Bounds(class73.field854, var39, var1.stringWidth(SpriteMask.field2800), 11);
               var1.drawCentered(SpriteMask.field2800, class73.field854, var39, 16777215, 0);
            } else if (Login.field669 == 3) {
               var39 = 201;
               var0.drawCentered("Invalid username or password.", Login.field650 + 180, var39, 16776960, 0);
               var40 = var39 + 20;
               var1.drawCentered("For accounts created after 24th November 2010, please use your", Login.field650 + 180, var40, 16776960, 0);
               var40 += 15;
               var1.drawCentered("email address to login. Otherwise please login with your username.", Login.field650 + 180, var40, 16776960, 0);
               var40 += 15;
               var23 = Login.field650 + 180;
               var6 = 276;
               class294.field3719.method6304(var23 - 73, var6 - 20);
               var2.drawCentered("Try again", var23, var6 + 5, 16777215, 0);
               var23 = Login.field650 + 180;
               var6 = 326;
               class294.field3719.method6304(var23 - 73, var6 - 20);
               var2.drawCentered("Forgotten password?", var23, var6 + 5, 16777215, 0);
            } else {
               short var9;
               if (Login.field669 == 4) {
                  var0.drawCentered("Authenticator", Login.field650 + 180, 201, 16776960, 0);
                  var39 = 236;
                  var0.drawCentered(Login.field671, Login.field650 + 180, var39, 16777215, 0);
                  var40 = var39 + 15;
                  var0.drawCentered(Login.field672, Login.field650 + 180, var40, 16777215, 0);
                  var40 += 15;
                  var0.drawCentered(Login.field673, Login.field650 + 180, var40, 16777215, 0);
                  var40 += 15;
                  var0.draw("PIN: " + IndexStoreAction.method4779(class85.field968) + (Client.field2098 % 40 < 20 ? ModelData0.method2792(16776960) + "|" : ""), Login.field650 + 180 - 108, var40, 16777215, 0);
                  var40 -= 8;
                  var0.draw("Trust this computer", Login.field650 + 180 - 9, var40, 16776960, 0);
                  var40 += 15;
                  var0.draw("for 30 days: ", Login.field650 + 180 - 9, var40, 16776960, 0);
                  var23 = Login.field650 + 180 - 9 + var0.stringWidth("for 30 days: ") + 15;
                  var32 = var40 - var0.ascent;
                  IndexedSprite var42;
                  if (Login.field678) {
                     var42 = Frames.field1635;
                  } else {
                     var42 = ByteArrayPool.field2470;
                  }

                  var42.method6304(var23, var32);
                  var40 += 15;
                  var26 = Login.field650 + 180 - 80;
                  var9 = 321;
                  class294.field3719.method6304(var26 - 73, var9 - 20);
                  var0.drawCentered("Continue", var26, var9 + 5, 16777215, 0);
                  var26 = Login.field650 + 180 + 80;
                  class294.field3719.method6304(var26 - 73, var9 - 20);
                  var0.drawCentered("Cancel", var26, var9 + 5, 16777215, 0);
                  var1.drawCentered("<u=ff>Can't Log In?</u>", Login.field650 + 180, var9 + 36, 255, 0);
               } else if (Login.field669 == 5) {
                  var0.drawCentered("Forgotten your password?", Login.field650 + 180, 201, 16776960, 0);
                  var39 = 221;
                  var2.drawCentered(Login.field671, Login.field650 + 180, var39, 16776960, 0);
                  var40 = var39 + 15;
                  var2.drawCentered(Login.field672, Login.field650 + 180, var40, 16776960, 0);
                  var40 += 15;
                  var2.drawCentered(Login.field673, Login.field650 + 180, var40, 16776960, 0);
                  var40 += 15;
                  var40 += 14;
                  var0.draw("Username/email: ", Login.field650 + 180 - 145, var40, 16777215, 0);
                  var41 = 174;
                  var24 = GameShell.field72.hideUsername ? IndexStoreAction.method4779(Login.field686) : Login.field686;

                  for(var25 = var24; var0.stringWidth(var25) > var41; var25 = var25.substring(1)) {
                     ;
                  }

                  var0.draw(AbstractFont.method5851(var25) + (Client.field2098 % 40 < 20 ? ModelData0.method2792(16776960) + "|" : ""), Login.field650 + 180 - 34, var40, 16777215, 0);
                  var40 += 15;
                  var26 = Login.field650 + 180 - 80;
                  var9 = 321;
                  class294.field3719.method6304(var26 - 73, var9 - 20);
                  var0.drawCentered("Recover", var26, var9 + 5, 16777215, 0);
                  var26 = Login.field650 + 180 + 80;
                  class294.field3719.method6304(var26 - 73, var9 - 20);
                  var0.drawCentered("Back", var26, var9 + 5, 16777215, 0);
               } else if (Login.field669 == 6) {
                  var39 = 201;
                  var0.drawCentered(Login.field671, Login.field650 + 180, var39, 16776960, 0);
                  var40 = var39 + 15;
                  var0.drawCentered(Login.field672, Login.field650 + 180, var40, 16776960, 0);
                  var40 += 15;
                  var0.drawCentered(Login.field673, Login.field650 + 180, var40, 16776960, 0);
                  var40 += 15;
                  var23 = Login.field650 + 180;
                  var6 = 321;
                  class294.field3719.method6304(var23 - 73, var6 - 20);
                  var0.drawCentered("Back", var23, var6 + 5, 16777215, 0);
               } else if (Login.field669 == 7) {
                  var39 = 216;
                  var0.drawCentered("Your date of birth isn't set.", Login.field650 + 180, var39, 16776960, 0);
                  var40 = var39 + 15;
                  var2.drawCentered("Please verify your account status by", Login.field650 + 180, var40, 16776960, 0);
                  var40 += 15;
                  var2.drawCentered("setting your date of birth.", Login.field650 + 180, var40, 16776960, 0);
                  var40 += 15;
                  var23 = Login.field650 + 180 - 80;
                  var6 = 321;
                  class294.field3719.method6304(var23 - 73, var6 - 20);
                  var0.drawCentered("Set Date of Birth", var23, var6 + 5, 16777215, 0);
                  var23 = Login.field650 + 180 + 80;
                  class294.field3719.method6304(var23 - 73, var6 - 20);
                  var0.drawCentered("Back", var23, var6 + 5, 16777215, 0);
               } else if (Login.field669 == 8) {
                  var39 = 216;
                  var0.drawCentered("Sorry, but your account is not eligible to play.", Login.field650 + 180, var39, 16776960, 0);
                  var40 = var39 + 15;
                  var2.drawCentered("For more information, please take a look at", Login.field650 + 180, var40, 16776960, 0);
                  var40 += 15;
                  var2.drawCentered("our privacy policy.", Login.field650 + 180, var40, 16776960, 0);
                  var40 += 15;
                  var23 = Login.field650 + 180 - 80;
                  var6 = 321;
                  class294.field3719.method6304(var23 - 73, var6 - 20);
                  var0.drawCentered("Privacy Policy", var23, var6 + 5, 16777215, 0);
                  var23 = Login.field650 + 180 + 80;
                  class294.field3719.method6304(var23 - 73, var6 - 20);
                  var0.drawCentered("Back", var23, var6 + 5, 16777215, 0);
               } else if (Login.field669 == 12) {
                  var39 = 201;
                  String var5 = "";
                  var24 = "";
                  var25 = "";
                  switch(Login.field648) {
                  case 0:
                     var5 = "Your account has been disabled.";
                     var24 = Strings.field3007;
                     var25 = "";
                     break;
                  case 1:
                     var5 = "Account locked as we suspect it has been stolen.";
                     var24 = Strings.field3046;
                     var25 = "";
                     break;
                  default:
                     class21.method544(false);
                  }

                  var0.drawCentered(var5, Login.field650 + 180, var39, 16776960, 0);
                  var40 = var39 + 15;
                  var2.drawCentered(var24, Login.field650 + 180, var40, 16776960, 0);
                  var40 += 15;
                  var2.drawCentered(var25, Login.field650 + 180, var40, 16776960, 0);
                  var40 += 15;
                  var26 = Login.field650 + 180;
                  var9 = 276;
                  class294.field3719.method6304(var26 - 73, var9 - 20);
                  var0.drawCentered("Support Page", var26, var9 + 5, 16777215, 0);
                  var26 = Login.field650 + 180;
                  var9 = 326;
                  class294.field3719.method6304(var26 - 73, var9 - 20);
                  var0.drawCentered("Back", var26, var9 + 5, 16777215, 0);
               }
            }
         }

         if (Login.field662 > 0) {
            var40 = Login.field662;
            var41 = 256;
            Login.field666 += var40 * 128;
            if (Login.field666 > OwnWorldComparator.field274.length) {
               Login.field666 -= OwnWorldComparator.field274.length;
               var32 = (int)(Math.random() * 12.0D);
               class273.method5343(class57.field640[var32]);
            }

            var32 = 0;
            var7 = var40 * 128;
            var26 = (var41 - var40) * 128;

            for(var34 = 0; var34 < var26; ++var34) {
               var35 = class93.field1025[var7 + var32] - OwnWorldComparator.field274[var32 + Login.field666 & OwnWorldComparator.field274.length - 1] * var40 / 6;
               if (var35 < 0) {
                  var35 = 0;
               }

               class93.field1025[var32++] = var35;
            }

            for(var34 = var41 - var40; var34 < var41; ++var34) {
               var35 = var34 * 128;

               for(var36 = 0; var36 < 128; ++var36) {
                  var12 = (int)(Math.random() * 100.0D);
                  if (var12 < 50 && var36 > 10 && var36 < 118) {
                     class93.field1025[var36 + var35] = 255;
                  } else {
                     class93.field1025[var35 + var36] = 0;
                  }
               }
            }

            if (Login.field658 > 0) {
               Login.field658 -= var40 * 4;
            }

            if (Login.field659 > 0) {
               Login.field659 -= var40 * 4;
            }

            if (Login.field658 == 0 && Login.field659 == 0) {
               var34 = (int)(Math.random() * (double)(2000 / var40));
               if (var34 == 0) {
                  Login.field658 = 1024;
               }

               if (var34 == 1) {
                  Login.field659 = 1024;
               }
            }

            for(var34 = 0; var34 < var41 - var40; ++var34) {
               Login.field668[var34] = Login.field668[var34 + var40];
            }

            for(var34 = var41 - var40; var34 < var41; ++var34) {
               Login.field668[var34] = (int)(Math.sin((double)Login.field663 / 14.0D) * 16.0D + Math.sin((double)Login.field663 / 15.0D) * 14.0D + Math.sin((double)Login.field663 / 16.0D) * 12.0D);
               ++Login.field663;
            }

            Login.field679 += var40;
            var34 = (var40 + (Client.field2098 & 1)) / 2;
            if (var34 > 0) {
               for(var35 = 0; var35 < Login.field679 * 100; ++var35) {
                  var36 = (int)(Math.random() * 124.0D) + 2;
                  var12 = (int)(Math.random() * 128.0D) + 128;
                  class93.field1025[var36 + (var12 << 7)] = 192;
               }

               Login.field679 = 0;
               var35 = 0;

               label744:
               while(true) {
                  if (var35 >= var41) {
                     var35 = 0;

                     while(true) {
                        if (var35 >= 128) {
                           break label744;
                        }

                        var36 = 0;

                        for(var12 = -var34; var12 < var41; ++var12) {
                           var13 = var12 * 128;
                           if (var34 + var12 < var41) {
                              var36 += class93.field1026[var35 + var13 + var34 * 128];
                           }

                           if (var12 - (var34 + 1) >= 0) {
                              var36 -= class93.field1026[var13 + var35 - (var34 + 1) * 128];
                           }

                           if (var12 >= 0) {
                              class93.field1025[var35 + var13] = var36 / (var34 * 2 + 1);
                           }
                        }

                        ++var35;
                     }
                  }

                  var36 = 0;
                  var12 = var35 * 128;

                  for(var13 = -var34; var13 < 128; ++var13) {
                     if (var34 + var13 < 128) {
                        var36 += class93.field1025[var13 + var12 + var34];
                     }

                     if (var13 - (var34 + 1) >= 0) {
                        var36 -= class93.field1025[var12 + var13 - (var34 + 1)];
                     }

                     if (var13 >= 0) {
                        class93.field1026[var13 + var12] = var36 / (var34 * 2 + 1);
                     }
                  }

                  ++var35;
               }
            }

            Login.field662 = 0;
         }

         var39 = 256;
         if (Login.field658 > 0) {
            for(var23 = 0; var23 < 256; ++var23) {
               if (Login.field658 > 768) {
                  ObjectSound.field573[var23] = Login.method1254(Login.field657[var23], MouseRecorder.field505[var23], 1024 - Login.field658);
               } else if (Login.field658 > 256) {
                  ObjectSound.field573[var23] = MouseRecorder.field505[var23];
               } else {
                  ObjectSound.field573[var23] = Login.method1254(MouseRecorder.field505[var23], Login.field657[var23], 256 - Login.field658);
               }
            }
         } else if (Login.field659 > 0) {
            for(var23 = 0; var23 < 256; ++var23) {
               if (Login.field659 > 768) {
                  ObjectSound.field573[var23] = Login.method1254(Login.field657[var23], BufferedNetSocket.field1783[var23], 1024 - Login.field659);
               } else if (Login.field659 > 256) {
                  ObjectSound.field573[var23] = BufferedNetSocket.field1783[var23];
               } else {
                  ObjectSound.field573[var23] = Login.method1254(BufferedNetSocket.field1783[var23], Login.field657[var23], 256 - Login.field659);
               }
            }
         } else {
            for(var23 = 0; var23 < 256; ++var23) {
               ObjectSound.field573[var23] = Login.field657[var23];
            }
         }

         Rasterizer2D.method6243(Login.field649, 9, Login.field649 + 128, var39 + 7);
         Login.field651.method6368(Login.field649, 0);
         Rasterizer2D.method6213();
         var23 = 0;
         var32 = WorldMapManager.field45.width * 9 + Login.field649;

         for(var7 = 1; var7 < var39 - 1; ++var7) {
            var26 = Login.field668[var7] * (var39 - var7) / var39;
            var34 = var26 + 22;
            if (var34 < 0) {
               var34 = 0;
            }

            var23 += var34;

            for(var35 = var34; var35 < 128; ++var35) {
               var36 = class93.field1025[var23++];
               if (var36 != 0) {
                  var12 = var36;
                  var13 = 256 - var36;
                  var36 = ObjectSound.field573[var36];
                  var38 = WorldMapManager.field45.pixels[var32];
                  WorldMapManager.field45.pixels[var32++] = ((var36 & 16711935) * var12 + (var38 & 16711935) * var13 & -16711936) + (var13 * (var38 & '\uff00') + var12 * (var36 & '\uff00') & 16711680) >> 8;
               } else {
                  ++var32;
               }
            }

            var32 += var34 + WorldMapManager.field45.width - 128;
         }

         Rasterizer2D.method6243(Login.field649 + 765 - 128, 9, Login.field649 + 765, var39 + 7);
         Login.field652.method6368(Login.field649 + 382, 0);
         Rasterizer2D.method6213();
         var23 = 0;
         var32 = WorldMapManager.field45.width * 9 + Login.field649 + 637 + 24;

         for(var7 = 1; var7 < var39 - 1; ++var7) {
            var26 = Login.field668[var7] * (var39 - var7) / var39;
            var34 = 103 - var26;
            var32 += var26;

            for(var35 = 0; var35 < var34; ++var35) {
               var36 = class93.field1025[var23++];
               if (var36 != 0) {
                  var12 = var36;
                  var13 = 256 - var36;
                  var36 = ObjectSound.field573[var36];
                  var38 = WorldMapManager.field45.pixels[var32];
                  WorldMapManager.field45.pixels[var32++] = (var13 * (var38 & '\uff00') + var12 * (var36 & '\uff00') & 16711680) + ((var38 & 16711935) * var13 + (var36 & 16711935) * var12 & -16711936) >> 8;
               } else {
                  ++var32;
               }
            }

            var23 += 128 - var34;
            var32 += WorldMapManager.field45.width - var34 - var26;
         }

         Login.field653[GameShell.field72.titleMusicDisabled ? 1 : 0].method6304(Login.field649 + 765 - 40, 463);
         if (Client.field2163 > 5 && Client.field2228 == 0) {
            if (class85.field963 != null) {
               var40 = Login.field649 + 5;
               var41 = 463;
               byte var37 = 100;
               byte var33 = 35;
               class85.field963.method6304(var40, var41);
               var0.drawCentered("World" + " " + Client.field2134, var37 / 2 + var40, var33 / 2 + var41 - 2, 16777215, 0);
               if (World.field346 != null) {
                  var1.drawCentered("Loading...", var37 / 2 + var40, var33 / 2 + var41 + 12, 16777215, 0);
               } else {
                  var1.drawCentered("Click to switch", var37 / 2 + var40, var33 / 2 + var41 + 12, 16777215, 0);
               }
            } else {
               class85.field963 = AreaDefinition.readNext(RunException.field1608, "sl_button", "");
            }
         }

      }
   }

   static final void method2902(int var0, int var1, int var2, int var3, int var4) {
      long var5 = class243.field2904.method2251(var0, var1, var2);
      int var7;
      int var8;
      int var9;
      int var10;
      int var12;
      int var13;
      if (0L != var5) {
         var7 = class243.field2904.getObjectFlags(var0, var1, var2, var5);
         var8 = var7 >> 6 & 3;
         var9 = var7 & 31;
         var10 = var3;
         if (class93.method1787(var5)) {
            var10 = var4;
         }

         int[] var11 = TotalQuantityComparator.field986.pixels;
         var12 = var1 * 4 + (103 - var2) * 2048 + 24624;
         var13 = WidgetGroupParent.method1000(var5);
         ObjectDefinition var14 = class252.method4958(var13);
         if (var14.mapSceneId != -1) {
            IndexedSprite var15 = class273.field3514[var14.mapSceneId];
            if (var15 != null) {
               int var16 = (var14.sizeX * 4 - var15.subWidth) / 2;
               int var17 = (var14.sizeY * 4 - var15.subHeight) / 2;
               var15.method6304(var16 + var1 * 4 + 48, (104 - var2 - var14.sizeY) * 4 + var17 + 48);
            }
         } else {
            if (var9 == 0 || var9 == 2) {
               if (var8 == 0) {
                  var11[var12] = var10;
                  var11[var12 + 512] = var10;
                  var11[var12 + 1024] = var10;
                  var11[var12 + 1536] = var10;
               } else if (var8 == 1) {
                  var11[var12] = var10;
                  var11[var12 + 1] = var10;
                  var11[var12 + 2] = var10;
                  var11[var12 + 3] = var10;
               } else if (var8 == 2) {
                  var11[var12 + 3] = var10;
                  var11[var12 + 512 + 3] = var10;
                  var11[var12 + 1024 + 3] = var10;
                  var11[var12 + 1536 + 3] = var10;
               } else if (var8 == 3) {
                  var11[var12 + 1536] = var10;
                  var11[var12 + 1536 + 1] = var10;
                  var11[var12 + 1536 + 2] = var10;
                  var11[var12 + 1536 + 3] = var10;
               }
            }

            if (var9 == 3) {
               if (var8 == 0) {
                  var11[var12] = var10;
               } else if (var8 == 1) {
                  var11[var12 + 3] = var10;
               } else if (var8 == 2) {
                  var11[var12 + 1536 + 3] = var10;
               } else if (var8 == 3) {
                  var11[var12 + 1536] = var10;
               }
            }

            if (var9 == 2) {
               if (var8 == 3) {
                  var11[var12] = var10;
                  var11[var12 + 512] = var10;
                  var11[var12 + 1024] = var10;
                  var11[var12 + 1536] = var10;
               } else if (var8 == 0) {
                  var11[var12] = var10;
                  var11[var12 + 1] = var10;
                  var11[var12 + 2] = var10;
                  var11[var12 + 3] = var10;
               } else if (var8 == 1) {
                  var11[var12 + 3] = var10;
                  var11[var12 + 512 + 3] = var10;
                  var11[var12 + 1024 + 3] = var10;
                  var11[var12 + 1536 + 3] = var10;
               } else if (var8 == 2) {
                  var11[var12 + 1536] = var10;
                  var11[var12 + 1536 + 1] = var10;
                  var11[var12 + 1536 + 2] = var10;
                  var11[var12 + 1536 + 3] = var10;
               }
            }
         }
      }

      var5 = class243.field2904.method2253(var0, var1, var2);
      if (var5 != 0L) {
         var7 = class243.field2904.getObjectFlags(var0, var1, var2, var5);
         var8 = var7 >> 6 & 3;
         var9 = var7 & 31;
         var10 = WidgetGroupParent.method1000(var5);
         ObjectDefinition var24 = class252.method4958(var10);
         int var19;
         if (var24.mapSceneId != -1) {
            IndexedSprite var18 = class273.field3514[var24.mapSceneId];
            if (var18 != null) {
               var13 = (var24.sizeX * 4 - var18.subWidth) / 2;
               var19 = (var24.sizeY * 4 - var18.subHeight) / 2;
               var18.method6304(var13 + var1 * 4 + 48, var19 + (104 - var2 - var24.sizeY) * 4 + 48);
            }
         } else if (var9 == 9) {
            var12 = 15658734;
            if (class93.method1787(var5)) {
               var12 = 15597568;
            }

            int[] var23 = TotalQuantityComparator.field986.pixels;
            var19 = var1 * 4 + (103 - var2) * 2048 + 24624;
            if (var8 != 0 && var8 != 2) {
               var23[var19] = var12;
               var23[var19 + 1 + 512] = var12;
               var23[var19 + 1024 + 2] = var12;
               var23[var19 + 1536 + 3] = var12;
            } else {
               var23[var19 + 1536] = var12;
               var23[var19 + 1 + 1024] = var12;
               var23[var19 + 512 + 2] = var12;
               var23[var19 + 3] = var12;
            }
         }
      }

      var5 = class243.field2904.getFloorDecorationTag(var0, var1, var2);
      if (var5 != 0L) {
         var7 = WidgetGroupParent.method1000(var5);
         ObjectDefinition var20 = class252.method4958(var7);
         if (var20.mapSceneId != -1) {
            IndexedSprite var21 = class273.field3514[var20.mapSceneId];
            if (var21 != null) {
               var10 = (var20.sizeX * 4 - var21.subWidth) / 2;
               int var22 = (var20.sizeY * 4 - var21.subHeight) / 2;
               var21.method6304(var1 * 4 + var10 + 48, var22 + (104 - var2 - var20.sizeY) * 4 + 48);
            }
         }
      }

   }

   static void method2903(Widget var0, int var1, int var2, boolean var3) {
      int var4 = var0.width;
      int var5 = var0.height;
      if (var0.widthAlignment == 0) {
         var0.width = var0.rawWidth;
      } else if (var0.widthAlignment == 1) {
         var0.width = var1 - var0.rawWidth;
      } else if (var0.widthAlignment == 2) {
         var0.width = var0.rawWidth * var1 >> 14;
      }

      if (var0.heightAlignment == 0) {
         var0.height = var0.rawHeight;
      } else if (var0.heightAlignment == 1) {
         var0.height = var2 - var0.rawHeight;
      } else if (var0.heightAlignment == 2) {
         var0.height = var2 * var0.rawHeight >> 14;
      }

      if (var0.widthAlignment == 4) {
         var0.width = var0.height * var0.field2605 / var0.field2589;
      }

      if (var0.heightAlignment == 4) {
         var0.height = var0.width * var0.field2589 / var0.field2605;
      }

      if (var0.contentType == 1337) {
         Client.field2258 = var0;
      }

      if (var3 && var0.field2703 != null && (var4 != var0.width || var5 != var0.height)) {
         ScriptEvent var6 = new ScriptEvent();
         var6.widget = var0;
         var6.args = var0.field2703;
         Client.field2285.addFirst(var6);
      }

   }
}
