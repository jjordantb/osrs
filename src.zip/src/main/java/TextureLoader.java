public interface TextureLoader {
   boolean vmethod2977(int var1);

   int[] load(int var1);

   boolean isLowDetail(int var1);

   int vmethod2974(int var1);
}
