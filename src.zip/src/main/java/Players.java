public class Players {
   static int[] field947 = new int[2048];
   static Buffer[] field958 = new Buffer[2048];
   static int field952 = 0;
   static byte[] field948 = new byte[2048];
   static int[] field955 = new int[2048];
   static int[] field959 = new int[2048];
   static int field951 = 0;
   static int[] field957 = new int[2048];
   static int[] field950 = new int[2048];
   static int[] field956 = new int[2048];
   static byte[] field949 = new byte[2048];
   static int field953 = 0;
   static Buffer field960 = new Buffer(new byte[5000]);
}
