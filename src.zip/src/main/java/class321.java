public class class321 {
   static IterableNodeDeque field3914 = new IterableNodeDeque();
   static int field3913;
}
