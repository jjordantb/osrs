public interface Usernamed {
   Username username();
}
