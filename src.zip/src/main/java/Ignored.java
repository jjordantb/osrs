public class Ignored extends User {
   int field3695;

   public int vmethod5942(User var1) {
      return this.method5573((Ignored)var1);
   }

   int method5573(Ignored var1) {
      return this.field3695 - var1.field3695;
   }

   public int compareTo(Object var1) {
      return this.method5573((Ignored)var1);
   }
}
