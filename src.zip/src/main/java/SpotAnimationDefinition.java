public class SpotAnimationDefinition extends DualNode {
   static EvictingDualNodeHashTable field3664 = new EvictingDualNodeHashTable(64);
   static AbstractIndexCache field3667;
   static EvictingDualNodeHashTable field3665 = new EvictingDualNodeHashTable(30);
   static AbstractIndexCache field3663;
   public int sequence = -1;
   int id;
   int heightScale = 128;
   short[] retextureFrom;
   int orientation = 0;
   int archive;
   int widthScale = 128;
   short[] recolorTo;
   short[] retextureTo;
   int field3675 = 0;
   short[] recolorFrom;
   int field3676 = 0;

   public final Model getModel(int var1) {
      Model var2 = (Model)field3665.get((long)this.id);
      if (var2 == null) {
         ModelData var3 = ModelData.method2741(field3663, this.archive, 0);
         if (var3 == null) {
            return null;
         }

         int var4;
         if (this.recolorFrom != null) {
            for(var4 = 0; var4 < this.recolorFrom.length; ++var4) {
               var3.recolor(this.recolorFrom[var4], this.recolorTo[var4]);
            }
         }

         if (this.retextureFrom != null) {
            for(var4 = 0; var4 < this.retextureFrom.length; ++var4) {
               var3.retexture(this.retextureFrom[var4], this.retextureTo[var4]);
            }
         }

         var2 = var3.toModel(this.field3676 + 64, this.field3675 + 850, -30, -50, -30);
         field3665.put(var2, (long)this.id);
      }

      Model var5;
      if (this.sequence != -1 && var1 != -1) {
         var5 = WorldMapCacheName.method547(this.sequence).animateSpotAnimation(var2, var1);
      } else {
         var5 = var2.toSharedSpotAnimationModel(true);
      }

      if (this.widthScale != 128 || this.heightScale != 128) {
         var5.scale(this.widthScale, this.heightScale, this.widthScale);
      }

      if (this.orientation != 0) {
         if (this.orientation == 90) {
            var5.rotateY90Ccw();
         }

         if (this.orientation == 180) {
            var5.rotateY90Ccw();
            var5.rotateY90Ccw();
         }

         if (this.orientation == 270) {
            var5.rotateY90Ccw();
            var5.rotateY90Ccw();
            var5.rotateY90Ccw();
         }
      }

      return var5;
   }

   void read(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.readNext(var1, var2);
      }
   }

   void readNext(Buffer var1, int var2) {
      if (var2 == 1) {
         this.archive = var1.method3913();
      } else if (var2 == 2) {
         this.sequence = var1.method3913();
      } else if (var2 == 4) {
         this.widthScale = var1.method3913();
      } else if (var2 == 5) {
         this.heightScale = var1.method3913();
      } else if (var2 == 6) {
         this.orientation = var1.method3913();
      } else if (var2 == 7) {
         this.field3676 = var1.readUnsignedByte();
      } else if (var2 == 8) {
         this.field3675 = var1.readUnsignedByte();
      } else {
         int var3;
         int var4;
         if (var2 == 40) {
            var3 = var1.readUnsignedByte();
            this.recolorFrom = new short[var3];
            this.recolorTo = new short[var3];

            for(var4 = 0; var4 < var3; ++var4) {
               this.recolorFrom[var4] = (short)var1.method3913();
               this.recolorTo[var4] = (short)var1.method3913();
            }
         } else if (var2 == 41) {
            var3 = var1.readUnsignedByte();
            this.retextureFrom = new short[var3];
            this.retextureTo = new short[var3];

            for(var4 = 0; var4 < var3; ++var4) {
               this.retextureFrom[var4] = (short)var1.method3913();
               this.retextureTo[var4] = (short)var1.method3913();
            }
         }
      }

   }

   static int method5542(int var0, Script var1, boolean var2) {
      if (var0 == 6200) {
         class31.field364 -= 2;
         Client.field2092 = (short)FontName.method5760(Interpreter.field467[class31.field364]);
         if (Client.field2092 <= 0) {
            Client.field2092 = 256;
         }

         Client.field2339 = (short)FontName.method5760(Interpreter.field467[class31.field364 + 1]);
         if (Client.field2339 <= 0) {
            Client.field2339 = 256;
         }

         return 1;
      } else if (var0 == 6201) {
         class31.field364 -= 2;
         Client.field2340 = (short)Interpreter.field467[class31.field364];
         if (Client.field2340 <= 0) {
            Client.field2340 = 256;
         }

         Client.field2341 = (short)Interpreter.field467[class31.field364 + 1];
         if (Client.field2341 <= 0) {
            Client.field2341 = 320;
         }

         return 1;
      } else if (var0 == 6202) {
         class31.field364 -= 4;
         Client.field2342 = (short)Interpreter.field467[class31.field364];
         if (Client.field2342 <= 0) {
            Client.field2342 = 1;
         }

         Client.field2127 = (short)Interpreter.field467[class31.field364 + 1];
         if (Client.field2127 <= 0) {
            Client.field2127 = 32767;
         } else if (Client.field2127 < Client.field2342) {
            Client.field2127 = Client.field2342;
         }

         Client.field2344 = (short)Interpreter.field467[class31.field364 + 2];
         if (Client.field2344 <= 0) {
            Client.field2344 = 1;
         }

         Client.field2197 = (short)Interpreter.field467[class31.field364 + 3];
         if (Client.field2197 <= 0) {
            Client.field2197 = 32767;
         } else if (Client.field2197 < Client.field2344) {
            Client.field2197 = Client.field2344;
         }

         return 1;
      } else if (var0 == 6203) {
         if (Client.field2258 != null) {
            TotalQuantityComparator.method1768(0, 0, Client.field2258.width, Client.field2258.height, false);
            Interpreter.field467[++class31.field364 - 1] = Client.field2087;
            Interpreter.field467[++class31.field364 - 1] = Client.field2207;
         } else {
            Interpreter.field467[++class31.field364 - 1] = -1;
            Interpreter.field467[++class31.field364 - 1] = -1;
         }

         return 1;
      } else if (var0 == 6204) {
         Interpreter.field467[++class31.field364 - 1] = Client.field2340;
         Interpreter.field467[++class31.field364 - 1] = Client.field2341;
         return 1;
      } else if (var0 == 6205) {
         Interpreter.field467[++class31.field364 - 1] = NetCache.method4809(Client.field2092);
         Interpreter.field467[++class31.field364 - 1] = NetCache.method4809(Client.field2339);
         return 1;
      } else {
         return 2;
      }
   }

   static final void method5548(PacketBuffer var0) {
      var0.importIndex();
      int var1 = Client.field2190;
      Player var2 = ObjectSound.field589 = Client.field2141[var1] = new Player();
      var2.index = var1;
      int var3 = var0.readBits(30);
      byte var4 = (byte)(var3 >> 28);
      int var5 = var3 >> 14 & 16383;
      int var6 = var3 & 16383;
      var2.pathX[0] = var5 - class21.field230;
      var2.x = (var2.pathX[0] << 7) + (var2.transformedSize() << 6);
      var2.pathY[0] = var6 - class79.field902;
      var2.y = (var2.pathY[0] << 7) + (var2.transformedSize() << 6);
      class31.field363 = var2.plane = var4;
      if (Players.field958[var1] != null) {
         var2.read(Players.field958[var1]);
      }

      Players.field951 = 0;
      Players.field947[++Players.field951 - 1] = var1;
      Players.field948[var1] = 0;
      Players.field953 = 0;

      for(int var7 = 1; var7 < 2048; ++var7) {
         if (var7 != var1) {
            int var8 = var0.readBits(18);
            int var9 = var8 >> 16;
            int var10 = var8 >> 8 & 597;
            int var11 = var8 & 597;
            Players.field955[var7] = (var10 << 14) + var11 + (var9 << 28);
            Players.field956[var7] = 0;
            Players.field957[var7] = -1;
            Players.field950[++Players.field953 - 1] = var7;
            Players.field948[var7] = 0;
         }
      }

      var0.exportIndex();
   }
}
