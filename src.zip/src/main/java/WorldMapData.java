import java.util.Iterator;
import java.util.LinkedList;

public class WorldMapData {
   int field881 = Integer.MAX_VALUE;
   int field879 = -1;
   String field875;
   int field883 = -1;
   int field886 = 0;
   TileLocation location = null;
   LinkedList sections;
   int field877 = Integer.MAX_VALUE;
   boolean boolean1 = false;
   int field878 = -1;
   String archiveName0;
   int field882 = 0;

   public int method1503() {
      return this.field882;
   }

   public int[] method1493(int var1, int var2, int var3) {
      Iterator var4 = this.sections.iterator();

      WorldMapSection var5;
      do {
         if (!var4.hasNext()) {
            return null;
         }

         var5 = (WorldMapSection)var4.next();
      } while(!var5.vmethod1856(var1, var2, var3));

      return var5.vmethod1858(var1, var2, var3);
   }

   public boolean method1497() {
      return this.boolean1;
   }

   public boolean method1491(int var1, int var2, int var3) {
      Iterator var4 = this.sections.iterator();

      WorldMapSection var5;
      do {
         if (!var4.hasNext()) {
            return false;
         }

         var5 = (WorldMapSection)var4.next();
      } while(!var5.vmethod1856(var1, var2, var3));

      return true;
   }

   public int method1523() {
      return this.field881;
   }

   public void read(Buffer var1, int var2) {
      this.field883 = var2;
      this.archiveName0 = var1.readStringCp1252NullTerminated();
      this.field875 = var1.readStringCp1252NullTerminated();
      this.location = new TileLocation(var1.readInt());
      this.field878 = var1.readInt();
      var1.readUnsignedByte();
      this.boolean1 = var1.readUnsignedByte() == 1;
      this.field879 = var1.readUnsignedByte();
      int var3 = var1.readUnsignedByte();
      this.sections = new LinkedList();

      for(int var4 = 0; var4 < var3; ++var4) {
         this.sections.add(this.readWorldMapSection(var1));
      }

      this.method1532();
   }

   public int method1501() {
      return this.field879;
   }

   public TileLocation method1522(int var1, int var2) {
      Iterator var3 = this.sections.iterator();

      WorldMapSection var4;
      do {
         if (!var3.hasNext()) {
            return null;
         }

         var4 = (WorldMapSection)var3.next();
      } while(!var4.vmethod1857(var1, var2));

      return var4.vmethod1861(var1, var2);
   }

   public String archiveName() {
      return this.archiveName0;
   }

   public int method1514() {
      return this.field886;
   }

   public int method1496() {
      return this.field883;
   }

   public TileLocation method1509() {
      return new TileLocation(this.location);
   }

   void method1532() {
      Iterator var1 = this.sections.iterator();

      while(var1.hasNext()) {
         WorldMapSection var2 = (WorldMapSection)var1.next();
         var2.vmethod1855(this);
      }

   }

   public boolean method1492(int var1, int var2) {
      int var3 = var1 / 64;
      int var4 = var2 / 64;
      if (var3 >= this.field881 && var3 <= this.field882) {
         if (var4 >= this.field877 && var4 <= this.field886) {
            Iterator var5 = this.sections.iterator();

            WorldMapSection var6;
            do {
               if (!var5.hasNext()) {
                  return false;
               }

               var6 = (WorldMapSection)var5.next();
            } while(!var6.vmethod1857(var1, var2));

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   WorldMapSection readWorldMapSection(Buffer var1) {
      int var2 = var1.readUnsignedByte();
      WorldMapSectionType var3 = (WorldMapSectionType)class10.method352(WorldMapSectionType.method1820(), var2);
      Object var4 = null;
      switch(var3.type) {
      case 0:
         var4 = new WorldMapSection0();
         break;
      case 1:
         var4 = new WorldMapSection2();
         break;
      case 2:
         var4 = new WorldMapSection1();
         break;
      case 3:
         var4 = new WorldMapSection3();
         break;
      default:
         throw new IllegalStateException("");
      }

      ((WorldMapSection)var4).read(var1);
      return (WorldMapSection)var4;
   }

   public int method1546() {
      return this.location.x;
   }

   public int method1494() {
      return this.field877;
   }

   public int method1508() {
      return this.location.y;
   }

   int method1500() {
      return this.field878;
   }

   public String method1510() {
      return this.field875;
   }

   public int method1499() {
      return this.location.plane;
   }

   static final void method1561(String var0) {
      class6.method183("Please remove " + var0 + " from your friend list first");
   }

   static void readWorldMapSection(AbstractIndexCache var0, AbstractIndexCache var1, boolean var2, int var3) {
      if (Login.field680) {
         if (var3 == 4) {
            Login.field669 = 4;
         }

      } else {
         Login.field669 = var3;
         Rasterizer2D.method6219();
         byte[] var4 = var0.takeRecordByNames("title.jpg", "");
         Login.field651 = Interpreter.method966(var4);
         Login.field652 = Login.field651.copy();
         if ((Client.field2103 & 536870912) != 0) {
            VarbitDefinition.field3505 = AreaDefinition.readNext(var1, "logo_deadman_mode", "");
         } else {
            VarbitDefinition.field3505 = AreaDefinition.readNext(var1, "logo", "");
         }

         Login.field655 = AreaDefinition.readNext(var1, "titlebox", "");
         class294.field3719 = AreaDefinition.readNext(var1, "titlebutton", "");
         int var6 = var1.getArchiveId("runes");
         int var7 = var1.getRecordId(var6, "");
         IndexedSprite[] var8;
         if (!class65.method1382(var1, var6, var7)) {
            var8 = null;
         } else {
            var8 = SpriteIds.method5817();
         }

         class57.field640 = var8;
         var7 = var1.getArchiveId("title_mute");
         int var10 = var1.getRecordId(var7, "");
         IndexedSprite[] var9;
         if (!class65.method1382(var1, var7, var10)) {
            var9 = null;
         } else {
            var9 = SpriteIds.method5817();
         }

         Login.field653 = var9;
         ByteArrayPool.field2470 = AreaDefinition.readNext(var1, "options_radio_buttons,0", "");
         Login.field654 = AreaDefinition.readNext(var1, "options_radio_buttons,4", "");
         Frames.field1635 = AreaDefinition.readNext(var1, "options_radio_buttons,2", "");
         UrlRequest.field1614 = AreaDefinition.readNext(var1, "options_radio_buttons,6", "");
         ObjectSound.field576 = ByteArrayPool.field2470.subWidth;
         Canvas.field122 = ByteArrayPool.field2470.subHeight;
         Login.field657 = new int[256];

         for(var7 = 0; var7 < 64; ++var7) {
            Login.field657[var7] = var7 * 262144;
         }

         for(var7 = 0; var7 < 64; ++var7) {
            Login.field657[var7 + 64] = var7 * 1024 + 16711680;
         }

         for(var7 = 0; var7 < 64; ++var7) {
            Login.field657[var7 + 128] = var7 * 4 + 16776960;
         }

         for(var7 = 0; var7 < 64; ++var7) {
            Login.field657[var7 + 192] = 16777215;
         }

         MouseRecorder.field505 = new int[256];

         for(var7 = 0; var7 < 64; ++var7) {
            MouseRecorder.field505[var7] = var7 * 1024;
         }

         for(var7 = 0; var7 < 64; ++var7) {
            MouseRecorder.field505[var7 + 64] = var7 * 4 + '\uff00';
         }

         for(var7 = 0; var7 < 64; ++var7) {
            MouseRecorder.field505[var7 + 128] = var7 * 262144 + '\uffff';
         }

         for(var7 = 0; var7 < 64; ++var7) {
            MouseRecorder.field505[var7 + 192] = 16777215;
         }

         BufferedNetSocket.field1783 = new int[256];

         for(var7 = 0; var7 < 64; ++var7) {
            BufferedNetSocket.field1783[var7] = var7 * 4;
         }

         for(var7 = 0; var7 < 64; ++var7) {
            BufferedNetSocket.field1783[var7 + 64] = var7 * 262144 + 255;
         }

         for(var7 = 0; var7 < 64; ++var7) {
            BufferedNetSocket.field1783[var7 + 128] = var7 * 1024 + 16711935;
         }

         for(var7 = 0; var7 < 64; ++var7) {
            BufferedNetSocket.field1783[var7 + 192] = 16777215;
         }

         ObjectSound.field573 = new int[256];
         OwnWorldComparator.field274 = new int['耀'];
         class25.field263 = new int['耀'];
         class273.method5343((IndexedSprite)null);
         class93.field1025 = new int['耀'];
         class93.field1026 = new int['耀'];
         if (var2) {
            Login.field686 = "";
            Login.field675 = "";
         }

         class31.field368 = 0;
         class85.field968 = "";
         Login.field678 = true;
         Login.field682 = false;
         if (!GameShell.field72.titleMusicDisabled) {
            WorldMapSection2.read(2, ServerPacket.field1995, "scape main", "", 255, false);
         } else {
            class165.method3136(2);
         }

         Varps.method4668(false);
         Login.field680 = true;
         Login.field649 = (FriendSystem.field379 - 765) / 2;
         Login.field650 = Login.field649 + 202;
         class73.field854 = Login.field650 + 180;
         Login.field651.method6368(Login.field649, 0);
         Login.field652.method6368(Login.field649 + 382, 0);
         VarbitDefinition.field3505.method6304(Login.field649 + 382 - VarbitDefinition.field3505.subWidth / 2, 18);
      }
   }
}
