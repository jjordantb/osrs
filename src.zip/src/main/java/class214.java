public class class214 extends TaskDataNode {
   long field2543;
   int field2542;
   class222[][] field2538 = new class222[16][128];
   class223 field2545 = new class223(this);
   class227 field2539 = new class227();
   int field2532;
   boolean field2530;
   long field2544;
   int[] field2525 = new int[16];
   int[] field2519 = new int[16];
   int[] field2541 = new int[16];
   int field2521 = 1000000;
   NodeHashTable field2540 = new NodeHashTable(128);
   int[] field2527 = new int[16];
   int[] field2528 = new int[16];
   int[] field2524 = new int[16];
   int[] field2535 = new int[16];
   int[] field2522 = new int[16];
   class222[][] field2537 = new class222[16][128];
   int[] field2526 = new int[16];
   int[] field2534 = new int[16];
   int field2520 = 256;
   int[] field2523 = new int[16];
   int[] field2531 = new int[16];
   int[] field2529 = new int[16];
   int[] field2536 = new int[16];
   int[] field2533 = new int[16];

   public class214() {
      this.method4383();
   }

   void method4463(int var1) {
      for(class222 var2 = (class222)this.field2545.field2754.last(); var2 != null; var2 = (class222)this.field2545.field2754.previous()) {
         if ((var1 < 0 || var2.field2752 == var1) && var2.field2744 < 0) {
            this.field2537[var2.field2752][var2.field2735] = null;
            var2.field2744 = 0;
         }
      }

   }

   void method4379(int var1, int var2) {
      this.field2526[var1] = var2;
   }

   void method4385(int var1) {
      if ((this.field2531[var1] & 4) != 0) {
         for(class222 var2 = (class222)this.field2545.field2754.last(); var2 != null; var2 = (class222)this.field2545.field2754.previous()) {
            if (var2.field2752 == var1) {
               var2.field2734 = 0;
            }
         }
      }

   }

   void method4384(int var1) {
      if ((this.field2531[var1] & 2) != 0) {
         for(class222 var2 = (class222)this.field2545.field2754.last(); var2 != null; var2 = (class222)this.field2545.field2754.previous()) {
            if (var2.field2752 == var1 && this.field2537[var1][var2.field2735] == null && var2.field2744 < 0) {
               var2.field2744 = 0;
            }
         }
      }

   }

   void method4383() {
      this.method4380(-1);
      this.method4381(-1);

      int var1;
      for(var1 = 0; var1 < 16; ++var1) {
         this.field2522[var1] = this.field2525[var1];
      }

      for(var1 = 0; var1 < 16; ++var1) {
         this.field2527[var1] = this.field2525[var1] & -128;
      }

   }

   void method4380(int var1) {
      for(class222 var2 = (class222)this.field2545.field2754.last(); var2 != null; var2 = (class222)this.field2545.field2754.previous()) {
         if (var1 < 0 || var2.field2752 == var1) {
            if (var2.field2748 != null) {
               var2.field2748.method2048(AbstractSoundSystem.field936 / 100);
               if (var2.field2748.method2052()) {
                  this.field2545.field2756.method1565(var2.field2748);
               }

               var2.method4624();
            }

            if (var2.field2744 < 0) {
               this.field2537[var2.field2752][var2.field2735] = null;
            }

            var2.remove();
         }
      }

   }

   void method4438(int var1) {
      int var2 = var1 & 240;
      int var3;
      int var4;
      int var5;
      if (var2 == 128) {
         var3 = var1 & 15;
         var4 = var1 >> 8 & 127;
         var5 = var1 >> 16 & 127;
         this.method4445(var3, var4, var5);
      } else if (var2 == 144) {
         var3 = var1 & 15;
         var4 = var1 >> 8 & 127;
         var5 = var1 >> 16 & 127;
         if (var5 > 0) {
            this.method4374(var3, var4, var5);
         } else {
            this.method4445(var3, var4, 64);
         }

      } else if (var2 == 160) {
         var3 = var1 & 15;
         var4 = var1 >> 8 & 127;
         var5 = var1 >> 16 & 127;
         this.method4377(var3, var4, var5);
      } else if (var2 == 176) {
         var3 = var1 & 15;
         var4 = var1 >> 8 & 127;
         var5 = var1 >> 16 & 127;
         if (var4 == 0) {
            this.field2527[var3] = (var5 << 14) + (this.field2527[var3] & -2080769);
         }

         if (var4 == 32) {
            this.field2527[var3] = (var5 << 7) + (this.field2527[var3] & -16257);
         }

         if (var4 == 1) {
            this.field2535[var3] = (var5 << 7) + (this.field2535[var3] & -16257);
         }

         if (var4 == 33) {
            this.field2535[var3] = var5 + (this.field2535[var3] & -128);
         }

         if (var4 == 5) {
            this.field2541[var3] = (var5 << 7) + (this.field2541[var3] & -16257);
         }

         if (var4 == 37) {
            this.field2541[var3] = var5 + (this.field2541[var3] & -128);
         }

         if (var4 == 7) {
            this.field2534[var3] = (var5 << 7) + (this.field2534[var3] & -16257);
         }

         if (var4 == 39) {
            this.field2534[var3] = var5 + (this.field2534[var3] & -128);
         }

         if (var4 == 10) {
            this.field2519[var3] = (var5 << 7) + (this.field2519[var3] & -16257);
         }

         if (var4 == 42) {
            this.field2519[var3] = var5 + (this.field2519[var3] & -128);
         }

         if (var4 == 11) {
            this.field2524[var3] = (var5 << 7) + (this.field2524[var3] & -16257);
         }

         if (var4 == 43) {
            this.field2524[var3] = var5 + (this.field2524[var3] & -128);
         }

         if (var4 == 64) {
            if (var5 >= 64) {
               this.field2531[var3] |= 1;
            } else {
               this.field2531[var3] &= -2;
            }
         }

         if (var4 == 65) {
            if (var5 >= 64) {
               this.field2531[var3] |= 2;
            } else {
               this.method4384(var3);
               this.field2531[var3] &= -3;
            }
         }

         if (var4 == 99) {
            this.field2528[var3] = (var5 << 7) + (this.field2528[var3] & 127);
         }

         if (var4 == 98) {
            this.field2528[var3] = (this.field2528[var3] & 16256) + var5;
         }

         if (var4 == 101) {
            this.field2528[var3] = (var5 << 7) + (this.field2528[var3] & 127) + 16384;
         }

         if (var4 == 100) {
            this.field2528[var3] = (this.field2528[var3] & 16256) + var5 + 16384;
         }

         if (var4 == 120) {
            this.method4380(var3);
         }

         if (var4 == 121) {
            this.method4381(var3);
         }

         if (var4 == 123) {
            this.method4463(var3);
         }

         int var6;
         if (var4 == 6) {
            var6 = this.field2528[var3];
            if (var6 == 16384) {
               this.field2533[var3] = (var5 << 7) + (this.field2533[var3] & -16257);
            }
         }

         if (var4 == 38) {
            var6 = this.field2528[var3];
            if (var6 == 16384) {
               this.field2533[var3] = var5 + (this.field2533[var3] & -128);
            }
         }

         if (var4 == 16) {
            this.field2523[var3] = (var5 << 7) + (this.field2523[var3] & -16257);
         }

         if (var4 == 48) {
            this.field2523[var3] = var5 + (this.field2523[var3] & -128);
         }

         if (var4 == 81) {
            if (var5 >= 64) {
               this.field2531[var3] |= 4;
            } else {
               this.method4385(var3);
               this.field2531[var3] &= -5;
            }
         }

         if (var4 == 17) {
            this.method4387(var3, (var5 << 7) + (this.field2536[var3] & -16257));
         }

         if (var4 == 49) {
            this.method4387(var3, var5 + (this.field2536[var3] & -128));
         }

      } else if (var2 == 192) {
         var3 = var1 & 15;
         var4 = var1 >> 8 & 127;
         this.method4373(var3, var4 + this.field2527[var3]);
      } else if (var2 == 208) {
         var3 = var1 & 15;
         var4 = var1 >> 8 & 127;
         this.method4363(var3, var4);
      } else if (var2 == 224) {
         var3 = var1 & 15;
         var4 = (var1 >> 8 & 127) + (var1 >> 9 & 16256);
         this.method4379(var3, var4);
      } else {
         var2 = var1 & 255;
         if (var2 == 255) {
            this.method4383();
         }
      }
   }

   int method4388(class222 var1) {
      int var2 = (var1.field2740 * var1.field2739 >> 12) + var1.field2753;
      var2 += (this.field2526[var1.field2752] - 8192) * this.field2533[var1.field2752] >> 12;
      class209 var3 = var1.field2733;
      int var4;
      if (var3.field2507 > 0 && (var3.field2510 > 0 || this.field2535[var1.field2752] > 0)) {
         var4 = var3.field2510 << 2;
         int var5 = var3.field2504 << 1;
         if (var1.field2746 < var5) {
            var4 = var4 * var1.field2746 / var5;
         }

         var4 += this.field2535[var1.field2752] >> 7;
         double var6 = Math.sin(0.01227184630308513D * (double)(var1.field2747 & 511));
         var2 += (int)(var6 * (double)var4);
      }

      var4 = (int)((double)(var1.field2732.field990 * 256) * Math.pow(2.0D, 3.255208333333333E-4D * (double)var2) / (double)AbstractSoundSystem.field936 + 0.5D);
      return var4 < 1 ? 1 : var4;
   }

   void method4387(int var1, int var2) {
      this.field2536[var1] = var2;
      this.field2529[var1] = (int)(2097152.0D * Math.pow(2.0D, 5.4931640625E-4D * (double)var2) + 0.5D);
   }

   void method4381(int var1) {
      if (var1 >= 0) {
         this.field2534[var1] = 12800;
         this.field2519[var1] = 8192;
         this.field2524[var1] = 16383;
         this.field2526[var1] = 8192;
         this.field2535[var1] = 0;
         this.field2541[var1] = 8192;
         this.method4384(var1);
         this.method4385(var1);
         this.field2531[var1] = 0;
         this.field2528[var1] = 32767;
         this.field2533[var1] = 256;
         this.field2523[var1] = 0;
         this.method4387(var1, 8192);
      } else {
         for(var1 = 0; var1 < 16; ++var1) {
            this.method4381(var1);
         }

      }
   }

   void method4402() {
      int var1 = this.field2532;
      int var2 = this.field2542;

      long var3;
      for(var3 = this.field2544; var2 == this.field2542; var3 = this.field2539.method4681(var2)) {
         while(var2 == this.field2539.field2768[var1]) {
            this.field2539.method4708(var1);
            int var5 = this.field2539.method4678(var1);
            if (var5 == 1) {
               this.field2539.method4676();
               this.field2539.method4675(var1);
               if (this.field2539.method4683()) {
                  if (!this.field2530 || var2 == 0) {
                     this.method4383();
                     this.field2539.method4722();
                     return;
                  }

                  this.field2539.method4674(var3);
               }
               break;
            }

            if ((var5 & 128) != 0) {
               this.method4438(var5);
            }

            this.field2539.method4677(var1);
            this.field2539.method4675(var1);
         }

         var1 = this.field2539.method4713();
         var2 = this.field2539.field2768[var1];
      }

      this.field2532 = var1;
      this.field2542 = var2;
      this.field2544 = var3;
   }

   boolean method4396(class222 var1) {
      if (var1.field2748 == null) {
         if (var1.field2744 >= 0) {
            var1.remove();
            if (var1.field2750 > 0 && var1 == this.field2538[var1.field2752][var1.field2750]) {
               this.field2538[var1.field2752][var1.field2750] = null;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   boolean method4475(class222 var1, int[] var2, int var3, int var4) {
      var1.field2743 = AbstractSoundSystem.field936 / 100;
      if (var1.field2744 < 0 || var1.field2748 != null && !var1.field2748.method2051()) {
         int var5 = var1.field2740;
         if (var5 > 0) {
            var5 -= (int)(16.0D * Math.pow(2.0D, 4.921259842519685E-4D * (double)this.field2541[var1.field2752]) + 0.5D);
            if (var5 < 0) {
               var5 = 0;
            }

            var1.field2740 = var5;
         }

         var1.field2748.method2046(this.method4388(var1));
         class209 var6 = var1.field2733;
         boolean var7 = false;
         ++var1.field2746;
         var1.field2747 += var6.field2507;
         double var8 = 5.086263020833333E-6D * (double)((var1.field2735 - 60 << 8) + (var1.field2739 * var1.field2740 >> 12));
         if (var6.field2506 > 0) {
            if (var6.field2509 > 0) {
               var1.field2741 += (int)(128.0D * Math.pow(2.0D, (double)var6.field2509 * var8) + 0.5D);
            } else {
               var1.field2741 += 128;
            }
         }

         if (var6.field2505 != null) {
            if (var6.field2512 > 0) {
               var1.field2742 += (int)(128.0D * Math.pow(2.0D, (double)var6.field2512 * var8) + 0.5D);
            } else {
               var1.field2742 += 128;
            }

            while(var1.field2731 < var6.field2505.length - 2 && var1.field2742 > (var6.field2505[var1.field2731 + 2] & 255) << 8) {
               var1.field2731 += 2;
            }

            if (var6.field2505.length - 2 == var1.field2731 && var6.field2505[var1.field2731 + 1] == 0) {
               var7 = true;
            }
         }

         if (var1.field2744 >= 0 && var6.field2508 != null && (this.field2531[var1.field2752] & 1) == 0 && (var1.field2750 < 0 || var1 != this.field2538[var1.field2752][var1.field2750])) {
            if (var6.field2511 > 0) {
               var1.field2744 += (int)(128.0D * Math.pow(2.0D, var8 * (double)var6.field2511) + 0.5D);
            } else {
               var1.field2744 += 128;
            }

            while(var1.field2745 < var6.field2508.length - 2 && var1.field2744 > (var6.field2508[var1.field2745 + 2] & 255) << 8) {
               var1.field2745 += 2;
            }

            if (var6.field2508.length - 2 == var1.field2745) {
               var7 = true;
            }
         }

         if (var7) {
            var1.field2748.method2048(var1.field2743);
            if (var2 != null) {
               var1.field2748.vmethod4652(var2, var3, var4);
            } else {
               var1.field2748.vmethod4633(var4);
            }

            if (var1.field2748.method2052()) {
               this.field2545.field2756.method1565(var1.field2748);
            }

            var1.method4624();
            if (var1.field2744 >= 0) {
               var1.remove();
               if (var1.field2750 > 0 && var1 == this.field2538[var1.field2752][var1.field2750]) {
                  this.field2538[var1.field2752][var1.field2750] = null;
               }
            }

            return true;
         } else {
            var1.field2748.method2047(var1.field2743, this.method4389(var1), this.method4390(var1));
            return false;
         }
      } else {
         var1.method4624();
         var1.remove();
         if (var1.field2750 > 0 && var1 == this.field2538[var1.field2752][var1.field2750]) {
            this.field2538[var1.field2752][var1.field2750] = null;
         }

         return true;
      }
   }

   int method4389(class222 var1) {
      class209 var2 = var1.field2733;
      int var3 = this.field2534[var1.field2752] * this.field2524[var1.field2752] + 4096 >> 13;
      var3 = var3 * var3 + 16384 >> 15;
      var3 = var3 * var1.field2737 + 16384 >> 15;
      var3 = var3 * this.field2520 + 128 >> 8;
      if (var2.field2506 > 0) {
         var3 = (int)((double)var3 * Math.pow(0.5D, (double)var2.field2506 * 1.953125E-5D * (double)var1.field2741) + 0.5D);
      }

      int var4;
      int var5;
      int var6;
      int var7;
      if (var2.field2505 != null) {
         var4 = var1.field2742;
         var5 = var2.field2505[var1.field2731 + 1];
         if (var1.field2731 < var2.field2505.length - 2) {
            var6 = (var2.field2505[var1.field2731] & 255) << 8;
            var7 = (var2.field2505[var1.field2731 + 2] & 255) << 8;
            var5 += (var4 - var6) * (var2.field2505[var1.field2731 + 3] - var5) / (var7 - var6);
         }

         var3 = var5 * var3 + 32 >> 6;
      }

      if (var1.field2744 > 0 && var2.field2508 != null) {
         var4 = var1.field2744;
         var5 = var2.field2508[var1.field2745 + 1];
         if (var1.field2745 < var2.field2508.length - 2) {
            var6 = (var2.field2508[var1.field2745] & 255) << 8;
            var7 = (var2.field2508[var1.field2745 + 2] & 255) << 8;
            var5 += (var2.field2508[var1.field2745 + 3] - var5) * (var4 - var6) / (var7 - var6);
         }

         var3 = var5 * var3 + 32 >> 6;
      }

      return var3;
   }

   int method4390(class222 var1) {
      int var2 = this.field2519[var1.field2752];
      return var2 < 8192 ? var2 * var1.field2736 + 32 >> 6 : 16384 - ((128 - var1.field2736) * (16384 - var2) + 32 >> 6);
   }

   void method4450(int var1, int var2) {
      this.field2525[var1] = var2;
      this.field2527[var1] = var2 & -128;
      this.method4373(var1, var2);
   }

   public synchronized void method4443() {
      for(MusicPatch var1 = (MusicPatch)this.field2540.first(); var1 != null; var1 = (MusicPatch)this.field2540.next()) {
         var1.remove();
      }

   }

   protected synchronized void vmethod4652(int[] var1, int var2, int var3) {
      if (this.field2539.method4669()) {
         int var4 = this.field2539.field2765 * this.field2521 / AbstractSoundSystem.field936;

         do {
            long var5 = this.field2543 + (long)var4 * (long)var3;
            if (this.field2544 - var5 >= 0L) {
               this.field2543 = var5;
               break;
            }

            int var7 = (int)((this.field2544 - this.field2543 + (long)var4 - 1L) / (long)var4);
            this.field2543 += (long)var7 * (long)var4;
            this.field2545.vmethod4652(var1, var2, var7);
            var2 += var7;
            var3 -= var7;
            this.method4402();
         } while(this.field2539.method4669());
      }

      this.field2545.vmethod4652(var1, var2, var3);
   }

   synchronized boolean method4365(Track var1, AbstractIndexCache var2, class66 var3, int var4) {
      var1.method4493();
      boolean var5 = true;
      int[] var6 = null;
      if (var4 > 0) {
         var6 = new int[]{var4};
      }

      for(ByteArrayNode var7 = (ByteArrayNode)var1.field2546.first(); var7 != null; var7 = (ByteArrayNode)var1.field2546.next()) {
         int var8 = (int)var7.key;
         MusicPatch var9 = (MusicPatch)this.field2540.get((long)var8);
         if (var9 == null) {
            var9 = class5.method155(var2, var8);
            if (var9 == null) {
               var5 = false;
               continue;
            }

            this.field2540.put(var9, (long)var8);
         }

         if (!var9.method4724(var3, var7.byteArray, var6)) {
            var5 = false;
         }
      }

      if (var5) {
         var1.method4498();
      }

      return var5;
   }

   public synchronized void method4371(int var1, int var2) {
      this.method4450(var1, var2);
   }

   public synchronized void method4393(int var1) {
      this.field2520 = var1;
   }

   public synchronized boolean method4459() {
      return this.field2539.method4669();
   }

   protected synchronized TaskDataNode vmethod4628() {
      return this.field2545;
   }

   synchronized void method4368(Track var1, boolean var2) {
      this.method4488();
      this.field2539.method4671(var1.field2547);
      this.field2530 = var2;
      this.field2543 = 0L;
      int var3 = this.field2539.method4712();

      for(int var4 = 0; var4 < var3; ++var4) {
         this.field2539.method4708(var4);
         this.field2539.method4677(var4);
         this.field2539.method4675(var4);
      }

      this.field2532 = this.field2539.method4713();
      this.field2542 = this.field2539.field2768[this.field2532];
      this.field2544 = this.field2539.method4681(this.field2542);
   }

   void method4374(int var1, int var2, int var3) {
      this.method4445(var1, var2, 64);
      if ((this.field2531[var1] & 2) != 0) {
         for(class222 var4 = (class222)this.field2545.field2754.first(); var4 != null; var4 = (class222)this.field2545.field2754.next()) {
            if (var4.field2752 == var1 && var4.field2744 < 0) {
               this.field2537[var1][var4.field2735] = null;
               this.field2537[var1][var2] = var4;
               int var5 = (var4.field2739 * var4.field2740 >> 12) + var4.field2753;
               var4.field2753 += var2 - var4.field2735 << 8;
               var4.field2739 = var5 - var4.field2753;
               var4.field2740 = 4096;
               var4.field2735 = var2;
               return;
            }
         }
      }

      MusicPatch var9 = (MusicPatch)this.field2540.get((long)this.field2522[var1]);
      if (var9 != null) {
         class88 var8 = var9.field2781[var2];
         if (var8 != null) {
            class222 var6 = new class222();
            var6.field2752 = var1;
            var6.field2738 = var9;
            var6.field2732 = var8;
            var6.field2733 = var9.field2785[var2];
            var6.field2750 = var9.field2786[var2];
            var6.field2735 = var2;
            var6.field2737 = var3 * var3 * var9.field2783[var2] * var9.field2782 + 1024 >> 11;
            var6.field2736 = var9.field2791[var2] & 255;
            var6.field2753 = (var2 << 8) - (var9.field2780[var2] & 32767);
            var6.field2741 = 0;
            var6.field2742 = 0;
            var6.field2731 = 0;
            var6.field2744 = -1;
            var6.field2745 = 0;
            if (this.field2523[var1] == 0) {
               var6.field2748 = class104.method2035(var8, this.method4388(var6), this.method4389(var6), this.method4390(var6));
            } else {
               var6.field2748 = class104.method2035(var8, this.method4388(var6), 0, this.method4390(var6));
               this.method4375(var6, var9.field2780[var2] < 0);
            }

            if (var9.field2780[var2] < 0) {
               var6.field2748.method2037(-1);
            }

            if (var6.field2750 >= 0) {
               class222 var7 = this.field2538[var1][var6.field2750];
               if (var7 != null && var7.field2744 < 0) {
                  this.field2537[var1][var7.field2735] = null;
                  var7.field2744 = 0;
               }

               this.field2538[var1][var6.field2750] = var6;
            }

            this.field2545.field2754.addFirst(var6);
            this.field2537[var1][var2] = var6;
         }
      }
   }

   protected synchronized int vmethod4641() {
      return 0;
   }

   void method4363(int var1, int var2) {
   }

   protected synchronized TaskDataNode vmethod4630() {
      return null;
   }

   synchronized void method4366() {
      for(MusicPatch var1 = (MusicPatch)this.field2540.first(); var1 != null; var1 = (MusicPatch)this.field2540.next()) {
         var1.method4725();
      }

   }

   public int method4370() {
      return this.field2520;
   }

   void method4375(class222 var1, boolean var2) {
      int var3 = var1.field2732.field988.length;
      int var4;
      if (var2 && var1.field2732.field987) {
         int var5 = var3 + var3 - var1.field2732.field989;
         var4 = (int)((long)var5 * (long)this.field2523[var1.field2752] >> 6);
         var3 <<= 8;
         if (var4 >= var3) {
            var4 = var3 + var3 - 1 - var4;
            var1.field2748.method2044();
         }
      } else {
         var4 = (int)((long)var3 * (long)this.field2523[var1.field2752] >> 6);
      }

      var1.field2748.method2043(var4);
   }

   void method4373(int var1, int var2) {
      if (var2 != this.field2522[var1]) {
         this.field2522[var1] = var2;

         for(int var3 = 0; var3 < 128; ++var3) {
            this.field2538[var1][var3] = null;
         }
      }

   }

   void method4377(int var1, int var2, int var3) {
   }

   public synchronized void method4488() {
      this.field2539.method4722();
      this.method4383();
   }

   protected synchronized void vmethod4633(int var1) {
      if (this.field2539.method4669()) {
         int var2 = this.field2539.field2765 * this.field2521 / AbstractSoundSystem.field936;

         do {
            long var3 = this.field2543 + (long)var1 * (long)var2;
            if (this.field2544 - var3 >= 0L) {
               this.field2543 = var3;
               break;
            }

            int var5 = (int)((this.field2544 - this.field2543 + (long)var2 - 1L) / (long)var2);
            this.field2543 += (long)var2 * (long)var5;
            this.field2545.vmethod4633(var5);
            var1 -= var5;
            this.method4402();
         } while(this.field2539.method4669());
      }

      this.field2545.vmethod4633(var1);
   }

   void method4445(int var1, int var2, int var3) {
      class222 var4 = this.field2537[var1][var2];
      if (var4 != null) {
         this.field2537[var1][var2] = null;
         if ((this.field2531[var1] & 2) != 0) {
            for(class222 var5 = (class222)this.field2545.field2754.last(); var5 != null; var5 = (class222)this.field2545.field2754.previous()) {
               if (var4.field2752 == var5.field2752 && var5.field2744 < 0 && var4 != var5) {
                  var4.field2744 = 0;
                  break;
               }
            }
         } else {
            var4.field2744 = 0;
         }

      }
   }

   public static Clock method4490() {
      try {
         return new NanoClock();
      } catch (Throwable var1) {
         return new MilliClock();
      }
   }

   static void method4489() {
      for(ObjectSound var0 = (ObjectSound)ObjectSound.field577.last(); var0 != null; var0 = (ObjectSound)ObjectSound.field577.previous()) {
         if (var0.obj != null) {
            var0.method1084();
         }
      }

   }
}
