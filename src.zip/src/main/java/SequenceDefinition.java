public class SequenceDefinition extends DualNode {
   static EvictingDualNodeHashTable field3467 = new EvictingDualNodeHashTable(100);
   static AbstractIndexCache field3465;
   static AbstractIndexCache field3479;
   static EvictingDualNodeHashTable field3466 = new EvictingDualNodeHashTable(64);
   static AbstractIndexCache field3464;
   public int field3463 = 2;
   int[] frameIds2;
   public int field3475 = 5;
   public int field3480 = -1;
   public int field3470 = -1;
   public int frameCount = -1;
   public int shield = -1;
   public int[] frameIds;
   public boolean field3474 = false;
   public int[] field3468;
   int[] field3473;
   public int field3481 = 99;
   public int[] frameLengths;
   public int weapon = -1;

   void init() {
      if (this.field3470 == -1) {
         if (this.field3473 != null) {
            this.field3470 = 2;
         } else {
            this.field3470 = 0;
         }
      }

      if (this.field3480 == -1) {
         if (this.field3473 != null) {
            this.field3480 = 2;
         } else {
            this.field3480 = 0;
         }
      }

   }

   public Model animateSequence2(Model var1, int var2, SequenceDefinition var3, int var4) {
      var2 = this.frameIds[var2];
      Frames var5 = class95.method1800(var2 >> 16);
      var2 &= 65535;
      if (var5 == null) {
         return var3.animateSequence(var1, var4);
      } else {
         var4 = var3.frameIds[var4];
         Frames var6 = class95.method1800(var4 >> 16);
         var4 &= 65535;
         Model var7;
         if (var6 == null) {
            var7 = var1.toSharedSequenceModel(!var5.hasAlphaTransform(var2));
            var7.animate(var5, var2);
            return var7;
         } else {
            var7 = var1.toSharedSequenceModel(!var5.hasAlphaTransform(var2) & !var6.hasAlphaTransform(var4));
            var7.animate2(var5, var2, var6, var4, this.field3473);
            return var7;
         }
      }
   }

   void read(Buffer var1) {
      while(true) {
         int var2 = var1.readUnsignedByte();
         if (var2 == 0) {
            return;
         }

         this.readNext(var1, var2);
      }
   }

   public Model animateSequence(Model var1, int var2) {
      var2 = this.frameIds[var2];
      Frames var3 = class95.method1800(var2 >> 16);
      var2 &= 65535;
      if (var3 == null) {
         return var1.toSharedSequenceModel(true);
      } else {
         Model var4 = var1.toSharedSequenceModel(!var3.hasAlphaTransform(var2));
         var4.animate(var3, var2);
         return var4;
      }
   }

   public Model animateWidget(Model var1, int var2) {
      int var3 = this.frameIds[var2];
      Frames var4 = class95.method1800(var3 >> 16);
      var3 &= 65535;
      if (var4 == null) {
         return var1.toSharedSequenceModel(true);
      } else {
         Frames var5 = null;
         int var6 = 0;
         if (this.frameIds2 != null && var2 < this.frameIds2.length) {
            var6 = this.frameIds2[var2];
            var5 = class95.method1800(var6 >> 16);
            var6 &= 65535;
         }

         Model var7;
         if (var5 != null && var6 != 65535) {
            var7 = var1.toSharedSequenceModel(!var4.hasAlphaTransform(var3) & !var5.hasAlphaTransform(var6));
            var7.animate(var4, var3);
            var7.animate(var5, var6);
            return var7;
         } else {
            var7 = var1.toSharedSequenceModel(!var4.hasAlphaTransform(var3));
            var7.animate(var4, var3);
            return var7;
         }
      }
   }

   Model animateSpotAnimation(Model var1, int var2) {
      var2 = this.frameIds[var2];
      Frames var3 = class95.method1800(var2 >> 16);
      var2 &= 65535;
      if (var3 == null) {
         return var1.toSharedSpotAnimationModel(true);
      } else {
         Model var4 = var1.toSharedSpotAnimationModel(!var3.hasAlphaTransform(var2));
         var4.animate(var3, var2);
         return var4;
      }
   }

   Model animateObject(Model var1, int var2, int var3) {
      var2 = this.frameIds[var2];
      Frames var4 = class95.method1800(var2 >> 16);
      var2 &= 65535;
      if (var4 == null) {
         return var1.toSharedSequenceModel(true);
      } else {
         Model var5 = var1.toSharedSequenceModel(!var4.hasAlphaTransform(var2));
         var3 &= 3;
         if (var3 == 1) {
            var5.rotateY270Ccw();
         } else if (var3 == 2) {
            var5.rotateY180();
         } else if (var3 == 3) {
            var5.rotateY90Ccw();
         }

         var5.animate(var4, var2);
         if (var3 == 1) {
            var5.rotateY90Ccw();
         } else if (var3 == 2) {
            var5.rotateY180();
         } else if (var3 == 3) {
            var5.rotateY270Ccw();
         }

         return var5;
      }
   }

   void readNext(Buffer var1, int var2) {
      int var3;
      int var4;
      if (var2 == 1) {
         var3 = var1.method3913();
         this.frameLengths = new int[var3];

         for(var4 = 0; var4 < var3; ++var4) {
            this.frameLengths[var4] = var1.method3913();
         }

         this.frameIds = new int[var3];

         for(var4 = 0; var4 < var3; ++var4) {
            this.frameIds[var4] = var1.method3913();
         }

         for(var4 = 0; var4 < var3; ++var4) {
            this.frameIds[var4] += var1.method3913() << 16;
         }
      } else if (var2 == 2) {
         this.frameCount = var1.method3913();
      } else if (var2 == 3) {
         var3 = var1.readUnsignedByte();
         this.field3473 = new int[var3 + 1];

         for(var4 = 0; var4 < var3; ++var4) {
            this.field3473[var4] = var1.readUnsignedByte();
         }

         this.field3473[var3] = 9999999;
      } else if (var2 == 4) {
         this.field3474 = true;
      } else if (var2 == 5) {
         this.field3475 = var1.readUnsignedByte();
      } else if (var2 == 6) {
         this.shield = var1.method3913();
      } else if (var2 == 7) {
         this.weapon = var1.method3913();
      } else if (var2 == 8) {
         this.field3481 = var1.readUnsignedByte();
      } else if (var2 == 9) {
         this.field3470 = var1.readUnsignedByte();
      } else if (var2 == 10) {
         this.field3480 = var1.readUnsignedByte();
      } else if (var2 == 11) {
         this.field3463 = var1.readUnsignedByte();
      } else if (var2 == 12) {
         var3 = var1.readUnsignedByte();
         this.frameIds2 = new int[var3];

         for(var4 = 0; var4 < var3; ++var4) {
            this.frameIds2[var4] = var1.method3913();
         }

         for(var4 = 0; var4 < var3; ++var4) {
            this.frameIds2[var4] += var1.method3913() << 16;
         }
      } else if (var2 == 13) {
         var3 = var1.readUnsignedByte();
         this.field3468 = new int[var3];

         for(var4 = 0; var4 < var3; ++var4) {
            this.field3468[var4] = var1.readMedium();
         }
      }

   }

   static int method5264(int var0, Script var1, boolean var2) {
      if (var0 == 3200) {
         class31.field364 -= 3;
         class17.method467(Interpreter.field467[class31.field364], Interpreter.field467[class31.field364 + 1], Interpreter.field467[class31.field364 + 2]);
         return 1;
      } else if (var0 == 3201) {
         ObjectSound.method1093(Interpreter.field467[--class31.field364]);
         return 1;
      } else if (var0 == 3202) {
         class31.field364 -= 2;
         class257.method5062(Interpreter.field467[class31.field364], Interpreter.field467[class31.field364 + 1]);
         return 1;
      } else {
         return 2;
      }
   }

   static void method5247(int var0, int var1) {
      PacketBufferNode var2 = FaceNormal.method2884(ClientPacket.field1836, Client.field2133.isaacCipher);
      var2.packetBuffer.writeIntLE16(var0);
      var2.packetBuffer.method4029(var1);
      Client.field2133.method1281(var2);
   }
}
