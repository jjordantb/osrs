public class class192 {
   static long field2437;
   static long field2436;
   static Sprite[] field2438;

   public static boolean method3891(int var0) {
      return (var0 >> 20 & 1) != 0;
   }

   public static void method3889() {
      SpotAnimationDefinition.field3664.clear();
      SpotAnimationDefinition.field3665.clear();
   }
}
