public class SpriteIds {
   public int mapMarkers = -1;
   public int headIconsPrayer = -1;
   public int mapScenes = -1;
   public int field3776 = -1;
   public int scrollBars = -1;
   public int headIconsHint = -1;
   public int mapDots = -1;
   public int modIcons = -1;
   public int headIconsPk = -1;
   public int field3777 = -1;
   public int crosses = -1;

   public void read(AbstractIndexCache var1) {
      byte[] var2 = var1.takeRecordFlat(class302.field3764.field3763);
      Buffer var3 = new Buffer(var2);

      while(true) {
         int var4 = var3.readUnsignedByte();
         if (var4 == 0) {
            return;
         }

         switch(var4) {
         case 1:
            var3.readMedium();
            break;
         case 2:
            this.field3776 = var3.method4040();
            this.field3777 = var3.method4040();
            this.mapScenes = var3.method4040();
            this.headIconsPk = var3.method4040();
            this.headIconsPrayer = var3.method4040();
            this.headIconsHint = var3.method4040();
            this.mapMarkers = var3.method4040();
            this.crosses = var3.method4040();
            this.mapDots = var3.method4040();
            this.scrollBars = var3.method4040();
            this.modIcons = var3.method4040();
         }
      }
   }

   public static IndexedSprite[] method5817() {
      IndexedSprite[] var0 = new IndexedSprite[class328.field3985];

      for(int var1 = 0; var1 < class328.field3985; ++var1) {
         IndexedSprite var2 = var0[var1] = new IndexedSprite();
         var2.width = class328.field3983;
         var2.height = class328.field3988;
         var2.xOffset = class328.field3982[var1];
         var2.yOffset = class328.field3984[var1];
         var2.subWidth = class328.field3987[var1];
         var2.subHeight = VarcInt.field2811[var1];
         var2.palette = class328.field3986;
         var2.pixels = class328.field3989[var1];
      }

      class328.field3982 = null;
      class328.field3984 = null;
      class328.field3987 = null;
      VarcInt.field2811 = null;
      class328.field3986 = null;
      class328.field3989 = null;
      return var0;
   }
}
