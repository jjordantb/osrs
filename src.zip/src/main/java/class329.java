public class class329 implements Enumerated {
   static final class329 field3992 = new class329(3, 4);
   static final class329 field3993 = new class329(0, 2);
   public static final class329 field3995 = new class329(1, 0);
   static final class329 field3994 = new class329(4, 3);
   static final class329 field3991 = new class329(2, 1);
   final int field3997;
   final int field3996;

   class329(int var1, int var2) {
      this.field3996 = var1;
      this.field3997 = var2;
   }

   public int ordinal() {
      return this.field3997;
   }
}
